import {
  AddressSaveFormComponent
} from "./chunk-6WHLQ2Z5.js";
import {
  LocationService
} from "./chunk-4TQR4WSH.js";
import "./chunk-V444GY6B.js";
import "./chunk-QH3WR2OQ.js";
import {
  AppDialogService
} from "./chunk-W37RSO62.js";
import {
  AuthService
} from "./chunk-EB6T6TPT.js";
import "./chunk-YJYUHAOC.js";
import "./chunk-OE5MTPUR.js";
import {
  addIcons,
  addOutline,
  arrowBackOutline,
  briefcaseOutline,
  checkmarkCircle,
  createOutline,
  ellipseOutline,
  homeOutline,
  locationOutline,
  mapOutline,
  navigateOutline,
  shieldCheckmarkOutline,
  star,
  starOutline,
  trashOutline
} from "./chunk-FJYXZAS7.js";
import {
  IonButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonIcon,
  IonSkeletonText,
  IonTitle,
  IonToast,
  IonToolbar
} from "./chunk-CJE2NDTY.js";
import {
  CommonModule,
  EventEmitter,
  FormsModule,
  LowerCasePipe,
  NavController,
  SlicePipe,
  UpperCasePipe,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵloadQuery,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind1,
  ɵɵpipeBind3,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵpureFunction2,
  ɵɵqueryRefresh,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIdentity,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵviewQuery
} from "./chunk-Z7XNNJSA.js";
import "./chunk-XR3JUECC.js";
import "./chunk-FH4NU4VH.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async,
  __spreadProps,
  __spreadValues
} from "./chunk-6B6DTIB5.js";

// src/app/components/saved-addresses/saved-addresses.component.ts
var _c0 = () => [1, 2, 3];
var _c1 = (a0, a1) => ({ lat: a0, lng: a1 });
var _forTrack0 = ($index, $item) => $item.id || $index;
function SavedAddressesComponent_Conditional_1_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 6)(1, "div", 7);
    \u0275\u0275element(2, "ion-skeleton-text", 8)(3, "ion-skeleton-text", 9);
    \u0275\u0275elementEnd();
    \u0275\u0275element(4, "ion-skeleton-text", 10)(5, "ion-skeleton-text", 11)(6, "ion-skeleton-text", 12);
    \u0275\u0275elementEnd();
  }
}
function SavedAddressesComponent_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 1);
    \u0275\u0275repeaterCreate(1, SavedAddressesComponent_Conditional_1_For_2_Template, 7, 0, "div", 6, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance();
    \u0275\u0275repeater(\u0275\u0275pureFunction0(0, _c0));
  }
}
function SavedAddressesComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 2)(1, "div", 13);
    \u0275\u0275element(2, "ion-icon", 14);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "h3", 15);
    \u0275\u0275text(4, "No Saved Addresses");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p", 16);
    \u0275\u0275text(6, " You haven't added any delivery addresses yet. Choose your location on the map to get started. ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "button", 17);
    \u0275\u0275listener("click", function SavedAddressesComponent_Conditional_2_Template_button_click_7_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.openMap());
    });
    \u0275\u0275element(8, "ion-icon", 14);
    \u0275\u0275elementStart(9, "span");
    \u0275\u0275text(10, "Select on Map");
    \u0275\u0275elementEnd()()();
  }
}
function SavedAddressesComponent_Conditional_3_For_8_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 30);
    \u0275\u0275element(1, "ion-icon", 44);
    \u0275\u0275elementEnd();
  }
}
function SavedAddressesComponent_Conditional_3_For_8_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 45);
    \u0275\u0275listener("click", function SavedAddressesComponent_Conditional_3_For_8_Conditional_10_Template_button_click_0_listener($event) {
      \u0275\u0275restoreView(_r6);
      const item_r5 = \u0275\u0275nextContext().$implicit;
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.setAsPrimary(item_r5, $event));
    });
    \u0275\u0275element(1, "ion-icon", 46);
    \u0275\u0275elementEnd();
  }
}
function SavedAddressesComponent_Conditional_3_For_8_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 33);
    \u0275\u0275element(1, "ion-icon", 47);
    \u0275\u0275elementEnd();
  }
}
function SavedAddressesComponent_Conditional_3_For_8_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const item_r5 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(item_r5.house_no);
  }
}
function SavedAddressesComponent_Conditional_3_For_8_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const item_r5 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate2("", item_r5.house_no ? ", " : "", "", item_r5.building_name, "");
  }
}
function SavedAddressesComponent_Conditional_3_For_8_Conditional_21_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1);
    \u0275\u0275pipe(2, "slice");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const item_r5 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(item_r5.landmark || \u0275\u0275pipeBind3(2, 1, item_r5.address, 0, 30));
  }
}
function SavedAddressesComponent_Conditional_3_For_8_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 41);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const item_r5 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("Near ", item_r5.landmark, ", ");
  }
}
function SavedAddressesComponent_Conditional_3_For_8_Conditional_26_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 49);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const item_r5 = \u0275\u0275nextContext(2).$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(item_r5.receiver_name);
  }
}
function SavedAddressesComponent_Conditional_3_For_8_Conditional_26_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 50);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const item_r5 = \u0275\u0275nextContext(2).$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("(", item_r5.receiver_contact, ")");
  }
}
function SavedAddressesComponent_Conditional_3_For_8_Conditional_26_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 42)(1, "span", 48);
    \u0275\u0275text(2, "Contact:");
    \u0275\u0275elementEnd();
    \u0275\u0275template(3, SavedAddressesComponent_Conditional_3_For_8_Conditional_26_Conditional_3_Template, 2, 1, "span", 49)(4, SavedAddressesComponent_Conditional_3_For_8_Conditional_26_Conditional_4_Template, 2, 1, "span", 50);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const item_r5 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance(3);
    \u0275\u0275conditional(item_r5.receiver_name ? 3 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(item_r5.receiver_contact ? 4 : -1);
  }
}
function SavedAddressesComponent_Conditional_3_For_8_Conditional_27_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "div", 43);
  }
}
function SavedAddressesComponent_Conditional_3_For_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 25);
    \u0275\u0275listener("click", function SavedAddressesComponent_Conditional_3_For_8_Template_div_click_0_listener() {
      const item_r5 = \u0275\u0275restoreView(_r4).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.selectAddress(item_r5));
    });
    \u0275\u0275elementStart(1, "div", 26)(2, "div", 27)(3, "div", 28);
    \u0275\u0275pipe(4, "lowercase");
    \u0275\u0275element(5, "ion-icon", 29);
    \u0275\u0275elementStart(6, "span");
    \u0275\u0275text(7);
    \u0275\u0275pipe(8, "uppercase");
    \u0275\u0275elementEnd()();
    \u0275\u0275template(9, SavedAddressesComponent_Conditional_3_For_8_Conditional_9_Template, 2, 0, "span", 30)(10, SavedAddressesComponent_Conditional_3_For_8_Conditional_10_Template, 2, 0, "button", 31);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "div", 32);
    \u0275\u0275template(12, SavedAddressesComponent_Conditional_3_For_8_Conditional_12_Template, 2, 0, "span", 33);
    \u0275\u0275elementStart(13, "button", 34);
    \u0275\u0275listener("click", function SavedAddressesComponent_Conditional_3_For_8_Template_button_click_13_listener($event) {
      const item_r5 = \u0275\u0275restoreView(_r4).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.openEditAddress(item_r5, $event));
    });
    \u0275\u0275element(14, "ion-icon", 35);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "button", 36);
    \u0275\u0275listener("click", function SavedAddressesComponent_Conditional_3_For_8_Template_button_click_15_listener($event) {
      const item_r5 = \u0275\u0275restoreView(_r4).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.confirmDeleteAddress(item_r5, $event));
    });
    \u0275\u0275element(16, "ion-icon", 37);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(17, "div", 38)(18, "h4", 39);
    \u0275\u0275template(19, SavedAddressesComponent_Conditional_3_For_8_Conditional_19_Template, 2, 1, "span")(20, SavedAddressesComponent_Conditional_3_For_8_Conditional_20_Template, 2, 2, "span")(21, SavedAddressesComponent_Conditional_3_For_8_Conditional_21_Template, 3, 5, "span");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(22, "p", 40);
    \u0275\u0275template(23, SavedAddressesComponent_Conditional_3_For_8_Conditional_23_Template, 2, 1, "span", 41);
    \u0275\u0275elementStart(24, "span");
    \u0275\u0275text(25);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(26, SavedAddressesComponent_Conditional_3_For_8_Conditional_26_Template, 5, 2, "div", 42);
    \u0275\u0275elementEnd();
    \u0275\u0275template(27, SavedAddressesComponent_Conditional_3_For_8_Conditional_27_Template, 1, 0, "div", 43);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const item_r5 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275classProp("is-active", item_r5.id === ctx_r1.activeAddressId);
    \u0275\u0275advance(3);
    \u0275\u0275attribute("data-label", \u0275\u0275pipeBind1(4, 14, item_r5.label || "other"));
    \u0275\u0275advance(2);
    \u0275\u0275property("name", ctx_r1.getLabelIcon(item_r5.label));
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(8, 16, item_r5.label || "Other"));
    \u0275\u0275advance(2);
    \u0275\u0275conditional(item_r5.is_primary ? 9 : 10);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(item_r5.id === ctx_r1.activeAddressId ? 12 : -1);
    \u0275\u0275advance(7);
    \u0275\u0275conditional(item_r5.house_no ? 19 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(item_r5.building_name ? 20 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(!item_r5.house_no && !item_r5.building_name ? 21 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(item_r5.landmark ? 23 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(item_r5.address);
    \u0275\u0275advance();
    \u0275\u0275conditional(item_r5.receiver_name || item_r5.receiver_contact ? 26 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(item_r5.id === ctx_r1.activeAddressId ? 27 : -1);
  }
}
function SavedAddressesComponent_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 3)(1, "div", 18)(2, "span", 19);
    \u0275\u0275text(3, "SAVED DELIVERY ADDRESSES");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "span", 20);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "div", 21);
    \u0275\u0275repeaterCreate(7, SavedAddressesComponent_Conditional_3_For_8_Template, 28, 18, "div", 22, _forTrack0);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "div", 23)(10, "button", 24);
    \u0275\u0275listener("click", function SavedAddressesComponent_Conditional_3_Template_button_click_10_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.openMap());
    });
    \u0275\u0275element(11, "ion-icon", 14);
    \u0275\u0275elementStart(12, "span");
    \u0275\u0275text(13, "Select on map");
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r1.addresses.length);
    \u0275\u0275advance(2);
    \u0275\u0275repeater(ctx_r1.addresses);
  }
}
function SavedAddressesComponent_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 51);
    \u0275\u0275listener("click", function SavedAddressesComponent_Conditional_4_Template_div_click_0_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.closeEditModal());
    });
    \u0275\u0275elementStart(1, "div", 52);
    \u0275\u0275listener("click", function SavedAddressesComponent_Conditional_4_Template_div_click_1_listener($event) {
      \u0275\u0275restoreView(_r7);
      return \u0275\u0275resetView($event.stopPropagation());
    });
    \u0275\u0275elementStart(2, "app-address-save-form", 53);
    \u0275\u0275listener("addressSaved", function SavedAddressesComponent_Conditional_4_Template_app_address_save_form_addressSaved_2_listener($event) {
      \u0275\u0275restoreView(_r7);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.onAddressUpdated($event));
    })("cancel", function SavedAddressesComponent_Conditional_4_Template_app_address_save_form_cancel_2_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.closeEditModal());
    });
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(2);
    \u0275\u0275property("editAddress", ctx_r1.editingAddress)("initialCoords", \u0275\u0275pureFunction2(3, _c1, ctx_r1.editingAddress.lat || 12.8556, ctx_r1.editingAddress.lng || 77.6818))("initialAddress", ctx_r1.editingAddress.address || "");
  }
}
var _SavedAddressesComponent = class _SavedAddressesComponent {
  constructor(navCtrl, authService, locationService, dialogService) {
    this.navCtrl = navCtrl;
    this.authService = authService;
    this.locationService = locationService;
    this.dialogService = dialogService;
    this.routeSource = "home";
    this.autoNavigateBackOnSelect = true;
    this.addressSelected = new EventEmitter();
    this.selectOnMap = new EventEmitter();
    this.addresses = [];
    this.activeAddressId = null;
    this.isLoading = true;
    this.token = "";
    this.isToastOpen = false;
    this.toastMessage = "";
    this.isEditModalOpen = false;
    this.editingAddress = null;
    addIcons({
      homeOutline,
      briefcaseOutline,
      locationOutline,
      checkmarkCircle,
      ellipseOutline,
      trashOutline,
      mapOutline,
      addOutline,
      navigateOutline,
      shieldCheckmarkOutline,
      createOutline,
      star,
      starOutline
    });
  }
  ngOnInit() {
    return __async(this, null, function* () {
      this.token = (yield this.authService.getToken()) || "";
      this.locationService.location$.subscribe((loc) => {
        if (loc == null ? void 0 : loc.id) {
          this.activeAddressId = loc.id;
        }
      });
      const saved = localStorage.getItem("location");
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (parsed == null ? void 0 : parsed.id) {
            this.activeAddressId = parsed.id;
          }
        } catch (e) {
        }
      }
      this.loadAddresses();
    });
  }
  loadAddresses(showLoader = true) {
    if (showLoader) {
      this.isLoading = true;
    }
    if (!this.token) {
      this.addresses = [];
      this.isLoading = false;
      return;
    }
    this.locationService.getAddressesList(this.token).subscribe({
      next: (res) => {
        this.addresses = Array.isArray(res == null ? void 0 : res.data) ? res.data : [];
        this.isLoading = false;
        if (!this.activeAddressId && this.addresses.length > 0) {
          const primary = this.addresses.find((a) => a.is_primary);
          if (primary) {
            this.activeAddressId = primary.id;
          }
        }
      },
      error: () => {
        this.addresses = [];
        this.isLoading = false;
      }
    });
  }
  selectAddress(item) {
    var _a;
    const wasAlreadyPrimary = Boolean(item.is_primary);
    const data = {
      lat: item.lat,
      lng: item.lng,
      id: item.id,
      label: item.label,
      address: item.address,
      area: ((_a = item.address) == null ? void 0 : _a.split(",")[0]) || "Athani",
      house_no: item.house_no,
      building_name: item.building_name,
      landmark: item.landmark,
      receiver_name: item.receiver_name,
      receiver_contact: item.receiver_contact,
      is_primary: true
    };
    this.activeAddressId = item.id;
    this.locationService.setAddress(data, this.token);
    localStorage.setItem("location", JSON.stringify(data));
    if (item == null ? void 0 : item.id) {
      item.is_primary = true;
      this.addresses = this.addresses.map((a) => __spreadProps(__spreadValues({}, a), {
        is_primary: a.id === item.id
      }));
      if (this.token && !wasAlreadyPrimary) {
        this.locationService.setPrimaryAddress(item.id, this.token).subscribe({
          next: () => {
            console.log(`\u2705 Address #${item.id} marked as primary on selection`);
          },
          error: (err) => {
            console.warn("Could not mark selected address as primary:", err);
          }
        });
      }
    }
    this.addressSelected.emit(item);
    if (this.autoNavigateBackOnSelect && this.routeSource && this.routeSource !== "profile") {
      this.navCtrl.back();
    }
  }
  setAsPrimary(item, event) {
    if (event) {
      event.stopPropagation();
    }
    if (!(item == null ? void 0 : item.id) || !this.token)
      return;
    this.locationService.setPrimaryAddress(item.id, this.token).subscribe({
      next: () => {
        this.showToast("Default delivery address updated");
        this.addresses = this.addresses.map((a) => __spreadProps(__spreadValues({}, a), {
          is_primary: a.id === item.id
        }));
        this.selectAddress(item);
      },
      error: (err) => {
        var _a;
        this.showToast(((_a = err == null ? void 0 : err.error) == null ? void 0 : _a.message) || "Failed to set default address");
      }
    });
  }
  openEditAddress(item, event) {
    if (event) {
      event.stopPropagation();
    }
    this.editingAddress = __spreadValues({}, item);
    this.isEditModalOpen = true;
  }
  closeEditModal() {
    this.isEditModalOpen = false;
    this.editingAddress = null;
  }
  onAddressUpdated(updatedAddr) {
    this.closeEditModal();
    this.showToast("Address updated successfully");
    this.loadAddresses(false);
    if (this.activeAddressId === (updatedAddr == null ? void 0 : updatedAddr.id)) {
      const locData = {
        lat: updatedAddr.lat,
        lng: updatedAddr.lng,
        id: updatedAddr.id,
        label: updatedAddr.label,
        address: updatedAddr.address,
        area: (updatedAddr.address || "").split(",")[0] || "Athani"
      };
      this.locationService.setAddress(locData);
    }
  }
  confirmDeleteAddress(item, event) {
    return __async(this, null, function* () {
      if (event) {
        event.stopPropagation();
      }
      if (!(item == null ? void 0 : item.id))
        return;
      const displayAddr = item.house_no ? `${item.house_no}, ${item.address}` : item.address;
      const confirmed = yield this.dialogService.showDangerConfirm({
        title: "Delete Address?",
        message: `Are you sure you want to delete this address:
"${displayAddr}"?
This action cannot be undone.`,
        confirmText: "Yes, Delete",
        cancelText: "Cancel"
      });
      if (confirmed) {
        this.deleteAddress(item.id);
      }
    });
  }
  deleteAddress(id) {
    if (!id || !this.token)
      return;
    this.locationService.deleteAddress(this.token, id).subscribe({
      next: () => {
        this.showToast("Address deleted successfully");
        this.addresses = this.addresses.filter((a) => a.id !== id);
        if (this.activeAddressId === id) {
          this.activeAddressId = null;
        }
      },
      error: () => {
        this.showToast("Failed to delete address");
      }
    });
  }
  openMap() {
    this.selectOnMap.emit();
    this.navCtrl.navigateForward("/layout/map", {
      state: { data: this.routeSource || "home" }
    });
  }
  showToast(msg) {
    this.toastMessage = msg;
    this.isToastOpen = true;
  }
  getLabelIcon(label) {
    const l = (label || "").toLowerCase();
    if (l === "home")
      return "home-outline";
    if (l === "work")
      return "briefcase-outline";
    return "location-outline";
  }
};
_SavedAddressesComponent.\u0275fac = function SavedAddressesComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _SavedAddressesComponent)(\u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(AuthService), \u0275\u0275directiveInject(LocationService), \u0275\u0275directiveInject(AppDialogService));
};
_SavedAddressesComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _SavedAddressesComponent, selectors: [["app-saved-addresses"]], inputs: { routeSource: "routeSource", autoNavigateBackOnSelect: "autoNavigateBackOnSelect" }, outputs: { addressSelected: "addressSelected", selectOnMap: "selectOnMap" }, decls: 6, vars: 5, consts: [[1, "saved-addresses-container"], [1, "skeleton-wrapper"], [1, "empty-state-wrapper"], [1, "address-content-wrapper"], [1, "edit-modal-backdrop", "animate__animated", "animate__fadeIn"], [3, "didDismiss", "isOpen", "message", "duration"], [1, "address-skeleton-card"], [1, "skel-top-row"], ["animated", "", 2, "width", "70px", "height", "24px", "border-radius", "6px"], ["animated", "", 2, "width", "24px", "height", "24px", "border-radius", "50%"], ["animated", "", 2, "width", "60%", "height", "16px", "border-radius", "4px", "margin", "10px 0 6px"], ["animated", "", 2, "width", "90%", "height", "14px", "border-radius", "4px", "margin-bottom", "6px"], ["animated", "", 2, "width", "40%", "height", "14px", "border-radius", "4px"], [1, "empty-icon-circle"], ["name", "map-outline"], [1, "empty-title"], [1, "empty-subtitle"], ["type", "button", 1, "btn-select-map-primary", 3, "click"], [1, "section-badge-row"], [1, "section-label"], [1, "badge-count"], [1, "address-cards-list"], ["role", "button", "tabindex", "0", 1, "address-card", 3, "is-active"], [1, "map-action-footer"], ["type", "button", 1, "btn-select-map", 3, "click"], ["role", "button", "tabindex", "0", 1, "address-card", 3, "click"], [1, "card-top-row"], [1, "labels-cluster"], [1, "address-label-chip"], [3, "name"], ["title", "Default Delivery Address", 1, "star-indicator", "is-primary"], ["type", "button", "title", "Set as Default Delivery Address", "aria-label", "Set as default address", 1, "star-indicator", "not-primary"], [1, "card-actions"], ["title", "Selected Address", 1, "selected-check-icon"], ["type", "button", "title", "Edit Address", "aria-label", "Edit Address", 1, "btn-action-icon", "btn-edit", 3, "click"], ["name", "create-outline"], ["type", "button", "title", "Delete Address", "aria-label", "Delete Address", 1, "btn-action-icon", "btn-delete", 3, "click"], ["name", "trash-outline"], [1, "card-body"], [1, "address-name"], [1, "full-address-text"], [1, "landmark-text"], [1, "receiver-pill"], [1, "active-accent-bar"], ["name", "star"], ["type", "button", "title", "Set as Default Delivery Address", "aria-label", "Set as default address", 1, "star-indicator", "not-primary", 3, "click"], ["name", "star-outline"], ["name", "checkmark-circle"], [1, "rec-label"], [1, "rec-name"], [1, "rec-phone"], [1, "edit-modal-backdrop", "animate__animated", "animate__fadeIn", 3, "click"], [1, "edit-modal-sheet", "animate__animated", "animate__slideInUp", 3, "click"], [3, "addressSaved", "cancel", "editAddress", "initialCoords", "initialAddress"]], template: function SavedAddressesComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 0);
    \u0275\u0275template(1, SavedAddressesComponent_Conditional_1_Template, 3, 1, "div", 1)(2, SavedAddressesComponent_Conditional_2_Template, 11, 0, "div", 2)(3, SavedAddressesComponent_Conditional_3_Template, 14, 1, "div", 3)(4, SavedAddressesComponent_Conditional_4_Template, 3, 6, "div", 4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "ion-toast", 5);
    \u0275\u0275listener("didDismiss", function SavedAddressesComponent_Template_ion_toast_didDismiss_5_listener() {
      return ctx.isToastOpen = false;
    });
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.isLoading ? 1 : ctx.addresses.length === 0 ? 2 : 3);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx.isEditModalOpen && ctx.editingAddress ? 4 : -1);
    \u0275\u0275advance();
    \u0275\u0275property("isOpen", ctx.isToastOpen)("message", ctx.toastMessage)("duration", 2500);
  }
}, dependencies: [
  CommonModule,
  UpperCasePipe,
  LowerCasePipe,
  SlicePipe,
  FormsModule,
  IonIcon,
  IonSkeletonText,
  IonToast,
  AddressSaveFormComponent
], styles: ["\n\n[_nghost-%COMP%] {\n  display: block;\n  width: 100%;\n}\n.saved-addresses-container[_ngcontent-%COMP%] {\n  padding: 16px;\n  max-width: 600px;\n  margin: 0 auto;\n  min-height: 100%;\n  display: flex;\n  flex-direction: column;\n}\n.skeleton-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n}\n.address-skeleton-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 16px;\n  padding: 16px;\n  border: 1px solid #e2e8f0;\n  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);\n}\n.address-skeleton-card[_ngcontent-%COMP%]   .skel-top-row[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n.empty-state-wrapper[_ngcontent-%COMP%] {\n  flex: 1;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  text-align: center;\n  padding: 48px 24px;\n  min-height: 55vh;\n}\n.empty-state-wrapper[_ngcontent-%COMP%]   .empty-icon-circle[_ngcontent-%COMP%] {\n  width: 80px;\n  height: 80px;\n  border-radius: 50%;\n  background:\n    linear-gradient(\n      135deg,\n      rgba(160, 0, 226, 0.1) 0%,\n      rgba(99, 102, 241, 0.1) 100%);\n  border: 2px dashed rgba(160, 0, 226, 0.3);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin-bottom: 20px;\n}\n.empty-state-wrapper[_ngcontent-%COMP%]   .empty-icon-circle[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 38px;\n  color: #a000e2;\n}\n.empty-state-wrapper[_ngcontent-%COMP%]   .empty-title[_ngcontent-%COMP%] {\n  font-size: 1.25rem;\n  font-weight: 700;\n  color: #0f172a;\n  margin: 0 0 8px 0;\n}\n.empty-state-wrapper[_ngcontent-%COMP%]   .empty-subtitle[_ngcontent-%COMP%] {\n  font-size: 0.88rem;\n  color: #64748b;\n  line-height: 1.45;\n  max-width: 280px;\n  margin: 0 0 28px 0;\n}\n.empty-state-wrapper[_ngcontent-%COMP%]   .btn-select-map-primary[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  gap: 8px;\n  width: 100%;\n  max-width: 280px;\n  height: 48px;\n  background:\n    linear-gradient(\n      135deg,\n      #a000e2 0%,\n      #7c00b3 100%);\n  color: #ffffff;\n  font-size: 0.95rem;\n  font-weight: 700;\n  border: none;\n  border-radius: 12px;\n  cursor: pointer;\n  box-shadow: 0 4px 14px rgba(160, 0, 226, 0.35);\n  transition: transform 0.15s ease, box-shadow 0.15s ease;\n}\n.empty-state-wrapper[_ngcontent-%COMP%]   .btn-select-map-primary[_ngcontent-%COMP%]:active {\n  transform: scale(0.98);\n  box-shadow: 0 2px 8px rgba(160, 0, 226, 0.25);\n}\n.empty-state-wrapper[_ngcontent-%COMP%]   .btn-select-map-primary[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 20px;\n}\n.address-content-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n  padding-bottom: 84px;\n}\n.section-badge-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 4px 2px 8px;\n}\n.section-badge-row[_ngcontent-%COMP%]   .section-label[_ngcontent-%COMP%] {\n  font-size: 0.72rem;\n  font-weight: 800;\n  letter-spacing: 0.8px;\n  color: #64748b;\n}\n.section-badge-row[_ngcontent-%COMP%]   .badge-count[_ngcontent-%COMP%] {\n  font-size: 0.72rem;\n  font-weight: 700;\n  background: #f1f5f9;\n  color: #475569;\n  padding: 2px 8px;\n  border-radius: 10px;\n}\n.address-cards-list[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n}\n.address-card[_ngcontent-%COMP%] {\n  position: relative;\n  background: #ffffff;\n  border-radius: 16px;\n  padding: 16px;\n  border: 1.5px solid #e2e8f0;\n  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04);\n  cursor: pointer;\n  overflow: hidden;\n  transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);\n}\n.address-card[_ngcontent-%COMP%]:active {\n  transform: scale(0.99);\n}\n.address-card.is-active[_ngcontent-%COMP%] {\n  border-color: #a000e2;\n  background:\n    linear-gradient(\n      to bottom,\n      rgba(160, 0, 226, 0.02) 0%,\n      #ffffff 100%);\n  box-shadow: 0 4px 16px rgba(160, 0, 226, 0.12);\n}\n.address-card.is-active[_ngcontent-%COMP%]   .active-accent-bar[_ngcontent-%COMP%] {\n  position: absolute;\n  left: 0;\n  top: 0;\n  bottom: 0;\n  width: 4px;\n  background:\n    linear-gradient(\n      to bottom,\n      #a000e2,\n      #c026d3);\n  border-radius: 4px 0 0 4px;\n}\n.address-card[_ngcontent-%COMP%]   .card-top-row[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 10px;\n  gap: 8px;\n}\n.address-card[_ngcontent-%COMP%]   .labels-cluster[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  flex-wrap: wrap;\n}\n.address-card[_ngcontent-%COMP%]   .address-label-chip[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  font-size: 0.72rem;\n  font-weight: 800;\n  letter-spacing: 0.5px;\n  padding: 4px 10px;\n  border-radius: 8px;\n  background: #f1f5f9;\n  color: #475569;\n}\n.address-card[_ngcontent-%COMP%]   .address-label-chip[data-label=home][_ngcontent-%COMP%] {\n  background: rgba(16, 185, 129, 0.12);\n  color: #059669;\n}\n.address-card[_ngcontent-%COMP%]   .address-label-chip[data-label=work][_ngcontent-%COMP%] {\n  background: rgba(59, 130, 246, 0.12);\n  color: #2563eb;\n}\n.address-card[_ngcontent-%COMP%]   .address-label-chip[data-label=other][_ngcontent-%COMP%] {\n  background: rgba(160, 0, 226, 0.1);\n  color: #a000e2;\n}\n.address-card[_ngcontent-%COMP%]   .address-label-chip[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n}\n.address-card[_ngcontent-%COMP%]   .star-indicator[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  background: transparent;\n  border: none;\n  padding: 2px 4px;\n  line-height: 1;\n}\n.address-card[_ngcontent-%COMP%]   .star-indicator.is-primary[_ngcontent-%COMP%] {\n  color: #eab308;\n  filter: drop-shadow(0 1px 2px rgba(234, 179, 8, 0.35));\n}\n.address-card[_ngcontent-%COMP%]   .star-indicator.is-primary[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n}\n.address-card[_ngcontent-%COMP%]   .star-indicator.not-primary[_ngcontent-%COMP%] {\n  color: #94a3b8;\n  cursor: pointer;\n  border-radius: 6px;\n  transition: all 0.15s ease;\n}\n.address-card[_ngcontent-%COMP%]   .star-indicator.not-primary[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n}\n.address-card[_ngcontent-%COMP%]   .star-indicator.not-primary[_ngcontent-%COMP%]:hover {\n  color: #eab308;\n  transform: scale(1.15);\n}\n.address-card[_ngcontent-%COMP%]   .star-indicator.not-primary[_ngcontent-%COMP%]:active {\n  transform: scale(0.9);\n}\n.address-card[_ngcontent-%COMP%]   .card-actions[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.address-card[_ngcontent-%COMP%]   .card-actions[_ngcontent-%COMP%]   .selected-check-icon[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  color: #10b981;\n  line-height: 1;\n  filter: drop-shadow(0 1px 2px rgba(16, 185, 129, 0.25));\n}\n.address-card[_ngcontent-%COMP%]   .card-actions[_ngcontent-%COMP%]   .selected-check-icon[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 20px;\n}\n.address-card[_ngcontent-%COMP%]   .card-actions[_ngcontent-%COMP%]   .btn-action-icon[_ngcontent-%COMP%] {\n  width: 32px;\n  height: 32px;\n  border-radius: 8px;\n  border: none;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 16px;\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n.address-card[_ngcontent-%COMP%]   .card-actions[_ngcontent-%COMP%]   .btn-action-icon.btn-edit[_ngcontent-%COMP%] {\n  background: #f3e8ff;\n  color: var(--app-theme-color, #a000e2);\n}\n.address-card[_ngcontent-%COMP%]   .card-actions[_ngcontent-%COMP%]   .btn-action-icon.btn-edit[_ngcontent-%COMP%]:hover {\n  background: #e9d5ff;\n}\n.address-card[_ngcontent-%COMP%]   .card-actions[_ngcontent-%COMP%]   .btn-action-icon.btn-edit[_ngcontent-%COMP%]:active {\n  transform: scale(0.92);\n}\n.address-card[_ngcontent-%COMP%]   .card-actions[_ngcontent-%COMP%]   .btn-action-icon.btn-delete[_ngcontent-%COMP%] {\n  background: #fee2e2;\n  color: #ef4444;\n}\n.address-card[_ngcontent-%COMP%]   .card-actions[_ngcontent-%COMP%]   .btn-action-icon.btn-delete[_ngcontent-%COMP%]:hover {\n  background: #fecaca;\n}\n.address-card[_ngcontent-%COMP%]   .card-actions[_ngcontent-%COMP%]   .btn-action-icon.btn-delete[_ngcontent-%COMP%]:active {\n  transform: scale(0.92);\n}\n.address-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .address-name[_ngcontent-%COMP%] {\n  font-size: 0.95rem;\n  font-weight: 700;\n  color: #0f172a;\n  margin: 0 0 4px 0;\n  line-height: 1.3;\n}\n.address-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .full-address-text[_ngcontent-%COMP%] {\n  font-size: 0.82rem;\n  color: #64748b;\n  line-height: 1.45;\n  margin: 0 0 6px 0;\n}\n.address-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .full-address-text[_ngcontent-%COMP%]   .landmark-text[_ngcontent-%COMP%] {\n  font-weight: 600;\n  color: #475569;\n}\n.address-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .receiver-pill[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  font-size: 0.75rem;\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n  padding: 3px 8px;\n  border-radius: 6px;\n  color: #475569;\n  margin-top: 4px;\n}\n.address-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .receiver-pill[_ngcontent-%COMP%]   .rec-label[_ngcontent-%COMP%] {\n  color: #94a3b8;\n  font-weight: 500;\n}\n.address-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .receiver-pill[_ngcontent-%COMP%]   .rec-name[_ngcontent-%COMP%] {\n  font-weight: 600;\n}\n.address-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .receiver-pill[_ngcontent-%COMP%]   .rec-phone[_ngcontent-%COMP%] {\n  color: #64748b;\n}\n.map-action-footer[_ngcontent-%COMP%] {\n  position: fixed;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  padding: 12px 16px max(12px, env(safe-area-inset-bottom, 12px));\n  background: rgba(255, 255, 255, 0.95);\n  backdrop-filter: blur(10px);\n  -webkit-backdrop-filter: blur(10px);\n  border-top: 1px solid #e2e8f0;\n  box-shadow: 0 -4px 16px rgba(0, 0, 0, 0.05);\n  display: flex;\n  justify-content: center;\n  z-index: 100;\n}\n.map-action-footer[_ngcontent-%COMP%]   .btn-select-map[_ngcontent-%COMP%] {\n  width: 100%;\n  max-width: 560px;\n  height: 48px;\n  background:\n    linear-gradient(\n      135deg,\n      #a000e2 0%,\n      #7c00b3 100%);\n  color: #ffffff;\n  font-size: 0.95rem;\n  font-weight: 700;\n  border: none;\n  border-radius: 12px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 8px;\n  cursor: pointer;\n  box-shadow: 0 4px 14px rgba(160, 0, 226, 0.35);\n  transition: transform 0.15s ease, box-shadow 0.15s ease;\n}\n.map-action-footer[_ngcontent-%COMP%]   .btn-select-map[_ngcontent-%COMP%]:active {\n  transform: scale(0.98);\n  box-shadow: 0 2px 8px rgba(160, 0, 226, 0.25);\n}\n.map-action-footer[_ngcontent-%COMP%]   .btn-select-map[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 20px;\n}\n.edit-modal-backdrop[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  background: rgba(15, 23, 42, 0.55);\n  backdrop-filter: blur(4px);\n  -webkit-backdrop-filter: blur(4px);\n  z-index: 9999;\n  display: flex;\n  align-items: flex-end;\n  justify-content: center;\n}\n.edit-modal-backdrop[_ngcontent-%COMP%]   .edit-modal-sheet[_ngcontent-%COMP%] {\n  width: 100%;\n  max-width: 560px;\n  max-height: 90vh;\n  background: #ffffff;\n  border-radius: 24px 24px 0 0;\n  box-shadow: 0 -10px 40px rgba(0, 0, 0, 0.2);\n  overflow: hidden;\n  animation-duration: 0.25s;\n}\n/*# sourceMappingURL=saved-addresses.component.css.map */"] });
var SavedAddressesComponent = _SavedAddressesComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(SavedAddressesComponent, { className: "SavedAddressesComponent", filePath: "src/app/components/saved-addresses/saved-addresses.component.ts", lineNumber: 45 });
})();

// src/app/pages/address-list/address-list.page.ts
var _AddressListPage = class _AddressListPage {
  constructor(navCtrl) {
    this.navCtrl = navCtrl;
    this.routeSource = "home";
    addIcons({ arrowBackOutline });
  }
  ngOnInit() {
    var _a;
    this.routeSource = ((_a = history.state) == null ? void 0 : _a.data) || "home";
  }
  ionViewWillEnter() {
    var _a;
    this.routeSource = ((_a = history.state) == null ? void 0 : _a.data) || this.routeSource || "home";
    if (this.savedAddressesComp) {
      this.savedAddressesComp.loadAddresses(false);
    }
  }
  goBack() {
    this.navCtrl.back();
  }
};
_AddressListPage.\u0275fac = function AddressListPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _AddressListPage)(\u0275\u0275directiveInject(NavController));
};
_AddressListPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _AddressListPage, selectors: [["app-address-list"]], viewQuery: function AddressListPage_Query(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275viewQuery(SavedAddressesComponent, 5);
  }
  if (rf & 2) {
    let _t;
    \u0275\u0275queryRefresh(_t = \u0275\u0275loadQuery()) && (ctx.savedAddressesComp = _t.first);
  }
}, decls: 9, vars: 3, consts: [[1, "ion-no-border", "bg-white", "pt-2", "address-list-header"], ["slot", "start"], [3, "click"], ["name", "arrow-back-outline", "color", "dark"], [1, "fw-bold", "text-dark"], [1, "address-list-content", 3, "fullscreen"], [3, "routeSource", "autoNavigateBackOnSelect"]], template: function AddressListPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar")(2, "ion-buttons", 1)(3, "ion-button", 2);
    \u0275\u0275listener("click", function AddressListPage_Template_ion_button_click_3_listener() {
      return ctx.goBack();
    });
    \u0275\u0275element(4, "ion-icon", 3);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "ion-title", 4);
    \u0275\u0275text(6, "Saved Addresses");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(7, "ion-content", 5);
    \u0275\u0275element(8, "app-saved-addresses", 6);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance(7);
    \u0275\u0275property("fullscreen", false);
    \u0275\u0275advance();
    \u0275\u0275property("routeSource", ctx.routeSource)("autoNavigateBackOnSelect", ctx.routeSource !== "profile");
  }
}, dependencies: [
  CommonModule,
  FormsModule,
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  IonButton,
  IonButtons,
  IonIcon,
  SavedAddressesComponent
], styles: ["\n\n[_nghost-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  height: 100%;\n}\n.address-list-header[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-bottom: 1px solid #f1f5f9;\n}\n.address-list-content[_ngcontent-%COMP%] {\n  --background: #f8fafc;\n}\n/*# sourceMappingURL=address-list.page.css.map */"] });
var AddressListPage = _AddressListPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(AddressListPage, { className: "AddressListPage", filePath: "src/app/pages/address-list/address-list.page.ts", lineNumber: 36 });
})();
export {
  AddressListPage
};
//# sourceMappingURL=address-list.page-RREH67XB.js.map
