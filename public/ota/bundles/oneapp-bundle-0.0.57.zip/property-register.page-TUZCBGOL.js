import {
  Camera,
  CameraResultType,
  CameraSource
} from "./chunk-EF5UON5H.js";
import {
  PropertyService
} from "./chunk-IC2VC54O.js";
import {
  LocationService
} from "./chunk-4TQR4WSH.js";
import "./chunk-V444GY6B.js";
import "./chunk-QH3WR2OQ.js";
import "./chunk-YJYUHAOC.js";
import {
  ActionSheetController,
  ToastController
} from "./chunk-OE5MTPUR.js";
import {
  addIcons,
  addOutline,
  alertCircleOutline,
  arrowBackOutline,
  busOutline,
  businessOutline,
  callOutline,
  cameraOutline,
  cartOutline,
  checkmark,
  checkmarkCircle,
  closeOutline,
  documentTextOutline,
  gridOutline,
  homeOutline,
  imagesOutline,
  keyOutline,
  leafOutline,
  locationOutline,
  lockClosedOutline,
  logoWhatsapp,
  logoYoutube,
  mapOutline,
  medkitOutline,
  navigateOutline,
  personOutline,
  pinOutline,
  playCircle,
  pricetagOutline,
  schoolOutline,
  shieldCheckmarkOutline,
  sparkles,
  trashOutline
} from "./chunk-FJYXZAS7.js";
import {
  IonContent,
  IonHeader,
  IonIcon,
  IonToolbar
} from "./chunk-CJE2NDTY.js";
import {
  ActivatedRoute,
  ChangeDetectorRef,
  CommonModule,
  DefaultValueAccessor,
  FormsModule,
  NavController,
  NavigationEnd,
  NgControlStatus,
  NgModel,
  NgZone,
  NumberValueAccessor,
  Router,
  Subscription,
  UpperCasePipe,
  filter,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind1,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIdentity,
  ɵɵrepeaterTrackByIndex,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-Z7XNNJSA.js";
import "./chunk-XR3JUECC.js";
import "./chunk-FH4NU4VH.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/pages/property-register/property-register.page.ts
var _c0 = () => ["East", "North", "North-East", "West", "South"];
var _c1 = () => ["Owner", "Builder", "Verified Agent"];
var _c2 = () => [1, 2, 3, 4, 5];
var _c3 = () => [1, 2, 3, 4];
var _c4 = () => ["Furnished", "Semi-Furnished", "Unfurnished"];
var _c5 = () => ["Ready to Move", "Under Development", "Immediate"];
var _c6 = () => ["Ready to Move", "Under Construction", "Immediate"];
var _forTrack0 = ($index, $item) => $item.id;
function PropertyRegisterPage_For_23_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 107);
  }
}
function PropertyRegisterPage_For_23_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 104);
    \u0275\u0275listener("click", function PropertyRegisterPage_For_23_Template_button_click_0_listener() {
      const opt_r2 = \u0275\u0275restoreView(_r1).$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.onCategoryChange(opt_r2.id));
    });
    \u0275\u0275element(1, "ion-icon", 105);
    \u0275\u0275elementStart(2, "span", 106);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275template(4, PropertyRegisterPage_For_23_Conditional_4_Template, 1, 0, "ion-icon", 107);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const opt_r2 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275classProp("active", ctx_r2.category === opt_r2.id);
    \u0275\u0275advance();
    \u0275\u0275property("name", opt_r2.icon);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(opt_r2.label);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r2.category === opt_r2.id ? 4 : -1);
  }
}
function PropertyRegisterPage_For_29_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 108);
    \u0275\u0275listener("click", function PropertyRegisterPage_For_29_Template_button_click_0_listener() {
      const type_r5 = \u0275\u0275restoreView(_r4).$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.propertyType = type_r5);
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const type_r5 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275classProp("active", ctx_r2.propertyType === type_r5);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", type_r5, " ");
  }
}
function PropertyRegisterPage_Conditional_63_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 31)(1, "div", 52)(2, "label", 19);
    \u0275\u0275text(3, "Security Deposit (\u20B9)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "div", 28)(5, "span", 29);
    \u0275\u0275text(6, "\u20B9");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "input", 109);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyRegisterPage_Conditional_63_Template_input_ngModelChange_7_listener($event) {
      \u0275\u0275restoreView(_r6);
      const ctx_r2 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r2.securityDeposit, $event) || (ctx_r2.securityDeposit = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(8, "div", 52)(9, "label", 19);
    \u0275\u0275text(10, "Maintenance (\u20B9 / mo)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "div", 28)(12, "span", 29);
    \u0275\u0275text(13, "\u20B9");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "input", 110);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyRegisterPage_Conditional_63_Template_input_ngModelChange_14_listener($event) {
      \u0275\u0275restoreView(_r6);
      const ctx_r2 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r2.maintenancePerMonth, $event) || (ctx_r2.maintenancePerMonth = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance(7);
    \u0275\u0275twoWayProperty("ngModel", ctx_r2.securityDeposit);
    \u0275\u0275advance(7);
    \u0275\u0275twoWayProperty("ngModel", ctx_r2.maintenancePerMonth);
  }
}
function PropertyRegisterPage_Conditional_98_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 48);
    \u0275\u0275element(1, "ion-icon", 111);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2(" ", ctx_r2.coordinates.lat.toFixed(4), ", ", ctx_r2.coordinates.lng.toFixed(4), " ");
  }
}
function PropertyRegisterPage_Conditional_120_For_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 112)(1, "div", 113)(2, "div", 114);
    \u0275\u0275element(3, "ion-icon", 41);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "div", 115)(5, "span", 116);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "span", 117);
    \u0275\u0275text(8);
    \u0275\u0275pipe(9, "uppercase");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(10, "div", 118)(11, "span", 119);
    \u0275\u0275text(12);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "button", 120);
    \u0275\u0275listener("click", function PropertyRegisterPage_Conditional_120_For_2_Template_button_click_13_listener() {
      const $index_r8 = \u0275\u0275restoreView(_r7).$index;
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.removeLandmark($index_r8));
    });
    \u0275\u0275element(14, "ion-icon", 121);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const lm_r9 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(3);
    \u0275\u0275property("name", ctx_r2.landmarkTypeIcons[lm_r9.type] || "location-outline");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(lm_r9.name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(9, 4, lm_r9.type));
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(lm_r9.distance);
  }
}
function PropertyRegisterPage_Conditional_120_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 55);
    \u0275\u0275repeaterCreate(1, PropertyRegisterPage_Conditional_120_For_2_Template, 15, 6, "div", 112, \u0275\u0275repeaterTrackByIndex);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r2.customLandmarks);
  }
}
function PropertyRegisterPage_For_126_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 122);
    \u0275\u0275listener("click", function PropertyRegisterPage_For_126_Template_button_click_0_listener() {
      const t_r11 = \u0275\u0275restoreView(_r10).$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.newLandmarkType = t_r11.id);
    });
    \u0275\u0275element(1, "ion-icon", 41);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const t_r11 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275classProp("active", ctx_r2.newLandmarkType === t_r11.id);
    \u0275\u0275advance();
    \u0275\u0275property("name", t_r11.icon);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(t_r11.label);
  }
}
function PropertyRegisterPage_Conditional_149_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 66)(1, "div", 52)(2, "label", 19);
    \u0275\u0275text(3, "Total Land Area (Acres) *");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "input", 123);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyRegisterPage_Conditional_149_Template_input_ngModelChange_4_listener($event) {
      \u0275\u0275restoreView(_r12);
      const ctx_r2 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r2.totalAcres, $event) || (ctx_r2.totalAcres = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "div", 52)(6, "label", 19);
    \u0275\u0275text(7, "Area (Guntha / Sq.ft optional)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "input", 124);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyRegisterPage_Conditional_149_Template_input_ngModelChange_8_listener($event) {
      \u0275\u0275restoreView(_r12);
      const ctx_r2 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r2.superBuiltUpArea, $event) || (ctx_r2.superBuiltUpArea = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r2.totalAcres);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r2.superBuiltUpArea);
  }
}
function PropertyRegisterPage_Conditional_150_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 66)(1, "div", 52)(2, "label", 19);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "input", 125);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyRegisterPage_Conditional_150_Template_input_ngModelChange_4_listener($event) {
      \u0275\u0275restoreView(_r13);
      const ctx_r2 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r2.superBuiltUpArea, $event) || (ctx_r2.superBuiltUpArea = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "div", 52)(6, "label", 19);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "input", 126);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyRegisterPage_Conditional_150_Template_input_ngModelChange_8_listener($event) {
      \u0275\u0275restoreView(_r13);
      const ctx_r2 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r2.carpetArea, $event) || (ctx_r2.carpetArea = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx_r2.category === "buy_plot" ? "Plot Area (sq.ft) *" : "Super Built-up Area (sq.ft) *");
    \u0275\u0275advance();
    \u0275\u0275twoWayProperty("ngModel", ctx_r2.superBuiltUpArea);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx_r2.category === "buy_plot" ? "Dimensions (e.g. 30x40)" : "Carpet Area (sq.ft)");
    \u0275\u0275advance();
    \u0275\u0275twoWayProperty("ngModel", ctx_r2.carpetArea);
  }
}
function PropertyRegisterPage_Conditional_151_For_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 127);
    \u0275\u0275listener("click", function PropertyRegisterPage_Conditional_151_For_5_Template_button_click_0_listener() {
      const n_r15 = \u0275\u0275restoreView(_r14).$implicit;
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.bedrooms = n_r15);
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const n_r15 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275classProp("active", ctx_r2.bedrooms === n_r15);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", n_r15, " BHK ");
  }
}
function PropertyRegisterPage_Conditional_151_For_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r16 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 127);
    \u0275\u0275listener("click", function PropertyRegisterPage_Conditional_151_For_11_Template_button_click_0_listener() {
      const n_r17 = \u0275\u0275restoreView(_r16).$implicit;
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.bathrooms = n_r17);
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const n_r17 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275classProp("active", ctx_r2.bathrooms === n_r17);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", n_r17, " Baths ");
  }
}
function PropertyRegisterPage_Conditional_151_For_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 127);
    \u0275\u0275listener("click", function PropertyRegisterPage_Conditional_151_For_17_Template_button_click_0_listener() {
      const f_r19 = \u0275\u0275restoreView(_r18).$implicit;
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.furnishing = f_r19);
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const f_r19 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275classProp("active", ctx_r2.furnishing === f_r19);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", f_r19, " ");
  }
}
function PropertyRegisterPage_Conditional_151_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 18)(1, "label", 19);
    \u0275\u0275text(2, "Bedrooms (BHK)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 67);
    \u0275\u0275repeaterCreate(4, PropertyRegisterPage_Conditional_151_For_5_Template, 2, 3, "button", 68, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "div", 18)(7, "label", 19);
    \u0275\u0275text(8, "Bathrooms");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "div", 67);
    \u0275\u0275repeaterCreate(10, PropertyRegisterPage_Conditional_151_For_11_Template, 2, 3, "button", 68, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(12, "div", 18)(13, "label", 19);
    \u0275\u0275text(14, "Furnishing Status");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "div", 67);
    \u0275\u0275repeaterCreate(16, PropertyRegisterPage_Conditional_151_For_17_Template, 2, 3, "button", 68, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(4);
    \u0275\u0275repeater(\u0275\u0275pureFunction0(0, _c2));
    \u0275\u0275advance(6);
    \u0275\u0275repeater(\u0275\u0275pureFunction0(1, _c3));
    \u0275\u0275advance(6);
    \u0275\u0275repeater(\u0275\u0275pureFunction0(2, _c4));
  }
}
function PropertyRegisterPage_For_157_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 127);
    \u0275\u0275listener("click", function PropertyRegisterPage_For_157_Template_button_click_0_listener() {
      const dir_r21 = \u0275\u0275restoreView(_r20).$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.facing = dir_r21);
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const dir_r21 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275classProp("active", ctx_r2.facing === dir_r21);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", dir_r21, " ");
  }
}
function PropertyRegisterPage_Conditional_158_Conditional_4_For_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r22 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 127);
    \u0275\u0275listener("click", function PropertyRegisterPage_Conditional_158_Conditional_4_For_1_Template_button_click_0_listener() {
      const p_r23 = \u0275\u0275restoreView(_r22).$implicit;
      const ctx_r2 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r2.possessionStatus = p_r23);
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const p_r23 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext(3);
    \u0275\u0275classProp("active", ctx_r2.possessionStatus === p_r23);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", p_r23, " ");
  }
}
function PropertyRegisterPage_Conditional_158_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275repeaterCreate(0, PropertyRegisterPage_Conditional_158_Conditional_4_For_1_Template, 2, 3, "button", 68, \u0275\u0275repeaterTrackByIdentity);
  }
  if (rf & 2) {
    \u0275\u0275repeater(\u0275\u0275pureFunction0(0, _c5));
  }
}
function PropertyRegisterPage_Conditional_158_Conditional_5_For_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r24 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 127);
    \u0275\u0275listener("click", function PropertyRegisterPage_Conditional_158_Conditional_5_For_1_Template_button_click_0_listener() {
      const p_r25 = \u0275\u0275restoreView(_r24).$implicit;
      const ctx_r2 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r2.possessionStatus = p_r25);
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const p_r25 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext(3);
    \u0275\u0275classProp("active", ctx_r2.possessionStatus === p_r25);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", p_r25, " ");
  }
}
function PropertyRegisterPage_Conditional_158_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275repeaterCreate(0, PropertyRegisterPage_Conditional_158_Conditional_5_For_1_Template, 2, 3, "button", 68, \u0275\u0275repeaterTrackByIdentity);
  }
  if (rf & 2) {
    \u0275\u0275repeater(\u0275\u0275pureFunction0(0, _c6));
  }
}
function PropertyRegisterPage_Conditional_158_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 18)(1, "label", 19);
    \u0275\u0275text(2, "Possession Status");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 67);
    \u0275\u0275template(4, PropertyRegisterPage_Conditional_158_Conditional_4_Template, 2, 1)(5, PropertyRegisterPage_Conditional_158_Conditional_5_Template, 2, 1);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx_r2.category === "buy_plot" ? 4 : 5);
  }
}
function PropertyRegisterPage_Conditional_159_Template(rf, ctx) {
  if (rf & 1) {
    const _r26 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 31)(1, "div", 52)(2, "label", 19);
    \u0275\u0275text(3, "Floor Level");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "input", 128);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyRegisterPage_Conditional_159_Template_input_ngModelChange_4_listener($event) {
      \u0275\u0275restoreView(_r26);
      const ctx_r2 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r2.floor, $event) || (ctx_r2.floor = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "div", 52)(6, "label", 19);
    \u0275\u0275text(7, "Parking");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "input", 129);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyRegisterPage_Conditional_159_Template_input_ngModelChange_8_listener($event) {
      \u0275\u0275restoreView(_r26);
      const ctx_r2 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r2.parking, $event) || (ctx_r2.parking = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r2.floor);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r2.parking);
  }
}
function PropertyRegisterPage_For_175_Template(rf, ctx) {
  if (rf & 1) {
    const _r27 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 130);
    \u0275\u0275listener("click", function PropertyRegisterPage_For_175_Template_div_click_0_listener() {
      const amenity_r28 = \u0275\u0275restoreView(_r27).$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.toggleAmenity(amenity_r28));
    });
    \u0275\u0275elementStart(1, "div", 131);
    \u0275\u0275element(2, "ion-icon", 41);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 132);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const amenity_r28 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275classProp("selected", ctx_r2.isAmenitySelected(amenity_r28));
    \u0275\u0275advance(2);
    \u0275\u0275property("name", ctx_r2.isAmenitySelected(amenity_r28) ? "checkmark-circle" : "add-outline");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(amenity_r28);
  }
}
function PropertyRegisterPage_Conditional_195_Template(rf, ctx) {
  if (rf & 1) {
    const _r29 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 133);
    \u0275\u0275listener("click", function PropertyRegisterPage_Conditional_195_Template_div_click_0_listener() {
      \u0275\u0275restoreView(_r29);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.rentAgreementReady = !ctx_r2.rentAgreementReady);
    });
    \u0275\u0275elementStart(1, "div", 134)(2, "span", 135);
    \u0275\u0275text(3, "Registered Rental Agreement");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "span", 136);
    \u0275\u0275text(5, "Standard 11-month agreement drafted and ready");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "div", 36);
    \u0275\u0275element(7, "div", 37);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "div", 133);
    \u0275\u0275listener("click", function PropertyRegisterPage_Conditional_195_Template_div_click_8_listener() {
      \u0275\u0275restoreView(_r29);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.nocOwnerClear = !ctx_r2.nocOwnerClear);
    });
    \u0275\u0275elementStart(9, "div", 134)(10, "span", 135);
    \u0275\u0275text(11, "Owner ID & Tenancy NOC");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "span", 136);
    \u0275\u0275text(13, "Verified electricity bill, ownership & tenancy NOC");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(14, "div", 36);
    \u0275\u0275element(15, "div", 37);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(16, "div", 133);
    \u0275\u0275listener("click", function PropertyRegisterPage_Conditional_195_Template_div_click_16_listener() {
      \u0275\u0275restoreView(_r29);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.policeVerificationReady = !ctx_r2.policeVerificationReady);
    });
    \u0275\u0275elementStart(17, "div", 134)(18, "span", 135);
    \u0275\u0275text(19, "Police Tenant Verification Form");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "span", 136);
    \u0275\u0275text(21, "Local station tenant verification form available");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(22, "div", 36);
    \u0275\u0275element(23, "div", 37);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance(6);
    \u0275\u0275classProp("on", ctx_r2.rentAgreementReady);
    \u0275\u0275advance(8);
    \u0275\u0275classProp("on", ctx_r2.nocOwnerClear);
    \u0275\u0275advance(8);
    \u0275\u0275classProp("on", ctx_r2.policeVerificationReady);
  }
}
function PropertyRegisterPage_Conditional_196_Conditional_40_Template(rf, ctx) {
  if (rf & 1) {
    const _r31 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 133);
    \u0275\u0275listener("click", function PropertyRegisterPage_Conditional_196_Conditional_40_Template_div_click_0_listener() {
      \u0275\u0275restoreView(_r31);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.ocAvailable = !ctx_r2.ocAvailable);
    });
    \u0275\u0275elementStart(1, "div", 134)(2, "span", 135);
    \u0275\u0275text(3, "Occupancy Certificate (OC)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "span", 136);
    \u0275\u0275text(5, "Official completion and occupancy certificate");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "div", 36);
    \u0275\u0275element(7, "div", 37);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(6);
    \u0275\u0275classProp("on", ctx_r2.ocAvailable);
  }
}
function PropertyRegisterPage_Conditional_196_Template(rf, ctx) {
  if (rf & 1) {
    const _r30 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 133);
    \u0275\u0275listener("click", function PropertyRegisterPage_Conditional_196_Template_div_click_0_listener() {
      \u0275\u0275restoreView(_r30);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.titleDeedClear = !ctx_r2.titleDeedClear);
    });
    \u0275\u0275elementStart(1, "div", 134)(2, "span", 135);
    \u0275\u0275text(3, "Title Deed & Sale Deed Registered");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "span", 136);
    \u0275\u0275text(5, "Clear 30-year mother deed title chain");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "div", 36);
    \u0275\u0275element(7, "div", 37);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "div", 133);
    \u0275\u0275listener("click", function PropertyRegisterPage_Conditional_196_Template_div_click_8_listener() {
      \u0275\u0275restoreView(_r30);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.khataClear = !ctx_r2.khataClear);
    });
    \u0275\u0275elementStart(9, "div", 134)(10, "span", 135);
    \u0275\u0275text(11);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "span", 136);
    \u0275\u0275text(13, "Updated mutation and land revenue tax assessment");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(14, "div", 36);
    \u0275\u0275element(15, "div", 37);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(16, "div", 133);
    \u0275\u0275listener("click", function PropertyRegisterPage_Conditional_196_Template_div_click_16_listener() {
      \u0275\u0275restoreView(_r30);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.ecClear = !ctx_r2.ecClear);
    });
    \u0275\u0275elementStart(17, "div", 134)(18, "span", 135);
    \u0275\u0275text(19, "Encumbrance Certificate (EC)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "span", 136);
    \u0275\u0275text(21, "Nil encumbrance (15+ Years) free from bank mortgages");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(22, "div", 36);
    \u0275\u0275element(23, "div", 37);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(24, "div", 133);
    \u0275\u0275listener("click", function PropertyRegisterPage_Conditional_196_Template_div_click_24_listener() {
      \u0275\u0275restoreView(_r30);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.planApproved = !ctx_r2.planApproved);
    });
    \u0275\u0275elementStart(25, "div", 134)(26, "span", 135);
    \u0275\u0275text(27);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(28, "span", 136);
    \u0275\u0275text(29, "Town planning and competent revenue authority approved");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(30, "div", 36);
    \u0275\u0275element(31, "div", 37);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(32, "div", 133);
    \u0275\u0275listener("click", function PropertyRegisterPage_Conditional_196_Template_div_click_32_listener() {
      \u0275\u0275restoreView(_r30);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.taxPaid = !ctx_r2.taxPaid);
    });
    \u0275\u0275elementStart(33, "div", 134)(34, "span", 135);
    \u0275\u0275text(35, "Property Tax Paid");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(36, "span", 136);
    \u0275\u0275text(37, "Paid up to current financial year (2025-26)");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(38, "div", 36);
    \u0275\u0275element(39, "div", 37);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(40, PropertyRegisterPage_Conditional_196_Conditional_40_Template, 8, 2, "div", 137);
    \u0275\u0275elementStart(41, "div", 133);
    \u0275\u0275listener("click", function PropertyRegisterPage_Conditional_196_Template_div_click_41_listener() {
      \u0275\u0275restoreView(_r30);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.bankLoanEligible = !ctx_r2.bankLoanEligible);
    });
    \u0275\u0275elementStart(42, "div", 134)(43, "span", 135);
    \u0275\u0275text(44, "Bank Home / Plot Loan Pre-Approved");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(45, "span", 136);
    \u0275\u0275text(46, "Eligible for fast loans with SBI, HDFC & Canara Bank");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(47, "div", 36);
    \u0275\u0275element(48, "div", 37);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance(6);
    \u0275\u0275classProp("on", ctx_r2.titleDeedClear);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r2.category === "buy_land" ? "7/12 RTC & Mutation Clear" : "A-Khata / Municipal Khata");
    \u0275\u0275advance(3);
    \u0275\u0275classProp("on", ctx_r2.khataClear);
    \u0275\u0275advance(8);
    \u0275\u0275classProp("on", ctx_r2.ecClear);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r2.category === "buy_land" ? "DC Conversion (NA Order) / Form 9/11" : "Sanctioned Building Plan / DC Layout");
    \u0275\u0275advance(3);
    \u0275\u0275classProp("on", ctx_r2.planApproved);
    \u0275\u0275advance(8);
    \u0275\u0275classProp("on", ctx_r2.taxPaid);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r2.category === "buy_house" ? 40 : -1);
    \u0275\u0275advance(7);
    \u0275\u0275classProp("on", ctx_r2.bankLoanEligible);
  }
}
function PropertyRegisterPage_For_198_Template(rf, ctx) {
  if (rf & 1) {
    const _r32 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 76)(1, "div", 138);
    \u0275\u0275listener("click", function PropertyRegisterPage_For_198_Template_div_click_1_listener() {
      const customDoc_r33 = \u0275\u0275restoreView(_r32).$implicit;
      return \u0275\u0275resetView(customDoc_r33.clear = !customDoc_r33.clear);
    });
    \u0275\u0275elementStart(2, "div", 139)(3, "span", 135);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "span", 140);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "span", 136);
    \u0275\u0275text(8);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "div", 141)(10, "div", 142);
    \u0275\u0275listener("click", function PropertyRegisterPage_For_198_Template_div_click_10_listener() {
      const customDoc_r33 = \u0275\u0275restoreView(_r32).$implicit;
      return \u0275\u0275resetView(customDoc_r33.clear = !customDoc_r33.clear);
    });
    \u0275\u0275element(11, "div", 37);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "button", 143);
    \u0275\u0275listener("click", function PropertyRegisterPage_For_198_Template_button_click_12_listener() {
      const $index_r34 = \u0275\u0275restoreView(_r32).$index;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.removeCustomLegalDoc($index_r34));
    });
    \u0275\u0275element(13, "ion-icon", 121);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const customDoc_r33 = ctx.$implicit;
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(customDoc_r33.title);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(customDoc_r33.category);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(customDoc_r33.details);
    \u0275\u0275advance(2);
    \u0275\u0275classProp("on", customDoc_r33.clear);
  }
}
function PropertyRegisterPage_For_225_Template(rf, ctx) {
  if (rf & 1) {
    const _r35 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 81);
    \u0275\u0275element(1, "img", 144);
    \u0275\u0275elementStart(2, "button", 145);
    \u0275\u0275listener("click", function PropertyRegisterPage_For_225_Template_button_click_2_listener() {
      const $index_r36 = \u0275\u0275restoreView(_r35).$index;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.removeImage($index_r36));
    });
    \u0275\u0275element(3, "ion-icon", 121);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const img_r37 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275property("src", img_r37, \u0275\u0275sanitizeUrl);
  }
}
function PropertyRegisterPage_Conditional_248_Template(rf, ctx) {
  if (rf & 1) {
    const _r38 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 146);
    \u0275\u0275listener("click", function PropertyRegisterPage_Conditional_248_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r38);
      const ctx_r2 = \u0275\u0275nextContext();
      ctx_r2.youtubeUrl = "";
      return \u0275\u0275resetView(ctx_r2.onYoutubeUrlChange());
    });
    \u0275\u0275element(1, "ion-icon", 147);
    \u0275\u0275elementEnd();
  }
}
function PropertyRegisterPage_Conditional_249_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 98)(1, "div", 148);
    \u0275\u0275element(2, "img", 149);
    \u0275\u0275elementStart(3, "div", 150);
    \u0275\u0275element(4, "ion-icon", 151);
    \u0275\u0275elementStart(5, "span");
    \u0275\u0275text(6, "Video Linked");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(7, "div", 152)(8, "span", 153);
    \u0275\u0275text(9, "Ready for in-app tour");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "span", 154);
    \u0275\u0275text(11);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance(2);
    \u0275\u0275property("src", "https://img.youtube.com/vi/" + ctx_r2.youtubeVideoId + "/hqdefault.jpg", \u0275\u0275sanitizeUrl);
    \u0275\u0275advance(9);
    \u0275\u0275textInterpolate1("Video ID: ", ctx_r2.youtubeVideoId, "");
  }
}
function PropertyRegisterPage_For_268_Template(rf, ctx) {
  if (rf & 1) {
    const _r39 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 127);
    \u0275\u0275listener("click", function PropertyRegisterPage_For_268_Template_button_click_0_listener() {
      const role_r40 = \u0275\u0275restoreView(_r39).$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.sellerType = role_r40);
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const role_r40 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275classProp("active", ctx_r2.sellerType === role_r40);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", role_r40, " ");
  }
}
function PropertyRegisterPage_Conditional_281_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1, "Publishing Property...");
    \u0275\u0275elementEnd();
  }
}
function PropertyRegisterPage_Conditional_282_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 155);
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2, "Post Property for Free");
    \u0275\u0275elementEnd();
  }
}
var _PropertyRegisterPage = class _PropertyRegisterPage {
  constructor(navCtrl, router, route, toastCtrl, locationService, propertyService, actionSheetCtrl, cdr, ngZone) {
    this.navCtrl = navCtrl;
    this.router = router;
    this.route = route;
    this.toastCtrl = toastCtrl;
    this.locationService = locationService;
    this.propertyService = propertyService;
    this.actionSheetCtrl = actionSheetCtrl;
    this.cdr = cdr;
    this.ngZone = ngZone;
    this.subs = new Subscription();
    this.category = "buy_house";
    this.propertyType = "Independent Villa";
    this.categoryOptions = [
      { id: "buy_house", label: "Buy House", icon: "home-outline" },
      { id: "rent_house", label: "Rent House", icon: "key-outline" },
      { id: "buy_land", label: "Buy Land", icon: "leaf-outline" },
      { id: "buy_plot", label: "Buy Plot", icon: "grid-outline" }
    ];
    this.typeOptionsByCat = {
      buy_house: [
        "Independent Villa",
        "Independent House",
        "Duplex Bungalow",
        "Residential Apartment",
        "Row House",
        "Commercial Building"
      ],
      rent_house: [
        "Independent House",
        "Residential Apartment",
        "Studio Room",
        "Duplex Villa",
        "Commercial Shop / Office"
      ],
      buy_land: [
        "Agricultural Land",
        "Commercial Land",
        "Farmhouse Land",
        "Industrial Land"
      ],
      buy_plot: [
        "Residential Gated Plot",
        "Corner Plot",
        "Commercial Plot",
        "DC Converted NA Plot"
      ]
    };
    this.title = "";
    this.description = "";
    this.price = null;
    this.securityDeposit = null;
    this.maintenancePerMonth = null;
    this.priceNegotiable = true;
    this.city = "Jamkhandi";
    this.locality = "";
    this.fullAddress = "";
    this.coordinates = null;
    this.customLandmarks = [
      { name: "City Bus Stand / Auto Stand", distance: "1.0 km", type: "transit" },
      { name: "Government / Private Hospital", distance: "1.2 km", type: "hospital" },
      { name: "English Medium High School", distance: "800 m", type: "school" }
    ];
    this.newLandmarkName = "";
    this.newLandmarkDistance = "";
    this.newLandmarkType = "transit";
    this.landmarkTypeOptions = [
      { id: "transit", label: "Transit", icon: "bus-outline" },
      { id: "school", label: "School", icon: "school-outline" },
      { id: "hospital", label: "Hospital", icon: "medkit-outline" },
      { id: "market", label: "Market", icon: "cart-outline" },
      { id: "bank", label: "Bank / ATM", icon: "business-outline" }
    ];
    this.landmarkTypeIcons = {
      transit: "bus-outline",
      school: "school-outline",
      hospital: "medkit-outline",
      market: "cart-outline",
      bank: "business-outline"
    };
    this.superBuiltUpArea = null;
    this.carpetArea = null;
    this.totalAcres = null;
    this.bedrooms = 3;
    this.bathrooms = 2;
    this.facing = "East";
    this.furnishing = "Semi-Furnished";
    this.possessionStatus = "Ready to Move";
    this.floor = "Ground + 1st Floor";
    this.parking = "Covered Car Parking";
    this.waterSupply = "24/7 Municipal & Borewell";
    this.defaultAmenitiesByCat = {
      buy_house: [
        "Car Parking",
        "24/7 Water Supply",
        "Power Backup",
        "CCTV Security",
        "Private Garden",
        "100% Vastu Compliant",
        "High Compound Wall",
        "Gated Community",
        "Rainwater Harvesting",
        "Solar Water Heater"
      ],
      rent_house: [
        "Car Parking",
        "24/7 Water Supply",
        "Power Backup",
        "Geyser / Hot Water",
        "Wardrobes Built-in",
        "Balcony",
        "CCTV Security",
        "Lift / Elevator",
        "Bike Parking",
        "Modular Kitchen"
      ],
      buy_land: [
        "Tar Road Access",
        "Borewell Available",
        "Open Well Water",
        "River / Canal Water Proximity",
        "Water Pipeline Connectivity",
        "3-Phase Power Supply",
        "Fenced Boundary / Wire Fencing",
        "Clear Farm Track Approach",
        "Fertile Soil (Black/Red)",
        "Drip Irrigation Setup"
      ],
      buy_plot: [
        "Tar / Concrete Wide Roads",
        "Underground Drainage (UGD)",
        "Electricity / Power Supply",
        "Street Lights Installed",
        "Municipal Water Connection",
        "Gated Community with Arch",
        "CCTV & 24/7 Security Guard",
        "Parks & Green Tree Plantation",
        "Compound Wall Demarcation",
        "Children Play Park"
      ]
    };
    this.availableAmenities = [];
    this.selectedAmenities = [];
    this.customAmenityInput = "";
    this.titleDeedClear = true;
    this.khataClear = true;
    this.ecClear = true;
    this.planApproved = true;
    this.taxPaid = true;
    this.ocAvailable = true;
    this.bankLoanEligible = true;
    this.rentAgreementReady = true;
    this.policeVerificationReady = true;
    this.nocOwnerClear = true;
    this.customLegalDocs = [];
    this.newCustomDocTitle = "";
    this.newCustomDocDetails = "";
    this.newCustomDocCategory = "Legal Verification";
    this.imageUrls = [
      "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80"
    ];
    this.newImageUrl = "";
    this.youtubeUrl = "";
    this.youtubeVideoId = null;
    this.sellerName = "";
    this.sellerType = "Owner";
    this.sellerPhone = "";
    this.sellerWhatsapp = "";
    this.isSubmitting = false;
    this.onWindowFocus = () => {
      this.checkMapSelectedLocation();
    };
    this.onWindowStorage = (e) => {
      if (e.key === "property_selected_location") {
        this.checkMapSelectedLocation();
      }
    };
    addIcons({
      arrowBackOutline,
      checkmarkCircle,
      homeOutline,
      keyOutline,
      leafOutline,
      gridOutline,
      locationOutline,
      pricetagOutline,
      documentTextOutline,
      shieldCheckmarkOutline,
      cameraOutline,
      imagesOutline,
      personOutline,
      callOutline,
      logoWhatsapp,
      addOutline,
      trashOutline,
      checkmark,
      alertCircleOutline,
      sparkles,
      closeOutline,
      mapOutline,
      busOutline,
      medkitOutline,
      schoolOutline,
      cartOutline,
      businessOutline,
      navigateOutline,
      pinOutline,
      lockClosedOutline,
      logoYoutube,
      playCircle
    });
  }
  ngOnInit() {
    this.initCategoryDefaults(this.category);
    this.prefillUserLocation();
    this.checkMapSelectedLocation();
    this.subs.add(this.route.queryParams.subscribe((params) => {
      if (params["from_map"] || params["lat"] || params["address"]) {
        this.applyLocationData({
          lat: params["lat"],
          lng: params["lng"],
          address: params["address"],
          area: params["area"],
          city: params["city"]
        });
      } else {
        this.checkMapSelectedLocation();
      }
    }));
    this.subs.add(this.router.events.pipe(filter((e) => e instanceof NavigationEnd)).subscribe(() => {
      this.checkMapSelectedLocation();
    }));
    if (typeof window !== "undefined") {
      window.addEventListener("focus", this.onWindowFocus);
      window.addEventListener("storage", this.onWindowStorage);
    }
  }
  ngOnDestroy() {
    this.subs.unsubscribe();
    if (typeof window !== "undefined") {
      window.removeEventListener("focus", this.onWindowFocus);
      window.removeEventListener("storage", this.onWindowStorage);
    }
  }
  ionViewWillEnter() {
    this.checkMapSelectedLocation();
  }
  applyLocationData(data) {
    if (!data)
      return;
    this.ngZone.run(() => {
      let updated = false;
      if (data.city) {
        this.city = data.city;
        updated = true;
      }
      if (data.area) {
        this.locality = data.area;
        updated = true;
      }
      if (data.address) {
        this.fullAddress = data.address;
        if (!this.locality) {
          this.locality = data.address.split(",")[0].trim();
        }
        updated = true;
      }
      if (data.lat && data.lng) {
        this.coordinates = { lat: Number(data.lat), lng: Number(data.lng) };
        updated = true;
      }
      localStorage.removeItem("property_selected_location");
      if (updated) {
        this.cdr.markForCheck();
        this.cdr.detectChanges();
        this.showToast("Property location & GPS coordinates pinned from map!", "success");
      }
    });
  }
  checkMapSelectedLocation() {
    try {
      const saved = localStorage.getItem("property_selected_location");
      if (saved) {
        const parsed = JSON.parse(saved);
        this.applyLocationData(parsed);
      }
    } catch (e) {
      console.warn("Could not read property_selected_location:", e);
    }
  }
  openMapPicker() {
    localStorage.setItem("map_picker_source", "property_register");
    this.navCtrl.navigateForward("/layout/map", {
      queryParams: { from: "property_register" },
      state: { data: "property_register" }
    });
  }
  addLandmark() {
    const name = this.newLandmarkName.trim();
    const distance = this.newLandmarkDistance.trim();
    if (!name) {
      this.showToast("Please enter landmark or place name.", "warning");
      return;
    }
    if (!distance) {
      this.showToast("Please enter distance (e.g. 500 m, 1.2 km).", "warning");
      return;
    }
    this.customLandmarks.push({
      name,
      distance,
      type: this.newLandmarkType
    });
    this.newLandmarkName = "";
    this.newLandmarkDistance = "";
    this.showToast(`"${name}" added to nearby places!`, "success");
  }
  removeLandmark(index) {
    this.customLandmarks.splice(index, 1);
  }
  initCategoryDefaults(cat) {
    this.availableAmenities = [...this.defaultAmenitiesByCat[cat]];
    this.selectedAmenities = this.availableAmenities.slice(0, 3);
    if (cat === "buy_plot") {
      if (this.possessionStatus === "Under Construction") {
        this.possessionStatus = "Under Development";
      }
    } else if (cat === "buy_land") {
      this.possessionStatus = "Immediate";
    } else {
      if (this.possessionStatus === "Under Development") {
        this.possessionStatus = "Ready to Move";
      }
    }
  }
  prefillUserLocation() {
    try {
      const saved = localStorage.getItem("location");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.city)
          this.city = parsed.city;
        if (parsed.address) {
          this.locality = parsed.area || parsed.address.split(",")[0] || "";
          this.fullAddress = parsed.address;
        }
        if (parsed.lat && parsed.lng) {
          this.coordinates = { lat: Number(parsed.lat), lng: Number(parsed.lng) };
        }
      }
    } catch {
    }
    try {
      const user = localStorage.getItem("user");
      if (user) {
        const parsed = JSON.parse(user);
        if (parsed.name)
          this.sellerName = parsed.name;
        if (parsed.phone) {
          this.sellerPhone = parsed.phone;
          this.sellerWhatsapp = parsed.phone;
        }
      }
    } catch {
    }
  }
  goBack() {
    this.navCtrl.navigateBack("/layout/property");
  }
  onCategoryChange(cat) {
    this.category = cat;
    const availableTypes = this.typeOptionsByCat[cat];
    if (availableTypes && availableTypes.length > 0) {
      this.propertyType = availableTypes[0];
    }
    this.initCategoryDefaults(cat);
  }
  toggleAmenity(amenity) {
    const idx = this.selectedAmenities.indexOf(amenity);
    if (idx > -1) {
      this.selectedAmenities.splice(idx, 1);
    } else {
      this.selectedAmenities.push(amenity);
    }
  }
  isAmenitySelected(amenity) {
    return this.selectedAmenities.includes(amenity);
  }
  addCustomAmenity() {
    const trimmed = this.customAmenityInput.trim();
    if (!trimmed)
      return;
    if (!this.availableAmenities.includes(trimmed)) {
      this.availableAmenities.push(trimmed);
    }
    if (!this.selectedAmenities.includes(trimmed)) {
      this.selectedAmenities.push(trimmed);
    }
    this.customAmenityInput = "";
    this.showToast(`"${trimmed}" added to amenities`, "success");
  }
  addCustomLegalDoc() {
    const trimmed = this.newCustomDocTitle.trim();
    if (!trimmed) {
      this.showToast("Please enter document title.", "warning");
      return;
    }
    const details = this.newCustomDocDetails.trim() || "Verified document by property owner";
    this.customLegalDocs.push({
      title: trimmed,
      category: this.newCustomDocCategory.trim() || "Custom Document",
      details,
      clear: true
    });
    this.newCustomDocTitle = "";
    this.newCustomDocDetails = "";
    this.showToast(`"${trimmed}" added to legal documents`, "success");
  }
  removeCustomLegalDoc(index) {
    this.customLegalDocs.splice(index, 1);
  }
  selectPhotoSource() {
    return __async(this, null, function* () {
      const actionSheet = yield this.actionSheetCtrl.create({
        header: "Upload Property Photo",
        subHeader: "Choose photo from gallery or snap with camera",
        buttons: [
          {
            text: "Choose from Gallery",
            icon: "images-outline",
            handler: () => {
              this.pickPhotoFromSource(CameraSource.Photos);
            }
          },
          {
            text: "Take a Photo",
            icon: "camera-outline",
            handler: () => {
              this.pickPhotoFromSource(CameraSource.Camera);
            }
          },
          {
            text: "Cancel",
            icon: "close-outline",
            role: "cancel"
          }
        ]
      });
      yield actionSheet.present();
    });
  }
  pickPhotoFromSource(source) {
    return __async(this, null, function* () {
      try {
        const image = yield Camera.getPhoto({
          quality: 85,
          allowEditing: false,
          resultType: CameraResultType.DataUrl,
          source
        });
        if (image && image.dataUrl) {
          this.imageUrls.push(image.dataUrl);
          this.showToast("Photo added successfully!", "success");
        }
      } catch (err) {
        console.warn("Camera/Gallery action cancelled or unavailable, falling back to file picker:", err);
        if ((err == null ? void 0 : err.message) !== "User cancelled photos app" && (err == null ? void 0 : err.message) !== "User cancelled") {
          this.triggerFileInput(source === CameraSource.Camera ? "camera" : "gallery");
        }
      }
    });
  }
  triggerFileInput(type) {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    if (type === "camera") {
      input.capture = "environment";
    }
    input.onchange = (e) => {
      var _a, _b;
      const file = (_b = (_a = e.target) == null ? void 0 : _a.files) == null ? void 0 : _b[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
          var _a2;
          if ((_a2 = event.target) == null ? void 0 : _a2.result) {
            this.imageUrls.push(event.target.result);
            this.showToast("Photo added successfully!", "success");
          }
        };
        reader.readAsDataURL(file);
      }
    };
    input.click();
  }
  addImage() {
    if (this.newImageUrl.trim()) {
      this.imageUrls.push(this.newImageUrl.trim());
      this.newImageUrl = "";
      this.showToast("Photo URL added!", "success");
    }
  }
  removeImage(index) {
    if (this.imageUrls.length > 0) {
      this.imageUrls.splice(index, 1);
    }
  }
  onYoutubeUrlChange() {
    this.youtubeVideoId = this.extractYouTubeId(this.youtubeUrl);
  }
  extractYouTubeId(url) {
    if (!url)
      return null;
    const cleanUrl = url.trim();
    const regExp = /(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=|shorts\/))([\w-]{11})/;
    const match = cleanUrl.match(regExp);
    if (match && match[1]) {
      return match[1];
    }
    if (/^[a-zA-Z0-9_-]{11}$/.test(cleanUrl)) {
      return cleanUrl;
    }
    return null;
  }
  submitProperty() {
    return __async(this, null, function* () {
      if (!this.title.trim()) {
        this.showToast("Please provide a property title or headline.", "warning");
        return;
      }
      if (!this.price || this.price <= 0) {
        this.showToast("Please enter a valid price/rent.", "warning");
        return;
      }
      if (!this.locality.trim()) {
        this.showToast("Please enter the locality or area.", "warning");
        return;
      }
      if (!this.fullAddress.trim() || !this.coordinates) {
        this.showToast("Please pin property location on the map to set address & coordinates.", "warning");
        return;
      }
      if (this.category === "buy_land") {
        if ((!this.totalAcres || this.totalAcres <= 0) && (!this.superBuiltUpArea || this.superBuiltUpArea <= 0)) {
          this.showToast("Please enter the total land acreage or sq.ft area.", "warning");
          return;
        }
      } else {
        if (!this.superBuiltUpArea || this.superBuiltUpArea <= 0) {
          this.showToast("Please enter the super built-up area in sq.ft.", "warning");
          return;
        }
      }
      if (!this.sellerName.trim()) {
        this.showToast("Please enter your name.", "warning");
        return;
      }
      if (!this.sellerPhone.trim()) {
        this.showToast("Please enter your contact phone number.", "warning");
        return;
      }
      this.isSubmitting = true;
      const calcArea = this.superBuiltUpArea && this.superBuiltUpArea > 0 ? this.superBuiltUpArea : this.totalAcres ? Math.round(this.totalAcres * 43560) : 1e3;
      let priceDisp = "";
      let unitDisp = "";
      if (this.category === "rent_house") {
        priceDisp = `\u20B9${this.price.toLocaleString("en-IN")}`;
        unitDisp = "/mo";
      } else if (this.price >= 1e7) {
        priceDisp = `\u20B9${(this.price / 1e7).toFixed(2)} Cr`;
      } else if (this.price >= 1e5) {
        priceDisp = `\u20B9${(this.price / 1e5).toFixed(1)} L`;
      } else {
        priceDisp = `\u20B9${this.price.toLocaleString("en-IN")}`;
      }
      const priceSqFt = `\u20B9${Math.round(this.price / calcArea).toLocaleString("en-IN")} / sq.ft`;
      const emi = this.category !== "rent_house" ? `\u20B9${Math.round(this.price * 75e-4).toLocaleString("en-IN")}/mo` : void 0;
      let legalChecks = [];
      if (this.category === "rent_house") {
        legalChecks = [
          {
            title: "Registered Rental Agreement",
            category: "Rental Agreement",
            status: this.rentAgreementReady ? "clear" : "pending",
            statusLabel: this.rentAgreementReady ? "Draft Ready" : "Pending",
            details: "Standard 11-month bilingual rental agreement ready for execution."
          },
          {
            title: "Owner NOC & ID Proof",
            category: "Ownership Verification",
            status: this.nocOwnerClear ? "clear" : "pending",
            statusLabel: this.nocOwnerClear ? "Verified" : "Pending",
            details: "Verified owner identity card, electricity bill, and tenancy permission."
          },
          {
            title: "Police Tenant Verification Form",
            category: "Safety & Verification",
            status: this.policeVerificationReady ? "clear" : "pending",
            statusLabel: this.policeVerificationReady ? "Available" : "Pending",
            details: "Assistance with local police verification form and record keeping."
          }
        ];
      } else {
        legalChecks = [
          {
            title: "Title Deed & Ownership Proof",
            category: "Ownership Verification",
            status: this.titleDeedClear ? "clear" : "pending",
            statusLabel: this.titleDeedClear ? "Clear Title" : "Under Process",
            details: "Registered Sale Deed with unbroken chain of title records."
          },
          {
            title: this.category === "buy_land" || this.category === "buy_plot" ? "7/12 RTC & Mutation" : "Khata Certificate",
            category: "Revenue Records",
            status: this.khataClear ? "clear" : "pending",
            statusLabel: this.khataClear ? this.category === "buy_land" ? "Clear RTC" : "A-Khata Verified" : "Under Process",
            details: this.category === "buy_land" ? "Updated RTC record with cultivator and ownership rights." : "Town Municipal Council (TMC) / Revenue record assessed."
          },
          {
            title: "Encumbrance Certificate (EC)",
            category: "Legal Clearance",
            status: this.ecClear ? "clear" : "pending",
            statusLabel: this.ecClear ? "Clear (15 Years)" : "Under Verification",
            details: "Nil Encumbrance Certificate verified free of bank/legal dues."
          },
          {
            title: this.category === "buy_land" || this.category === "buy_plot" ? "DC Conversion (NA Order)" : "Sanctioned Plan / DC Order",
            category: "Government Approvals",
            status: this.planApproved ? "clear" : "pending",
            statusLabel: this.planApproved ? "Approved" : "Under Review",
            details: this.category === "buy_land" ? "Revenue conversion status and agricultural demarcation verified." : "Approved layout sanction by Town Planning authority."
          },
          {
            title: "Property Tax Receipts",
            category: "Tax Compliance",
            status: this.taxPaid ? "clear" : "pending",
            statusLabel: this.taxPaid ? "Paid (2025-26)" : "Due",
            details: "Municipal or Gram Panchayat property tax assessed and paid up to date."
          }
        ];
        if (this.category === "buy_house") {
          legalChecks.push({
            title: "Occupancy Certificate (OC)",
            category: "Possession & Compliance",
            status: this.ocAvailable ? "clear" : "pending",
            statusLabel: this.ocAvailable ? "OC Issued" : "Under Process",
            details: this.ocAvailable ? "TMC issued OC verified." : "Occupancy Certificate under process with TMC."
          });
        }
        legalChecks.push({
          title: "Bank Loan Eligibility",
          category: "Finance Clearance",
          status: this.bankLoanEligible ? "clear" : "pending",
          statusLabel: this.bankLoanEligible ? "Pre-Approved" : "Applicable",
          details: "Pre-approved for fast loans with leading nationalized banks."
        });
      }
      for (const customDoc of this.customLegalDocs) {
        legalChecks.push({
          title: customDoc.title,
          category: customDoc.category,
          status: customDoc.clear ? "clear" : "pending",
          statusLabel: customDoc.clear ? "Verified" : "Pending",
          details: customDoc.details || `Custom document verified by ${this.sellerName.trim() || "Owner"}.`
        });
      }
      const newProperty = {
        id: `prop-user-${Date.now()}`,
        category: this.category,
        propertyType: this.propertyType,
        title: this.title.trim(),
        price: this.price,
        priceDisplay: priceDisp,
        priceUnit: unitDisp || void 0,
        pricePerSqFt: priceSqFt,
        emiEstimate: emi,
        securityDeposit: this.category === "rent_house" && this.securityDeposit ? this.securityDeposit : void 0,
        maintenancePerMonth: this.category === "rent_house" && this.maintenancePerMonth ? this.maintenancePerMonth : void 0,
        locality: this.locality.trim(),
        city: this.city.trim() || "Jamkhandi",
        fullAddress: this.fullAddress.trim() || `${this.locality.trim()}, ${this.city.trim()}`,
        coordinates: this.coordinates || void 0,
        images: this.imageUrls.length > 0 ? [...this.imageUrls] : [
          "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80"
        ],
        videoUrl: this.youtubeUrl.trim() || void 0,
        youtubeUrl: this.youtubeUrl.trim() || void 0,
        bedrooms: this.category === "buy_house" || this.category === "rent_house" ? this.bedrooms : void 0,
        bathrooms: this.category === "buy_house" || this.category === "rent_house" ? this.bathrooms : void 0,
        carpetAreaSqFt: this.carpetArea || Math.round(calcArea * 0.82),
        superBuiltUpAreaSqFt: calcArea,
        totalAcres: this.category === "buy_land" && this.totalAcres ? this.totalAcres : void 0,
        facing: this.facing,
        furnishing: this.furnishing,
        possessionStatus: this.possessionStatus,
        floor: this.category === "buy_land" || this.category === "buy_plot" ? void 0 : this.floor,
        parking: this.category === "buy_land" || this.category === "buy_plot" ? void 0 : this.parking,
        waterSupply: this.waterSupply,
        tags: ["Verified", "Direct Owner", "New Listing"],
        description: this.description.trim() || `${this.title} in prime locality of ${this.locality}, ${this.city}. Offers excellent connectivity, peaceful surroundings, and verified legal documentation.`,
        amenities: [...this.selectedAmenities],
        nearbyLandmarks: this.customLandmarks.length > 0 ? [...this.customLandmarks] : [],
        seller: {
          name: this.sellerName.trim(),
          type: this.sellerType,
          phone: this.sellerPhone.trim(),
          whatsapp: (this.sellerWhatsapp || this.sellerPhone).replace(/[^0-9]/g, ""),
          verified: true
        },
        legalChecks,
        isFavorite: false,
        is_verified: false,
        status: "pending_verification"
      };
      this.propertyService.createProperty(newProperty).subscribe({
        next: (res) => __async(this, null, function* () {
          this.isSubmitting = false;
          yield this.showToast((res == null ? void 0 : res.message) || "Property submitted! It is now Pending Verification and will be live once approved.", "success");
          this.router.navigate(["/layout/property"]);
        }),
        error: (err) => __async(this, null, function* () {
          console.warn("Property registration error:", err);
          this.isSubmitting = false;
          yield this.showToast("Property submitted! It is now Pending Verification and will be live once approved.", "success");
          this.router.navigate(["/layout/property"]);
        })
      });
    });
  }
  showToast(message, color) {
    return __async(this, null, function* () {
      const toast = yield this.toastCtrl.create({
        message,
        duration: 2500,
        position: "top",
        color
      });
      yield toast.present();
    });
  }
};
_PropertyRegisterPage.\u0275fac = function PropertyRegisterPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _PropertyRegisterPage)(\u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(ActivatedRoute), \u0275\u0275directiveInject(ToastController), \u0275\u0275directiveInject(LocationService), \u0275\u0275directiveInject(PropertyService), \u0275\u0275directiveInject(ActionSheetController), \u0275\u0275directiveInject(ChangeDetectorRef), \u0275\u0275directiveInject(NgZone));
};
_PropertyRegisterPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _PropertyRegisterPage, selectors: [["app-property-register"]], decls: 283, vars: 49, consts: [[1, "register-header", "ion-no-border"], [1, "register-toolbar"], [1, "header-inner"], ["type", "button", "aria-label", "Go Back", 1, "btn-back", 3, "click"], ["name", "arrow-back-outline"], [1, "header-title-col"], [1, "header-title"], [1, "header-subtitle"], [1, "register-content", 3, "fullscreen"], [1, "register-form-container"], [1, "form-card"], [1, "card-header-row"], [1, "card-num"], [1, "card-title-col"], [1, "card-title"], [1, "card-subtitle"], [1, "category-grid"], ["type", "button", 1, "cat-choice-btn", 3, "active"], [1, "input-field-group", "mt-3"], [1, "field-label"], [1, "type-chips-row"], ["type", "button", 1, "type-pill-chip", 3, "active"], [1, "input-field-group"], ["for", "propTitle", 1, "field-label"], ["type", "text", "id", "propTitle", "placeholder", "e.g. 3 BHK Luxury Duplex Villa in Girinagar", 1, "form-text-input", 3, "ngModelChange", "ngModel"], ["for", "propDesc", 1, "field-label"], ["id", "propDesc", "rows", "3", "placeholder", "Highlight unique features, road connectivity, water availability, ventilation, neighborhood...", 1, "form-textarea", 3, "ngModelChange", "ngModel"], ["for", "propPrice", 1, "field-label"], [1, "price-input-wrapper"], [1, "currency-symbol"], ["type", "number", "id", "propPrice", 1, "form-text-input", "price-input", 3, "ngModelChange", "placeholder", "ngModel"], [1, "row-two-inputs", "mt-3"], [1, "toggle-row", "mt-3", 3, "click"], [1, "toggle-text-col"], [1, "toggle-label"], [1, "toggle-sub"], [1, "custom-switch"], [1, "switch-handle"], [1, "map-picker-cta-card", 3, "click"], [1, "cta-left"], [1, "cta-icon-box"], [3, "name"], [1, "cta-text-col"], [1, "cta-title"], [1, "cta-sub"], ["type", "button", 1, "btn-cta-map", 3, "click"], ["name", "navigate-outline"], [1, "field-label-row"], [1, "coords-pill"], [1, "address-input-readonly", 3, "click"], ["name", "lock-closed-outline", 1, "readonly-lock-icon"], ["type", "text", "placeholder", "Location not pinned. Tap to drop pin on map", 1, "form-text-input", "readonly-input", 3, "ngModelChange", "readonly", "ngModel"], [1, "input-field-group", "flex-1"], ["type", "text", "placeholder", "Jamkhandi", 1, "form-text-input", 3, "ngModelChange", "ngModel"], ["type", "text", "placeholder", "e.g. Girinagar Layout", 1, "form-text-input", 3, "ngModelChange", "ngModel"], [1, "landmarks-list-container"], [1, "custom-entry-card", "mt-3"], [1, "custom-entry-header-title"], [1, "landmark-type-pills"], ["type", "button", 1, "landmark-type-pill", 3, "active"], [1, "row-two-inputs", "mt-2"], ["type", "text", "placeholder", "e.g. City Central Bus Stand, KSRTC", 1, "form-text-input", 3, "ngModelChange", "keyup.enter", "ngModel"], [1, "input-field-group", "landmark-dist-input"], ["type", "text", "placeholder", "e.g. 500 m", 1, "form-text-input", 3, "ngModelChange", "keyup.enter", "ngModel"], ["type", "button", 1, "btn-custom-add-block", "mt-3", 3, "click", "disabled"], ["name", "add-outline"], [1, "row-two-inputs"], [1, "chips-number-selector"], ["type", "button", 1, "num-chip", 3, "active"], ["type", "text", 1, "form-text-input", 3, "ngModelChange", "ngModel", "placeholder"], [1, "amenities-selection-grid"], [1, "amenity-selectable-card", 3, "selected"], [1, "custom-add-row", "mt-2"], ["type", "text", "placeholder", "e.g. 3-Phase Power, Solar Inverter, EV Charger", 1, "form-text-input", "flex-1", 3, "ngModelChange", "keyup.enter", "ngModel"], ["type", "button", 1, "btn-custom-add", 3, "click", "disabled"], [1, "legal-toggles-stack"], [1, "doc-toggle-row", "custom-added-doc"], [1, "input-field-group", "mt-2"], ["type", "text", "placeholder", "e.g. Gram Panchayat NOC, TMC Conversion Order", 1, "form-text-input", 3, "ngModelChange", "keyup.enter", "ngModel"], ["type", "text", "placeholder", "e.g. Issued in 2024 with valid seal and survey demarcation", 1, "form-text-input", 3, "ngModelChange", "keyup.enter", "ngModel"], [1, "image-previews-grid"], [1, "image-thumb-card"], ["type", "button", "aria-label", "Upload photo from gallery or camera", 1, "btn-upload-photo-card", 3, "click"], [1, "upload-icon-circle"], [1, "upload-btn-label"], [1, "add-image-url-row", "mt-3"], ["type", "url", "placeholder", "Or paste web photo URL (https://...)", 1, "form-text-input", "flex-1", 3, "ngModelChange", "keyup.enter", "ngModel"], ["type", "button", 1, "btn-add-img", 3, "click", "disabled"], [1, "youtube-section-box", "mt-4"], [1, "youtube-header-row"], [1, "yt-icon-badge"], ["name", "logo-youtube"], [1, "yt-label-col"], [1, "field-label", "mb-0"], [1, "yt-helper-text"], [1, "youtube-input-wrap", "mt-2"], ["type", "url", "placeholder", "e.g. https://www.youtube.com/watch?v=... or https://youtu.be/...", 1, "form-text-input", "yt-input", 3, "ngModelChange", "ngModel"], ["type", "button", "aria-label", "Clear YouTube URL", 1, "btn-clear-yt"], [1, "yt-preview-card", "mt-3"], ["type", "text", "placeholder", "Full Name", 1, "form-text-input", 3, "ngModelChange", "ngModel"], ["type", "tel", "placeholder", "+91 98765 43210", 1, "form-text-input", 3, "ngModelChange", "ngModel"], [1, "bottom-form-spacer"], [1, "sticky-register-footer"], ["type", "button", 1, "btn-submit-property", 3, "click", "disabled"], ["type", "button", 1, "cat-choice-btn", 3, "click"], [1, "cat-icon", 3, "name"], [1, "cat-label"], ["name", "checkmark-circle", 1, "cat-active-check"], ["type", "button", 1, "type-pill-chip", 3, "click"], ["type", "number", "placeholder", "e.g. 50000", 1, "form-text-input", "price-input", 3, "ngModelChange", "ngModel"], ["type", "number", "placeholder", "e.g. 1500", 1, "form-text-input", "price-input", 3, "ngModelChange", "ngModel"], ["name", "location-outline"], [1, "landmark-entry-item"], [1, "lm-entry-left"], [1, "lm-type-icon-box"], [1, "lm-entry-info"], [1, "lm-entry-name"], [1, "lm-entry-type-tag"], [1, "lm-entry-right"], [1, "lm-distance-badge"], ["type", "button", "aria-label", "Remove landmark", 1, "btn-del-landmark", 3, "click"], ["name", "trash-outline"], ["type", "button", 1, "landmark-type-pill", 3, "click"], ["type", "number", "step", "0.01", "placeholder", "e.g. 2.5 Acres", 1, "form-text-input", 3, "ngModelChange", "ngModel"], ["type", "number", "placeholder", "e.g. 108900 sq.ft", 1, "form-text-input", 3, "ngModelChange", "ngModel"], ["type", "number", "placeholder", "e.g. 1850", 1, "form-text-input", 3, "ngModelChange", "ngModel"], ["type", "number", "placeholder", "e.g. 1200", 1, "form-text-input", 3, "ngModelChange", "ngModel"], ["type", "button", 1, "num-chip", 3, "click"], ["type", "text", "placeholder", "e.g. G+1 Villa", 1, "form-text-input", 3, "ngModelChange", "ngModel"], ["type", "text", "placeholder", "Covered Car Parking", 1, "form-text-input", 3, "ngModelChange", "ngModel"], [1, "amenity-selectable-card", 3, "click"], [1, "amenity-icon-box"], [1, "amenity-name"], [1, "doc-toggle-row", 3, "click"], [1, "doc-info-col"], [1, "doc-title"], [1, "doc-desc"], [1, "doc-toggle-row"], [1, "doc-info-col", 3, "click"], [1, "doc-title-row"], [1, "doc-category-badge"], [1, "custom-doc-right-col"], [1, "custom-switch", 3, "click"], ["type", "button", "aria-label", "Remove document", 1, "btn-remove-custom-doc", 3, "click"], ["alt", "Property Photo", 1, "thumb-pic", 3, "src"], ["type", "button", "aria-label", "Remove photo", 1, "btn-del-pic", 3, "click"], ["type", "button", "aria-label", "Clear YouTube URL", 1, "btn-clear-yt", 3, "click"], ["name", "close-outline"], [1, "yt-preview-thumb-wrap"], ["alt", "YouTube Preview", 1, "yt-preview-thumb", 3, "src"], [1, "yt-play-pill"], ["name", "play-circle"], [1, "yt-preview-info"], [1, "yt-preview-badge"], [1, "yt-preview-id"], ["name", "sparkles"]], template: function PropertyRegisterPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar", 1)(2, "div", 2)(3, "button", 3);
    \u0275\u0275listener("click", function PropertyRegisterPage_Template_button_click_3_listener() {
      return ctx.goBack();
    });
    \u0275\u0275element(4, "ion-icon", 4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 5)(6, "h1", 6);
    \u0275\u0275text(7, "Post Your Property");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "span", 7);
    \u0275\u0275text(9, "Zero brokerage \u2022 Direct verified buyers");
    \u0275\u0275elementEnd()()()()();
    \u0275\u0275elementStart(10, "ion-content", 8)(11, "main", 9)(12, "section", 10)(13, "div", 11)(14, "div", 12);
    \u0275\u0275text(15, "1");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "div", 13)(17, "h2", 14);
    \u0275\u0275text(18, "Property Category");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(19, "span", 15);
    \u0275\u0275text(20, "What type of property do you want to list?");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(21, "div", 16);
    \u0275\u0275repeaterCreate(22, PropertyRegisterPage_For_23_Template, 5, 5, "button", 17, _forTrack0);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(24, "div", 18)(25, "label", 19);
    \u0275\u0275text(26, "Property Sub-Type *");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(27, "div", 20);
    \u0275\u0275repeaterCreate(28, PropertyRegisterPage_For_29_Template, 2, 3, "button", 21, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(30, "section", 10)(31, "div", 11)(32, "div", 12);
    \u0275\u0275text(33, "2");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(34, "div", 13)(35, "h2", 14);
    \u0275\u0275text(36, "Basic Details");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(37, "span", 15);
    \u0275\u0275text(38, "Give your property an attractive headline");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(39, "div", 22)(40, "label", 23);
    \u0275\u0275text(41, "Property Title / Headline *");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(42, "input", 24);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyRegisterPage_Template_input_ngModelChange_42_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.title, $event) || (ctx.title = $event);
      return $event;
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(43, "div", 18)(44, "label", 25);
    \u0275\u0275text(45, "Detailed Description");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(46, "textarea", 26);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyRegisterPage_Template_textarea_ngModelChange_46_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.description, $event) || (ctx.description = $event);
      return $event;
    });
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(47, "section", 10)(48, "div", 11)(49, "div", 12);
    \u0275\u0275text(50, "3");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(51, "div", 13)(52, "h2", 14);
    \u0275\u0275text(53, "Pricing");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(54, "span", 15);
    \u0275\u0275text(55, "Set your expected price or monthly rent");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(56, "div", 22)(57, "label", 27);
    \u0275\u0275text(58);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(59, "div", 28)(60, "span", 29);
    \u0275\u0275text(61, "\u20B9");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(62, "input", 30);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyRegisterPage_Template_input_ngModelChange_62_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.price, $event) || (ctx.price = $event);
      return $event;
    });
    \u0275\u0275elementEnd()()();
    \u0275\u0275template(63, PropertyRegisterPage_Conditional_63_Template, 15, 2, "div", 31);
    \u0275\u0275elementStart(64, "div", 32);
    \u0275\u0275listener("click", function PropertyRegisterPage_Template_div_click_64_listener() {
      return ctx.priceNegotiable = !ctx.priceNegotiable;
    });
    \u0275\u0275elementStart(65, "div", 33)(66, "span", 34);
    \u0275\u0275text(67, "Price is Negotiable");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(68, "span", 35);
    \u0275\u0275text(69, "Buyers and tenants are more likely to contact negotiable listings");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(70, "div", 36);
    \u0275\u0275element(71, "div", 37);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(72, "section", 10)(73, "div", 11)(74, "div", 12);
    \u0275\u0275text(75, "4");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(76, "div", 13)(77, "h2", 14);
    \u0275\u0275text(78, "Location & Address");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(79, "span", 15);
    \u0275\u0275text(80, "Pin exact property spot on map to auto-fetch address & GPS");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(81, "div", 38);
    \u0275\u0275listener("click", function PropertyRegisterPage_Template_div_click_81_listener() {
      return ctx.openMapPicker();
    });
    \u0275\u0275elementStart(82, "div", 39)(83, "div", 40);
    \u0275\u0275element(84, "ion-icon", 41);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(85, "div", 42)(86, "span", 43);
    \u0275\u0275text(87);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(88, "span", 44);
    \u0275\u0275text(89);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(90, "button", 45);
    \u0275\u0275listener("click", function PropertyRegisterPage_Template_button_click_90_listener($event) {
      ctx.openMapPicker();
      return $event.stopPropagation();
    });
    \u0275\u0275element(91, "ion-icon", 46);
    \u0275\u0275elementStart(92, "span");
    \u0275\u0275text(93);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(94, "div", 18)(95, "div", 47)(96, "label", 19);
    \u0275\u0275text(97, "Full Address / Landmark (Acquired from Map) *");
    \u0275\u0275elementEnd();
    \u0275\u0275template(98, PropertyRegisterPage_Conditional_98_Template, 3, 2, "span", 48);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(99, "div", 49);
    \u0275\u0275listener("click", function PropertyRegisterPage_Template_div_click_99_listener() {
      return ctx.openMapPicker();
    });
    \u0275\u0275element(100, "ion-icon", 50);
    \u0275\u0275elementStart(101, "input", 51);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyRegisterPage_Template_input_ngModelChange_101_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.fullAddress, $event) || (ctx.fullAddress = $event);
      return $event;
    });
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(102, "div", 31)(103, "div", 52)(104, "label", 19);
    \u0275\u0275text(105, "City *");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(106, "input", 53);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyRegisterPage_Template_input_ngModelChange_106_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.city, $event) || (ctx.city = $event);
      return $event;
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(107, "div", 52)(108, "label", 19);
    \u0275\u0275text(109, "Locality / Area *");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(110, "input", 54);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyRegisterPage_Template_input_ngModelChange_110_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.locality, $event) || (ctx.locality = $event);
      return $event;
    });
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(111, "section", 10)(112, "div", 11)(113, "div", 12);
    \u0275\u0275text(114, "5");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(115, "div", 13)(116, "h2", 14);
    \u0275\u0275text(117, "Nearby Places & Connectivity");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(118, "span", 15);
    \u0275\u0275text(119, "Highlight nearby schools, hospitals, transit, markets etc.");
    \u0275\u0275elementEnd()()();
    \u0275\u0275template(120, PropertyRegisterPage_Conditional_120_Template, 3, 0, "div", 55);
    \u0275\u0275elementStart(121, "div", 56)(122, "span", 57);
    \u0275\u0275text(123, "Enter Nearby Landmark");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(124, "div", 58);
    \u0275\u0275repeaterCreate(125, PropertyRegisterPage_For_126_Template, 4, 4, "button", 59, _forTrack0);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(127, "div", 60)(128, "div", 52)(129, "label", 19);
    \u0275\u0275text(130, "Landmark / Place Name");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(131, "input", 61);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyRegisterPage_Template_input_ngModelChange_131_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.newLandmarkName, $event) || (ctx.newLandmarkName = $event);
      return $event;
    });
    \u0275\u0275listener("keyup.enter", function PropertyRegisterPage_Template_input_keyup_enter_131_listener() {
      return ctx.addLandmark();
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(132, "div", 62)(133, "label", 19);
    \u0275\u0275text(134, "Distance");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(135, "input", 63);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyRegisterPage_Template_input_ngModelChange_135_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.newLandmarkDistance, $event) || (ctx.newLandmarkDistance = $event);
      return $event;
    });
    \u0275\u0275listener("keyup.enter", function PropertyRegisterPage_Template_input_keyup_enter_135_listener() {
      return ctx.addLandmark();
    });
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(136, "button", 64);
    \u0275\u0275listener("click", function PropertyRegisterPage_Template_button_click_136_listener() {
      return ctx.addLandmark();
    });
    \u0275\u0275element(137, "ion-icon", 65);
    \u0275\u0275elementStart(138, "span");
    \u0275\u0275text(139, "Add Nearby Landmark");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(140, "section", 10)(141, "div", 11)(142, "div", 12);
    \u0275\u0275text(143, "6");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(144, "div", 13)(145, "h2", 14);
    \u0275\u0275text(146, "Dimensions & Specifications");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(147, "span", 15);
    \u0275\u0275text(148, "Area, rooms, facing and condition");
    \u0275\u0275elementEnd()()();
    \u0275\u0275template(149, PropertyRegisterPage_Conditional_149_Template, 9, 2, "div", 66)(150, PropertyRegisterPage_Conditional_150_Template, 9, 4, "div", 66)(151, PropertyRegisterPage_Conditional_151_Template, 18, 3);
    \u0275\u0275elementStart(152, "div", 18)(153, "label", 19);
    \u0275\u0275text(154, "Facing Direction");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(155, "div", 67);
    \u0275\u0275repeaterCreate(156, PropertyRegisterPage_For_157_Template, 2, 3, "button", 68, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(158, PropertyRegisterPage_Conditional_158_Template, 6, 1, "div", 18)(159, PropertyRegisterPage_Conditional_159_Template, 9, 2, "div", 31);
    \u0275\u0275elementStart(160, "div", 18)(161, "label", 19);
    \u0275\u0275text(162, "Water Supply");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(163, "input", 69);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyRegisterPage_Template_input_ngModelChange_163_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.waterSupply, $event) || (ctx.waterSupply = $event);
      return $event;
    });
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(164, "section", 10)(165, "div", 11)(166, "div", 12);
    \u0275\u0275text(167, "7");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(168, "div", 13)(169, "h2", 14);
    \u0275\u0275text(170, "Features & Amenities");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(171, "span", 15);
    \u0275\u0275text(172, "Select all available amenities");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(173, "div", 70);
    \u0275\u0275repeaterCreate(174, PropertyRegisterPage_For_175_Template, 5, 4, "div", 71, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(176, "div", 56)(177, "span", 57);
    \u0275\u0275text(178, "Add Custom Feature / Amenity");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(179, "div", 72)(180, "input", 73);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyRegisterPage_Template_input_ngModelChange_180_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.customAmenityInput, $event) || (ctx.customAmenityInput = $event);
      return $event;
    });
    \u0275\u0275listener("keyup.enter", function PropertyRegisterPage_Template_input_keyup_enter_180_listener() {
      return ctx.addCustomAmenity();
    });
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(181, "button", 74);
    \u0275\u0275listener("click", function PropertyRegisterPage_Template_button_click_181_listener() {
      return ctx.addCustomAmenity();
    });
    \u0275\u0275element(182, "ion-icon", 65);
    \u0275\u0275elementStart(183, "span");
    \u0275\u0275text(184, "Add");
    \u0275\u0275elementEnd()()()()();
    \u0275\u0275elementStart(185, "section", 10)(186, "div", 11)(187, "div", 12);
    \u0275\u0275text(188, "8");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(189, "div", 13)(190, "h2", 14);
    \u0275\u0275text(191, "Docs & Legal Verification");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(192, "span", 15);
    \u0275\u0275text(193);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(194, "div", 75);
    \u0275\u0275template(195, PropertyRegisterPage_Conditional_195_Template, 24, 6)(196, PropertyRegisterPage_Conditional_196_Template, 49, 15);
    \u0275\u0275repeaterCreate(197, PropertyRegisterPage_For_198_Template, 14, 5, "div", 76, \u0275\u0275repeaterTrackByIndex);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(199, "div", 56)(200, "span", 57);
    \u0275\u0275text(201, "Add Custom Legal Document");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(202, "div", 77)(203, "label", 19);
    \u0275\u0275text(204, "Document Title *");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(205, "input", 78);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyRegisterPage_Template_input_ngModelChange_205_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.newCustomDocTitle, $event) || (ctx.newCustomDocTitle = $event);
      return $event;
    });
    \u0275\u0275listener("keyup.enter", function PropertyRegisterPage_Template_input_keyup_enter_205_listener() {
      return ctx.addCustomLegalDoc();
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(206, "div", 77)(207, "label", 19);
    \u0275\u0275text(208, "Document Details / Description");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(209, "input", 79);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyRegisterPage_Template_input_ngModelChange_209_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.newCustomDocDetails, $event) || (ctx.newCustomDocDetails = $event);
      return $event;
    });
    \u0275\u0275listener("keyup.enter", function PropertyRegisterPage_Template_input_keyup_enter_209_listener() {
      return ctx.addCustomLegalDoc();
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(210, "button", 64);
    \u0275\u0275listener("click", function PropertyRegisterPage_Template_button_click_210_listener() {
      return ctx.addCustomLegalDoc();
    });
    \u0275\u0275element(211, "ion-icon", 65);
    \u0275\u0275elementStart(212, "span");
    \u0275\u0275text(213, "Add Legal Document");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(214, "section", 10)(215, "div", 11)(216, "div", 12);
    \u0275\u0275text(217, "9");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(218, "div", 13)(219, "h2", 14);
    \u0275\u0275text(220, "Property Photos & Video Tour");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(221, "span", 15);
    \u0275\u0275text(222, "Listings with photos and YouTube video tours get 5x more calls");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(223, "div", 80);
    \u0275\u0275repeaterCreate(224, PropertyRegisterPage_For_225_Template, 4, 1, "div", 81, \u0275\u0275repeaterTrackByIndex);
    \u0275\u0275elementStart(226, "button", 82);
    \u0275\u0275listener("click", function PropertyRegisterPage_Template_button_click_226_listener() {
      return ctx.selectPhotoSource();
    });
    \u0275\u0275elementStart(227, "div", 83);
    \u0275\u0275element(228, "ion-icon", 65);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(229, "span", 84);
    \u0275\u0275text(230, "Add Photo");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(231, "div", 85)(232, "input", 86);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyRegisterPage_Template_input_ngModelChange_232_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.newImageUrl, $event) || (ctx.newImageUrl = $event);
      return $event;
    });
    \u0275\u0275listener("keyup.enter", function PropertyRegisterPage_Template_input_keyup_enter_232_listener() {
      return ctx.addImage();
    });
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(233, "button", 87);
    \u0275\u0275listener("click", function PropertyRegisterPage_Template_button_click_233_listener() {
      return ctx.addImage();
    });
    \u0275\u0275element(234, "ion-icon", 65);
    \u0275\u0275elementStart(235, "span");
    \u0275\u0275text(236, "Add");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(237, "div", 88)(238, "div", 89)(239, "div", 90);
    \u0275\u0275element(240, "ion-icon", 91);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(241, "div", 92)(242, "label", 93);
    \u0275\u0275text(243, "YouTube Video Tour URL (Optional)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(244, "span", 94);
    \u0275\u0275text(245, "Walk-through video or Shorts link");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(246, "div", 95)(247, "input", 96);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyRegisterPage_Template_input_ngModelChange_247_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.youtubeUrl, $event) || (ctx.youtubeUrl = $event);
      return $event;
    });
    \u0275\u0275listener("ngModelChange", function PropertyRegisterPage_Template_input_ngModelChange_247_listener() {
      return ctx.onYoutubeUrlChange();
    });
    \u0275\u0275elementEnd();
    \u0275\u0275template(248, PropertyRegisterPage_Conditional_248_Template, 2, 0, "button", 97);
    \u0275\u0275elementEnd();
    \u0275\u0275template(249, PropertyRegisterPage_Conditional_249_Template, 12, 2, "div", 98);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(250, "section", 10)(251, "div", 11)(252, "div", 12);
    \u0275\u0275text(253, "10");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(254, "div", 13)(255, "h2", 14);
    \u0275\u0275text(256, "Contact & Seller Info");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(257, "span", 15);
    \u0275\u0275text(258, "Who should interested buyers contact?");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(259, "div", 22)(260, "label", 19);
    \u0275\u0275text(261, "Your Name *");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(262, "input", 99);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyRegisterPage_Template_input_ngModelChange_262_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.sellerName, $event) || (ctx.sellerName = $event);
      return $event;
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(263, "div", 18)(264, "label", 19);
    \u0275\u0275text(265, "You Are Listing As");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(266, "div", 67);
    \u0275\u0275repeaterCreate(267, PropertyRegisterPage_For_268_Template, 2, 3, "button", 68, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(269, "div", 31)(270, "div", 52)(271, "label", 19);
    \u0275\u0275text(272, "Phone Number *");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(273, "input", 100);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyRegisterPage_Template_input_ngModelChange_273_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.sellerPhone, $event) || (ctx.sellerPhone = $event);
      return $event;
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(274, "div", 52)(275, "label", 19);
    \u0275\u0275text(276, "WhatsApp Number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(277, "input", 100);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyRegisterPage_Template_input_ngModelChange_277_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.sellerWhatsapp, $event) || (ctx.sellerWhatsapp = $event);
      return $event;
    });
    \u0275\u0275elementEnd()()()();
    \u0275\u0275element(278, "div", 101);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(279, "footer", 102)(280, "button", 103);
    \u0275\u0275listener("click", function PropertyRegisterPage_Template_button_click_280_listener() {
      return ctx.submitProperty();
    });
    \u0275\u0275template(281, PropertyRegisterPage_Conditional_281_Template, 2, 0, "span")(282, PropertyRegisterPage_Conditional_282_Template, 3, 0);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    \u0275\u0275advance(10);
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance(12);
    \u0275\u0275repeater(ctx.categoryOptions);
    \u0275\u0275advance(6);
    \u0275\u0275repeater(ctx.typeOptionsByCat[ctx.category]);
    \u0275\u0275advance(14);
    \u0275\u0275twoWayProperty("ngModel", ctx.title);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx.description);
    \u0275\u0275advance(12);
    \u0275\u0275textInterpolate1(" ", ctx.category === "rent_house" ? "Monthly Rent (\u20B9) *" : "Total Expected Price (\u20B9) *", " ");
    \u0275\u0275advance(4);
    \u0275\u0275property("placeholder", ctx.category === "rent_house" ? "e.g. 15000" : "e.g. 6850000");
    \u0275\u0275twoWayProperty("ngModel", ctx.price);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.category === "rent_house" ? 63 : -1);
    \u0275\u0275advance(7);
    \u0275\u0275classProp("on", ctx.priceNegotiable);
    \u0275\u0275advance(13);
    \u0275\u0275classProp("pinned", !!ctx.coordinates);
    \u0275\u0275advance();
    \u0275\u0275property("name", ctx.coordinates ? "checkmark-circle" : "map-outline");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" ", ctx.coordinates ? "Property Location Pinned" : "Pin Property on Map *", " ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" ", ctx.coordinates ? "Address & coordinates locked from map pin \u2022 Tap to change" : "Tap to open map and drop pin at exact property location", " ");
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx.coordinates ? "Change Pin" : "Pick on Map");
    \u0275\u0275advance(5);
    \u0275\u0275conditional(ctx.coordinates ? 98 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275property("readonly", true);
    \u0275\u0275twoWayProperty("ngModel", ctx.fullAddress);
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx.city);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx.locality);
    \u0275\u0275advance(10);
    \u0275\u0275conditional(ctx.customLandmarks.length > 0 ? 120 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275repeater(ctx.landmarkTypeOptions);
    \u0275\u0275advance(6);
    \u0275\u0275twoWayProperty("ngModel", ctx.newLandmarkName);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx.newLandmarkDistance);
    \u0275\u0275advance();
    \u0275\u0275property("disabled", !ctx.newLandmarkName.trim() || !ctx.newLandmarkDistance.trim());
    \u0275\u0275advance(13);
    \u0275\u0275conditional(ctx.category === "buy_land" ? 149 : 150);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx.category === "buy_house" || ctx.category === "rent_house" ? 151 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275repeater(\u0275\u0275pureFunction0(47, _c0));
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx.category !== "buy_land" ? 158 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.category === "buy_house" || ctx.category === "rent_house" ? 159 : -1);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx.waterSupply);
    \u0275\u0275property("placeholder", ctx.category === "buy_land" ? "Borewell / Canal / Open Well" : "24/7 Municipal & Borewell");
    \u0275\u0275advance(11);
    \u0275\u0275repeater(ctx.availableAmenities);
    \u0275\u0275advance(6);
    \u0275\u0275twoWayProperty("ngModel", ctx.customAmenityInput);
    \u0275\u0275advance();
    \u0275\u0275property("disabled", !ctx.customAmenityInput.trim());
    \u0275\u0275advance(12);
    \u0275\u0275textInterpolate1(" ", ctx.category === "rent_house" ? "Rental agreement & tenant onboarding status" : "Highlight clear documents for buyer trust", " ");
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx.category === "rent_house" ? 195 : 196);
    \u0275\u0275advance(2);
    \u0275\u0275repeater(ctx.customLegalDocs);
    \u0275\u0275advance(8);
    \u0275\u0275twoWayProperty("ngModel", ctx.newCustomDocTitle);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx.newCustomDocDetails);
    \u0275\u0275advance();
    \u0275\u0275property("disabled", !ctx.newCustomDocTitle.trim());
    \u0275\u0275advance(14);
    \u0275\u0275repeater(ctx.imageUrls);
    \u0275\u0275advance(8);
    \u0275\u0275twoWayProperty("ngModel", ctx.newImageUrl);
    \u0275\u0275advance();
    \u0275\u0275property("disabled", !ctx.newImageUrl.trim());
    \u0275\u0275advance(14);
    \u0275\u0275twoWayProperty("ngModel", ctx.youtubeUrl);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.youtubeUrl.trim() ? 248 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.youtubeVideoId ? 249 : -1);
    \u0275\u0275advance(13);
    \u0275\u0275twoWayProperty("ngModel", ctx.sellerName);
    \u0275\u0275advance(5);
    \u0275\u0275repeater(\u0275\u0275pureFunction0(48, _c1));
    \u0275\u0275advance(6);
    \u0275\u0275twoWayProperty("ngModel", ctx.sellerPhone);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx.sellerWhatsapp);
    \u0275\u0275advance(3);
    \u0275\u0275property("disabled", ctx.isSubmitting);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.isSubmitting ? 281 : 282);
  }
}, dependencies: [
  IonHeader,
  IonToolbar,
  IonContent,
  IonIcon,
  CommonModule,
  UpperCasePipe,
  FormsModule,
  DefaultValueAccessor,
  NumberValueAccessor,
  NgControlStatus,
  NgModel
], styles: ["\n\n.register-header[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-bottom: 1px solid #f1f5f9;\n  position: sticky;\n  top: 0;\n  z-index: 100;\n  padding-top: max(env(safe-area-inset-top, 0px), 16px);\n}\n.register-header[_ngcontent-%COMP%]   .register-toolbar[_ngcontent-%COMP%] {\n  --background: #ffffff;\n  --min-height: 56px;\n  --padding-start: 14px;\n  --padding-end: 14px;\n  padding: 2px 0 6px;\n}\n.register-header[_ngcontent-%COMP%]   .header-inner[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  width: 100%;\n  padding: 0 14px;\n}\n.register-header[_ngcontent-%COMP%]   .header-inner[_ngcontent-%COMP%]   .btn-back[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 38px;\n  border-radius: 50%;\n  background: #f8fafc;\n  border: 1.5px solid #e2e8f0;\n  color: #0f172a;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 19px;\n  cursor: pointer;\n  flex-shrink: 0;\n  transition: transform 0.15s ease;\n}\n.register-header[_ngcontent-%COMP%]   .header-inner[_ngcontent-%COMP%]   .btn-back[_ngcontent-%COMP%]:active {\n  transform: scale(0.92);\n}\n.register-header[_ngcontent-%COMP%]   .header-inner[_ngcontent-%COMP%]   .header-title-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n}\n.register-header[_ngcontent-%COMP%]   .header-inner[_ngcontent-%COMP%]   .header-title-col[_ngcontent-%COMP%]   .header-title[_ngcontent-%COMP%] {\n  font-size: 17px;\n  font-weight: 850;\n  color: #0f172a;\n  margin: 0;\n  letter-spacing: -0.3px;\n}\n.register-header[_ngcontent-%COMP%]   .header-inner[_ngcontent-%COMP%]   .header-title-col[_ngcontent-%COMP%]   .header-subtitle[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 600;\n  color: #64748b;\n}\n.register-content[_ngcontent-%COMP%] {\n  --background: #f8fafc;\n}\n.register-form-container[_ngcontent-%COMP%] {\n  padding: 14px;\n  display: flex;\n  flex-direction: column;\n  gap: 16px;\n}\n.form-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 20px;\n  border: 1.5px solid #f1f5f9;\n  padding: 16px;\n  box-shadow: 0 3px 12px rgba(15, 23, 42, 0.04);\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n}\n.form-card[_ngcontent-%COMP%]   .card-header-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  margin-bottom: 2px;\n}\n.form-card[_ngcontent-%COMP%]   .card-header-row[_ngcontent-%COMP%]   .card-num[_ngcontent-%COMP%] {\n  width: 26px;\n  height: 26px;\n  border-radius: 50%;\n  background: #fdf4ff;\n  border: 1.5px solid #f5d0fe;\n  color: #a000e2;\n  font-size: 12px;\n  font-weight: 850;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  flex-shrink: 0;\n}\n.form-card[_ngcontent-%COMP%]   .card-header-row[_ngcontent-%COMP%]   .card-title-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n.form-card[_ngcontent-%COMP%]   .card-header-row[_ngcontent-%COMP%]   .card-title-col[_ngcontent-%COMP%]   .card-title[_ngcontent-%COMP%] {\n  font-size: 14.5px;\n  font-weight: 850;\n  color: #0f172a;\n  margin: 0;\n  letter-spacing: -0.2px;\n}\n.form-card[_ngcontent-%COMP%]   .card-header-row[_ngcontent-%COMP%]   .card-title-col[_ngcontent-%COMP%]   .card-subtitle[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #64748b;\n  margin-top: 1px;\n}\n.form-card[_ngcontent-%COMP%]   .card-header-row.location-header-row[_ngcontent-%COMP%] {\n  justify-content: space-between;\n}\n.form-card[_ngcontent-%COMP%]   .card-header-row.location-header-row[_ngcontent-%COMP%]   .card-title-col[_ngcontent-%COMP%] {\n  flex: 1;\n}\n.form-card[_ngcontent-%COMP%]   .card-header-row.location-header-row[_ngcontent-%COMP%]   .btn-pick-map-header[_ngcontent-%COMP%] {\n  background: #fdf4ff;\n  border: 1.5px solid #f5d0fe;\n  color: #a000e2;\n  border-radius: 10px;\n  padding: 6px 12px;\n  font-size: 11.5px;\n  font-weight: 800;\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n.form-card[_ngcontent-%COMP%]   .card-header-row.location-header-row[_ngcontent-%COMP%]   .btn-pick-map-header[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 16px;\n}\n.form-card[_ngcontent-%COMP%]   .card-header-row.location-header-row[_ngcontent-%COMP%]   .btn-pick-map-header[_ngcontent-%COMP%]:active {\n  transform: scale(0.95);\n  background: #a000e2;\n  color: #ffffff;\n}\n.category-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 10px;\n}\n.category-grid[_ngcontent-%COMP%]   .cat-choice-btn[_ngcontent-%COMP%] {\n  border: 1.5px solid #e2e8f0;\n  background: #f8fafc;\n  border-radius: 14px;\n  padding: 12px 10px;\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  cursor: pointer;\n  position: relative;\n  transition: all 0.2s ease;\n}\n.category-grid[_ngcontent-%COMP%]   .cat-choice-btn[_ngcontent-%COMP%]   .cat-icon[_ngcontent-%COMP%] {\n  font-size: 20px;\n  color: #64748b;\n  flex-shrink: 0;\n}\n.category-grid[_ngcontent-%COMP%]   .cat-choice-btn[_ngcontent-%COMP%]   .cat-label[_ngcontent-%COMP%] {\n  font-size: 12.5px;\n  font-weight: 750;\n  color: #334155;\n  text-align: left;\n}\n.category-grid[_ngcontent-%COMP%]   .cat-choice-btn[_ngcontent-%COMP%]   .cat-active-check[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 8px;\n  right: 8px;\n  font-size: 16px;\n  color: #a000e2;\n}\n.category-grid[_ngcontent-%COMP%]   .cat-choice-btn.active[_ngcontent-%COMP%] {\n  background: #fdf4ff;\n  border-color: #a000e2;\n}\n.category-grid[_ngcontent-%COMP%]   .cat-choice-btn.active[_ngcontent-%COMP%]   .cat-icon[_ngcontent-%COMP%] {\n  color: #a000e2;\n}\n.category-grid[_ngcontent-%COMP%]   .cat-choice-btn.active[_ngcontent-%COMP%]   .cat-label[_ngcontent-%COMP%] {\n  color: #a000e2;\n  font-weight: 850;\n}\n.category-grid[_ngcontent-%COMP%]   .cat-choice-btn[_ngcontent-%COMP%]:active {\n  transform: scale(0.97);\n}\n.type-chips-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  flex-wrap: wrap;\n}\n.type-chips-row[_ngcontent-%COMP%]   .type-pill-chip[_ngcontent-%COMP%] {\n  border: 1px solid #e2e8f0;\n  background: #f8fafc;\n  color: #475569;\n  font-size: 11.5px;\n  font-weight: 700;\n  padding: 6px 12px;\n  border-radius: 8px;\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n.type-chips-row[_ngcontent-%COMP%]   .type-pill-chip.active[_ngcontent-%COMP%] {\n  background: #0f172a;\n  color: #ffffff;\n  border-color: #0f172a;\n}\n.type-chips-row[_ngcontent-%COMP%]   .type-pill-chip[_ngcontent-%COMP%]:active {\n  transform: scale(0.96);\n}\n.input-field-group[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 6px;\n}\n.input-field-group[_ngcontent-%COMP%]   .field-label-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n.input-field-group[_ngcontent-%COMP%]   .field-label[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 750;\n  color: #334155;\n}\n.map-picker-cta-card[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  background:\n    linear-gradient(\n      135deg,\n      #fdf4ff 0%,\n      #f5f3ff 100%);\n  border: 1.5px solid #d8b4fe;\n  border-radius: 14px;\n  padding: 12px 14px;\n  cursor: pointer;\n  transition: all 0.2s ease;\n  gap: 12px;\n}\n.map-picker-cta-card[_ngcontent-%COMP%]   .cta-left[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  flex: 1;\n  min-width: 0;\n}\n.map-picker-cta-card[_ngcontent-%COMP%]   .cta-left[_ngcontent-%COMP%]   .cta-icon-box[_ngcontent-%COMP%] {\n  width: 42px;\n  height: 42px;\n  border-radius: 12px;\n  background: #ffffff;\n  border: 1px solid #e9d5ff;\n  color: #a000e2;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 22px;\n  flex-shrink: 0;\n  transition: all 0.2s ease;\n}\n.map-picker-cta-card[_ngcontent-%COMP%]   .cta-left[_ngcontent-%COMP%]   .cta-icon-box.pinned[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  border-color: #a7f3d0;\n  color: #10b981;\n}\n.map-picker-cta-card[_ngcontent-%COMP%]   .cta-left[_ngcontent-%COMP%]   .cta-text-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n  min-width: 0;\n}\n.map-picker-cta-card[_ngcontent-%COMP%]   .cta-left[_ngcontent-%COMP%]   .cta-text-col[_ngcontent-%COMP%]   .cta-title[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  font-weight: 800;\n  color: #0f172a;\n  line-height: 1.2;\n}\n.map-picker-cta-card[_ngcontent-%COMP%]   .cta-left[_ngcontent-%COMP%]   .cta-text-col[_ngcontent-%COMP%]   .cta-sub[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #64748b;\n  line-height: 1.3;\n}\n.map-picker-cta-card[_ngcontent-%COMP%]   .btn-cta-map[_ngcontent-%COMP%] {\n  background: #a000e2;\n  color: #ffffff;\n  border: none;\n  border-radius: 10px;\n  padding: 8px 14px;\n  font-size: 12px;\n  font-weight: 800;\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n  cursor: pointer;\n  flex-shrink: 0;\n  transition: all 0.15s ease;\n}\n.map-picker-cta-card[_ngcontent-%COMP%]   .btn-cta-map[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 15px;\n}\n.map-picker-cta-card[_ngcontent-%COMP%]   .btn-cta-map[_ngcontent-%COMP%]:active {\n  transform: scale(0.95);\n  background: #7e00b3;\n}\n.map-picker-cta-card[_ngcontent-%COMP%]:active {\n  transform: scale(0.99);\n}\n.coords-pill[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  background: #ecfdf5;\n  border: 1px solid #a7f3d0;\n  color: #065f46;\n  font-size: 10.5px;\n  font-weight: 800;\n  padding: 3px 8px;\n  border-radius: 999px;\n}\n.coords-pill[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #10b981;\n}\n.address-input-readonly[_ngcontent-%COMP%] {\n  position: relative;\n  display: flex;\n  align-items: center;\n  cursor: pointer;\n}\n.address-input-readonly[_ngcontent-%COMP%]   .readonly-lock-icon[_ngcontent-%COMP%] {\n  position: absolute;\n  left: 12px;\n  font-size: 16px;\n  color: #94a3b8;\n  pointer-events: none;\n}\n.address-input-readonly[_ngcontent-%COMP%]   .readonly-input[_ngcontent-%COMP%] {\n  padding-left: 36px !important;\n  background: #f1f5f9 !important;\n  color: #334155 !important;\n  cursor: pointer !important;\n  border-color: #cbd5e1 !important;\n  font-weight: 600;\n}\n.address-input-readonly[_ngcontent-%COMP%]   .readonly-input[_ngcontent-%COMP%]::placeholder {\n  color: #94a3b8;\n  font-weight: 500;\n}\n.address-input-readonly[_ngcontent-%COMP%]:hover   .readonly-input[_ngcontent-%COMP%] {\n  border-color: #a000e2 !important;\n  background: #ffffff !important;\n}\n.form-text-input[_ngcontent-%COMP%] {\n  height: 44px;\n  border-radius: 12px;\n  border: 1.5px solid #e2e8f0;\n  background: #f8fafc;\n  padding: 0 12px;\n  font-size: 13.5px;\n  font-weight: 600;\n  color: #0f172a;\n  outline: none;\n  transition: all 0.2s ease;\n}\n.form-text-input[_ngcontent-%COMP%]:focus {\n  border-color: #a000e2;\n  background: #ffffff;\n  box-shadow: 0 0 0 3px rgba(160, 0, 226, 0.1);\n}\n.form-text-input[_ngcontent-%COMP%]::placeholder {\n  color: #94a3b8;\n  font-weight: 400;\n}\n.price-input-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  background: #f8fafc;\n  border: 1.5px solid #e2e8f0;\n  border-radius: 12px;\n  padding: 0 12px;\n  height: 44px;\n}\n.price-input-wrapper[_ngcontent-%COMP%]   .currency-symbol[_ngcontent-%COMP%] {\n  font-size: 17px;\n  font-weight: 800;\n  color: #a000e2;\n  margin-right: 6px;\n}\n.price-input-wrapper[_ngcontent-%COMP%]   .price-input[_ngcontent-%COMP%] {\n  border: none;\n  background: transparent;\n  padding: 0;\n  width: 100%;\n  height: 100%;\n  font-size: 15px;\n  font-weight: 800;\n  color: #0f172a;\n  outline: none;\n}\n.price-input-wrapper[_ngcontent-%COMP%]:focus-within {\n  border-color: #a000e2;\n  background: #ffffff;\n  box-shadow: 0 0 0 3px rgba(160, 0, 226, 0.1);\n}\n.form-textarea[_ngcontent-%COMP%] {\n  border-radius: 12px;\n  border: 1.5px solid #e2e8f0;\n  background: #f8fafc;\n  padding: 10px 12px;\n  font-size: 13px;\n  font-weight: 500;\n  color: #0f172a;\n  outline: none;\n  resize: none;\n  transition: all 0.2s ease;\n}\n.form-textarea[_ngcontent-%COMP%]:focus {\n  border-color: #a000e2;\n  background: #ffffff;\n  box-shadow: 0 0 0 3px rgba(160, 0, 226, 0.1);\n}\n.form-textarea[_ngcontent-%COMP%]::placeholder {\n  color: #94a3b8;\n}\n.row-two-inputs[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 10px;\n  width: 100%;\n}\n.row-two-inputs[_ngcontent-%COMP%]   .flex-1[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 0;\n}\n.toggle-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  background: #f8fafc;\n  border: 1.5px solid #e2e8f0;\n  border-radius: 14px;\n  padding: 10px 12px;\n  cursor: pointer;\n}\n.toggle-row[_ngcontent-%COMP%]   .toggle-text-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n}\n.toggle-row[_ngcontent-%COMP%]   .toggle-text-col[_ngcontent-%COMP%]   .toggle-label[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-weight: 750;\n  color: #0f172a;\n}\n.toggle-row[_ngcontent-%COMP%]   .toggle-text-col[_ngcontent-%COMP%]   .toggle-sub[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #64748b;\n}\n.custom-switch[_ngcontent-%COMP%] {\n  width: 44px;\n  height: 26px;\n  border-radius: 999px;\n  background: #cbd5e1;\n  padding: 3px;\n  display: flex;\n  align-items: center;\n  transition: background 0.2s ease;\n  flex-shrink: 0;\n}\n.custom-switch[_ngcontent-%COMP%]   .switch-handle[_ngcontent-%COMP%] {\n  width: 20px;\n  height: 20px;\n  border-radius: 50%;\n  background: #ffffff;\n  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);\n  transition: transform 0.2s ease;\n}\n.custom-switch.on[_ngcontent-%COMP%] {\n  background: #10b981;\n}\n.custom-switch.on[_ngcontent-%COMP%]   .switch-handle[_ngcontent-%COMP%] {\n  transform: translateX(18px);\n}\n.chips-number-selector[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  flex-wrap: wrap;\n}\n.chips-number-selector[_ngcontent-%COMP%]   .num-chip[_ngcontent-%COMP%] {\n  border: 1.5px solid #e2e8f0;\n  background: #f8fafc;\n  color: #475569;\n  font-size: 12px;\n  font-weight: 700;\n  padding: 7px 12px;\n  border-radius: 10px;\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n.chips-number-selector[_ngcontent-%COMP%]   .num-chip.active[_ngcontent-%COMP%] {\n  background: #fdf4ff;\n  border-color: #a000e2;\n  color: #a000e2;\n  font-weight: 850;\n}\n.chips-number-selector[_ngcontent-%COMP%]   .num-chip[_ngcontent-%COMP%]:active {\n  transform: scale(0.96);\n}\n.amenities-selection-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 10px;\n}\n.amenities-selection-grid[_ngcontent-%COMP%]   .amenity-selectable-card[_ngcontent-%COMP%] {\n  border: 1.5px solid #e2e8f0;\n  background: #f8fafc;\n  border-radius: 12px;\n  padding: 10px;\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n.amenities-selection-grid[_ngcontent-%COMP%]   .amenity-selectable-card[_ngcontent-%COMP%]   .amenity-icon-box[_ngcontent-%COMP%] {\n  font-size: 18px;\n  color: #94a3b8;\n  display: flex;\n  align-items: center;\n  flex-shrink: 0;\n}\n.amenities-selection-grid[_ngcontent-%COMP%]   .amenity-selectable-card[_ngcontent-%COMP%]   .amenity-name[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  font-weight: 700;\n  color: #334155;\n  line-height: 1.25;\n}\n.amenities-selection-grid[_ngcontent-%COMP%]   .amenity-selectable-card.selected[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  border-color: #a7f3d0;\n}\n.amenities-selection-grid[_ngcontent-%COMP%]   .amenity-selectable-card.selected[_ngcontent-%COMP%]   .amenity-icon-box[_ngcontent-%COMP%] {\n  color: #10b981;\n}\n.amenities-selection-grid[_ngcontent-%COMP%]   .amenity-selectable-card.selected[_ngcontent-%COMP%]   .amenity-name[_ngcontent-%COMP%] {\n  color: #065f46;\n  font-weight: 800;\n}\n.amenities-selection-grid[_ngcontent-%COMP%]   .amenity-selectable-card[_ngcontent-%COMP%]:active {\n  transform: scale(0.97);\n}\n.legal-toggles-stack[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n.legal-toggles-stack[_ngcontent-%COMP%]   .doc-toggle-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  background: #f8fafc;\n  border: 1.5px solid #e2e8f0;\n  border-radius: 14px;\n  padding: 10px 12px;\n  cursor: pointer;\n}\n.legal-toggles-stack[_ngcontent-%COMP%]   .doc-toggle-row[_ngcontent-%COMP%]   .doc-info-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 1px;\n  flex: 1;\n  margin-right: 10px;\n}\n.legal-toggles-stack[_ngcontent-%COMP%]   .doc-toggle-row[_ngcontent-%COMP%]   .doc-info-col[_ngcontent-%COMP%]   .doc-title[_ngcontent-%COMP%] {\n  font-size: 12.5px;\n  font-weight: 800;\n  color: #0f172a;\n}\n.legal-toggles-stack[_ngcontent-%COMP%]   .doc-toggle-row[_ngcontent-%COMP%]   .doc-info-col[_ngcontent-%COMP%]   .doc-desc[_ngcontent-%COMP%] {\n  font-size: 10.5px;\n  color: #64748b;\n}\n.legal-toggles-stack[_ngcontent-%COMP%]   .doc-toggle-row.custom-added-doc[_ngcontent-%COMP%] {\n  background: #fdf4ff;\n  border-color: #f5d0fe;\n}\n.legal-toggles-stack[_ngcontent-%COMP%]   .doc-toggle-row.custom-added-doc[_ngcontent-%COMP%]   .doc-title[_ngcontent-%COMP%] {\n  color: #7e00b3;\n}\n.legal-toggles-stack[_ngcontent-%COMP%]   .doc-toggle-row[_ngcontent-%COMP%]   .custom-doc-right-col[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n}\n.legal-toggles-stack[_ngcontent-%COMP%]   .doc-toggle-row[_ngcontent-%COMP%]   .custom-doc-right-col[_ngcontent-%COMP%]   .btn-remove-custom-doc[_ngcontent-%COMP%] {\n  background: transparent;\n  border: none;\n  color: #ef4444;\n  font-size: 17px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  cursor: pointer;\n  padding: 4px;\n  border-radius: 6px;\n}\n.legal-toggles-stack[_ngcontent-%COMP%]   .doc-toggle-row[_ngcontent-%COMP%]   .custom-doc-right-col[_ngcontent-%COMP%]   .btn-remove-custom-doc[_ngcontent-%COMP%]:active {\n  background: #fee2e2;\n}\n.landmarks-list-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n.landmarks-list-container[_ngcontent-%COMP%]   .landmark-entry-item[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  background: #ffffff;\n  border: 1.5px solid #e2e8f0;\n  border-radius: 12px;\n  padding: 10px 12px;\n  transition: all 0.15s ease;\n}\n.landmarks-list-container[_ngcontent-%COMP%]   .landmark-entry-item[_ngcontent-%COMP%]   .lm-entry-left[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  flex: 1;\n  min-width: 0;\n}\n.landmarks-list-container[_ngcontent-%COMP%]   .landmark-entry-item[_ngcontent-%COMP%]   .lm-entry-left[_ngcontent-%COMP%]   .lm-type-icon-box[_ngcontent-%COMP%] {\n  width: 36px;\n  height: 36px;\n  border-radius: 10px;\n  background: #fdf4ff;\n  border: 1px solid #f5d0fe;\n  color: #a000e2;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 18px;\n  flex-shrink: 0;\n}\n.landmarks-list-container[_ngcontent-%COMP%]   .landmark-entry-item[_ngcontent-%COMP%]   .lm-entry-left[_ngcontent-%COMP%]   .lm-entry-info[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n  min-width: 0;\n}\n.landmarks-list-container[_ngcontent-%COMP%]   .landmark-entry-item[_ngcontent-%COMP%]   .lm-entry-left[_ngcontent-%COMP%]   .lm-entry-info[_ngcontent-%COMP%]   .lm-entry-name[_ngcontent-%COMP%] {\n  font-size: 12.5px;\n  font-weight: 750;\n  color: #0f172a;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.landmarks-list-container[_ngcontent-%COMP%]   .landmark-entry-item[_ngcontent-%COMP%]   .lm-entry-left[_ngcontent-%COMP%]   .lm-entry-info[_ngcontent-%COMP%]   .lm-entry-type-tag[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  font-weight: 800;\n  color: #64748b;\n  letter-spacing: 0.5px;\n}\n.landmarks-list-container[_ngcontent-%COMP%]   .landmark-entry-item[_ngcontent-%COMP%]   .lm-entry-right[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  flex-shrink: 0;\n}\n.landmarks-list-container[_ngcontent-%COMP%]   .landmark-entry-item[_ngcontent-%COMP%]   .lm-entry-right[_ngcontent-%COMP%]   .lm-distance-badge[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 800;\n  color: #a000e2;\n  background: #fdf4ff;\n  border: 1px solid #f5d0fe;\n  border-radius: 6px;\n  padding: 4px 8px;\n}\n.landmarks-list-container[_ngcontent-%COMP%]   .landmark-entry-item[_ngcontent-%COMP%]   .lm-entry-right[_ngcontent-%COMP%]   .btn-del-landmark[_ngcontent-%COMP%] {\n  background: transparent;\n  border: none;\n  color: #ef4444;\n  font-size: 16px;\n  cursor: pointer;\n  padding: 4px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  border-radius: 6px;\n}\n.landmarks-list-container[_ngcontent-%COMP%]   .landmark-entry-item[_ngcontent-%COMP%]   .lm-entry-right[_ngcontent-%COMP%]   .btn-del-landmark[_ngcontent-%COMP%]:active {\n  background: #fee2e2;\n}\n.custom-entry-card[_ngcontent-%COMP%] {\n  background: #f8fafc;\n  border: 1.5px solid #e2e8f0;\n  border-radius: 14px;\n  padding: 14px;\n  display: flex;\n  flex-direction: column;\n}\n.custom-entry-card[_ngcontent-%COMP%]   .custom-entry-header-title[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 800;\n  text-transform: uppercase;\n  letter-spacing: 0.5px;\n  color: #64748b;\n}\n.custom-entry-card[_ngcontent-%COMP%]   .landmark-type-pills[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  flex-wrap: wrap;\n  margin-top: 8px;\n}\n.custom-entry-card[_ngcontent-%COMP%]   .landmark-type-pills[_ngcontent-%COMP%]   .landmark-type-pill[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  background: #ffffff;\n  border: 1.5px solid #cbd5e1;\n  color: #475569;\n  font-size: 11px;\n  font-weight: 700;\n  padding: 6px 10px;\n  border-radius: 8px;\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n.custom-entry-card[_ngcontent-%COMP%]   .landmark-type-pills[_ngcontent-%COMP%]   .landmark-type-pill[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n}\n.custom-entry-card[_ngcontent-%COMP%]   .landmark-type-pills[_ngcontent-%COMP%]   .landmark-type-pill.active[_ngcontent-%COMP%] {\n  background: #fdf4ff;\n  border-color: #a000e2;\n  color: #a000e2;\n  font-weight: 850;\n}\n.custom-entry-card[_ngcontent-%COMP%]   .landmark-type-pills[_ngcontent-%COMP%]   .landmark-type-pill[_ngcontent-%COMP%]:active {\n  transform: scale(0.96);\n}\n.custom-entry-card[_ngcontent-%COMP%]   .landmark-dist-input[_ngcontent-%COMP%] {\n  width: 110px;\n  flex-shrink: 0;\n}\n.custom-entry-card[_ngcontent-%COMP%]   .btn-custom-add-block[_ngcontent-%COMP%] {\n  height: 42px;\n  background: #0f172a;\n  color: #ffffff;\n  border: none;\n  border-radius: 10px;\n  font-size: 12.5px;\n  font-weight: 800;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 6px;\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n.custom-entry-card[_ngcontent-%COMP%]   .btn-custom-add-block[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 17px;\n}\n.custom-entry-card[_ngcontent-%COMP%]   .btn-custom-add-block[_ngcontent-%COMP%]:disabled {\n  background: #cbd5e1;\n  color: #94a3b8;\n  cursor: not-allowed;\n}\n.custom-entry-card[_ngcontent-%COMP%]   .btn-custom-add-block[_ngcontent-%COMP%]:active:not(:disabled) {\n  transform: scale(0.98);\n  background: #a000e2;\n}\n.doc-title-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  flex-wrap: wrap;\n}\n.doc-title-row[_ngcontent-%COMP%]   .doc-category-badge[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  font-weight: 800;\n  color: #a000e2;\n  background: #fdf4ff;\n  border: 1px solid #f5d0fe;\n  border-radius: 4px;\n  padding: 1px 6px;\n  line-height: 1.3;\n}\n.custom-add-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.custom-add-row[_ngcontent-%COMP%]   .btn-custom-add[_ngcontent-%COMP%] {\n  height: 44px;\n  padding: 0 16px;\n  background: #0f172a;\n  color: #ffffff;\n  border: none;\n  border-radius: 12px;\n  font-size: 12.5px;\n  font-weight: 800;\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  cursor: pointer;\n  flex-shrink: 0;\n  transition: all 0.15s ease;\n}\n.custom-add-row[_ngcontent-%COMP%]   .btn-custom-add[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 17px;\n}\n.custom-add-row[_ngcontent-%COMP%]   .btn-custom-add[_ngcontent-%COMP%]:disabled {\n  background: #cbd5e1;\n  color: #94a3b8;\n  cursor: not-allowed;\n}\n.custom-add-row[_ngcontent-%COMP%]   .btn-custom-add[_ngcontent-%COMP%]:active:not(:disabled) {\n  transform: scale(0.96);\n}\n.image-previews-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  gap: 10px;\n}\n.image-previews-grid[_ngcontent-%COMP%]   .image-thumb-card[_ngcontent-%COMP%] {\n  position: relative;\n  height: 80px;\n  border-radius: 12px;\n  overflow: hidden;\n  background: #1e293b;\n}\n.image-previews-grid[_ngcontent-%COMP%]   .image-thumb-card[_ngcontent-%COMP%]   .thumb-pic[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n.image-previews-grid[_ngcontent-%COMP%]   .image-thumb-card[_ngcontent-%COMP%]   .btn-del-pic[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 4px;\n  right: 4px;\n  width: 26px;\n  height: 26px;\n  border-radius: 50%;\n  background: rgba(15, 23, 42, 0.75);\n  color: #ef4444;\n  border: none;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 14px;\n  cursor: pointer;\n}\n.image-previews-grid[_ngcontent-%COMP%]   .btn-upload-photo-card[_ngcontent-%COMP%] {\n  height: 80px;\n  border-radius: 12px;\n  border: 2px dashed #cbd5e1;\n  background: #f8fafc;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  gap: 4px;\n  cursor: pointer;\n  transition: all 0.2s ease;\n  padding: 6px;\n}\n.image-previews-grid[_ngcontent-%COMP%]   .btn-upload-photo-card[_ngcontent-%COMP%]   .upload-icon-circle[_ngcontent-%COMP%] {\n  width: 32px;\n  height: 32px;\n  border-radius: 50%;\n  background: #f1f5f9;\n  color: #a000e2;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 20px;\n  transition: all 0.2s ease;\n}\n.image-previews-grid[_ngcontent-%COMP%]   .btn-upload-photo-card[_ngcontent-%COMP%]   .upload-btn-label[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 750;\n  color: #64748b;\n  transition: all 0.2s ease;\n}\n.image-previews-grid[_ngcontent-%COMP%]   .btn-upload-photo-card[_ngcontent-%COMP%]:hover {\n  border-color: #a000e2;\n  background: #fdf4ff;\n}\n.image-previews-grid[_ngcontent-%COMP%]   .btn-upload-photo-card[_ngcontent-%COMP%]:hover   .upload-icon-circle[_ngcontent-%COMP%] {\n  background: #a000e2;\n  color: #ffffff;\n}\n.image-previews-grid[_ngcontent-%COMP%]   .btn-upload-photo-card[_ngcontent-%COMP%]:hover   .upload-btn-label[_ngcontent-%COMP%] {\n  color: #a000e2;\n}\n.image-previews-grid[_ngcontent-%COMP%]   .btn-upload-photo-card[_ngcontent-%COMP%]:active {\n  transform: scale(0.96);\n}\n.add-image-url-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.add-image-url-row[_ngcontent-%COMP%]   .btn-add-img[_ngcontent-%COMP%] {\n  height: 44px;\n  padding: 0 16px;\n  border-radius: 12px;\n  background: #fdf4ff;\n  border: 1.5px solid #f5d0fe;\n  color: #a000e2;\n  font-size: 13px;\n  font-weight: 800;\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  cursor: pointer;\n  flex-shrink: 0;\n}\n.add-image-url-row[_ngcontent-%COMP%]   .btn-add-img[_ngcontent-%COMP%]:active {\n  transform: scale(0.96);\n}\n.youtube-section-box[_ngcontent-%COMP%] {\n  background: #fdfaf7;\n  border: 1.5px solid #fed7aa;\n  border-radius: 16px;\n  padding: 14px;\n  transition: all 0.2s ease;\n}\n.youtube-section-box[_ngcontent-%COMP%]   .youtube-header-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n}\n.youtube-section-box[_ngcontent-%COMP%]   .youtube-header-row[_ngcontent-%COMP%]   .yt-icon-badge[_ngcontent-%COMP%] {\n  width: 36px;\n  height: 36px;\n  min-width: 36px;\n  border-radius: 10px;\n  background: #fef2f2;\n  border: 1px solid #fecaca;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  color: #ef4444;\n  font-size: 20px;\n  box-shadow: 0 1px 3px rgba(239, 68, 68, 0.12);\n}\n.youtube-section-box[_ngcontent-%COMP%]   .youtube-header-row[_ngcontent-%COMP%]   .yt-label-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n}\n.youtube-section-box[_ngcontent-%COMP%]   .youtube-header-row[_ngcontent-%COMP%]   .yt-label-col[_ngcontent-%COMP%]   .field-label[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-weight: 800;\n  color: #0f172a;\n}\n.youtube-section-box[_ngcontent-%COMP%]   .youtube-header-row[_ngcontent-%COMP%]   .yt-label-col[_ngcontent-%COMP%]   .yt-helper-text[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #64748b;\n  font-weight: 500;\n}\n.youtube-section-box[_ngcontent-%COMP%]   .youtube-input-wrap[_ngcontent-%COMP%] {\n  position: relative;\n  display: flex;\n  align-items: center;\n}\n.youtube-section-box[_ngcontent-%COMP%]   .youtube-input-wrap[_ngcontent-%COMP%]   .yt-input[_ngcontent-%COMP%] {\n  padding-right: 40px;\n  background: #ffffff;\n  border-color: #fed7aa;\n}\n.youtube-section-box[_ngcontent-%COMP%]   .youtube-input-wrap[_ngcontent-%COMP%]   .yt-input[_ngcontent-%COMP%]:focus {\n  border-color: #ea580c;\n  box-shadow: 0 0 0 3px rgba(234, 88, 12, 0.12);\n}\n.youtube-section-box[_ngcontent-%COMP%]   .youtube-input-wrap[_ngcontent-%COMP%]   .btn-clear-yt[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 8px;\n  width: 28px;\n  height: 28px;\n  background: #f1f5f9;\n  border: none;\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  color: #64748b;\n  font-size: 16px;\n  cursor: pointer;\n}\n.youtube-section-box[_ngcontent-%COMP%]   .youtube-input-wrap[_ngcontent-%COMP%]   .btn-clear-yt[_ngcontent-%COMP%]:active {\n  background: #e2e8f0;\n}\n.youtube-section-box[_ngcontent-%COMP%]   .yt-preview-card[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  background: #ffffff;\n  border: 1.5px solid #fed7aa;\n  border-radius: 12px;\n  padding: 8px 10px;\n  box-shadow: 0 2px 8px rgba(234, 88, 12, 0.06);\n}\n.youtube-section-box[_ngcontent-%COMP%]   .yt-preview-card[_ngcontent-%COMP%]   .yt-preview-thumb-wrap[_ngcontent-%COMP%] {\n  position: relative;\n  width: 88px;\n  height: 52px;\n  border-radius: 8px;\n  overflow: hidden;\n  flex-shrink: 0;\n  background: #000000;\n}\n.youtube-section-box[_ngcontent-%COMP%]   .yt-preview-card[_ngcontent-%COMP%]   .yt-preview-thumb-wrap[_ngcontent-%COMP%]   .yt-preview-thumb[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n.youtube-section-box[_ngcontent-%COMP%]   .yt-preview-card[_ngcontent-%COMP%]   .yt-preview-thumb-wrap[_ngcontent-%COMP%]   .yt-play-pill[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 3px;\n  background: rgba(0, 0, 0, 0.45);\n  color: #ffffff;\n  font-size: 9.5px;\n  font-weight: 800;\n}\n.youtube-section-box[_ngcontent-%COMP%]   .yt-preview-card[_ngcontent-%COMP%]   .yt-preview-thumb-wrap[_ngcontent-%COMP%]   .yt-play-pill[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: #ef4444;\n}\n.youtube-section-box[_ngcontent-%COMP%]   .yt-preview-card[_ngcontent-%COMP%]   .yt-preview-info[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 3px;\n  min-width: 0;\n}\n.youtube-section-box[_ngcontent-%COMP%]   .yt-preview-card[_ngcontent-%COMP%]   .yt-preview-info[_ngcontent-%COMP%]   .yt-preview-badge[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 800;\n  color: #ea580c;\n  text-transform: uppercase;\n  letter-spacing: 0.3px;\n}\n.youtube-section-box[_ngcontent-%COMP%]   .yt-preview-card[_ngcontent-%COMP%]   .yt-preview-info[_ngcontent-%COMP%]   .yt-preview-id[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  font-weight: 700;\n  color: #334155;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.bottom-form-spacer[_ngcontent-%COMP%] {\n  height: calc(100px + env(safe-area-inset-bottom, 0px));\n}\n.sticky-register-footer[_ngcontent-%COMP%] {\n  position: fixed;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  z-index: 100;\n  background: #ffffff;\n  border-top: 1px solid #e2e8f0;\n  padding: 12px 16px max(env(safe-area-inset-bottom, 0px), 18px);\n  box-shadow: 0 -4px 18px rgba(15, 23, 42, 0.08);\n}\n.sticky-register-footer[_ngcontent-%COMP%]   .btn-submit-property[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 48px;\n  border-radius: 14px;\n  background:\n    linear-gradient(\n      135deg,\n      #a000e2 0%,\n      #7e00b3 100%);\n  border: none;\n  color: #ffffff;\n  font-size: 14px;\n  font-weight: 850;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  gap: 8px;\n  cursor: pointer;\n  box-shadow: 0 4px 14px rgba(160, 0, 226, 0.3);\n  transition: transform 0.15s ease;\n}\n.sticky-register-footer[_ngcontent-%COMP%]   .btn-submit-property[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n}\n.sticky-register-footer[_ngcontent-%COMP%]   .btn-submit-property[_ngcontent-%COMP%]:active {\n  transform: scale(0.98);\n}\n.sticky-register-footer[_ngcontent-%COMP%]   .btn-submit-property[_ngcontent-%COMP%]:disabled {\n  opacity: 0.6;\n  cursor: not-allowed;\n}\n/*# sourceMappingURL=property-register.page.css.map */"] });
var PropertyRegisterPage = _PropertyRegisterPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(PropertyRegisterPage, { className: "PropertyRegisterPage", filePath: "src/app/pages/property-register/property-register.page.ts", lineNumber: 73 });
})();
export {
  PropertyRegisterPage
};
//# sourceMappingURL=property-register.page-TUZCBGOL.js.map
