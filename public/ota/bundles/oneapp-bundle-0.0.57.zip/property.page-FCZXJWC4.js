import {
  PropertyFooterComponent
} from "./chunk-UEAGU4IM.js";
import {
  PropertyService
} from "./chunk-IC2VC54O.js";
import {
  LocationService
} from "./chunk-4TQR4WSH.js";
import "./chunk-V444GY6B.js";
import "./chunk-QH3WR2OQ.js";
import "./chunk-YJYUHAOC.js";
import {
  ToastController
} from "./chunk-OE5MTPUR.js";
import {
  addIcons,
  addOutline,
  arrowBackOutline,
  bedOutline,
  callOutline,
  carOutline,
  checkmark,
  checkmarkCircle,
  chevronDown,
  closeCircleOutline,
  closeOutline,
  compassOutline,
  expandOutline,
  filterOutline,
  gridOutline,
  heart,
  heartOutline,
  homeOutline,
  keyOutline,
  leafOutline,
  location,
  lockClosedOutline,
  logoWhatsapp,
  optionsOutline,
  refreshOutline,
  searchOutline,
  shareSocialOutline,
  shieldCheckmarkOutline,
  sparkles,
  swapVerticalOutline,
  waterOutline
} from "./chunk-FJYXZAS7.js";
import {
  IonContent,
  IonHeader,
  IonIcon,
  IonModal,
  IonToolbar
} from "./chunk-CJE2NDTY.js";
import {
  CommonModule,
  DecimalPipe,
  DefaultValueAccessor,
  FormsModule,
  NavController,
  NgControlStatus,
  NgModel,
  Router,
  Subject,
  debounceTime,
  distinctUntilChanged,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind1,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIdentity,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-Z7XNNJSA.js";
import "./chunk-XR3JUECC.js";
import "./chunk-FH4NU4VH.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/pages/property/property.page.ts
var _c0 = () => [0, 0.5];
var _c1 = () => [0, 0.78, 0.95];
var _c2 = () => [1, 2, 3];
var _forTrack0 = ($index, $item) => $item.id;
function PropertyPage_For_20_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 41);
    \u0275\u0275listener("click", function PropertyPage_For_20_Template_button_click_0_listener() {
      const tab_r2 = \u0275\u0275restoreView(_r1).$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.setCategory(tab_r2.id));
    });
    \u0275\u0275element(1, "ion-icon", 42);
    \u0275\u0275elementStart(2, "span", 43);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const tab_r2 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275classProp("active", ctx_r2.activeCategory === tab_r2.id);
    \u0275\u0275advance();
    \u0275\u0275property("name", tab_r2.icon);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(tab_r2.label);
  }
}
function PropertyPage_Conditional_27_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 44);
    \u0275\u0275listener("click", function PropertyPage_Conditional_27_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r4);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.clearSearch());
    });
    \u0275\u0275element(1, "ion-icon", 45);
    \u0275\u0275elementEnd();
  }
}
function PropertyPage_Conditional_32_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 29);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r2.activeFiltersCount);
  }
}
function PropertyPage_Conditional_36_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 33);
    \u0275\u0275element(1, "span", 46);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3, "Loading properties from server...");
    \u0275\u0275elementEnd()();
  }
}
function PropertyPage_Conditional_37_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0, " Showing ");
    \u0275\u0275elementStart(1, "b");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275text(3);
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r2.filteredProperties.length);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" properties in and near ", ctx_r2.locationTitle, " ");
  }
}
function PropertyPage_Conditional_38_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 47);
    \u0275\u0275listener("click", function PropertyPage_Conditional_38_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r5);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.clearAllFilters());
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" Clear filters (", ctx_r2.activeFiltersCount, ") ");
  }
}
function PropertyPage_Conditional_39_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 48)(1, "div", 49);
    \u0275\u0275element(2, "div", 50);
    \u0275\u0275elementStart(3, "div", 51);
    \u0275\u0275element(4, "div", 52)(5, "div", 53);
    \u0275\u0275elementEnd();
    \u0275\u0275element(6, "div", 54);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "div", 55);
    \u0275\u0275element(8, "div", 56)(9, "div", 57);
    \u0275\u0275elementStart(10, "div", 58);
    \u0275\u0275element(11, "div", 59)(12, "div", 59)(13, "div", 59)(14, "div", 59);
    \u0275\u0275elementEnd();
    \u0275\u0275element(15, "div", 60);
    \u0275\u0275elementStart(16, "div", 61)(17, "div", 62);
    \u0275\u0275element(18, "div", 63)(19, "div", 64);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "div", 65);
    \u0275\u0275element(21, "div", 66)(22, "div", 67);
    \u0275\u0275elementEnd()()()();
  }
}
function PropertyPage_Conditional_39_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 35);
    \u0275\u0275repeaterCreate(1, PropertyPage_Conditional_39_For_2_Template, 23, 0, "div", 48, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance();
    \u0275\u0275repeater(\u0275\u0275pureFunction0(0, _c2));
  }
}
function PropertyPage_Conditional_40_For_2_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 76);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const prop_r7 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", prop_r7.category === "rent_house" ? "Rented" : "Sold", " ");
  }
}
function PropertyPage_Conditional_40_For_2_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 76);
    \u0275\u0275text(1, " Closed ");
    \u0275\u0275elementEnd();
  }
}
function PropertyPage_Conditional_40_For_2_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 77);
    \u0275\u0275element(1, "ion-icon", 97);
    \u0275\u0275text(2, " Verified ");
    \u0275\u0275elementEnd();
  }
}
function PropertyPage_Conditional_40_For_2_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 83);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const prop_r7 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(prop_r7.priceUnit);
  }
}
function PropertyPage_Conditional_40_For_2_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 84);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const prop_r7 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(prop_r7.pricePerSqFt);
  }
}
function PropertyPage_Conditional_40_For_2_Conditional_26_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 89);
    \u0275\u0275element(1, "ion-icon", 98);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const prop_r7 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("", prop_r7.bedrooms, " Beds");
  }
}
function PropertyPage_Conditional_40_For_2_Conditional_27_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 89);
    \u0275\u0275element(1, "ion-icon", 99);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const prop_r7 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("", prop_r7.bathrooms, " Baths");
  }
}
function PropertyPage_Conditional_40_For_2_Conditional_45_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 100);
    \u0275\u0275listener("click", function PropertyPage_Conditional_40_For_2_Conditional_45_Template_button_click_0_listener($event) {
      \u0275\u0275restoreView(_r8);
      return \u0275\u0275resetView($event.stopPropagation());
    });
    \u0275\u0275element(1, "ion-icon", 101);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const prop_r7 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(prop_r7.category === "rent_house" ? "Rented Out" : "Sold Out");
  }
}
function PropertyPage_Conditional_40_For_2_Conditional_46_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 102);
    \u0275\u0275listener("click", function PropertyPage_Conditional_40_For_2_Conditional_46_Template_button_click_0_listener($event) {
      \u0275\u0275restoreView(_r9);
      const prop_r7 = \u0275\u0275nextContext().$implicit;
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.callSeller(prop_r7, $event));
    });
    \u0275\u0275element(1, "ion-icon", 103);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3, "Call");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(4, "button", 104);
    \u0275\u0275listener("click", function PropertyPage_Conditional_40_For_2_Conditional_46_Template_button_click_4_listener($event) {
      \u0275\u0275restoreView(_r9);
      const prop_r7 = \u0275\u0275nextContext().$implicit;
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.whatsappSeller(prop_r7, $event));
    });
    \u0275\u0275element(5, "ion-icon", 105);
    \u0275\u0275elementStart(6, "span");
    \u0275\u0275text(7, "WhatsApp");
    \u0275\u0275elementEnd()();
  }
}
function PropertyPage_Conditional_40_For_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "article", 70);
    \u0275\u0275listener("click", function PropertyPage_Conditional_40_For_2_Template_article_click_0_listener() {
      const prop_r7 = \u0275\u0275restoreView(_r6).$implicit;
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.viewDetails(prop_r7));
    });
    \u0275\u0275elementStart(1, "div", 71);
    \u0275\u0275element(2, "img", 72)(3, "div", 73);
    \u0275\u0275elementStart(4, "div", 74)(5, "span", 75);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275template(7, PropertyPage_Conditional_40_For_2_Conditional_7_Template, 2, 1, "span", 76)(8, PropertyPage_Conditional_40_For_2_Conditional_8_Template, 2, 0, "span", 76)(9, PropertyPage_Conditional_40_For_2_Conditional_9_Template, 3, 0, "span", 77);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "button", 78);
    \u0275\u0275listener("click", function PropertyPage_Conditional_40_For_2_Template_button_click_10_listener($event) {
      const prop_r7 = \u0275\u0275restoreView(_r6).$implicit;
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.toggleFavorite(prop_r7, $event));
    });
    \u0275\u0275element(11, "ion-icon", 79);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "div", 80)(13, "div", 81)(14, "span", 82);
    \u0275\u0275text(15);
    \u0275\u0275elementEnd();
    \u0275\u0275template(16, PropertyPage_Conditional_40_For_2_Conditional_16_Template, 2, 1, "span", 83);
    \u0275\u0275elementEnd();
    \u0275\u0275template(17, PropertyPage_Conditional_40_For_2_Conditional_17_Template, 2, 1, "span", 84);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(18, "div", 55)(19, "h3", 85);
    \u0275\u0275text(20);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(21, "p", 86);
    \u0275\u0275element(22, "ion-icon", 87);
    \u0275\u0275elementStart(23, "span");
    \u0275\u0275text(24);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(25, "div", 88);
    \u0275\u0275template(26, PropertyPage_Conditional_40_For_2_Conditional_26_Template, 4, 1, "div", 89)(27, PropertyPage_Conditional_40_For_2_Conditional_27_Template, 4, 1, "div", 89);
    \u0275\u0275elementStart(28, "div", 89);
    \u0275\u0275element(29, "ion-icon", 90);
    \u0275\u0275elementStart(30, "span");
    \u0275\u0275text(31);
    \u0275\u0275pipe(32, "number");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(33, "div", 89);
    \u0275\u0275element(34, "ion-icon", 91);
    \u0275\u0275elementStart(35, "span");
    \u0275\u0275text(36);
    \u0275\u0275elementEnd()()();
    \u0275\u0275element(37, "div", 60);
    \u0275\u0275elementStart(38, "div", 92)(39, "div", 93)(40, "span", 94);
    \u0275\u0275text(41);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(42, "span", 95);
    \u0275\u0275text(43);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(44, "div", 65);
    \u0275\u0275template(45, PropertyPage_Conditional_40_For_2_Conditional_45_Template, 4, 1, "button", 96)(46, PropertyPage_Conditional_40_For_2_Conditional_46_Template, 8, 0);
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const prop_r7 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275property("src", prop_r7.images[0], \u0275\u0275sanitizeUrl)("alt", prop_r7.title);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(prop_r7.propertyType);
    \u0275\u0275advance();
    \u0275\u0275conditional(prop_r7.status === "sold" ? 7 : prop_r7.status === "closed" ? 8 : prop_r7.tags.includes("Verified") || prop_r7.is_verified ? 9 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275classProp("active", prop_r7.isFavorite);
    \u0275\u0275advance();
    \u0275\u0275property("name", prop_r7.isFavorite ? "heart" : "heart-outline");
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(prop_r7.priceDisplay);
    \u0275\u0275advance();
    \u0275\u0275conditional(prop_r7.priceUnit ? 16 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(prop_r7.pricePerSqFt ? 17 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(prop_r7.title);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(prop_r7.locality);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(prop_r7.bedrooms ? 26 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(prop_r7.bathrooms ? 27 : -1);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("", \u0275\u0275pipeBind1(32, 19, prop_r7.superBuiltUpAreaSqFt), " sq.ft");
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(prop_r7.facing);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(prop_r7.seller.type);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(prop_r7.seller.name);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(prop_r7.status === "sold" ? 45 : 46);
  }
}
function PropertyPage_Conditional_40_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 68);
    \u0275\u0275repeaterCreate(1, PropertyPage_Conditional_40_For_2_Template, 47, 21, "article", 69, _forTrack0);
    \u0275\u0275elementEnd();
    \u0275\u0275element(3, "app-property-footer");
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r2.filteredProperties);
  }
}
function PropertyPage_Conditional_41_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 36)(1, "div", 106);
    \u0275\u0275element(2, "ion-icon", 107);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "h3", 108);
    \u0275\u0275text(4, "No Properties Match Your Filters");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p", 109);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "button", 110);
    \u0275\u0275listener("click", function PropertyPage_Conditional_41_Template_button_click_7_listener() {
      \u0275\u0275restoreView(_r10);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.clearAllFilters());
    });
    \u0275\u0275element(8, "ion-icon", 111);
    \u0275\u0275elementStart(9, "span");
    \u0275\u0275text(10, "Reset All Filters");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1("Try clearing your filters or changing the category to explore more verified homes and plots in ", ctx_r2.locationTitle, ".");
  }
}
function PropertyPage_ng_template_48_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 122);
  }
}
function PropertyPage_ng_template_48_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 122);
  }
}
function PropertyPage_ng_template_48_Conditional_27_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 122);
  }
}
function PropertyPage_ng_template_48_Conditional_34_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 122);
  }
}
function PropertyPage_ng_template_48_Conditional_41_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 122);
  }
}
function PropertyPage_ng_template_48_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 112)(1, "header", 113)(2, "h3", 114);
    \u0275\u0275text(3, "Sort Properties");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "button", 115);
    \u0275\u0275listener("click", function PropertyPage_ng_template_48_Template_button_click_4_listener() {
      \u0275\u0275restoreView(_r11);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.closeSortModal());
    });
    \u0275\u0275element(5, "ion-icon", 116);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "div", 117)(7, "div", 118);
    \u0275\u0275listener("click", function PropertyPage_ng_template_48_Template_div_click_7_listener() {
      \u0275\u0275restoreView(_r11);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.selectSort("featured"));
    });
    \u0275\u0275elementStart(8, "div", 119)(9, "span", 120);
    \u0275\u0275text(10, "Featured & Recommended");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "span", 121);
    \u0275\u0275text(12, "Handpicked verified properties");
    \u0275\u0275elementEnd()();
    \u0275\u0275template(13, PropertyPage_ng_template_48_Conditional_13_Template, 1, 0, "ion-icon", 122);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "div", 118);
    \u0275\u0275listener("click", function PropertyPage_ng_template_48_Template_div_click_14_listener() {
      \u0275\u0275restoreView(_r11);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.selectSort("price_low"));
    });
    \u0275\u0275elementStart(15, "div", 119)(16, "span", 120);
    \u0275\u0275text(17, "Price: Low to High");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "span", 121);
    \u0275\u0275text(19, "Affordable options first");
    \u0275\u0275elementEnd()();
    \u0275\u0275template(20, PropertyPage_ng_template_48_Conditional_20_Template, 1, 0, "ion-icon", 122);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(21, "div", 118);
    \u0275\u0275listener("click", function PropertyPage_ng_template_48_Template_div_click_21_listener() {
      \u0275\u0275restoreView(_r11);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.selectSort("price_high"));
    });
    \u0275\u0275elementStart(22, "div", 119)(23, "span", 120);
    \u0275\u0275text(24, "Price: High to Low");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(25, "span", 121);
    \u0275\u0275text(26, "Premium luxury options first");
    \u0275\u0275elementEnd()();
    \u0275\u0275template(27, PropertyPage_ng_template_48_Conditional_27_Template, 1, 0, "ion-icon", 122);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(28, "div", 118);
    \u0275\u0275listener("click", function PropertyPage_ng_template_48_Template_div_click_28_listener() {
      \u0275\u0275restoreView(_r11);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.selectSort("area_high"));
    });
    \u0275\u0275elementStart(29, "div", 119)(30, "span", 120);
    \u0275\u0275text(31, "Area: Largest First");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(32, "span", 121);
    \u0275\u0275text(33, "Maximum super built-up space");
    \u0275\u0275elementEnd()();
    \u0275\u0275template(34, PropertyPage_ng_template_48_Conditional_34_Template, 1, 0, "ion-icon", 122);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(35, "div", 118);
    \u0275\u0275listener("click", function PropertyPage_ng_template_48_Template_div_click_35_listener() {
      \u0275\u0275restoreView(_r11);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.selectSort("newest"));
    });
    \u0275\u0275elementStart(36, "div", 119)(37, "span", 120);
    \u0275\u0275text(38, "Newest Added");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(39, "span", 121);
    \u0275\u0275text(40, "Latest posted properties");
    \u0275\u0275elementEnd()();
    \u0275\u0275template(41, PropertyPage_ng_template_48_Conditional_41_Template, 1, 0, "ion-icon", 122);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance(7);
    \u0275\u0275classProp("selected", ctx_r2.sortBy === "featured");
    \u0275\u0275advance(6);
    \u0275\u0275conditional(ctx_r2.sortBy === "featured" ? 13 : -1);
    \u0275\u0275advance();
    \u0275\u0275classProp("selected", ctx_r2.sortBy === "price_low");
    \u0275\u0275advance(6);
    \u0275\u0275conditional(ctx_r2.sortBy === "price_low" ? 20 : -1);
    \u0275\u0275advance();
    \u0275\u0275classProp("selected", ctx_r2.sortBy === "price_high");
    \u0275\u0275advance(6);
    \u0275\u0275conditional(ctx_r2.sortBy === "price_high" ? 27 : -1);
    \u0275\u0275advance();
    \u0275\u0275classProp("selected", ctx_r2.sortBy === "area_high");
    \u0275\u0275advance(6);
    \u0275\u0275conditional(ctx_r2.sortBy === "area_high" ? 34 : -1);
    \u0275\u0275advance();
    \u0275\u0275classProp("selected", ctx_r2.sortBy === "newest");
    \u0275\u0275advance(6);
    \u0275\u0275conditional(ctx_r2.sortBy === "newest" ? 41 : -1);
  }
}
function PropertyPage_ng_template_50_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 125);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("", ctx_r2.activeFiltersCount, " active");
  }
}
function PropertyPage_ng_template_50_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 129)(1, "h4", 138);
    \u0275\u0275text(2, "BHK Choice");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 139)(4, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Conditional_23_Template_button_click_4_listener() {
      \u0275\u0275restoreView(_r13);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.selectedBhk = "all");
    });
    \u0275\u0275text(5, "Any");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Conditional_23_Template_button_click_6_listener() {
      \u0275\u0275restoreView(_r13);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.setBhkFilter("1"));
    });
    \u0275\u0275text(7, "1 BHK");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Conditional_23_Template_button_click_8_listener() {
      \u0275\u0275restoreView(_r13);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.setBhkFilter("2"));
    });
    \u0275\u0275text(9, "2 BHK");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Conditional_23_Template_button_click_10_listener() {
      \u0275\u0275restoreView(_r13);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.setBhkFilter("3"));
    });
    \u0275\u0275text(11, "3 BHK");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Conditional_23_Template_button_click_12_listener() {
      \u0275\u0275restoreView(_r13);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.setBhkFilter("4+"));
    });
    \u0275\u0275text(13, "4+ BHK");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(4);
    \u0275\u0275classProp("active", ctx_r2.selectedBhk === "all");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r2.selectedBhk === "1");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r2.selectedBhk === "2");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r2.selectedBhk === "3");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r2.selectedBhk === "4+");
  }
}
function PropertyPage_ng_template_50_Conditional_30_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Conditional_30_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r14);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.setBudgetFilter("under_30l"));
    });
    \u0275\u0275text(1, "Under \u20B930L");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Conditional_30_Template_button_click_2_listener() {
      \u0275\u0275restoreView(_r14);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.setBudgetFilter("30l_60l"));
    });
    \u0275\u0275text(3, "\u20B930L - \u20B960L");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Conditional_30_Template_button_click_4_listener() {
      \u0275\u0275restoreView(_r14);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.setBudgetFilter("60l_1cr"));
    });
    \u0275\u0275text(5, "\u20B960L - \u20B91Cr");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Conditional_30_Template_button_click_6_listener() {
      \u0275\u0275restoreView(_r14);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.setBudgetFilter("above_1cr"));
    });
    \u0275\u0275text(7, "\u20B91Cr+");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275classProp("active", ctx_r2.selectedBudget === "under_30l");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r2.selectedBudget === "30l_60l");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r2.selectedBudget === "60l_1cr");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r2.selectedBudget === "above_1cr");
  }
}
function PropertyPage_ng_template_50_Conditional_31_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Conditional_31_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r15);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.setBudgetFilter("under_10k"));
    });
    \u0275\u0275text(1, "Under \u20B910k");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Conditional_31_Template_button_click_2_listener() {
      \u0275\u0275restoreView(_r15);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.setBudgetFilter("10k_20k"));
    });
    \u0275\u0275text(3, "\u20B910k - \u20B920k");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Conditional_31_Template_button_click_4_listener() {
      \u0275\u0275restoreView(_r15);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.setBudgetFilter("above_20k"));
    });
    \u0275\u0275text(5, "\u20B920k+");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275classProp("active", ctx_r2.selectedBudget === "under_10k");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r2.selectedBudget === "10k_20k");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r2.selectedBudget === "above_20k");
  }
}
function PropertyPage_ng_template_50_Conditional_32_Template(rf, ctx) {
  if (rf & 1) {
    const _r16 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 129)(1, "h4", 138);
    \u0275\u0275text(2, "Furnishing Status");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 139)(4, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Conditional_32_Template_button_click_4_listener() {
      \u0275\u0275restoreView(_r16);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.selectedFurnishing = "all");
    });
    \u0275\u0275text(5, "Any");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Conditional_32_Template_button_click_6_listener() {
      \u0275\u0275restoreView(_r16);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.setFurnishingFilter("Fully Furnished"));
    });
    \u0275\u0275text(7, "Fully Furnished");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Conditional_32_Template_button_click_8_listener() {
      \u0275\u0275restoreView(_r16);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.setFurnishingFilter("Semi-Furnished"));
    });
    \u0275\u0275text(9, "Semi-Furnished");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Conditional_32_Template_button_click_10_listener() {
      \u0275\u0275restoreView(_r16);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.setFurnishingFilter("Unfurnished"));
    });
    \u0275\u0275text(11, "Unfurnished");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(4);
    \u0275\u0275classProp("active", ctx_r2.selectedFurnishing === "all");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r2.selectedFurnishing === "Fully Furnished");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r2.selectedFurnishing === "Semi-Furnished");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r2.selectedFurnishing === "Unfurnished");
  }
}
function PropertyPage_ng_template_50_Conditional_49_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 129)(1, "h4", 138);
    \u0275\u0275text(2, "Parking Availability");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 139)(4, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Conditional_49_Template_button_click_4_listener() {
      \u0275\u0275restoreView(_r17);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.selectedParking = "all");
    });
    \u0275\u0275text(5, "Any");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Conditional_49_Template_button_click_6_listener() {
      \u0275\u0275restoreView(_r17);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.setParkingFilter("Covered"));
    });
    \u0275\u0275text(7, "Covered Parking");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Conditional_49_Template_button_click_8_listener() {
      \u0275\u0275restoreView(_r17);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.setParkingFilter("Available"));
    });
    \u0275\u0275text(9, "Any Parking");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(4);
    \u0275\u0275classProp("active", ctx_r2.selectedParking === "all");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r2.selectedParking === "Covered");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r2.selectedParking === "Available");
  }
}
function PropertyPage_ng_template_50_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 123)(1, "header", 113)(2, "div", 124)(3, "h3", 114);
    \u0275\u0275text(4, "Filter Properties");
    \u0275\u0275elementEnd();
    \u0275\u0275template(5, PropertyPage_ng_template_50_Conditional_5_Template, 2, 1, "span", 125);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "div", 126)(7, "button", 127);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Template_button_click_7_listener() {
      \u0275\u0275restoreView(_r12);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.clearAllFilters());
    });
    \u0275\u0275text(8, " Reset ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "button", 115);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Template_button_click_9_listener() {
      \u0275\u0275restoreView(_r12);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.closeFilterModal());
    });
    \u0275\u0275element(10, "ion-icon", 116);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(11, "div", 128)(12, "div", 129)(13, "div", 130);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Template_div_click_13_listener() {
      \u0275\u0275restoreView(_r12);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.toggleVerifiedOnly());
    });
    \u0275\u0275elementStart(14, "div", 131)(15, "div", 132);
    \u0275\u0275element(16, "ion-icon", 133);
    \u0275\u0275elementStart(17, "span", 134);
    \u0275\u0275text(18, "Pintu Verified Only");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(19, "span", 135);
    \u0275\u0275text(20, "Show only properties verified with legal & physical checks");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(21, "div", 136);
    \u0275\u0275element(22, "div", 137);
    \u0275\u0275elementEnd()()();
    \u0275\u0275template(23, PropertyPage_ng_template_50_Conditional_23_Template, 14, 10, "div", 129);
    \u0275\u0275elementStart(24, "div", 129)(25, "h4", 138);
    \u0275\u0275text(26, "Budget Range");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(27, "div", 139)(28, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Template_button_click_28_listener() {
      \u0275\u0275restoreView(_r12);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.selectedBudget = "all");
    });
    \u0275\u0275text(29, "Any");
    \u0275\u0275elementEnd();
    \u0275\u0275template(30, PropertyPage_ng_template_50_Conditional_30_Template, 8, 8)(31, PropertyPage_ng_template_50_Conditional_31_Template, 6, 6);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(32, PropertyPage_ng_template_50_Conditional_32_Template, 12, 8, "div", 129);
    \u0275\u0275elementStart(33, "div", 129)(34, "h4", 138);
    \u0275\u0275text(35, "Facing Direction");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(36, "div", 139)(37, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Template_button_click_37_listener() {
      \u0275\u0275restoreView(_r12);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.selectedFacing = "all");
    });
    \u0275\u0275text(38, "Any");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(39, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Template_button_click_39_listener() {
      \u0275\u0275restoreView(_r12);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.setFacingFilter("East"));
    });
    \u0275\u0275text(40, "East");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(41, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Template_button_click_41_listener() {
      \u0275\u0275restoreView(_r12);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.setFacingFilter("North"));
    });
    \u0275\u0275text(42, "North");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(43, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Template_button_click_43_listener() {
      \u0275\u0275restoreView(_r12);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.setFacingFilter("North-East"));
    });
    \u0275\u0275text(44, "North-East");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(45, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Template_button_click_45_listener() {
      \u0275\u0275restoreView(_r12);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.setFacingFilter("West"));
    });
    \u0275\u0275text(46, "West");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(47, "button", 140);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Template_button_click_47_listener() {
      \u0275\u0275restoreView(_r12);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.setFacingFilter("South"));
    });
    \u0275\u0275text(48, "South");
    \u0275\u0275elementEnd()()();
    \u0275\u0275template(49, PropertyPage_ng_template_50_Conditional_49_Template, 10, 6, "div", 129);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(50, "footer", 141)(51, "button", 142);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Template_button_click_51_listener() {
      \u0275\u0275restoreView(_r12);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.clearAllFilters());
    });
    \u0275\u0275text(52, " Clear All ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(53, "button", 143);
    \u0275\u0275listener("click", function PropertyPage_ng_template_50_Template_button_click_53_listener() {
      \u0275\u0275restoreView(_r12);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.applyFilters());
    });
    \u0275\u0275text(54);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance(5);
    \u0275\u0275conditional(ctx_r2.activeFiltersCount > 0 ? 5 : -1);
    \u0275\u0275advance(8);
    \u0275\u0275classProp("active", ctx_r2.verifiedOnly);
    \u0275\u0275advance(8);
    \u0275\u0275classProp("on", ctx_r2.verifiedOnly);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r2.activeCategory === "buy_house" || ctx_r2.activeCategory === "rent_house" ? 23 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275classProp("active", ctx_r2.selectedBudget === "all");
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r2.activeCategory !== "rent_house" ? 30 : 31);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r2.activeCategory === "buy_house" || ctx_r2.activeCategory === "rent_house" ? 32 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275classProp("active", ctx_r2.selectedFacing === "all");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r2.selectedFacing === "East");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r2.selectedFacing === "North");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r2.selectedFacing === "North-East");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r2.selectedFacing === "West");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r2.selectedFacing === "South");
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r2.activeCategory === "buy_house" || ctx_r2.activeCategory === "rent_house" ? 49 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate1(" Show ", ctx_r2.filteredProperties.length, " Properties ");
  }
}
var _PropertyPage = class _PropertyPage {
  constructor(navCtrl, router, locationService, propertyService, toastCtrl) {
    this.navCtrl = navCtrl;
    this.router = router;
    this.locationService = locationService;
    this.propertyService = propertyService;
    this.toastCtrl = toastCtrl;
    this.locationTitle = "Jamkhandi";
    this.locationSubtitle = "Select your preferred location";
    this.locationSub = null;
    this.isRefreshing = false;
    this.isLoading = true;
    this.activeCategory = "buy_house";
    this.categoryTabs = [
      { id: "buy_house", label: "Buy House", icon: "home-outline", emoji: "\u{1F3E1}" },
      { id: "rent_house", label: "Rent House", icon: "key-outline", emoji: "\u{1F511}" },
      { id: "buy_land", label: "Buy Land", icon: "leaf-outline", emoji: "\u{1F33E}" },
      { id: "buy_plot", label: "Buy Plot", icon: "grid-outline", emoji: "\u{1F4D0}" }
    ];
    this.searchQuery = "";
    this.selectedBhk = "all";
    this.selectedBudget = "all";
    this.selectedFurnishing = "all";
    this.selectedFacing = "all";
    this.selectedParking = "all";
    this.verifiedOnly = false;
    this.sortBy = "featured";
    this.isSortModalOpen = false;
    this.isFilterModalOpen = false;
    this.filteredProperties = [];
    this.searchSubject = new Subject();
    this.searchSub = null;
    addIcons({
      arrowBackOutline,
      location,
      chevronDown,
      searchOutline,
      optionsOutline,
      heartOutline,
      heart,
      callOutline,
      logoWhatsapp,
      bedOutline,
      waterOutline,
      carOutline,
      compassOutline,
      expandOutline,
      checkmarkCircle,
      sparkles,
      shieldCheckmarkOutline,
      filterOutline,
      closeCircleOutline,
      refreshOutline,
      homeOutline,
      keyOutline,
      leafOutline,
      gridOutline,
      shareSocialOutline,
      swapVerticalOutline,
      checkmark,
      closeOutline,
      addOutline,
      lockClosedOutline
    });
  }
  ngOnInit() {
    this.initLocation();
    this.setupSearchSubscription();
    this.fetchPropertiesFromApi();
  }
  ionViewWillEnter() {
    this.initLocation();
    this.fetchPropertiesFromApi();
  }
  ngOnDestroy() {
    if (this.locationSub) {
      this.locationSub.unsubscribe();
    }
    if (this.searchSub) {
      this.searchSub.unsubscribe();
    }
  }
  setupSearchSubscription() {
    this.searchSub = this.searchSubject.pipe(debounceTime(350), distinctUntilChanged()).subscribe(() => {
      this.fetchPropertiesFromApi();
    });
  }
  onSearchChanged(query) {
    this.searchSubject.next(query);
  }
  clearSearch() {
    this.searchQuery = "";
    this.fetchPropertiesFromApi();
  }
  initLocation() {
    try {
      const saved = localStorage.getItem("location");
      if (saved) {
        const parsed = JSON.parse(saved);
        this.applyAcquiredLocation(parsed);
        if (parsed.lat && parsed.lng) {
          this.detectServiceArea(Number(parsed.lat), Number(parsed.lng));
          return;
        }
      }
    } catch (e) {
      console.warn("Could not read cached location in property page:", e);
    }
    try {
      const primarySaved = localStorage.getItem("primary_address");
      if (primarySaved) {
        const primaryParsed = JSON.parse(primarySaved);
        this.applyAcquiredLocation(primaryParsed);
        if (primaryParsed.lat && primaryParsed.lng) {
          this.detectServiceArea(Number(primaryParsed.lat), Number(primaryParsed.lng));
          return;
        }
      }
    } catch {
    }
    this.locationSub = this.locationService.address$.subscribe((addr) => {
      if (addr) {
        this.locationSubtitle = addr;
      }
    });
    this.locationService.getCurrentPosition().then((pos) => {
      var _a;
      if ((_a = pos == null ? void 0 : pos.coords) == null ? void 0 : _a.coords) {
        const lat = pos.coords.coords.latitude;
        const lng = pos.coords.coords.longitude;
        if (pos.address)
          this.locationSubtitle = pos.address;
        this.detectServiceArea(lat, lng);
      }
    }).catch(() => {
    });
  }
  applyAcquiredLocation(data) {
    if (!data)
      return;
    const detailedParts = [
      data.house_no,
      data.building_name,
      data.landmark ? "Near " + data.landmark : "",
      data.address
    ].filter(Boolean);
    if (detailedParts.length > 1) {
      this.locationSubtitle = detailedParts.join(", ");
    } else if (data.address && data.address.trim()) {
      this.locationSubtitle = data.address.trim();
    }
    if (data.city && data.city.trim()) {
      this.locationTitle = data.city.trim();
    } else if (data.area && data.area.trim()) {
      this.locationTitle = data.area.trim();
    }
  }
  detectServiceArea(lat, lng) {
    this.locationService.checkLocationInServiceArea(lat, lng).subscribe({
      next: (res) => {
        if (res == null ? void 0 : res.success) {
          if (res.inServiceArea && res.area) {
            this.locationTitle = res.area.cityName || res.area.name || this.locationTitle || "Jamkhandi";
          } else if (res.nearestArea) {
            this.locationTitle = res.nearestArea.cityName || this.locationTitle || "Jamkhandi";
          }
        }
      },
      error: (err) => {
        console.warn("Could not detect service area for property page:", err);
      }
    });
  }
  goBack() {
    this.navCtrl.navigateRoot("/layout/home");
  }
  openLocation() {
    this.router.navigate(["/layout/map"]);
  }
  refreshData() {
    return __async(this, null, function* () {
      if (this.isRefreshing)
        return;
      this.isRefreshing = true;
      this.initLocation();
      this.fetchPropertiesFromApi();
    });
  }
  fetchPropertiesFromApi() {
    this.isLoading = true;
    let minPrice;
    let maxPrice;
    if (this.selectedBudget !== "all") {
      if (this.activeCategory === "rent_house") {
        if (this.selectedBudget === "under_10k")
          maxPrice = 1e4;
        else if (this.selectedBudget === "10k_20k") {
          minPrice = 1e4;
          maxPrice = 2e4;
        } else if (this.selectedBudget === "above_20k")
          minPrice = 2e4;
      } else {
        if (this.selectedBudget === "under_30l")
          maxPrice = 3e6;
        else if (this.selectedBudget === "30l_60l") {
          minPrice = 3e6;
          maxPrice = 6e6;
        } else if (this.selectedBudget === "60l_1cr") {
          minPrice = 6e6;
          maxPrice = 1e7;
        } else if (this.selectedBudget === "above_1cr")
          minPrice = 1e7;
      }
    }
    const filters = {
      category: this.activeCategory,
      search: this.searchQuery.trim() || void 0,
      bedrooms: (this.activeCategory === "buy_house" || this.activeCategory === "rent_house") && this.selectedBhk !== "all" ? this.selectedBhk : void 0,
      minPrice,
      maxPrice,
      furnishing: this.selectedFurnishing !== "all" ? this.selectedFurnishing : void 0,
      facing: this.selectedFacing !== "all" ? this.selectedFacing : void 0,
      parking: this.selectedParking !== "all" ? this.selectedParking : void 0,
      verifiedOnly: this.verifiedOnly ? true : void 0,
      sortBy: this.sortBy !== "featured" ? this.sortBy : void 0
    };
    this.propertyService.getProperties(filters).subscribe({
      next: (data) => {
        this.filteredProperties = data || [];
        this.isLoading = false;
        this.isRefreshing = false;
      },
      error: (err) => {
        console.warn("Failed to fetch filtered properties from API:", err);
        this.isLoading = false;
        this.isRefreshing = false;
      }
    });
  }
  setCategory(catId) {
    if (this.activeCategory === catId)
      return;
    this.activeCategory = catId;
    this.selectedBhk = "all";
    this.selectedBudget = "all";
    this.selectedFurnishing = "all";
    this.selectedFacing = "all";
    this.selectedParking = "all";
    this.fetchPropertiesFromApi();
  }
  setBhkFilter(bhk) {
    this.selectedBhk = this.selectedBhk === bhk ? "all" : bhk;
    this.fetchPropertiesFromApi();
  }
  setBudgetFilter(budget) {
    this.selectedBudget = this.selectedBudget === budget ? "all" : budget;
    this.fetchPropertiesFromApi();
  }
  setFurnishingFilter(f) {
    this.selectedFurnishing = this.selectedFurnishing === f ? "all" : f;
    this.fetchPropertiesFromApi();
  }
  setFacingFilter(facing) {
    this.selectedFacing = this.selectedFacing === facing ? "all" : facing;
    this.fetchPropertiesFromApi();
  }
  setParkingFilter(parking) {
    this.selectedParking = this.selectedParking === parking ? "all" : parking;
    this.fetchPropertiesFromApi();
  }
  toggleVerifiedOnly() {
    this.verifiedOnly = !this.verifiedOnly;
    this.fetchPropertiesFromApi();
  }
  // Sort Modal Handlers
  openSortModal() {
    this.isSortModalOpen = true;
  }
  closeSortModal() {
    this.isSortModalOpen = false;
  }
  selectSort(sort) {
    this.sortBy = sort;
    this.closeSortModal();
    this.fetchPropertiesFromApi();
  }
  get currentSortLabel() {
    switch (this.sortBy) {
      case "price_low":
        return "Price: Low to High";
      case "price_high":
        return "Price: High to Low";
      case "newest":
        return "Newest First";
      case "area_high":
        return "Largest Area";
      default:
        return "Featured";
    }
  }
  // Filter Modal Handlers
  openFilterModal() {
    this.isFilterModalOpen = true;
  }
  closeFilterModal() {
    this.isFilterModalOpen = false;
  }
  applyFilters() {
    this.closeFilterModal();
    this.fetchPropertiesFromApi();
  }
  clearAllFilters() {
    this.searchQuery = "";
    this.selectedBhk = "all";
    this.selectedBudget = "all";
    this.selectedFurnishing = "all";
    this.selectedFacing = "all";
    this.selectedParking = "all";
    this.verifiedOnly = false;
    this.sortBy = "featured";
    this.fetchPropertiesFromApi();
  }
  get activeFiltersCount() {
    let count = 0;
    if (this.verifiedOnly)
      count++;
    if (this.selectedBhk !== "all")
      count++;
    if (this.selectedBudget !== "all")
      count++;
    if (this.selectedFurnishing !== "all")
      count++;
    if (this.selectedFacing !== "all")
      count++;
    if (this.selectedParking !== "all")
      count++;
    return count;
  }
  get hasActiveFilters() {
    return this.searchQuery.trim().length > 0 || this.activeFiltersCount > 0 || this.sortBy !== "featured";
  }
  toggleFavorite(prop, event) {
    event.stopPropagation();
    prop.isFavorite = !prop.isFavorite;
  }
  viewDetails(prop) {
    this.router.navigate(["/layout/property/details", prop.id]);
  }
  callSeller(prop, event) {
    event.stopPropagation();
    if (prop.status === "sold")
      return;
    window.open(`tel:${prop.seller.phone.replace(/[^0-9+]/g, "")}`, "_system");
  }
  whatsappSeller(prop, event) {
    event.stopPropagation();
    if (prop.status === "sold")
      return;
    const text = encodeURIComponent(`Hello ${prop.seller.name}, I am interested in your property on Pintu: "${prop.title}" (${prop.priceDisplay}) located in ${prop.locality}. Is it still available?`);
    window.open(`https://wa.me/${prop.seller.whatsapp}?text=${text}`, "_system");
  }
  goToRegisterProperty() {
    this.router.navigate(["/layout/property/register"]);
  }
};
_PropertyPage.\u0275fac = function PropertyPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _PropertyPage)(\u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(LocationService), \u0275\u0275directiveInject(PropertyService), \u0275\u0275directiveInject(ToastController));
};
_PropertyPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _PropertyPage, selectors: [["app-property"]], decls: 51, vars: 25, consts: [[1, "property-header", "ion-no-border"], [1, "property-toolbar"], [1, "header-content-wrap"], ["type", "button", "aria-label", "Go Back", 1, "btn-header-back", 3, "click"], ["name", "arrow-back-outline"], ["role", "button", "tabindex", "0", 1, "location-pill-wrap", 3, "click"], [1, "loc-pin-badge"], ["name", "location"], [1, "loc-text-col"], [1, "loc-title-row"], [1, "loc-city-name"], ["name", "chevron-down", 1, "chevron-mini"], [1, "loc-address-line", "text-truncate"], ["type", "button", "title", "Refresh Properties", "aria-label", "Refresh", 1, "btn-header-refresh", 3, "click"], ["name", "refresh-outline"], [1, "property-tabs-container"], [1, "property-tabs-strip"], ["type", "button", 1, "tab-pill", 3, "active"], [1, "property-page-content", 3, "fullscreen"], [1, "search-filter-section"], [1, "search-inline-row"], [1, "search-input-box"], ["name", "search-outline", 1, "search-lens"], ["type", "text", "placeholder", "Search locality, project, landmark...", 1, "search-text-field", 3, "ngModelChange", "ngModel"], ["type", "button", "aria-label", "Clear Search", 1, "btn-clear-search"], ["type", "button", "title", "Sort Properties", "aria-label", "Sort", 1, "icon-action-btn", 3, "click"], ["name", "swap-vertical-outline"], ["type", "button", "title", "Filter Properties", "aria-label", "Filter", 1, "icon-action-btn", 3, "click"], ["name", "options-outline"], [1, "mini-count-dot"], [1, "property-listings-container"], [1, "results-header-row"], [1, "results-count-text"], [1, "loading-label-wrap"], ["type", "button", 1, "btn-clear-chips"], ["aria-busy", "true", "aria-label", "Loading properties", 1, "cards-stack", "skeleton-stack"], [1, "empty-state-card"], [1, "bottom-safe-spacer"], ["type", "button", "title", "Post Property", "aria-label", "Post Property", 1, "fab-register-property", 3, "click"], ["name", "add-outline"], [3, "didDismiss", "isOpen", "initialBreakpoint", "breakpoints", "handle"], ["type", "button", 1, "tab-pill", 3, "click"], [1, "tab-pill-icon", 3, "name"], [1, "tab-pill-text"], ["type", "button", "aria-label", "Clear Search", 1, "btn-clear-search", 3, "click"], ["name", "close-circle-outline"], [1, "spinner-dot"], ["type", "button", 1, "btn-clear-chips", 3, "click"], [1, "property-card", "skeleton-card"], [1, "card-image-wrap", "skeleton-img-box"], [1, "skeleton-shimmer"], [1, "skeleton-top-badges"], [1, "skeleton-badge-pill"], [1, "skeleton-badge-pill", "sm"], [1, "skeleton-price-badge"], [1, "card-body"], [1, "skeleton-line", "title"], [1, "skeleton-line", "locality"], [1, "specs-chips-row", "skeleton-specs"], [1, "skeleton-chip"], [1, "card-divider"], [1, "card-footer-row", "skeleton-footer"], [1, "skeleton-seller"], [1, "skeleton-line", "role"], [1, "skeleton-line", "name"], [1, "action-buttons-group"], [1, "skeleton-btn"], [1, "skeleton-btn", "whatsapp"], [1, "cards-stack"], [1, "property-card"], [1, "property-card", 3, "click"], [1, "card-image-wrap"], ["loading", "lazy", 1, "card-hero-img", 3, "src", "alt"], [1, "card-gradient-scrim"], [1, "floating-tags-row"], [1, "property-type-tag"], [1, "sold-tag"], [1, "verified-tag"], ["type", "button", "aria-label", "Save Property", 1, "btn-favorite", 3, "click"], [3, "name"], [1, "image-price-banner"], [1, "price-val-row"], [1, "price-main"], [1, "price-unit"], [1, "price-sub-calc"], [1, "property-title"], [1, "property-locality"], ["name", "location", 1, "loc-mini-icon"], [1, "specs-chips-row"], [1, "spec-pill"], ["name", "expand-outline"], ["name", "compass-outline"], [1, "card-footer-row"], [1, "seller-brief"], [1, "seller-role"], [1, "seller-name"], ["type", "button", "disabled", "", "aria-label", "Property is Sold", 1, "btn-contact-sold"], ["name", "checkmark-circle"], ["name", "bed-outline"], ["name", "water-outline"], ["type", "button", "disabled", "", "aria-label", "Property is Sold", 1, "btn-contact-sold", 3, "click"], ["name", "lock-closed-outline"], ["type", "button", "aria-label", "Call Seller", 1, "btn-contact-call", 3, "click"], ["name", "call-outline"], ["type", "button", "aria-label", "WhatsApp Seller", 1, "btn-contact-whatsapp", 3, "click"], ["name", "logo-whatsapp"], [1, "empty-icon-halo"], ["name", "home-outline"], [1, "empty-title"], [1, "empty-desc"], ["type", "button", 1, "btn-reset-filters", 3, "click"], ["name", "refresh-outline", 1, "me-1"], [1, "sheet-container"], [1, "sheet-header"], [1, "sheet-title"], ["type", "button", "aria-label", "Close", 1, "btn-sheet-close", 3, "click"], ["name", "close-outline"], [1, "sheet-body"], [1, "sort-option-item", 3, "click"], [1, "sort-option-text"], [1, "sort-title"], [1, "sort-desc"], ["name", "checkmark", 1, "check-icon"], [1, "sheet-container", "filter-sheet-container"], [1, "sheet-header-left"], [1, "sheet-count-tag"], [1, "sheet-header-right"], ["type", "button", 1, "btn-sheet-reset", 3, "click"], [1, "sheet-scroll-body"], [1, "filter-section-block"], [1, "verified-toggle-card", 3, "click"], [1, "toggle-info-col"], [1, "toggle-title-row"], ["name", "checkmark-circle", 1, "verified-icon"], [1, "toggle-title"], [1, "toggle-desc"], [1, "custom-switch"], [1, "switch-handle"], [1, "filter-block-title"], [1, "chips-selector-row"], ["type", "button", 1, "choice-chip", 3, "click"], [1, "sheet-footer"], ["type", "button", 1, "btn-sheet-clear", 3, "click"], ["type", "button", 1, "btn-sheet-apply", 3, "click"]], template: function PropertyPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar", 1)(2, "div", 2)(3, "button", 3);
    \u0275\u0275listener("click", function PropertyPage_Template_button_click_3_listener() {
      return ctx.goBack();
    });
    \u0275\u0275element(4, "ion-icon", 4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 5);
    \u0275\u0275listener("click", function PropertyPage_Template_div_click_5_listener() {
      return ctx.openLocation();
    });
    \u0275\u0275elementStart(6, "div", 6);
    \u0275\u0275element(7, "ion-icon", 7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "div", 8)(9, "div", 9)(10, "span", 10);
    \u0275\u0275text(11);
    \u0275\u0275elementEnd();
    \u0275\u0275element(12, "ion-icon", 11);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "span", 12);
    \u0275\u0275text(14);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(15, "button", 13);
    \u0275\u0275listener("click", function PropertyPage_Template_button_click_15_listener() {
      return ctx.refreshData();
    });
    \u0275\u0275element(16, "ion-icon", 14);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(17, "div", 15)(18, "div", 16);
    \u0275\u0275repeaterCreate(19, PropertyPage_For_20_Template, 4, 4, "button", 17, _forTrack0);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(21, "ion-content", 18)(22, "div", 19)(23, "div", 20)(24, "div", 21);
    \u0275\u0275element(25, "ion-icon", 22);
    \u0275\u0275elementStart(26, "input", 23);
    \u0275\u0275twoWayListener("ngModelChange", function PropertyPage_Template_input_ngModelChange_26_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.searchQuery, $event) || (ctx.searchQuery = $event);
      return $event;
    });
    \u0275\u0275listener("ngModelChange", function PropertyPage_Template_input_ngModelChange_26_listener($event) {
      return ctx.onSearchChanged($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275template(27, PropertyPage_Conditional_27_Template, 2, 0, "button", 24);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(28, "button", 25);
    \u0275\u0275listener("click", function PropertyPage_Template_button_click_28_listener() {
      return ctx.openSortModal();
    });
    \u0275\u0275element(29, "ion-icon", 26);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(30, "button", 27);
    \u0275\u0275listener("click", function PropertyPage_Template_button_click_30_listener() {
      return ctx.openFilterModal();
    });
    \u0275\u0275element(31, "ion-icon", 28);
    \u0275\u0275template(32, PropertyPage_Conditional_32_Template, 2, 1, "span", 29);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(33, "main", 30)(34, "div", 31)(35, "span", 32);
    \u0275\u0275template(36, PropertyPage_Conditional_36_Template, 4, 0, "span", 33)(37, PropertyPage_Conditional_37_Template, 4, 2);
    \u0275\u0275elementEnd();
    \u0275\u0275template(38, PropertyPage_Conditional_38_Template, 2, 1, "button", 34);
    \u0275\u0275elementEnd();
    \u0275\u0275template(39, PropertyPage_Conditional_39_Template, 3, 1, "div", 35)(40, PropertyPage_Conditional_40_Template, 4, 0)(41, PropertyPage_Conditional_41_Template, 11, 1, "div", 36);
    \u0275\u0275element(42, "div", 37);
    \u0275\u0275elementStart(43, "button", 38);
    \u0275\u0275listener("click", function PropertyPage_Template_button_click_43_listener() {
      return ctx.goToRegisterProperty();
    });
    \u0275\u0275element(44, "ion-icon", 39);
    \u0275\u0275elementStart(45, "span");
    \u0275\u0275text(46, "Post Property");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(47, "ion-modal", 40);
    \u0275\u0275listener("didDismiss", function PropertyPage_Template_ion_modal_didDismiss_47_listener() {
      return ctx.closeSortModal();
    });
    \u0275\u0275template(48, PropertyPage_ng_template_48_Template, 42, 15, "ng-template");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(49, "ion-modal", 40);
    \u0275\u0275listener("didDismiss", function PropertyPage_Template_ion_modal_didDismiss_49_listener() {
      return ctx.closeFilterModal();
    });
    \u0275\u0275template(50, PropertyPage_ng_template_50_Template, 55, 24, "ng-template");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(11);
    \u0275\u0275textInterpolate(ctx.locationTitle);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx.locationSubtitle);
    \u0275\u0275advance();
    \u0275\u0275classProp("spinning", ctx.isRefreshing);
    \u0275\u0275advance(4);
    \u0275\u0275repeater(ctx.categoryTabs);
    \u0275\u0275advance(2);
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx.searchQuery);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.searchQuery.trim() ? 27 : -1);
    \u0275\u0275advance();
    \u0275\u0275classProp("active", ctx.sortBy !== "featured");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx.activeFiltersCount > 0);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx.activeFiltersCount > 0 ? 32 : -1);
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx.isLoading ? 36 : 37);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(!ctx.isLoading && ctx.activeFiltersCount > 0 ? 38 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.isLoading ? 39 : ctx.filteredProperties.length > 0 ? 40 : 41);
    \u0275\u0275advance(8);
    \u0275\u0275property("isOpen", ctx.isSortModalOpen)("initialBreakpoint", 0.5)("breakpoints", \u0275\u0275pureFunction0(23, _c0))("handle", true);
    \u0275\u0275advance(2);
    \u0275\u0275property("isOpen", ctx.isFilterModalOpen)("initialBreakpoint", 0.78)("breakpoints", \u0275\u0275pureFunction0(24, _c1))("handle", true);
  }
}, dependencies: [
  IonHeader,
  IonToolbar,
  IonContent,
  IonIcon,
  IonModal,
  CommonModule,
  DecimalPipe,
  FormsModule,
  DefaultValueAccessor,
  NgControlStatus,
  NgModel,
  PropertyFooterComponent
], styles: ['\n\n.property-header[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-bottom: 1px solid #f1f5f9;\n  position: sticky;\n  top: 0;\n  z-index: 100;\n  padding-top: max(env(safe-area-inset-top, 0px), 16px);\n}\n.property-header[_ngcontent-%COMP%]   .property-toolbar[_ngcontent-%COMP%] {\n  --background: #ffffff;\n  --min-height: 52px;\n  --padding-top: 4px;\n  --padding-bottom: 2px;\n  --padding-start: 14px;\n  --padding-end: 14px;\n  padding: 0;\n}\n.property-header[_ngcontent-%COMP%]   .header-content-wrap[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  width: 100%;\n  padding: 2px 0 4px;\n}\n.property-header[_ngcontent-%COMP%]   .btn-header-back[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 38px;\n  border-radius: 50%;\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n  color: #0f172a;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 19px;\n  cursor: pointer;\n  flex-shrink: 0;\n  transition: transform 0.15s ease;\n}\n.property-header[_ngcontent-%COMP%]   .btn-header-back[_ngcontent-%COMP%]:active {\n  transform: scale(0.92);\n}\n.property-header[_ngcontent-%COMP%]   .location-pill-wrap[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 0;\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  background: #f8fafc;\n  border: 1.5px solid #e2e8f0;\n  border-radius: 999px;\n  padding: 4px 12px 4px 6px;\n  cursor: pointer;\n  transition: all 0.2s ease;\n}\n.property-header[_ngcontent-%COMP%]   .location-pill-wrap[_ngcontent-%COMP%]:active {\n  background: #f1f5f9;\n  transform: scale(0.99);\n}\n.property-header[_ngcontent-%COMP%]   .location-pill-wrap[_ngcontent-%COMP%]   .loc-pin-badge[_ngcontent-%COMP%] {\n  width: 28px;\n  height: 28px;\n  border-radius: 50%;\n  background:\n    linear-gradient(\n      135deg,\n      #a000e2 0%,\n      #7e00b3 100%);\n  color: #ffffff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 15px;\n  flex-shrink: 0;\n  box-shadow: 0 2px 6px rgba(160, 0, 226, 0.3);\n}\n.property-header[_ngcontent-%COMP%]   .location-pill-wrap[_ngcontent-%COMP%]   .loc-text-col[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 0;\n  display: flex;\n  flex-direction: column;\n  line-height: 1.15;\n}\n.property-header[_ngcontent-%COMP%]   .location-pill-wrap[_ngcontent-%COMP%]   .loc-text-col[_ngcontent-%COMP%]   .loc-title-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 4px;\n}\n.property-header[_ngcontent-%COMP%]   .location-pill-wrap[_ngcontent-%COMP%]   .loc-text-col[_ngcontent-%COMP%]   .loc-title-row[_ngcontent-%COMP%]   .loc-city-name[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  font-weight: 800;\n  color: #0f172a;\n  letter-spacing: -0.2px;\n}\n.property-header[_ngcontent-%COMP%]   .location-pill-wrap[_ngcontent-%COMP%]   .loc-text-col[_ngcontent-%COMP%]   .loc-title-row[_ngcontent-%COMP%]   .chevron-mini[_ngcontent-%COMP%] {\n  font-size: 13px;\n  color: #64748b;\n}\n.property-header[_ngcontent-%COMP%]   .location-pill-wrap[_ngcontent-%COMP%]   .loc-text-col[_ngcontent-%COMP%]   .loc-address-line[_ngcontent-%COMP%] {\n  font-size: 10.5px;\n  font-weight: 500;\n  color: #64748b;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.property-header[_ngcontent-%COMP%]   .btn-header-refresh[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 38px;\n  border-radius: 50%;\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n  color: #475569;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 18px;\n  cursor: pointer;\n  flex-shrink: 0;\n  transition: all 0.2s ease;\n}\n.property-header[_ngcontent-%COMP%]   .btn-header-refresh[_ngcontent-%COMP%]:active {\n  transform: scale(0.92);\n  background: #f1f5f9;\n}\n.property-header[_ngcontent-%COMP%]   .btn-header-refresh.spinning[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  animation: _ngcontent-%COMP%_refresh-spin 0.7s linear infinite;\n}\n@keyframes _ngcontent-%COMP%_refresh-spin {\n  from {\n    transform: rotate(0deg);\n  }\n  to {\n    transform: rotate(360deg);\n  }\n}\n.property-tabs-container[_ngcontent-%COMP%] {\n  padding: 4px 14px 10px;\n  background: #ffffff;\n  width: 100%;\n  box-sizing: border-box;\n}\n.property-tabs-container[_ngcontent-%COMP%]   .property-tabs-strip[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  width: 100%;\n  background: #f1f5f9;\n  padding: 3px;\n  border-radius: 12px;\n  box-sizing: border-box;\n  gap: 2px;\n}\n.property-tabs-container[_ngcontent-%COMP%]   .property-tabs-strip[_ngcontent-%COMP%]   .tab-pill[_ngcontent-%COMP%] {\n  flex: 1;\n  border: none;\n  background: transparent;\n  padding: 8px 2px;\n  border-radius: 9px;\n  cursor: pointer;\n  text-align: center;\n  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);\n  white-space: nowrap;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 4px;\n}\n.property-tabs-container[_ngcontent-%COMP%]   .property-tabs-strip[_ngcontent-%COMP%]   .tab-pill[_ngcontent-%COMP%]   .tab-pill-icon[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  color: #64748b;\n  transition: color 0.2s ease;\n}\n.property-tabs-container[_ngcontent-%COMP%]   .property-tabs-strip[_ngcontent-%COMP%]   .tab-pill[_ngcontent-%COMP%]   .tab-pill-text[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 700;\n  color: #64748b;\n  transition: color 0.2s ease;\n}\n.property-tabs-container[_ngcontent-%COMP%]   .property-tabs-strip[_ngcontent-%COMP%]   .tab-pill[_ngcontent-%COMP%]:active {\n  transform: scale(0.97);\n}\n.property-tabs-container[_ngcontent-%COMP%]   .property-tabs-strip[_ngcontent-%COMP%]   .tab-pill.active[_ngcontent-%COMP%] {\n  background: #ffffff;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);\n}\n.property-tabs-container[_ngcontent-%COMP%]   .property-tabs-strip[_ngcontent-%COMP%]   .tab-pill.active[_ngcontent-%COMP%]   .tab-pill-icon[_ngcontent-%COMP%] {\n  color: #a000e2;\n}\n.property-tabs-container[_ngcontent-%COMP%]   .property-tabs-strip[_ngcontent-%COMP%]   .tab-pill.active[_ngcontent-%COMP%]   .tab-pill-text[_ngcontent-%COMP%] {\n  color: #a000e2;\n  font-weight: 850;\n}\n.property-page-content[_ngcontent-%COMP%] {\n  --background: #f8fafc;\n}\n.search-filter-section[_ngcontent-%COMP%] {\n  background: #ffffff;\n  padding: 10px 14px 12px;\n  border-bottom: 1px solid #f1f5f9;\n}\n.search-filter-section[_ngcontent-%COMP%]   .search-inline-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  width: 100%;\n}\n.search-filter-section[_ngcontent-%COMP%]   .search-inline-row[_ngcontent-%COMP%]   .search-input-box[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 0;\n  display: flex;\n  align-items: center;\n  background: #f8fafc;\n  border: 1.5px solid #e2e8f0;\n  border-radius: 12px;\n  padding: 0 12px;\n  height: 42px;\n  transition: all 0.2s ease;\n}\n.search-filter-section[_ngcontent-%COMP%]   .search-inline-row[_ngcontent-%COMP%]   .search-input-box[_ngcontent-%COMP%]:focus-within {\n  border-color: #a000e2;\n  background: #ffffff;\n  box-shadow: 0 0 0 3px rgba(160, 0, 226, 0.1);\n}\n.search-filter-section[_ngcontent-%COMP%]   .search-inline-row[_ngcontent-%COMP%]   .search-input-box[_ngcontent-%COMP%]   .search-lens[_ngcontent-%COMP%] {\n  font-size: 18px;\n  color: #94a3b8;\n  margin-right: 8px;\n  flex-shrink: 0;\n}\n.search-filter-section[_ngcontent-%COMP%]   .search-inline-row[_ngcontent-%COMP%]   .search-input-box[_ngcontent-%COMP%]   .search-text-field[_ngcontent-%COMP%] {\n  border: none;\n  background: transparent;\n  outline: none;\n  font-size: 13px;\n  font-weight: 600;\n  color: #0f172a;\n  width: 100%;\n}\n.search-filter-section[_ngcontent-%COMP%]   .search-inline-row[_ngcontent-%COMP%]   .search-input-box[_ngcontent-%COMP%]   .search-text-field[_ngcontent-%COMP%]::placeholder {\n  color: #94a3b8;\n  font-weight: 400;\n}\n.search-filter-section[_ngcontent-%COMP%]   .search-inline-row[_ngcontent-%COMP%]   .search-input-box[_ngcontent-%COMP%]   .btn-clear-search[_ngcontent-%COMP%] {\n  background: transparent;\n  border: none;\n  color: #94a3b8;\n  font-size: 18px;\n  cursor: pointer;\n  display: flex;\n  align-items: center;\n  padding: 0;\n}\n.search-filter-section[_ngcontent-%COMP%]   .search-inline-row[_ngcontent-%COMP%]   .icon-action-btn[_ngcontent-%COMP%] {\n  width: 42px;\n  height: 42px;\n  border-radius: 12px;\n  background: #f8fafc;\n  border: 1.5px solid #e2e8f0;\n  color: #475569;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 19px;\n  cursor: pointer;\n  flex-shrink: 0;\n  position: relative;\n  transition: all 0.15s ease;\n}\n.search-filter-section[_ngcontent-%COMP%]   .search-inline-row[_ngcontent-%COMP%]   .icon-action-btn[_ngcontent-%COMP%]:active {\n  transform: scale(0.92);\n  background: #f1f5f9;\n}\n.search-filter-section[_ngcontent-%COMP%]   .search-inline-row[_ngcontent-%COMP%]   .icon-action-btn.active[_ngcontent-%COMP%] {\n  background: #fdf4ff;\n  border-color: #f5d0fe;\n  color: #a000e2;\n}\n.search-filter-section[_ngcontent-%COMP%]   .search-inline-row[_ngcontent-%COMP%]   .icon-action-btn[_ngcontent-%COMP%]   .mini-count-dot[_ngcontent-%COMP%] {\n  position: absolute;\n  top: -4px;\n  right: -4px;\n  background: #a000e2;\n  color: #ffffff;\n  font-size: 9.5px;\n  font-weight: 850;\n  min-width: 18px;\n  height: 18px;\n  padding: 0 4px;\n  border-radius: 999px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  border: 2px solid #ffffff;\n  box-shadow: 0 2px 5px rgba(160, 0, 226, 0.35);\n}\n.property-listings-container[_ngcontent-%COMP%] {\n  padding: 12px 14px 20px;\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n}\n.property-listings-container[_ngcontent-%COMP%]   .results-header-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 0 2px;\n}\n.property-listings-container[_ngcontent-%COMP%]   .results-header-row[_ngcontent-%COMP%]   .results-count-text[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 600;\n  color: #64748b;\n}\n.property-listings-container[_ngcontent-%COMP%]   .results-header-row[_ngcontent-%COMP%]   .results-count-text[_ngcontent-%COMP%]   b[_ngcontent-%COMP%] {\n  color: #0f172a;\n}\n.property-listings-container[_ngcontent-%COMP%]   .results-header-row[_ngcontent-%COMP%]   .btn-clear-chips[_ngcontent-%COMP%] {\n  background: #fdf4ff;\n  border: 1px solid #f5d0fe;\n  color: #a000e2;\n  font-size: 11px;\n  font-weight: 750;\n  padding: 3px 8px;\n  border-radius: 8px;\n  cursor: pointer;\n}\n.property-listings-container[_ngcontent-%COMP%]   .cards-stack[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 16px;\n}\n.property-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 22px;\n  border: 1px solid #f1f5f9;\n  box-shadow: 0 4px 18px rgba(15, 23, 42, 0.05);\n  overflow: hidden;\n  cursor: pointer;\n  transition: transform 0.2s cubic-bezier(0.4, 0, 0.2, 1), box-shadow 0.2s ease;\n}\n.property-card[_ngcontent-%COMP%]:active {\n  transform: scale(0.985);\n}\n.property-card[_ngcontent-%COMP%]   .card-image-wrap[_ngcontent-%COMP%] {\n  position: relative;\n  width: 100%;\n  height: 190px;\n  background: #e2e8f0;\n  overflow: hidden;\n}\n.property-card[_ngcontent-%COMP%]   .card-image-wrap[_ngcontent-%COMP%]   .card-hero-img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n  display: block;\n  transition: transform 0.3s ease;\n}\n.property-card[_ngcontent-%COMP%]   .card-image-wrap[_ngcontent-%COMP%]   .card-gradient-scrim[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  background:\n    linear-gradient(\n      to bottom,\n      rgba(0, 0, 0, 0.3) 0%,\n      transparent 40%,\n      rgba(0, 0, 0, 0.75) 100%);\n  pointer-events: none;\n}\n.property-card[_ngcontent-%COMP%]   .card-image-wrap[_ngcontent-%COMP%]   .floating-tags-row[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 12px;\n  left: 12px;\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  z-index: 2;\n}\n.property-card[_ngcontent-%COMP%]   .card-image-wrap[_ngcontent-%COMP%]   .floating-tags-row[_ngcontent-%COMP%]   .property-type-tag[_ngcontent-%COMP%] {\n  background: rgba(15, 23, 42, 0.75);\n  -webkit-backdrop-filter: blur(6px);\n  backdrop-filter: blur(6px);\n  color: #ffffff;\n  font-size: 10px;\n  font-weight: 800;\n  padding: 4px 8px;\n  border-radius: 6px;\n  letter-spacing: 0.3px;\n  text-transform: uppercase;\n}\n.property-card[_ngcontent-%COMP%]   .card-image-wrap[_ngcontent-%COMP%]   .floating-tags-row[_ngcontent-%COMP%]   .verified-tag[_ngcontent-%COMP%] {\n  background: #10b981;\n  color: #ffffff;\n  font-size: 10px;\n  font-weight: 800;\n  padding: 4px 8px;\n  border-radius: 6px;\n  display: inline-flex;\n  align-items: center;\n  gap: 3px;\n  box-shadow: 0 2px 6px rgba(16, 185, 129, 0.35);\n}\n.property-card[_ngcontent-%COMP%]   .card-image-wrap[_ngcontent-%COMP%]   .floating-tags-row[_ngcontent-%COMP%]   .verified-tag[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 11px;\n}\n.property-card[_ngcontent-%COMP%]   .card-image-wrap[_ngcontent-%COMP%]   .floating-tags-row[_ngcontent-%COMP%]   .sold-tag[_ngcontent-%COMP%] {\n  background: #ef4444;\n  color: #ffffff;\n  font-size: 10px;\n  font-weight: 800;\n  padding: 4px 8px;\n  border-radius: 6px;\n  display: inline-flex;\n  align-items: center;\n  gap: 3px;\n  text-transform: uppercase;\n  letter-spacing: 0.4px;\n  box-shadow: 0 2px 6px rgba(239, 68, 68, 0.4);\n}\n.property-card[_ngcontent-%COMP%]   .card-image-wrap[_ngcontent-%COMP%]   .floating-tags-row[_ngcontent-%COMP%]   .verifying-tag[_ngcontent-%COMP%] {\n  background: #f59e0b;\n  color: #ffffff;\n  font-size: 10px;\n  font-weight: 800;\n  padding: 4px 8px;\n  border-radius: 6px;\n  display: inline-flex;\n  align-items: center;\n  gap: 3px;\n  letter-spacing: 0.3px;\n  box-shadow: 0 2px 6px rgba(245, 158, 11, 0.4);\n}\n.property-card[_ngcontent-%COMP%]   .card-image-wrap[_ngcontent-%COMP%]   .btn-favorite[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 12px;\n  right: 12px;\n  width: 36px;\n  height: 36px;\n  border-radius: 50%;\n  background: rgba(255, 255, 255, 0.85);\n  -webkit-backdrop-filter: blur(6px);\n  backdrop-filter: blur(6px);\n  border: none;\n  color: #64748b;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 19px;\n  cursor: pointer;\n  z-index: 2;\n  transition: all 0.2s ease;\n}\n.property-card[_ngcontent-%COMP%]   .card-image-wrap[_ngcontent-%COMP%]   .btn-favorite.active[_ngcontent-%COMP%] {\n  color: #ef4444;\n  background: #ffffff;\n}\n.property-card[_ngcontent-%COMP%]   .card-image-wrap[_ngcontent-%COMP%]   .btn-favorite[_ngcontent-%COMP%]:active {\n  transform: scale(0.85);\n}\n.property-card[_ngcontent-%COMP%]   .card-image-wrap[_ngcontent-%COMP%]   .image-price-banner[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 10px;\n  left: 14px;\n  right: 14px;\n  display: flex;\n  align-items: baseline;\n  justify-content: space-between;\n  color: #ffffff;\n  z-index: 2;\n}\n.property-card[_ngcontent-%COMP%]   .card-image-wrap[_ngcontent-%COMP%]   .image-price-banner[_ngcontent-%COMP%]   .price-val-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: baseline;\n  gap: 2px;\n}\n.property-card[_ngcontent-%COMP%]   .card-image-wrap[_ngcontent-%COMP%]   .image-price-banner[_ngcontent-%COMP%]   .price-val-row[_ngcontent-%COMP%]   .price-main[_ngcontent-%COMP%] {\n  font-size: 22px;\n  font-weight: 850;\n  color: #ffffff;\n  letter-spacing: -0.3px;\n  text-shadow: 0 2px 4px rgba(0, 0, 0, 0.4);\n}\n.property-card[_ngcontent-%COMP%]   .card-image-wrap[_ngcontent-%COMP%]   .image-price-banner[_ngcontent-%COMP%]   .price-val-row[_ngcontent-%COMP%]   .price-unit[_ngcontent-%COMP%] {\n  font-size: 12.5px;\n  font-weight: 700;\n  color: #f1f5f9;\n}\n.property-card[_ngcontent-%COMP%]   .card-image-wrap[_ngcontent-%COMP%]   .image-price-banner[_ngcontent-%COMP%]   .price-sub-calc[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 650;\n  color: #cbd5e1;\n  text-shadow: 0 1px 3px rgba(0, 0, 0, 0.4);\n}\n.property-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%] {\n  padding: 14px;\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n.property-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .property-title[_ngcontent-%COMP%] {\n  font-size: 14.5px;\n  font-weight: 800;\n  color: #0f172a;\n  margin: 0;\n  line-height: 1.35;\n  letter-spacing: -0.2px;\n}\n.property-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .property-locality[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  font-weight: 500;\n  color: #64748b;\n  margin: 0;\n  display: flex;\n  align-items: center;\n  gap: 4px;\n}\n.property-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .property-locality[_ngcontent-%COMP%]   .loc-mini-icon[_ngcontent-%COMP%] {\n  color: #a000e2;\n  font-size: 13px;\n  flex-shrink: 0;\n}\n.property-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .specs-chips-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  flex-wrap: wrap;\n  margin-top: 2px;\n}\n.property-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .specs-chips-row[_ngcontent-%COMP%]   .spec-pill[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  background: #f8fafc;\n  border: 1px solid #f1f5f9;\n  padding: 4px 8px;\n  border-radius: 8px;\n  font-size: 11px;\n  font-weight: 700;\n  color: #334155;\n}\n.property-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .specs-chips-row[_ngcontent-%COMP%]   .spec-pill[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 13px;\n  color: #64748b;\n}\n.property-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .card-divider[_ngcontent-%COMP%] {\n  height: 1px;\n  background: #f1f5f9;\n  margin: 4px 0;\n}\n.property-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .card-footer-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 10px;\n}\n.property-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .card-footer-row[_ngcontent-%COMP%]   .seller-brief[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  line-height: 1.2;\n}\n.property-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .card-footer-row[_ngcontent-%COMP%]   .seller-brief[_ngcontent-%COMP%]   .seller-role[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  font-weight: 750;\n  color: #94a3b8;\n  text-transform: uppercase;\n  letter-spacing: 0.3px;\n}\n.property-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .card-footer-row[_ngcontent-%COMP%]   .seller-brief[_ngcontent-%COMP%]   .seller-name[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 750;\n  color: #1e293b;\n}\n.property-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .card-footer-row[_ngcontent-%COMP%]   .action-buttons-group[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.property-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .card-footer-row[_ngcontent-%COMP%]   .action-buttons-group[_ngcontent-%COMP%]   .btn-contact-sold[_ngcontent-%COMP%] {\n  background: #f1f5f9;\n  color: #64748b;\n  border: 1px solid #cbd5e1;\n  border-radius: 12px;\n  padding: 8px 14px;\n  font-size: 11.5px;\n  font-weight: 700;\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  cursor: not-allowed;\n  opacity: 0.9;\n}\n.property-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .card-footer-row[_ngcontent-%COMP%]   .action-buttons-group[_ngcontent-%COMP%]   .btn-contact-sold[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 13px;\n}\n.property-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .card-footer-row[_ngcontent-%COMP%]   .action-buttons-group[_ngcontent-%COMP%]   .btn-contact-call[_ngcontent-%COMP%] {\n  background: #fdf4ff;\n  color: #a000e2;\n  border: 1px solid #f5d0fe;\n  border-radius: 12px;\n  padding: 8px 12px;\n  font-size: 11.5px;\n  font-weight: 750;\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  cursor: pointer;\n  transition: transform 0.15s ease;\n}\n.property-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .card-footer-row[_ngcontent-%COMP%]   .action-buttons-group[_ngcontent-%COMP%]   .btn-contact-call[_ngcontent-%COMP%]:active {\n  transform: scale(0.94);\n}\n.property-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .card-footer-row[_ngcontent-%COMP%]   .action-buttons-group[_ngcontent-%COMP%]   .btn-contact-call[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n}\n.property-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .card-footer-row[_ngcontent-%COMP%]   .action-buttons-group[_ngcontent-%COMP%]   .btn-contact-whatsapp[_ngcontent-%COMP%] {\n  background: #25d366;\n  color: #ffffff;\n  border: none;\n  border-radius: 12px;\n  padding: 8px 12px;\n  font-size: 11.5px;\n  font-weight: 750;\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  cursor: pointer;\n  box-shadow: 0 2px 8px rgba(37, 211, 102, 0.28);\n  transition: transform 0.15s ease;\n}\n.property-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .card-footer-row[_ngcontent-%COMP%]   .action-buttons-group[_ngcontent-%COMP%]   .btn-contact-whatsapp[_ngcontent-%COMP%]:active {\n  transform: scale(0.94);\n}\n.property-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .card-footer-row[_ngcontent-%COMP%]   .action-buttons-group[_ngcontent-%COMP%]   .btn-contact-whatsapp[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 15px;\n}\n.loading-label-wrap[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n}\n.spinner-dot[_ngcontent-%COMP%] {\n  display: inline-block;\n  width: 7px;\n  height: 7px;\n  border-radius: 50%;\n  background: var(--app-theme-color, #a000e2);\n  animation: _ngcontent-%COMP%_pulse-dot 1.2s infinite ease-in-out;\n  flex-shrink: 0;\n}\n@keyframes _ngcontent-%COMP%_pulse-dot {\n  0%, 100% {\n    transform: scale(0.75);\n    opacity: 0.4;\n  }\n  50% {\n    transform: scale(1.35);\n    opacity: 1;\n  }\n}\n.skeleton-stack[_ngcontent-%COMP%] {\n  pointer-events: none;\n  -webkit-user-select: none;\n  user-select: none;\n}\n.skeleton-card[_ngcontent-%COMP%] {\n  border-color: #f1f5f9;\n  background: #ffffff;\n  position: relative;\n  overflow: hidden;\n}\n.skeleton-card[_ngcontent-%COMP%]   .skeleton-img-box[_ngcontent-%COMP%] {\n  background: #e2e8f0;\n  position: relative;\n  overflow: hidden;\n}\n.skeleton-card[_ngcontent-%COMP%]   .skeleton-img-box[_ngcontent-%COMP%]   .skeleton-top-badges[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 12px;\n  left: 12px;\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  z-index: 2;\n}\n.skeleton-card[_ngcontent-%COMP%]   .skeleton-img-box[_ngcontent-%COMP%]   .skeleton-top-badges[_ngcontent-%COMP%]   .skeleton-badge-pill[_ngcontent-%COMP%] {\n  width: 74px;\n  height: 18px;\n  border-radius: 6px;\n  background: rgba(255, 255, 255, 0.45);\n}\n.skeleton-card[_ngcontent-%COMP%]   .skeleton-img-box[_ngcontent-%COMP%]   .skeleton-top-badges[_ngcontent-%COMP%]   .skeleton-badge-pill.sm[_ngcontent-%COMP%] {\n  width: 52px;\n}\n.skeleton-card[_ngcontent-%COMP%]   .skeleton-img-box[_ngcontent-%COMP%]   .skeleton-price-badge[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 10px;\n  left: 12px;\n  width: 100px;\n  height: 26px;\n  border-radius: 8px;\n  background: rgba(255, 255, 255, 0.55);\n  z-index: 2;\n}\n.skeleton-card[_ngcontent-%COMP%]   .skeleton-line[_ngcontent-%COMP%] {\n  background: #e2e8f0;\n  border-radius: 6px;\n  height: 14px;\n  position: relative;\n  overflow: hidden;\n}\n.skeleton-card[_ngcontent-%COMP%]   .skeleton-line.title[_ngcontent-%COMP%] {\n  width: 78%;\n  height: 18px;\n  border-radius: 8px;\n  margin-bottom: 2px;\n}\n.skeleton-card[_ngcontent-%COMP%]   .skeleton-line.locality[_ngcontent-%COMP%] {\n  width: 45%;\n  height: 12px;\n  margin-bottom: 4px;\n}\n.skeleton-card[_ngcontent-%COMP%]   .skeleton-line.role[_ngcontent-%COMP%] {\n  width: 48px;\n  height: 10px;\n  margin-bottom: 4px;\n}\n.skeleton-card[_ngcontent-%COMP%]   .skeleton-line.name[_ngcontent-%COMP%] {\n  width: 80px;\n  height: 14px;\n}\n.skeleton-card[_ngcontent-%COMP%]   .skeleton-specs[_ngcontent-%COMP%] {\n  gap: 8px;\n  margin-top: 2px;\n}\n.skeleton-card[_ngcontent-%COMP%]   .skeleton-specs[_ngcontent-%COMP%]   .skeleton-chip[_ngcontent-%COMP%] {\n  width: 68px;\n  height: 24px;\n  border-radius: 8px;\n  background: #f1f5f9;\n  position: relative;\n  overflow: hidden;\n}\n.skeleton-card[_ngcontent-%COMP%]   .skeleton-footer[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding-top: 2px;\n}\n.skeleton-card[_ngcontent-%COMP%]   .skeleton-footer[_ngcontent-%COMP%]   .skeleton-seller[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n}\n.skeleton-card[_ngcontent-%COMP%]   .skeleton-footer[_ngcontent-%COMP%]   .action-buttons-group[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.skeleton-card[_ngcontent-%COMP%]   .skeleton-footer[_ngcontent-%COMP%]   .action-buttons-group[_ngcontent-%COMP%]   .skeleton-btn[_ngcontent-%COMP%] {\n  width: 66px;\n  height: 32px;\n  border-radius: 12px;\n  background: #fdf4ff;\n  position: relative;\n  overflow: hidden;\n}\n.skeleton-card[_ngcontent-%COMP%]   .skeleton-footer[_ngcontent-%COMP%]   .action-buttons-group[_ngcontent-%COMP%]   .skeleton-btn.whatsapp[_ngcontent-%COMP%] {\n  background: #dcfce7;\n}\n.skeleton-card[_ngcontent-%COMP%]   .skeleton-shimmer[_ngcontent-%COMP%], \n.skeleton-card[_ngcontent-%COMP%]   .skeleton-line[_ngcontent-%COMP%]::after, \n.skeleton-card[_ngcontent-%COMP%]   .skeleton-chip[_ngcontent-%COMP%]::after, \n.skeleton-card[_ngcontent-%COMP%]   .skeleton-btn[_ngcontent-%COMP%]::after, \n.skeleton-card[_ngcontent-%COMP%]   .skeleton-badge-pill[_ngcontent-%COMP%]::after, \n.skeleton-card[_ngcontent-%COMP%]   .skeleton-price-badge[_ngcontent-%COMP%]::after {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  transform: translateX(-100%);\n  background:\n    linear-gradient(\n      90deg,\n      rgba(255, 255, 255, 0) 0%,\n      rgba(255, 255, 255, 0.55) 50%,\n      rgba(255, 255, 255, 0) 100%);\n  animation: _ngcontent-%COMP%_property-shimmer 1.5s infinite;\n  content: "";\n}\n.skeleton-card[_ngcontent-%COMP%]   .skeleton-shimmer[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  content: "";\n}\n@keyframes _ngcontent-%COMP%_property-shimmer {\n  100% {\n    transform: translateX(100%);\n  }\n}\n.empty-state-card[_ngcontent-%COMP%] {\n  text-align: center;\n  padding: 40px 20px;\n  background: #ffffff;\n  border-radius: 20px;\n  border: 1px solid #f1f5f9;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  gap: 10px;\n  margin-top: 10px;\n}\n.empty-state-card[_ngcontent-%COMP%]   .empty-icon-halo[_ngcontent-%COMP%] {\n  width: 60px;\n  height: 60px;\n  border-radius: 50%;\n  background: #fdf4ff;\n  color: #a000e2;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 28px;\n  margin-bottom: 4px;\n}\n.empty-state-card[_ngcontent-%COMP%]   .empty-title[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 800;\n  color: #0f172a;\n  margin: 0;\n}\n.empty-state-card[_ngcontent-%COMP%]   .empty-desc[_ngcontent-%COMP%] {\n  font-size: 12.5px;\n  color: #64748b;\n  margin: 0;\n  max-width: 280px;\n  line-height: 1.45;\n}\n.empty-state-card[_ngcontent-%COMP%]   .btn-reset-filters[_ngcontent-%COMP%] {\n  background: #a000e2;\n  color: #ffffff;\n  border: none;\n  border-radius: 12px;\n  padding: 10px 18px;\n  font-size: 12.5px;\n  font-weight: 750;\n  margin-top: 6px;\n  display: inline-flex;\n  align-items: center;\n  cursor: pointer;\n}\n.properties-end-container[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  margin: 18px 0 6px;\n  padding: 0 16px;\n  box-sizing: border-box;\n}\n.properties-end-container[_ngcontent-%COMP%]   .footer-divider-line[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 1px;\n  background:\n    linear-gradient(\n      90deg,\n      transparent 0%,\n      rgba(226, 232, 240, 0.9) 20%,\n      rgba(203, 213, 225, 0.9) 50%,\n      rgba(226, 232, 240, 0.9) 80%,\n      transparent 100%);\n  margin-bottom: 14px;\n}\n.properties-end-container[_ngcontent-%COMP%]   .end-message-box[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  gap: 3px;\n  text-align: center;\n}\n.properties-end-container[_ngcontent-%COMP%]   .end-message-box[_ngcontent-%COMP%]   .end-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n  margin-bottom: 2px;\n}\n.properties-end-container[_ngcontent-%COMP%]   .end-message-box[_ngcontent-%COMP%]   .end-text-primary[_ngcontent-%COMP%] {\n  font-size: 14.5px;\n  font-weight: 850;\n  color: #334155;\n  letter-spacing: -0.2px;\n}\n.properties-end-container[_ngcontent-%COMP%]   .end-message-box[_ngcontent-%COMP%]   .end-text-sub[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 600;\n  color: #94a3b8;\n}\n.bottom-safe-spacer[_ngcontent-%COMP%] {\n  height: calc(85px + env(safe-area-inset-bottom, 0px));\n}\n.fab-register-property[_ngcontent-%COMP%] {\n  position: fixed;\n  bottom: calc(24px + env(safe-area-inset-bottom, 0px));\n  right: 18px;\n  z-index: 95;\n  background:\n    linear-gradient(\n      135deg,\n      #a000e2 0%,\n      #7e00b3 100%);\n  color: #ffffff;\n  border: none;\n  border-radius: 999px;\n  padding: 12px 20px 12px 16px;\n  display: inline-flex;\n  align-items: center;\n  gap: 7px;\n  font-size: 13.5px;\n  font-weight: 850;\n  cursor: pointer;\n  box-shadow: 0 6px 20px rgba(160, 0, 226, 0.42), 0 2px 6px rgba(0, 0, 0, 0.08);\n  transition: all 0.22s cubic-bezier(0.16, 1, 0.3, 1);\n}\n.fab-register-property[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 22px;\n}\n.fab-register-property[_ngcontent-%COMP%]:hover {\n  transform: translateY(-2px);\n  box-shadow: 0 8px 24px rgba(160, 0, 226, 0.5);\n}\n.fab-register-property[_ngcontent-%COMP%]:active {\n  transform: scale(0.95);\n}\nion-modal[_ngcontent-%COMP%] {\n  --border-radius: 24px 24px 0 0;\n  --background: #ffffff;\n}\n.sheet-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  background: #ffffff;\n  height: 100%;\n  padding-bottom: max(env(safe-area-inset-bottom, 0px), 16px);\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-header[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 16px 20px 12px;\n  border-bottom: 1px solid #f1f5f9;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-header[_ngcontent-%COMP%]   .sheet-title[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 850;\n  color: #0f172a;\n  margin: 0;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-header[_ngcontent-%COMP%]   .btn-sheet-close[_ngcontent-%COMP%] {\n  width: 32px;\n  height: 32px;\n  border-radius: 50%;\n  background: #f1f5f9;\n  border: none;\n  color: #64748b;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 18px;\n  cursor: pointer;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-header[_ngcontent-%COMP%]   .sheet-header-left[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-header[_ngcontent-%COMP%]   .sheet-header-left[_ngcontent-%COMP%]   .sheet-count-tag[_ngcontent-%COMP%] {\n  background: #fdf4ff;\n  color: #a000e2;\n  border: 1px solid #f5d0fe;\n  font-size: 11px;\n  font-weight: 750;\n  padding: 2px 8px;\n  border-radius: 6px;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-header[_ngcontent-%COMP%]   .sheet-header-right[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-header[_ngcontent-%COMP%]   .sheet-header-right[_ngcontent-%COMP%]   .btn-sheet-reset[_ngcontent-%COMP%] {\n  background: transparent;\n  border: none;\n  color: #ef4444;\n  font-size: 13px;\n  font-weight: 750;\n  cursor: pointer;\n  padding: 0;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-body[_ngcontent-%COMP%] {\n  padding: 10px 16px;\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-body[_ngcontent-%COMP%]   .sort-option-item[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 12px 14px;\n  border-radius: 14px;\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-body[_ngcontent-%COMP%]   .sort-option-item[_ngcontent-%COMP%]   .sort-option-text[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-body[_ngcontent-%COMP%]   .sort-option-item[_ngcontent-%COMP%]   .sort-option-text[_ngcontent-%COMP%]   .sort-title[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 750;\n  color: #1e293b;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-body[_ngcontent-%COMP%]   .sort-option-item[_ngcontent-%COMP%]   .sort-option-text[_ngcontent-%COMP%]   .sort-desc[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  color: #64748b;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-body[_ngcontent-%COMP%]   .sort-option-item[_ngcontent-%COMP%]   .check-icon[_ngcontent-%COMP%] {\n  font-size: 20px;\n  color: #a000e2;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-body[_ngcontent-%COMP%]   .sort-option-item.selected[_ngcontent-%COMP%] {\n  background: #fdf4ff;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-body[_ngcontent-%COMP%]   .sort-option-item.selected[_ngcontent-%COMP%]   .sort-title[_ngcontent-%COMP%] {\n  color: #a000e2;\n  font-weight: 850;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-body[_ngcontent-%COMP%]   .sort-option-item[_ngcontent-%COMP%]:active {\n  background: #f1f5f9;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-scroll-body[_ngcontent-%COMP%] {\n  flex: 1;\n  overflow-y: auto;\n  padding: 14px 18px;\n  display: flex;\n  flex-direction: column;\n  gap: 18px;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-scroll-body[_ngcontent-%COMP%]   .filter-section-block[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-scroll-body[_ngcontent-%COMP%]   .filter-section-block[_ngcontent-%COMP%]   .filter-block-title[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-weight: 800;\n  color: #0f172a;\n  margin: 0;\n  text-transform: uppercase;\n  letter-spacing: 0.3px;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-scroll-body[_ngcontent-%COMP%]   .filter-section-block[_ngcontent-%COMP%]   .verified-toggle-card[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  background: #f8fafc;\n  border: 1.5px solid #e2e8f0;\n  border-radius: 16px;\n  padding: 12px 14px;\n  cursor: pointer;\n  transition: all 0.2s ease;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-scroll-body[_ngcontent-%COMP%]   .filter-section-block[_ngcontent-%COMP%]   .verified-toggle-card[_ngcontent-%COMP%]   .toggle-info-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-scroll-body[_ngcontent-%COMP%]   .filter-section-block[_ngcontent-%COMP%]   .verified-toggle-card[_ngcontent-%COMP%]   .toggle-info-col[_ngcontent-%COMP%]   .toggle-title-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-scroll-body[_ngcontent-%COMP%]   .filter-section-block[_ngcontent-%COMP%]   .verified-toggle-card[_ngcontent-%COMP%]   .toggle-info-col[_ngcontent-%COMP%]   .toggle-title-row[_ngcontent-%COMP%]   .verified-icon[_ngcontent-%COMP%] {\n  color: #10b981;\n  font-size: 17px;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-scroll-body[_ngcontent-%COMP%]   .filter-section-block[_ngcontent-%COMP%]   .verified-toggle-card[_ngcontent-%COMP%]   .toggle-info-col[_ngcontent-%COMP%]   .toggle-title-row[_ngcontent-%COMP%]   .toggle-title[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  font-weight: 800;\n  color: #0f172a;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-scroll-body[_ngcontent-%COMP%]   .filter-section-block[_ngcontent-%COMP%]   .verified-toggle-card[_ngcontent-%COMP%]   .toggle-info-col[_ngcontent-%COMP%]   .toggle-desc[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #64748b;\n  line-height: 1.35;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-scroll-body[_ngcontent-%COMP%]   .filter-section-block[_ngcontent-%COMP%]   .verified-toggle-card[_ngcontent-%COMP%]   .custom-switch[_ngcontent-%COMP%] {\n  width: 44px;\n  height: 26px;\n  border-radius: 999px;\n  background: #cbd5e1;\n  padding: 3px;\n  display: flex;\n  align-items: center;\n  transition: background 0.2s ease;\n  flex-shrink: 0;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-scroll-body[_ngcontent-%COMP%]   .filter-section-block[_ngcontent-%COMP%]   .verified-toggle-card[_ngcontent-%COMP%]   .custom-switch[_ngcontent-%COMP%]   .switch-handle[_ngcontent-%COMP%] {\n  width: 20px;\n  height: 20px;\n  border-radius: 50%;\n  background: #ffffff;\n  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);\n  transition: transform 0.2s ease;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-scroll-body[_ngcontent-%COMP%]   .filter-section-block[_ngcontent-%COMP%]   .verified-toggle-card[_ngcontent-%COMP%]   .custom-switch.on[_ngcontent-%COMP%] {\n  background: #10b981;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-scroll-body[_ngcontent-%COMP%]   .filter-section-block[_ngcontent-%COMP%]   .verified-toggle-card[_ngcontent-%COMP%]   .custom-switch.on[_ngcontent-%COMP%]   .switch-handle[_ngcontent-%COMP%] {\n  transform: translateX(18px);\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-scroll-body[_ngcontent-%COMP%]   .filter-section-block[_ngcontent-%COMP%]   .verified-toggle-card.active[_ngcontent-%COMP%] {\n  border-color: #a7f3d0;\n  background: #ecfdf5;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-scroll-body[_ngcontent-%COMP%]   .filter-section-block[_ngcontent-%COMP%]   .chips-selector-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  flex-wrap: wrap;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-scroll-body[_ngcontent-%COMP%]   .filter-section-block[_ngcontent-%COMP%]   .chips-selector-row[_ngcontent-%COMP%]   .choice-chip[_ngcontent-%COMP%] {\n  border: 1.5px solid #e2e8f0;\n  background: #f8fafc;\n  color: #475569;\n  font-size: 12px;\n  font-weight: 700;\n  padding: 8px 14px;\n  border-radius: 12px;\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-scroll-body[_ngcontent-%COMP%]   .filter-section-block[_ngcontent-%COMP%]   .chips-selector-row[_ngcontent-%COMP%]   .choice-chip.active[_ngcontent-%COMP%] {\n  background: #fdf4ff;\n  border-color: #a000e2;\n  color: #a000e2;\n  font-weight: 800;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-scroll-body[_ngcontent-%COMP%]   .filter-section-block[_ngcontent-%COMP%]   .chips-selector-row[_ngcontent-%COMP%]   .choice-chip[_ngcontent-%COMP%]:active {\n  transform: scale(0.96);\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-footer[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  padding: 12px 18px 4px;\n  border-top: 1px solid #f1f5f9;\n  background: #ffffff;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-footer[_ngcontent-%COMP%]   .btn-sheet-clear[_ngcontent-%COMP%] {\n  height: 46px;\n  padding: 0 16px;\n  border-radius: 12px;\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n  color: #64748b;\n  font-size: 13px;\n  font-weight: 750;\n  cursor: pointer;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-footer[_ngcontent-%COMP%]   .btn-sheet-apply[_ngcontent-%COMP%] {\n  flex: 1;\n  height: 46px;\n  border-radius: 12px;\n  background:\n    linear-gradient(\n      135deg,\n      #a000e2 0%,\n      #7e00b3 100%);\n  border: none;\n  color: #ffffff;\n  font-size: 13.5px;\n  font-weight: 800;\n  cursor: pointer;\n  box-shadow: 0 4px 14px rgba(160, 0, 226, 0.28);\n  transition: transform 0.15s ease;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-footer[_ngcontent-%COMP%]   .btn-sheet-apply[_ngcontent-%COMP%]:active {\n  transform: scale(0.98);\n}\n/*# sourceMappingURL=property.page.css.map */'] });
var PropertyPage = _PropertyPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(PropertyPage, { className: "PropertyPage", filePath: "src/app/pages/property/property.page.ts", lineNumber: 69 });
})();
export {
  PropertyPage
};
//# sourceMappingURL=property.page-FCZXJWC4.js.map
