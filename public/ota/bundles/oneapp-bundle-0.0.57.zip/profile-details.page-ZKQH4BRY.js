import {
  ProfileService
} from "./chunk-XB4LQWIP.js";
import {
  AppDialogService
} from "./chunk-W37RSO62.js";
import {
  AuthService
} from "./chunk-EB6T6TPT.js";
import "./chunk-YJYUHAOC.js";
import "./chunk-EBMCUG2R.js";
import "./chunk-OE5MTPUR.js";
import {
  addIcons,
  arrowBackOutline,
  callOutline,
  checkmarkCircle,
  closeOutline,
  lockClosedOutline,
  mailOutline,
  pencilOutline,
  personOutline,
  saveOutline,
  shieldCheckmarkOutline,
  trashOutline
} from "./chunk-FJYXZAS7.js";
import {
  IonButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonIcon,
  IonSkeletonText,
  IonSpinner,
  IonTitle,
  IonToolbar
} from "./chunk-CJE2NDTY.js";
import {
  CommonModule,
  DatePipe,
  DefaultValueAccessor,
  FormsModule,
  MaxLengthValidator,
  NavController,
  NgControlStatus,
  NgModel,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-Z7XNNJSA.js";
import "./chunk-XR3JUECC.js";
import "./chunk-FH4NU4VH.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async,
  __spreadValues
} from "./chunk-6B6DTIB5.js";

// src/app/pages/profile-details/profile-details.page.ts
function ProfileDetailsPage_Conditional_8_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-button", 11);
    \u0275\u0275listener("click", function ProfileDetailsPage_Conditional_8_Conditional_0_Template_ion_button_click_0_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.toggleEdit());
    });
    \u0275\u0275element(1, "ion-icon", 12);
    \u0275\u0275text(2, " Edit ");
    \u0275\u0275elementEnd();
  }
}
function ProfileDetailsPage_Conditional_8_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-button", 13);
    \u0275\u0275listener("click", function ProfileDetailsPage_Conditional_8_Conditional_1_Template_ion_button_click_0_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.toggleEdit());
    });
    \u0275\u0275element(1, "ion-icon", 14);
    \u0275\u0275text(2, " Cancel ");
    \u0275\u0275elementEnd();
  }
}
function ProfileDetailsPage_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275template(0, ProfileDetailsPage_Conditional_8_Conditional_0_Template, 3, 0, "ion-button", 9)(1, ProfileDetailsPage_Conditional_8_Conditional_1_Template, 3, 0, "ion-button", 10);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275conditional(!ctx_r1.isEditing ? 0 : 1);
  }
}
function ProfileDetailsPage_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 8)(1, "div", 15);
    \u0275\u0275element(2, "ion-skeleton-text", 16)(3, "ion-skeleton-text", 17)(4, "ion-skeleton-text", 18);
    \u0275\u0275elementEnd();
    \u0275\u0275element(5, "ion-skeleton-text", 19)(6, "ion-skeleton-text", 20);
    \u0275\u0275elementEnd();
  }
}
function ProfileDetailsPage_Conditional_12_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "img", 62);
    \u0275\u0275listener("error", function ProfileDetailsPage_Conditional_12_Conditional_2_Template_img_error_0_listener() {
      \u0275\u0275restoreView(_r5);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.profileData.profile_image = "");
    });
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275property("src", ctx_r1.profileData.profile_image, \u0275\u0275sanitizeUrl);
  }
}
function ProfileDetailsPage_Conditional_12_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 24);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r1.getUserInitials(), " ");
  }
}
function ProfileDetailsPage_Conditional_12_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 28);
    \u0275\u0275text(1);
    \u0275\u0275pipe(2, "date");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" Member since ", \u0275\u0275pipeBind2(2, 1, ctx_r1.memberSince, "MMMM yyyy"), " ");
  }
}
function ProfileDetailsPage_Conditional_12_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 63);
    \u0275\u0275listener("click", function ProfileDetailsPage_Conditional_12_Conditional_14_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.toggleEdit());
    });
    \u0275\u0275element(1, "ion-icon", 64);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3, "Edit Name");
    \u0275\u0275elementEnd()();
  }
}
function ProfileDetailsPage_Conditional_12_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 37);
    \u0275\u0275element(1, "ion-icon", 65);
    \u0275\u0275elementStart(2, "input", 66);
    \u0275\u0275twoWayListener("ngModelChange", function ProfileDetailsPage_Conditional_12_Conditional_19_Template_input_ngModelChange_2_listener($event) {
      \u0275\u0275restoreView(_r7);
      const ctx_r1 = \u0275\u0275nextContext(2);
      \u0275\u0275twoWayBindingSet(ctx_r1.firstName, $event) || (ctx_r1.firstName = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(2);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.firstName);
  }
}
function ProfileDetailsPage_Conditional_12_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 38);
    \u0275\u0275element(1, "ion-icon", 67);
    \u0275\u0275elementStart(2, "span", 68);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx_r1.firstName || "\u2014");
  }
}
function ProfileDetailsPage_Conditional_12_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 37);
    \u0275\u0275element(1, "ion-icon", 65);
    \u0275\u0275elementStart(2, "input", 69);
    \u0275\u0275twoWayListener("ngModelChange", function ProfileDetailsPage_Conditional_12_Conditional_24_Template_input_ngModelChange_2_listener($event) {
      \u0275\u0275restoreView(_r8);
      const ctx_r1 = \u0275\u0275nextContext(2);
      \u0275\u0275twoWayBindingSet(ctx_r1.lastName, $event) || (ctx_r1.lastName = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(2);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.lastName);
  }
}
function ProfileDetailsPage_Conditional_12_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 38);
    \u0275\u0275element(1, "ion-icon", 67);
    \u0275\u0275elementStart(2, "span", 68);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx_r1.lastName || "\u2014");
  }
}
function ProfileDetailsPage_Conditional_12_Conditional_26_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-spinner", 72);
    \u0275\u0275text(1, " Saving... ");
  }
}
function ProfileDetailsPage_Conditional_12_Conditional_26_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 73);
    \u0275\u0275text(1, " Save Changes ");
  }
}
function ProfileDetailsPage_Conditional_12_Conditional_26_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 40)(1, "ion-button", 70);
    \u0275\u0275listener("click", function ProfileDetailsPage_Conditional_12_Conditional_26_Template_ion_button_click_1_listener() {
      \u0275\u0275restoreView(_r9);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.toggleEdit());
    });
    \u0275\u0275text(2, " Cancel ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "ion-button", 71);
    \u0275\u0275listener("click", function ProfileDetailsPage_Conditional_12_Conditional_26_Template_ion_button_click_3_listener() {
      \u0275\u0275restoreView(_r9);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.saveProfile());
    });
    \u0275\u0275template(4, ProfileDetailsPage_Conditional_12_Conditional_26_Conditional_4_Template, 2, 0)(5, ProfileDetailsPage_Conditional_12_Conditional_26_Conditional_5_Template, 2, 0);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275property("disabled", ctx_r1.isSaving);
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", ctx_r1.isSaving);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.isSaving ? 4 : 5);
  }
}
function ProfileDetailsPage_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "section", 21)(1, "div", 22);
    \u0275\u0275template(2, ProfileDetailsPage_Conditional_12_Conditional_2_Template, 1, 1, "img", 23)(3, ProfileDetailsPage_Conditional_12_Conditional_3_Template, 2, 1, "div", 24);
    \u0275\u0275elementStart(4, "div", 25);
    \u0275\u0275element(5, "ion-icon", 26);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "h3", 27);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275template(8, ProfileDetailsPage_Conditional_12_Conditional_8_Template, 3, 4, "p", 28);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "section", 29)(10, "div", 30)(11, "div", 31)(12, "span", 32);
    \u0275\u0275text(13, "BASIC INFORMATION");
    \u0275\u0275elementEnd();
    \u0275\u0275template(14, ProfileDetailsPage_Conditional_12_Conditional_14_Template, 4, 0, "button", 33);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "div", 34)(16, "div", 35)(17, "label", 36);
    \u0275\u0275text(18, "First Name");
    \u0275\u0275elementEnd();
    \u0275\u0275template(19, ProfileDetailsPage_Conditional_12_Conditional_19_Template, 3, 1, "div", 37)(20, ProfileDetailsPage_Conditional_12_Conditional_20_Template, 4, 1, "div", 38);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(21, "div", 39)(22, "label", 36);
    \u0275\u0275text(23, "Last Name");
    \u0275\u0275elementEnd();
    \u0275\u0275template(24, ProfileDetailsPage_Conditional_12_Conditional_24_Template, 3, 1, "div", 37)(25, ProfileDetailsPage_Conditional_12_Conditional_25_Template, 4, 1, "div", 38);
    \u0275\u0275elementEnd();
    \u0275\u0275template(26, ProfileDetailsPage_Conditional_12_Conditional_26_Template, 6, 3, "div", 40);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(27, "section", 29)(28, "div", 30)(29, "span", 32);
    \u0275\u0275text(30, "ACCOUNT IDENTIFIERS");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(31, "span", 41);
    \u0275\u0275element(32, "ion-icon", 42);
    \u0275\u0275elementStart(33, "span");
    \u0275\u0275text(34, "Verified & Locked");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(35, "div", 34)(36, "div", 43);
    \u0275\u0275element(37, "ion-icon", 44);
    \u0275\u0275elementStart(38, "div", 45);
    \u0275\u0275text(39, " Phone number and email are permanently bound to your account and strictly non-editable for security & verification. ");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(40, "div", 35)(41, "div", 46)(42, "label", 47);
    \u0275\u0275text(43, "Mobile Phone Number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(44, "span", 48);
    \u0275\u0275text(45, "Locked");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(46, "div", 49);
    \u0275\u0275element(47, "ion-icon", 50);
    \u0275\u0275elementStart(48, "span", 51);
    \u0275\u0275text(49);
    \u0275\u0275elementEnd();
    \u0275\u0275element(50, "ion-icon", 52);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(51, "div", 53);
    \u0275\u0275text(52, "Primary OTP authentication number");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(53, "div", 39)(54, "div", 46)(55, "label", 47);
    \u0275\u0275text(56, "Registered Email Address");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(57, "span", 48);
    \u0275\u0275text(58, "Locked");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(59, "div", 49);
    \u0275\u0275element(60, "ion-icon", 54);
    \u0275\u0275elementStart(61, "span", 51);
    \u0275\u0275text(62);
    \u0275\u0275elementEnd();
    \u0275\u0275element(63, "ion-icon", 52);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(64, "div", 53);
    \u0275\u0275text(65, "Used for official order invoices and security alerts");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(66, "section", 55)(67, "div", 56)(68, "span", 57);
    \u0275\u0275text(69, "ACCOUNT ACTIONS");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(70, "div", 58)(71, "p", 59);
    \u0275\u0275text(72, " Permanently deletes your account history, saved addresses, and active orders. This action cannot be reversed. ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(73, "ion-button", 60);
    \u0275\u0275listener("click", function ProfileDetailsPage_Conditional_12_Template_ion_button_click_73_listener() {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.deleteAccount());
    });
    \u0275\u0275element(74, "ion-icon", 61);
    \u0275\u0275text(75, " Delete Account Permanently ");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(2);
    \u0275\u0275conditional((ctx_r1.profileData == null ? null : ctx_r1.profileData.profile_image) ? 2 : 3);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r1.getDisplayName());
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.memberSince ? 8 : -1);
    \u0275\u0275advance(6);
    \u0275\u0275conditional(!ctx_r1.isEditing ? 14 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275conditional(ctx_r1.isEditing ? 19 : 20);
    \u0275\u0275advance(5);
    \u0275\u0275conditional(ctx_r1.isEditing ? 24 : 25);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.isEditing ? 26 : -1);
    \u0275\u0275advance(23);
    \u0275\u0275textInterpolate(ctx_r1.phone || "+91");
    \u0275\u0275advance(13);
    \u0275\u0275textInterpolate(ctx_r1.email || "No email attached");
  }
}
var _ProfileDetailsPage = class _ProfileDetailsPage {
  constructor(navCtrl, authService, profileService, dialogService) {
    this.navCtrl = navCtrl;
    this.authService = authService;
    this.profileService = profileService;
    this.dialogService = dialogService;
    this.token = "";
    this.isLoading = true;
    this.isSaving = false;
    this.isEditing = false;
    this.profileData = null;
    this.firstName = "";
    this.lastName = "";
    this.phone = "";
    this.email = "";
    this.memberSince = "";
    addIcons({
      arrowBackOutline,
      pencilOutline,
      checkmarkCircle,
      closeOutline,
      lockClosedOutline,
      personOutline,
      mailOutline,
      callOutline,
      shieldCheckmarkOutline,
      trashOutline,
      saveOutline
    });
  }
  ngOnInit() {
    return __async(this, null, function* () {
      this.token = (yield this.authService.getToken()) || "";
      if (this.token) {
        this.loadProfile();
      } else {
        this.isLoading = false;
      }
    });
  }
  goBack() {
    this.navCtrl.back();
  }
  loadProfile() {
    this.isLoading = true;
    this.profileService.getProfileData(this.token).subscribe({
      next: (res) => {
        this.isLoading = false;
        this.profileData = (res == null ? void 0 : res.user) || (res == null ? void 0 : res.data) || res || {};
        this.initFormValues();
      },
      error: (err) => {
        this.isLoading = false;
        console.error("Failed to load profile details:", err);
        this.dialogService.showToast("Unable to load profile data", "danger");
      }
    });
  }
  initFormValues() {
    if (!this.profileData)
      return;
    this.firstName = (this.profileData.first_name || "").trim();
    this.lastName = (this.profileData.last_name || "").trim();
    this.phone = this.profileData.phone || "";
    this.email = this.profileData.email || "";
    this.memberSince = this.profileData.createdAt || this.profileData.date_joined || "";
  }
  toggleEdit() {
    if (this.isEditing) {
      this.initFormValues();
      this.isEditing = false;
    } else {
      this.isEditing = true;
    }
  }
  getDisplayName() {
    var _a;
    const full = `${this.firstName} ${this.lastName}`.trim();
    return full || ((_a = this.profileData) == null ? void 0 : _a.username) || "Pintu Customer";
  }
  getUserInitials() {
    const name = this.getDisplayName();
    return name.charAt(0).toUpperCase() || "P";
  }
  saveProfile() {
    if (!this.firstName.trim()) {
      this.dialogService.showToast("First name cannot be empty", "warning");
      return;
    }
    this.isSaving = true;
    const payload = {
      first_name: this.firstName.trim(),
      last_name: this.lastName.trim()
    };
    this.profileService.updateUser(payload, this.token).subscribe({
      next: (res) => {
        this.isSaving = false;
        this.isEditing = false;
        if (res == null ? void 0 : res.user) {
          this.profileData = __spreadValues(__spreadValues({}, this.profileData), res.user);
        }
        this.dialogService.showToast("Personal details updated successfully!", "success");
      },
      error: (err) => {
        var _a;
        this.isSaving = false;
        console.error("Update profile error:", err);
        this.dialogService.showToast(((_a = err == null ? void 0 : err.error) == null ? void 0 : _a.message) || "Failed to update profile", "danger");
      }
    });
  }
  deleteAccount() {
    return __async(this, null, function* () {
      var _a;
      const confirmed = yield this.dialogService.showDangerConfirm({
        title: "Delete Account Permanently?",
        message: "This will permanently remove your account, past orders, saved addresses, and active sessions.\n\nThis action cannot be undone.",
        confirmText: "Delete Permanently",
        cancelText: "Keep Account"
      });
      if (!confirmed)
        return;
      const id = (_a = this.profileData) == null ? void 0 : _a.id;
      this.profileService.deleteProfilePermanently({ token: this.token }, id).subscribe({
        next: () => __async(this, null, function* () {
          yield this.dialogService.showAlert("Account Deleted", "Your Pintu account and personal data have been permanently removed.", "info", "OK");
          yield this.authService.logout();
        }),
        error: (err) => {
          console.error("Delete account error:", err);
          this.dialogService.showToast("Failed to delete account. Please contact support.", "danger");
        }
      });
    });
  }
};
_ProfileDetailsPage.\u0275fac = function ProfileDetailsPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _ProfileDetailsPage)(\u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(AuthService), \u0275\u0275directiveInject(ProfileService), \u0275\u0275directiveInject(AppDialogService));
};
_ProfileDetailsPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _ProfileDetailsPage, selectors: [["app-profile-details"]], decls: 13, vars: 3, consts: [[1, "ion-no-border", "bg-white", "pt-2"], ["slot", "start"], [3, "click"], ["name", "arrow-back-outline", "color", "dark"], [1, "fw-bold", "text-dark"], ["slot", "end", 1, "pe-2"], [1, "details-content-page", 3, "fullscreen"], [1, "details-container"], [1, "skeleton-wrapper", "py-4", "px-3"], ["fill", "clear", "color", "primary", 1, "fw-semibold"], ["fill", "clear", "color", "medium", 1, "fw-semibold"], ["fill", "clear", "color", "primary", 1, "fw-semibold", 3, "click"], ["name", "pencil-outline", "slot", "start"], ["fill", "clear", "color", "medium", 1, "fw-semibold", 3, "click"], ["name", "close-outline", "slot", "start"], [1, "d-flex", "flex-column", "align-items-center", "mb-4"], ["animated", "", 2, "width", "84px", "height", "84px", "border-radius", "50%", "margin-bottom", "12px"], ["animated", "", 2, "width", "150px", "height", "20px", "border-radius", "6px", "margin-bottom", "6px"], ["animated", "", 2, "width", "100px", "height", "14px", "border-radius", "4px"], ["animated", "", 2, "width", "100%", "height", "160px", "border-radius", "16px", "margin-bottom", "16px"], ["animated", "", 2, "width", "100%", "height", "180px", "border-radius", "16px"], [1, "identity-header-card"], [1, "avatar-ring-container"], ["alt", "User Profile", 1, "avatar-img", 3, "src"], [1, "avatar-initials"], ["title", "Verified Customer", 1, "verified-icon-badge"], ["name", "shield-checkmark-outline"], [1, "user-name-title"], [1, "membership-subtitle"], [1, "card-box", "mb-3"], [1, "card-box-header"], [1, "d-flex", "align-items-center", "justify-content-between", "w-100"], [1, "box-label"], [1, "edit-badge-btn"], [1, "card-box-body"], [1, "form-group", "mb-3"], [1, "input-field-label"], [1, "input-field-wrapper", "is-active"], [1, "value-display-row"], [1, "form-group", "mb-2"], [1, "d-flex", "gap-2", "mt-4", "pt-2"], [1, "locked-indicator-badge"], ["name", "lock-closed-outline"], [1, "lock-notice-box", "mb-3"], ["name", "lock-closed-outline", 1, "lock-notice-icon"], [1, "lock-notice-text"], [1, "d-flex", "justify-content-between", "align-items-center", "mb-1"], [1, "input-field-label", "m-0"], [1, "field-status-tag"], [1, "locked-field-wrapper"], ["name", "call-outline", 1, "locked-icon"], [1, "locked-value"], ["name", "lock-closed-outline", 1, "locked-padlock"], [1, "field-hint-caption"], ["name", "mail-outline", 1, "locked-icon"], [1, "card-box", "danger-box", "mb-4"], [1, "card-box-header", "border-0", "pb-0"], [1, "box-label", "text-danger"], [1, "card-box-body", "pt-2"], [1, "danger-desc", "mb-3"], ["expand", "block", "fill", "outline", "color", "danger", 1, "delete-account-btn", 3, "click"], ["name", "trash-outline", "slot", "start"], ["alt", "User Profile", 1, "avatar-img", 3, "error", "src"], [1, "edit-badge-btn", 3, "click"], ["name", "pencil-outline"], ["name", "person-outline", 1, "input-lead-icon"], ["type", "text", "placeholder", "Enter first name", "maxlength", "40", 1, "custom-text-input", 3, "ngModelChange", "ngModel"], ["name", "person-outline", 1, "value-icon"], [1, "value-text"], ["type", "text", "placeholder", "Enter last name", "maxlength", "40", 1, "custom-text-input", 3, "ngModelChange", "ngModel"], ["expand", "block", "fill", "outline", "color", "medium", 1, "flex-1", "cancel-btn", 3, "click", "disabled"], ["expand", "block", 1, "flex-2", "save-btn", 3, "click", "disabled"], ["name", "crescent", 1, "me-2"], ["name", "checkmark-circle", "slot", "start"]], template: function ProfileDetailsPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar")(2, "ion-buttons", 1)(3, "ion-button", 2);
    \u0275\u0275listener("click", function ProfileDetailsPage_Template_ion_button_click_3_listener() {
      return ctx.goBack();
    });
    \u0275\u0275element(4, "ion-icon", 3);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "ion-title", 4);
    \u0275\u0275text(6, "Personal Details");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "ion-buttons", 5);
    \u0275\u0275template(8, ProfileDetailsPage_Conditional_8_Template, 2, 1);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(9, "ion-content", 6)(10, "div", 7);
    \u0275\u0275template(11, ProfileDetailsPage_Conditional_11_Template, 7, 0, "div", 8)(12, ProfileDetailsPage_Conditional_12_Template, 76, 9);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(8);
    \u0275\u0275conditional(!ctx.isLoading ? 8 : -1);
    \u0275\u0275advance();
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx.isLoading ? 11 : 12);
  }
}, dependencies: [
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  IonButtons,
  IonButton,
  IonIcon,
  IonSpinner,
  IonSkeletonText,
  CommonModule,
  DatePipe,
  FormsModule,
  DefaultValueAccessor,
  NgControlStatus,
  MaxLengthValidator,
  NgModel
], styles: ["\n\n.details-content-page[_ngcontent-%COMP%] {\n  --background: #f8f9fd;\n}\n.details-container[_ngcontent-%COMP%] {\n  padding: 16px;\n  max-width: 560px;\n  margin: 0 auto 32px;\n}\n.identity-header-card[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  text-align: center;\n  padding: 24px 16px 16px;\n}\n.avatar-ring-container[_ngcontent-%COMP%] {\n  position: relative;\n  width: 90px;\n  height: 90px;\n  margin-bottom: 12px;\n}\n.avatar-initials[_ngcontent-%COMP%] {\n  width: 90px;\n  height: 90px;\n  border-radius: 50%;\n  background:\n    linear-gradient(\n      135deg,\n      #a000e2 0%,\n      #c13df5 100%);\n  color: #ffffff;\n  font-size: 34px;\n  font-weight: 800;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  box-shadow: 0 8px 20px rgba(160, 0, 226, 0.28);\n  letter-spacing: -0.5px;\n}\n.avatar-img[_ngcontent-%COMP%] {\n  width: 90px;\n  height: 90px;\n  border-radius: 50%;\n  object-fit: cover;\n  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12);\n}\n.verified-icon-badge[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 0;\n  right: 0;\n  width: 28px;\n  height: 28px;\n  border-radius: 50%;\n  background: #10b981;\n  color: #ffffff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 16px;\n  border: 2.5px solid #ffffff;\n  box-shadow: 0 2px 6px rgba(16, 185, 129, 0.35);\n}\n.user-name-title[_ngcontent-%COMP%] {\n  font-size: 20px;\n  font-weight: 700;\n  color: #1a1a2e;\n  margin: 0 0 4px;\n  letter-spacing: -0.2px;\n}\n.membership-subtitle[_ngcontent-%COMP%] {\n  font-size: 13px;\n  color: #717182;\n  margin: 0;\n}\n.card-box[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 18px;\n  border: 1px solid #edf0f7;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);\n  overflow: hidden;\n}\n.card-box-header[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 14px 18px 10px;\n  border-bottom: 1px solid #f6f7fb;\n}\n.box-label[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 800;\n  letter-spacing: 0.8px;\n  color: #8e95a5;\n  text-transform: uppercase;\n}\n.edit-badge-btn[_ngcontent-%COMP%] {\n  background: #f4e8fc;\n  color: #a000e2;\n  border: none;\n  border-radius: 20px;\n  padding: 4px 10px;\n  font-size: 12px;\n  font-weight: 600;\n  display: flex;\n  align-items: center;\n  gap: 4px;\n  cursor: pointer;\n  transition: all 0.2s ease;\n}\n.edit-badge-btn[_ngcontent-%COMP%]:active {\n  transform: scale(0.96);\n  background: #eed5fa;\n}\n.locked-indicator-badge[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 4px;\n  background: #f0fdf4;\n  color: #15803d;\n  font-size: 11px;\n  font-weight: 700;\n  padding: 3px 8px;\n  border-radius: 12px;\n  border: 1px solid #dcfce7;\n}\n.locked-indicator-badge[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 12px;\n}\n.card-box-body[_ngcontent-%COMP%] {\n  padding: 16px 18px;\n}\n.form-group[_ngcontent-%COMP%] {\n  position: relative;\n}\n.input-field-label[_ngcontent-%COMP%] {\n  display: block;\n  font-size: 12px;\n  font-weight: 600;\n  color: #555b6d;\n  margin-bottom: 6px;\n}\n.input-field-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  background: #f9fafc;\n  border: 1.5px solid #e2e8f0;\n  border-radius: 12px;\n  padding: 0 12px;\n  height: 48px;\n  transition: all 0.2s ease;\n}\n.input-field-wrapper.is-active[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-color: #a000e2;\n  box-shadow: 0 0 0 3px rgba(160, 0, 226, 0.1);\n}\n.input-field-wrapper[_ngcontent-%COMP%]   .input-lead-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n  color: #a000e2;\n  margin-right: 10px;\n  flex-shrink: 0;\n}\n.input-field-wrapper[_ngcontent-%COMP%]   .custom-text-input[_ngcontent-%COMP%] {\n  width: 100%;\n  border: none;\n  outline: none;\n  background: transparent;\n  font-size: 15px;\n  font-weight: 500;\n  color: #1e293b;\n}\n.input-field-wrapper[_ngcontent-%COMP%]   .custom-text-input[_ngcontent-%COMP%]::placeholder {\n  color: #94a3b8;\n}\n.value-display-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  background: #fafbfe;\n  border: 1px solid #f1f4f9;\n  border-radius: 12px;\n  padding: 0 14px;\n  height: 46px;\n}\n.value-display-row[_ngcontent-%COMP%]   .value-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n  color: #8b92a2;\n  margin-right: 10px;\n  flex-shrink: 0;\n}\n.value-display-row[_ngcontent-%COMP%]   .value-text[_ngcontent-%COMP%] {\n  font-size: 15px;\n  font-weight: 600;\n  color: #242938;\n}\n.lock-notice-box[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-start;\n  gap: 10px;\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n  border-radius: 12px;\n  padding: 10px 12px;\n}\n.lock-notice-box[_ngcontent-%COMP%]   .lock-notice-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n  color: #64748b;\n  margin-top: 1px;\n  flex-shrink: 0;\n}\n.lock-notice-box[_ngcontent-%COMP%]   .lock-notice-text[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #475569;\n  line-height: 1.45;\n}\n.field-status-tag[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 700;\n  text-transform: uppercase;\n  letter-spacing: 0.5px;\n  color: #64748b;\n  background: #f1f5f9;\n  padding: 2px 6px;\n  border-radius: 6px;\n}\n.locked-field-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  background: #f8fafc;\n  border: 1.5px dashed #cbd5e1;\n  border-radius: 12px;\n  padding: 0 14px;\n  height: 48px;\n}\n.locked-field-wrapper[_ngcontent-%COMP%]   .locked-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n  color: #64748b;\n  margin-right: 10px;\n  flex-shrink: 0;\n}\n.locked-field-wrapper[_ngcontent-%COMP%]   .locked-value[_ngcontent-%COMP%] {\n  font-size: 15px;\n  font-weight: 600;\n  color: #334155;\n  flex: 1;\n}\n.locked-field-wrapper[_ngcontent-%COMP%]   .locked-padlock[_ngcontent-%COMP%] {\n  font-size: 16px;\n  color: #94a3b8;\n  flex-shrink: 0;\n}\n.field-hint-caption[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #94a3b8;\n  margin-top: 4px;\n  padding-left: 2px;\n}\n.save-btn[_ngcontent-%COMP%] {\n  --background: #a000e2;\n  --background-hover: #8e00c7;\n  --border-radius: 12px;\n  font-weight: 700;\n  font-size: 14px;\n  height: 46px;\n}\n.cancel-btn[_ngcontent-%COMP%] {\n  --border-radius: 12px;\n  font-weight: 600;\n  font-size: 14px;\n  height: 46px;\n}\n.flex-1[_ngcontent-%COMP%] {\n  flex: 1;\n}\n.flex-2[_ngcontent-%COMP%] {\n  flex: 1.8;\n}\n.danger-box[_ngcontent-%COMP%] {\n  border-color: #fee2e2;\n}\n.danger-box[_ngcontent-%COMP%]   .danger-desc[_ngcontent-%COMP%] {\n  font-size: 12.5px;\n  color: #64748b;\n  line-height: 1.45;\n}\n.danger-box[_ngcontent-%COMP%]   .delete-account-btn[_ngcontent-%COMP%] {\n  --border-radius: 12px;\n  --border-width: 1.5px;\n  font-weight: 700;\n  font-size: 13px;\n  letter-spacing: 0.2px;\n}\n/*# sourceMappingURL=profile-details.page.css.map */"] });
var ProfileDetailsPage = _ProfileDetailsPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(ProfileDetailsPage, { className: "ProfileDetailsPage", filePath: "src/app/pages/profile-details/profile-details.page.ts", lineNumber: 53 });
})();
export {
  ProfileDetailsPage
};
//# sourceMappingURL=profile-details.page-ZKQH4BRY.js.map
