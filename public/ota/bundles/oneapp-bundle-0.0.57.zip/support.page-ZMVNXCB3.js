import {
  AppDialogService
} from "./chunk-W37RSO62.js";
import {
  environment
} from "./chunk-YJYUHAOC.js";
import "./chunk-OE5MTPUR.js";
import {
  addCircleOutline,
  addIcons,
  arrowBackOutline,
  callOutline,
  chatbubblesOutline,
  chevronDown,
  chevronForward,
  chevronUp,
  logoWhatsapp,
  mailOutline,
  paperPlaneOutline,
  timeOutline
} from "./chunk-FJYXZAS7.js";
import {
  IonButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonIcon,
  IonSkeletonText,
  IonSpinner,
  IonTitle,
  IonToolbar
} from "./chunk-CJE2NDTY.js";
import {
  CommonModule,
  DatePipe,
  DefaultValueAccessor,
  FormsModule,
  HttpClient,
  NavController,
  NgControlStatus,
  NgControlStatusGroup,
  NgForm,
  NgModel,
  NgSelectOption,
  RequiredValidator,
  Router,
  SelectControlValueAccessor,
  ɵNgNoValidate,
  ɵNgSelectMultipleOption,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵinject,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIdentity,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-Z7XNNJSA.js";
import "./chunk-XR3JUECC.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import "./chunk-6B6DTIB5.js";

// src/app/services/support.service.ts
var _SupportService = class _SupportService {
  constructor(http) {
    this.http = http;
    this.url = environment.apiUrl;
  }
  createTicket(params) {
    return this.http.post(`${this.url}/api/tickets/create`, params);
  }
  getTickets() {
    let headers = {
      "authorization": `Bearer ${localStorage.getItem("auth-token")}`
    };
    return this.http.get(`${this.url}/api/tickets/user`, { headers });
  }
  closeTicket(id, params) {
    let headers = {
      "authorization": `Bearer ${localStorage.getItem("auth-token")}`
    };
    return this.http.put(`${this.url}/api/tickets/${id}`, params, { headers });
  }
};
_SupportService.\u0275fac = function SupportService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _SupportService)(\u0275\u0275inject(HttpClient));
};
_SupportService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _SupportService, factory: _SupportService.\u0275fac, providedIn: "root" });
var SupportService = _SupportService;

// src/app/pages/support/support.page.ts
var _c0 = () => [1, 2, 3];
var _forTrack0 = ($index, $item) => $item.id;
var _forTrack1 = ($index, $item) => $item.id || $item.ticket_id || $index;
function SupportPage_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 8);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r0.tickets.length);
  }
}
function SupportPage_Conditional_20_For_30_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 39)(1, "p", 40);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const faq_r4 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(faq_r4.answer);
  }
}
function SupportPage_Conditional_20_For_30_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 32)(1, "div", 33);
    \u0275\u0275listener("click", function SupportPage_Conditional_20_For_30_Template_div_click_1_listener() {
      const faq_r4 = \u0275\u0275restoreView(_r3).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.toggleFaq(faq_r4.id));
    });
    \u0275\u0275elementStart(2, "div", 34)(3, "span", 35);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "h4", 36);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "div", 37);
    \u0275\u0275element(8, "ion-icon", 38);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(9, SupportPage_Conditional_20_For_30_Conditional_9_Template, 3, 1, "div", 39);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const faq_r4 = ctx.$implicit;
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275classProp("expanded", ctx_r0.expandedFaqId === faq_r4.id);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(faq_r4.category);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(faq_r4.question);
    \u0275\u0275advance(2);
    \u0275\u0275property("name", ctx_r0.expandedFaqId === faq_r4.id ? "chevron-up" : "chevron-down");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.expandedFaqId === faq_r4.id ? 9 : -1);
  }
}
function SupportPage_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "section", 13)(1, "div", 14);
    \u0275\u0275listener("click", function SupportPage_Conditional_20_Template_div_click_1_listener() {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.openWhatsAppSupport());
    });
    \u0275\u0275elementStart(2, "div", 15);
    \u0275\u0275element(3, "ion-icon", 16);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "span", 17);
    \u0275\u0275text(5, "WhatsApp");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span", 18);
    \u0275\u0275text(7, "\u26A1Fast");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "a", 19)(9, "div", 20);
    \u0275\u0275element(10, "ion-icon", 21);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "span", 17);
    \u0275\u0275text(12, "Call Us");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "span", 22);
    \u0275\u0275text(14, "Toll-free");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "a", 23)(16, "div", 24);
    \u0275\u0275element(17, "ion-icon", 25);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "span", 17);
    \u0275\u0275text(19, "Email");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "span", 22);
    \u0275\u0275text(21, "Write to us");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(22, "section", 26)(23, "div", 27)(24, "h2", 28);
    \u0275\u0275text(25, "Frequently Asked Questions");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(26, "span", 29);
    \u0275\u0275text(27, "INSTANT ANSWERS");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(28, "div", 30);
    \u0275\u0275repeaterCreate(29, SupportPage_Conditional_20_For_30_Template, 10, 6, "div", 31, _forTrack0);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(29);
    \u0275\u0275repeater(ctx_r0.faqs);
  }
}
function SupportPage_Conditional_21_Conditional_35_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-spinner", 61);
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2, "Submitting Ticket...");
    \u0275\u0275elementEnd();
  }
}
function SupportPage_Conditional_21_Conditional_36_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 62);
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2, "Submit Support Request");
    \u0275\u0275elementEnd();
  }
}
function SupportPage_Conditional_21_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "section", 10)(1, "div", 41)(2, "h2", 42);
    \u0275\u0275text(3, "Submit a Support Ticket");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "p", 43);
    \u0275\u0275text(5, "Provide details of your query and our team will resolve it within 1 hour.");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "form", 44);
    \u0275\u0275listener("ngSubmit", function SupportPage_Conditional_21_Template_form_ngSubmit_6_listener() {
      \u0275\u0275restoreView(_r5);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.submitTicket());
    });
    \u0275\u0275elementStart(7, "div", 45)(8, "label", 46);
    \u0275\u0275text(9, "Select Issue Category");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "div", 47)(11, "select", 48);
    \u0275\u0275twoWayListener("ngModelChange", function SupportPage_Conditional_21_Template_select_ngModelChange_11_listener($event) {
      \u0275\u0275restoreView(_r5);
      const ctx_r0 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r0.ticketForm.category, $event) || (ctx_r0.ticketForm.category = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementStart(12, "option", 49);
    \u0275\u0275text(13, "\u{1F966} Grocery Order & Delivery");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "option", 50);
    \u0275\u0275text(15, "\u{1F6F5} Daily Rides & Driver Issue");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "option", 51);
    \u0275\u0275text(17, "\u{1F4B0} Payment & Refund Status");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "option", 52);
    \u0275\u0275text(19, "\u{1F464} Account, Login & Addresses");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "option", 53);
    \u0275\u0275text(21, "\u{1F4AC} General App Feedback");
    \u0275\u0275elementEnd()();
    \u0275\u0275element(22, "ion-icon", 54);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(23, "div", 45)(24, "label", 46);
    \u0275\u0275text(25, "Brief Subject");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(26, "div", 55)(27, "input", 56);
    \u0275\u0275twoWayListener("ngModelChange", function SupportPage_Conditional_21_Template_input_ngModelChange_27_listener($event) {
      \u0275\u0275restoreView(_r5);
      const ctx_r0 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r0.ticketForm.title, $event) || (ctx_r0.ticketForm.title = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(28, "div", 57)(29, "label", 46);
    \u0275\u0275text(30, "Detailed Description");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(31, "div", 58)(32, "textarea", 59);
    \u0275\u0275twoWayListener("ngModelChange", function SupportPage_Conditional_21_Template_textarea_ngModelChange_32_listener($event) {
      \u0275\u0275restoreView(_r5);
      const ctx_r0 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r0.ticketForm.description, $event) || (ctx_r0.ticketForm.description = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275text(33, "              ");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(34, "button", 60);
    \u0275\u0275template(35, SupportPage_Conditional_21_Conditional_35_Template, 3, 0)(36, SupportPage_Conditional_21_Conditional_36_Template, 3, 0);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(11);
    \u0275\u0275twoWayProperty("ngModel", ctx_r0.ticketForm.category);
    \u0275\u0275advance(16);
    \u0275\u0275twoWayProperty("ngModel", ctx_r0.ticketForm.title);
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx_r0.ticketForm.description);
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", ctx_r0.isSubmitting || !ctx_r0.ticketForm.title.trim() || !ctx_r0.ticketForm.description.trim());
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.isSubmitting ? 35 : 36);
  }
}
function SupportPage_Conditional_22_Conditional_1_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 66);
    \u0275\u0275element(1, "ion-skeleton-text", 67)(2, "ion-skeleton-text", 68)(3, "ion-skeleton-text", 69);
    \u0275\u0275elementEnd();
  }
}
function SupportPage_Conditional_22_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 63);
    \u0275\u0275repeaterCreate(1, SupportPage_Conditional_22_Conditional_1_For_2_Template, 4, 0, "div", 66, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance();
    \u0275\u0275repeater(\u0275\u0275pureFunction0(0, _c0));
  }
}
function SupportPage_Conditional_22_Conditional_2_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 70)(1, "div", 71)(2, "span", 72);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "span", 73);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "h4", 74);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "p", 75);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "div", 76)(11, "span", 77);
    \u0275\u0275element(12, "ion-icon", 78);
    \u0275\u0275text(13);
    \u0275\u0275pipe(14, "date");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ticket_r6 = ctx.$implicit;
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("#", ticket_r6.ticket_id || ticket_r6.id, "");
    \u0275\u0275advance();
    \u0275\u0275classProp("open-pill", ctx_r0.isOpenTicket(ticket_r6))("closed-pill", !ctx_r0.isOpenTicket(ticket_r6));
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r0.isOpenTicket(ticket_r6) ? "Active / Open" : "Resolved", " ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ticket_r6.title || ticket_r6.subject);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ticket_r6.description || "Customer inquiry submitted.");
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1(" ", \u0275\u0275pipeBind2(14, 9, ticket_r6.createdAt || ticket_r6.created_at, "dd MMM yyyy, hh:mm a"), " ");
  }
}
function SupportPage_Conditional_22_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 64);
    \u0275\u0275repeaterCreate(1, SupportPage_Conditional_22_Conditional_2_For_2_Template, 15, 12, "div", 70, _forTrack1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r0.tickets);
  }
}
function SupportPage_Conditional_22_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 65)(1, "div", 79);
    \u0275\u0275element(2, "ion-icon", 80);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "h3", 81);
    \u0275\u0275text(4, "No Tickets Found");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p", 82);
    \u0275\u0275text(6, "You have not raised any support requests yet. If you ever need help, we are here!");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "button", 83);
    \u0275\u0275listener("click", function SupportPage_Conditional_22_Conditional_3_Template_button_click_7_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.activeTab = "create");
    });
    \u0275\u0275element(8, "ion-icon", 84);
    \u0275\u0275elementStart(9, "span");
    \u0275\u0275text(10, "Raise an Issue");
    \u0275\u0275elementEnd()()();
  }
}
function SupportPage_Conditional_22_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 11);
    \u0275\u0275template(1, SupportPage_Conditional_22_Conditional_1_Template, 3, 1, "div", 63)(2, SupportPage_Conditional_22_Conditional_2_Template, 3, 0, "div", 64)(3, SupportPage_Conditional_22_Conditional_3_Template, 11, 0, "div", 65);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.isLoadingTickets ? 1 : ctx_r0.tickets && ctx_r0.tickets.length > 0 ? 2 : 3);
  }
}
var _SupportPage = class _SupportPage {
  constructor(router, navCtrl, supportService, dialogService) {
    this.router = router;
    this.navCtrl = navCtrl;
    this.supportService = supportService;
    this.dialogService = dialogService;
    this.activeTab = "channels";
    this.expandedFaqId = 1;
    this.tickets = [];
    this.isLoadingTickets = false;
    this.isSubmitting = false;
    this.ticketForm = {
      category: "Grocery Order Issue",
      title: "",
      description: ""
    };
    this.faqs = [
      {
        id: 1,
        category: "Delivery Speed",
        question: "How fast will my grocery order be delivered?",
        answer: "All grocery and daily essentials orders are packed inside our neighborhood micro-fulfillment centers and delivered to your doorstep within 10 to 15 minutes."
      },
      {
        id: 2,
        category: "Rides & Commute",
        question: "How do ride fares work and are there any surge charges?",
        answer: "Pintu Daily Rides feature transparent, regulated fares based purely on distance and vehicle type. We do not charge surprise peak surge fees."
      },
      {
        id: 3,
        category: "Payments & Refunds",
        question: "What is the refund timeline for cancelled items?",
        answer: "Refunds for cancelled orders or damaged items are processed instantly to your Pintu wallet or returned to your original payment method (UPI within 2-4 hours, cards in 2-3 business days)."
      },
      {
        id: 4,
        category: "Order Modifications",
        question: "Can I change my delivery address after placing an order?",
        answer: "If your order has not yet left the store, tap the live WhatsApp support button above and our 24/7 team will immediately update your delivery destination."
      },
      {
        id: 5,
        category: "Safety & Verification",
        question: "Are Pintu delivery and ride partners background-checked?",
        answer: "Yes, 100% of Pintu drivers and delivery partners are police-verified, government ID-checked, and vehicle fitness-approved before joining our platform."
      }
    ];
    addIcons({
      logoWhatsapp,
      callOutline,
      mailOutline,
      chevronForward,
      chevronDown,
      chevronUp,
      paperPlaneOutline,
      chatbubblesOutline,
      addCircleOutline,
      timeOutline,
      arrowBackOutline
    });
  }
  goBack() {
    this.navCtrl.back();
  }
  ngOnInit() {
    this.loadTickets();
  }
  openWhatsAppSupport() {
    const text = encodeURIComponent("Hi Pintu Customer Support, I need assistance with my account / order.");
    const whatsappUrl = `https://wa.me/918999335606?text=${text}`;
    window.open(whatsappUrl, "_system");
  }
  toggleFaq(id) {
    this.expandedFaqId = this.expandedFaqId === id ? null : id;
  }
  loadTickets() {
    this.isLoadingTickets = true;
    this.supportService.getTickets().subscribe({
      next: (res) => {
        this.tickets = (res == null ? void 0 : res.data) || res || [];
        this.isLoadingTickets = false;
      },
      error: () => {
        this.isLoadingTickets = false;
      }
    });
  }
  submitTicket() {
    if (!this.ticketForm.title.trim() || !this.ticketForm.description.trim()) {
      return;
    }
    this.isSubmitting = true;
    const params = {
      category: this.ticketForm.category,
      title: this.ticketForm.title.trim(),
      description: this.ticketForm.description.trim()
    };
    this.supportService.createTicket(params).subscribe({
      next: () => {
        this.isSubmitting = false;
        this.dialogService.showAlert("Ticket Submitted", "Your support ticket has been received. Our team will resolve it within 1 hour.", "success", "Great, Thanks");
        this.ticketForm = {
          category: "Grocery Order Issue",
          title: "",
          description: ""
        };
        this.activeTab = "tickets";
        this.loadTickets();
      },
      error: () => {
        this.isSubmitting = false;
        this.dialogService.showAlert("Submission Error", "Unable to submit your ticket right now. Please message us on WhatsApp for instant assistance.", "error", "OK");
      }
    });
  }
  isOpenTicket(ticket) {
    if (!ticket)
      return false;
    const s = (ticket.status || "").toString().toLowerCase();
    return s.includes("open") || s.includes("active") || s.includes("pending");
  }
};
_SupportPage.\u0275fac = function SupportPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _SupportPage)(\u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(SupportService), \u0275\u0275directiveInject(AppDialogService));
};
_SupportPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _SupportPage, selectors: [["app-support"]], decls: 24, vars: 9, consts: [[1, "ion-no-border", "bg-white", "pt-2"], ["slot", "start"], [3, "click"], ["name", "arrow-back-outline", "color", "dark"], [1, "fw-bold", "text-dark"], [1, "support-content-page", 3, "fullscreen"], [1, "support-tabs-strip"], ["type", "button", 1, "tab-pill", 3, "click"], [1, "ticket-badge"], [1, "support-body-container"], [1, "create-ticket-section", "animate__animated", "animate__fadeIn"], [1, "my-tickets-section", "animate__animated", "animate__fadeIn"], [1, "bottom-nav-spacer"], [1, "channels-grid", "animate__animated", "animate__fadeIn"], ["role", "button", "tabindex", "0", 1, "channel-card", "whatsapp-channel", 3, "click"], [1, "channel-icon-circle", "bg-whatsapp"], ["name", "logo-whatsapp"], [1, "channel-name"], [1, "speed-pill"], ["href", "tel:+918999335606", 1, "channel-card", "call-channel"], [1, "channel-icon-circle", "bg-call"], ["name", "call-outline"], [1, "channel-subtext"], ["href", "mailto:support@pintu.com?subject=Customer%20Support%20Request", 1, "channel-card", "email-channel"], [1, "channel-icon-circle", "bg-email"], ["name", "mail-outline"], [1, "faq-section", "animate__animated", "animate__fadeIn"], [1, "faq-header-row"], [1, "faq-title"], [1, "faq-tag"], [1, "faq-accordion-list"], [1, "faq-card", 3, "expanded"], [1, "faq-card"], ["role", "button", "tabindex", "0", 1, "faq-question-row", 3, "click"], [1, "faq-q-text-box"], [1, "faq-category-label"], [1, "faq-question"], [1, "faq-toggle-icon"], [3, "name"], [1, "faq-answer-box", "animate__animated", "animate__fadeIn"], [1, "faq-answer-text"], [1, "form-header-box"], [1, "form-title"], [1, "form-desc"], [1, "ticket-form", 3, "ngSubmit"], [1, "form-group", "mb-3"], [1, "input-label"], [1, "custom-select-wrapper"], ["name", "category", "required", "", 1, "custom-select", 3, "ngModelChange", "ngModel"], ["value", "Grocery Order Issue"], ["value", "Ride & Fare Dispute"], ["value", "Payment & Refund"], ["value", "Account & Profile"], ["value", "General Feedback"], ["name", "chevron-down", 1, "select-chevron"], [1, "input-container-modern"], ["type", "text", "placeholder", "e.g. Missing items in order #3928", "name", "title", "required", "", 1, "custom-input", 3, "ngModelChange", "ngModel"], [1, "form-group", "mb-4"], [1, "input-container-modern", "textarea-container"], ["rows", "4", "placeholder", "Explain the issue with relevant order IDs or details...", "name", "description", "required", "", 1, "custom-textarea", 3, "ngModelChange", "ngModel"], ["type", "submit", 1, "btn-primary-action", "w-100", 3, "disabled"], ["name", "crescent", 1, "spinner-small", "me-2"], ["name", "paper-plane-outline", 1, "me-2", "fs-5"], [1, "tickets-skeleton-list"], [1, "tickets-cards-list"], [1, "empty-tickets-box"], [1, "ticket-skeleton-card"], ["animated", "", 2, "width", "40%", "height", "16px", "border-radius", "4px", "margin-bottom", "8px"], ["animated", "", 2, "width", "70%", "height", "20px", "border-radius", "6px", "margin-bottom", "8px"], ["animated", "", 2, "width", "30%", "height", "14px", "border-radius", "4px"], [1, "ticket-card"], [1, "ticket-top-row"], [1, "ticket-id-tag"], [1, "ticket-status-pill"], [1, "ticket-title"], [1, "ticket-desc"], [1, "ticket-footer-row"], [1, "ticket-time"], ["name", "time-outline"], [1, "empty-icon-circle"], ["name", "chatbubbles-outline"], [1, "empty-title"], [1, "empty-subtitle"], ["type", "button", 1, "btn-raise-ticket-cta", 3, "click"], ["name", "add-circle-outline", 1, "me-1"]], template: function SupportPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar")(2, "ion-buttons", 1)(3, "ion-button", 2);
    \u0275\u0275listener("click", function SupportPage_Template_ion_button_click_3_listener() {
      return ctx.goBack();
    });
    \u0275\u0275element(4, "ion-icon", 3);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "ion-title", 4);
    \u0275\u0275text(6, "Help & Support");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(7, "ion-content", 5)(8, "div", 6)(9, "button", 7);
    \u0275\u0275listener("click", function SupportPage_Template_button_click_9_listener() {
      return ctx.activeTab = "channels";
    });
    \u0275\u0275elementStart(10, "span");
    \u0275\u0275text(11, "Contact & FAQ");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(12, "button", 7);
    \u0275\u0275listener("click", function SupportPage_Template_button_click_12_listener() {
      return ctx.activeTab = "create";
    });
    \u0275\u0275elementStart(13, "span");
    \u0275\u0275text(14, "Raise Issue");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "button", 7);
    \u0275\u0275listener("click", function SupportPage_Template_button_click_15_listener() {
      ctx.activeTab = "tickets";
      return ctx.loadTickets();
    });
    \u0275\u0275elementStart(16, "span");
    \u0275\u0275text(17, "My Tickets");
    \u0275\u0275elementEnd();
    \u0275\u0275template(18, SupportPage_Conditional_18_Template, 2, 1, "span", 8);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(19, "main", 9);
    \u0275\u0275template(20, SupportPage_Conditional_20_Template, 31, 0)(21, SupportPage_Conditional_21_Template, 37, 5, "section", 10)(22, SupportPage_Conditional_22_Template, 4, 1, "section", 11);
    \u0275\u0275element(23, "div", 12);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(7);
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx.activeTab === "channels");
    \u0275\u0275advance(3);
    \u0275\u0275classProp("active", ctx.activeTab === "create");
    \u0275\u0275advance(3);
    \u0275\u0275classProp("active", ctx.activeTab === "tickets");
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx.tickets.length > 0 ? 18 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx.activeTab === "channels" ? 20 : ctx.activeTab === "create" ? 21 : ctx.activeTab === "tickets" ? 22 : -1);
  }
}, dependencies: [
  CommonModule,
  DatePipe,
  FormsModule,
  \u0275NgNoValidate,
  NgSelectOption,
  \u0275NgSelectMultipleOption,
  DefaultValueAccessor,
  SelectControlValueAccessor,
  NgControlStatus,
  NgControlStatusGroup,
  RequiredValidator,
  NgModel,
  NgForm,
  IonHeader,
  IonToolbar,
  IonButtons,
  IonButton,
  IonTitle,
  IonContent,
  IonSpinner,
  IonSkeletonText,
  IonIcon
], styles: ["\n\n.support-content-page[_ngcontent-%COMP%] {\n  --background: #f8fafc;\n  --overflow: auto;\n  position: relative;\n}\nion-header[_ngcontent-%COMP%] {\n  --background: #ffffff;\n  background: #ffffff;\n  border-bottom: 1px solid #f1f5f9;\n}\nion-toolbar[_ngcontent-%COMP%] {\n  --background: #ffffff;\n}\n.support-tabs-strip[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  background: #f1f5f9;\n  padding: 4px;\n  border-radius: 14px;\n  margin: 14px 16px 4px;\n}\n.support-tabs-strip[_ngcontent-%COMP%]   .tab-pill[_ngcontent-%COMP%] {\n  flex: 1;\n  border: none;\n  background: transparent;\n  padding: 8px 12px;\n  border-radius: 10px;\n  font-size: 12.5px;\n  font-weight: 700;\n  color: #64748b;\n  cursor: pointer;\n  transition: all 0.2s ease;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 6px;\n}\n.support-tabs-strip[_ngcontent-%COMP%]   .tab-pill.active[_ngcontent-%COMP%] {\n  background: #ffffff;\n  color: #0f172a;\n  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.06);\n}\n.support-tabs-strip[_ngcontent-%COMP%]   .tab-pill[_ngcontent-%COMP%]   .ticket-badge[_ngcontent-%COMP%] {\n  background: var(--app-theme-color, #a000e2);\n  color: #ffffff;\n  font-size: 10px;\n  font-weight: 800;\n  padding: 1px 6px;\n  border-radius: 99px;\n}\n.support-body-container[_ngcontent-%COMP%] {\n  padding: 16px 16px 24px;\n  display: flex;\n  flex-direction: column;\n  gap: 20px;\n}\n.channels-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  gap: 10px;\n}\n.channels-grid[_ngcontent-%COMP%]   .channel-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border: 1px solid #f1f5f9;\n  border-radius: 20px;\n  padding: 16px 8px 14px;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  text-align: center;\n  text-decoration: none;\n  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.035);\n  cursor: pointer;\n  position: relative;\n  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);\n}\n.channels-grid[_ngcontent-%COMP%]   .channel-card[_ngcontent-%COMP%]:active {\n  transform: scale(0.96);\n  background: #f8fafc;\n  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.02);\n}\n.channels-grid[_ngcontent-%COMP%]   .channel-card[_ngcontent-%COMP%]   .channel-icon-circle[_ngcontent-%COMP%] {\n  width: 48px;\n  height: 48px;\n  border-radius: 16px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 24px;\n  margin-bottom: 10px;\n  transition: transform 0.2s ease;\n}\n.channels-grid[_ngcontent-%COMP%]   .channel-card[_ngcontent-%COMP%]   .channel-icon-circle.bg-whatsapp[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  color: #10b981;\n}\n.channels-grid[_ngcontent-%COMP%]   .channel-card[_ngcontent-%COMP%]   .channel-icon-circle.bg-call[_ngcontent-%COMP%] {\n  background: #eff6ff;\n  color: #3b82f6;\n}\n.channels-grid[_ngcontent-%COMP%]   .channel-card[_ngcontent-%COMP%]   .channel-icon-circle.bg-email[_ngcontent-%COMP%] {\n  background: #fdf4ff;\n  color: #a000e2;\n}\n.channels-grid[_ngcontent-%COMP%]   .channel-card[_ngcontent-%COMP%]:active   .channel-icon-circle[_ngcontent-%COMP%] {\n  transform: scale(0.92);\n}\n.channels-grid[_ngcontent-%COMP%]   .channel-card[_ngcontent-%COMP%]   .channel-name[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  font-weight: 750;\n  color: #0f172a;\n  line-height: 1.2;\n  margin-bottom: 4px;\n}\n.channels-grid[_ngcontent-%COMP%]   .channel-card[_ngcontent-%COMP%]   .speed-pill[_ngcontent-%COMP%] {\n  font-size: 9px;\n  font-weight: 800;\n  letter-spacing: 0.4px;\n  background: #ecfdf5;\n  color: #059669;\n  padding: 2px 7px;\n  border-radius: 99px;\n  white-space: nowrap;\n}\n.channels-grid[_ngcontent-%COMP%]   .channel-card[_ngcontent-%COMP%]   .channel-subtext[_ngcontent-%COMP%] {\n  font-size: 10.5px;\n  font-weight: 600;\n  color: #94a3b8;\n  white-space: nowrap;\n}\n.faq-section[_ngcontent-%COMP%]   .faq-header-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin-bottom: 12px;\n}\n.faq-section[_ngcontent-%COMP%]   .faq-header-row[_ngcontent-%COMP%]   .faq-title[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 800;\n  color: #0f172a;\n  margin: 0;\n}\n.faq-section[_ngcontent-%COMP%]   .faq-header-row[_ngcontent-%COMP%]   .faq-tag[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  font-weight: 800;\n  letter-spacing: 0.5px;\n  background: #eff6ff;\n  color: #2563eb;\n  padding: 2.5px 8px;\n  border-radius: 99px;\n}\n.faq-section[_ngcontent-%COMP%]   .faq-accordion-list[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n}\n.faq-section[_ngcontent-%COMP%]   .faq-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border: 1px solid #f1f5f9;\n  border-radius: 16px;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);\n  overflow: hidden;\n  transition: all 0.2s ease;\n}\n.faq-section[_ngcontent-%COMP%]   .faq-card.expanded[_ngcontent-%COMP%] {\n  border-color: rgba(160, 0, 226, 0.35);\n  box-shadow: 0 4px 16px rgba(160, 0, 226, 0.08);\n}\n.faq-section[_ngcontent-%COMP%]   .faq-card[_ngcontent-%COMP%]   .faq-question-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 14px 16px;\n  cursor: pointer;\n}\n.faq-section[_ngcontent-%COMP%]   .faq-card[_ngcontent-%COMP%]   .faq-question-row[_ngcontent-%COMP%]   .faq-q-text-box[_ngcontent-%COMP%] {\n  flex: 1;\n}\n.faq-section[_ngcontent-%COMP%]   .faq-card[_ngcontent-%COMP%]   .faq-question-row[_ngcontent-%COMP%]   .faq-q-text-box[_ngcontent-%COMP%]   .faq-category-label[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  font-weight: 800;\n  color: var(--app-theme-color, #a000e2);\n  text-transform: uppercase;\n  letter-spacing: 0.5px;\n}\n.faq-section[_ngcontent-%COMP%]   .faq-card[_ngcontent-%COMP%]   .faq-question-row[_ngcontent-%COMP%]   .faq-q-text-box[_ngcontent-%COMP%]   .faq-question[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  font-weight: 750;\n  color: #0f172a;\n  margin: 3px 0 0;\n  line-height: 1.35;\n}\n.faq-section[_ngcontent-%COMP%]   .faq-card[_ngcontent-%COMP%]   .faq-question-row[_ngcontent-%COMP%]   .faq-toggle-icon[_ngcontent-%COMP%] {\n  color: #64748b;\n  font-size: 18px;\n  margin-left: 10px;\n  flex-shrink: 0;\n}\n.faq-section[_ngcontent-%COMP%]   .faq-card[_ngcontent-%COMP%]   .faq-answer-box[_ngcontent-%COMP%] {\n  padding: 0 16px 14px;\n  border-top: 1px solid #f8fafc;\n}\n.faq-section[_ngcontent-%COMP%]   .faq-card[_ngcontent-%COMP%]   .faq-answer-box[_ngcontent-%COMP%]   .faq-answer-text[_ngcontent-%COMP%] {\n  font-size: 12.5px;\n  color: #475569;\n  line-height: 1.55;\n  margin: 10px 0 0;\n}\n.create-ticket-section[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 20px;\n  border: 1px solid #f1f5f9;\n  padding: 22px 18px;\n  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.04);\n}\n.create-ticket-section[_ngcontent-%COMP%]   .form-header-box[_ngcontent-%COMP%] {\n  margin-bottom: 20px;\n}\n.create-ticket-section[_ngcontent-%COMP%]   .form-header-box[_ngcontent-%COMP%]   .form-title[_ngcontent-%COMP%] {\n  font-size: 18px;\n  font-weight: 800;\n  color: #0f172a;\n  margin: 0 0 6px;\n  letter-spacing: -0.2px;\n}\n.create-ticket-section[_ngcontent-%COMP%]   .form-header-box[_ngcontent-%COMP%]   .form-desc[_ngcontent-%COMP%] {\n  font-size: 12.5px;\n  color: #64748b;\n  margin: 0;\n  line-height: 1.45;\n}\n.create-ticket-section[_ngcontent-%COMP%]   .ticket-form[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 16px;\n}\n.create-ticket-section[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n.create-ticket-section[_ngcontent-%COMP%]   .input-label[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  font-weight: 750;\n  color: #475569;\n  text-transform: uppercase;\n  letter-spacing: 0.5px;\n  margin-bottom: 7px;\n  display: block;\n}\n.create-ticket-section[_ngcontent-%COMP%]   .custom-select-wrapper[_ngcontent-%COMP%] {\n  position: relative;\n  width: 100%;\n}\n.create-ticket-section[_ngcontent-%COMP%]   .custom-select-wrapper[_ngcontent-%COMP%]   .custom-select[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 48px;\n  border-radius: 14px;\n  border: 1.5px solid #e2e8f0;\n  background: #f8fafc;\n  padding: 0 40px 0 16px;\n  font-size: 13.5px;\n  font-weight: 600;\n  color: #0f172a;\n  -moz-appearance: none;\n  appearance: none;\n  -webkit-appearance: none;\n  outline: none;\n  cursor: pointer;\n  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);\n}\n.create-ticket-section[_ngcontent-%COMP%]   .custom-select-wrapper[_ngcontent-%COMP%]   .custom-select[_ngcontent-%COMP%]:focus {\n  border-color: var(--app-theme-color, #a000e2);\n  background: #ffffff;\n  box-shadow: 0 0 0 4px rgba(160, 0, 226, 0.08);\n}\n.create-ticket-section[_ngcontent-%COMP%]   .custom-select-wrapper[_ngcontent-%COMP%]   .select-chevron[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 14px;\n  top: 50%;\n  transform: translateY(-50%);\n  font-size: 18px;\n  color: #64748b;\n  pointer-events: none;\n}\n.create-ticket-section[_ngcontent-%COMP%]   .input-container-modern[_ngcontent-%COMP%], \n.create-ticket-section[_ngcontent-%COMP%]   .custom-input-box[_ngcontent-%COMP%] {\n  border-radius: 14px;\n  border: 1.5px solid #e2e8f0;\n  background: #f8fafc;\n  padding: 0 16px;\n  min-height: 48px;\n  display: flex;\n  align-items: center;\n  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);\n}\n.create-ticket-section[_ngcontent-%COMP%]   .input-container-modern[_ngcontent-%COMP%]:focus-within, \n.create-ticket-section[_ngcontent-%COMP%]   .custom-input-box[_ngcontent-%COMP%]:focus-within {\n  border-color: var(--app-theme-color, #a000e2);\n  background: #ffffff;\n  box-shadow: 0 0 0 4px rgba(160, 0, 226, 0.08);\n}\n.create-ticket-section[_ngcontent-%COMP%]   .input-container-modern[_ngcontent-%COMP%]   .custom-input[_ngcontent-%COMP%], \n.create-ticket-section[_ngcontent-%COMP%]   .custom-input-box[_ngcontent-%COMP%]   .custom-input[_ngcontent-%COMP%] {\n  border: none;\n  background: transparent;\n  outline: none;\n  font-size: 13.5px;\n  font-weight: 600;\n  color: #0f172a;\n  width: 100%;\n  padding: 12px 0;\n  font-family: inherit;\n}\n.create-ticket-section[_ngcontent-%COMP%]   .input-container-modern[_ngcontent-%COMP%]   .custom-input[_ngcontent-%COMP%]::placeholder, \n.create-ticket-section[_ngcontent-%COMP%]   .custom-input-box[_ngcontent-%COMP%]   .custom-input[_ngcontent-%COMP%]::placeholder {\n  color: #94a3b8;\n  font-weight: 400;\n}\n.create-ticket-section[_ngcontent-%COMP%]   .input-container-modern.textarea-container[_ngcontent-%COMP%], \n.create-ticket-section[_ngcontent-%COMP%]   .custom-input-box.textarea-container[_ngcontent-%COMP%] {\n  padding: 14px 16px;\n  align-items: flex-start;\n  min-height: 125px;\n}\n.create-ticket-section[_ngcontent-%COMP%]   .input-container-modern.textarea-container[_ngcontent-%COMP%]   .custom-textarea[_ngcontent-%COMP%], \n.create-ticket-section[_ngcontent-%COMP%]   .custom-input-box.textarea-container[_ngcontent-%COMP%]   .custom-textarea[_ngcontent-%COMP%] {\n  border: none;\n  background: transparent;\n  outline: none;\n  font-size: 13.5px;\n  font-weight: 500;\n  color: #0f172a;\n  width: 100%;\n  min-height: 95px;\n  line-height: 1.5;\n  resize: none;\n  font-family: inherit;\n}\n.create-ticket-section[_ngcontent-%COMP%]   .input-container-modern.textarea-container[_ngcontent-%COMP%]   .custom-textarea[_ngcontent-%COMP%]::placeholder, \n.create-ticket-section[_ngcontent-%COMP%]   .custom-input-box.textarea-container[_ngcontent-%COMP%]   .custom-textarea[_ngcontent-%COMP%]::placeholder {\n  color: #94a3b8;\n  font-weight: 400;\n}\n.create-ticket-section[_ngcontent-%COMP%]   .btn-primary-action[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 50px;\n  background:\n    linear-gradient(\n      135deg,\n      #a000e2 0%,\n      #7e00b3 100%);\n  color: #ffffff;\n  border: none;\n  border-radius: 14px;\n  padding: 0 20px;\n  font-size: 15px;\n  font-weight: 750;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 8px;\n  box-shadow: 0 6px 18px rgba(160, 0, 226, 0.28);\n  cursor: pointer;\n  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);\n  margin-top: 4px;\n}\n.create-ticket-section[_ngcontent-%COMP%]   .btn-primary-action[_ngcontent-%COMP%]:active {\n  transform: scale(0.985);\n  box-shadow: 0 3px 10px rgba(160, 0, 226, 0.2);\n}\n.create-ticket-section[_ngcontent-%COMP%]   .btn-primary-action[_ngcontent-%COMP%]:disabled {\n  opacity: 0.55;\n  cursor: not-allowed;\n  box-shadow: none;\n  transform: none;\n}\n.create-ticket-section[_ngcontent-%COMP%]   .btn-primary-action[_ngcontent-%COMP%]   .spinner-small[_ngcontent-%COMP%] {\n  width: 18px;\n  height: 18px;\n}\n.my-tickets-section[_ngcontent-%COMP%]   .tickets-cards-list[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n}\n.my-tickets-section[_ngcontent-%COMP%]   .ticket-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border: 1px solid #f1f5f9;\n  border-radius: 16px;\n  padding: 14px 16px;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);\n}\n.my-tickets-section[_ngcontent-%COMP%]   .ticket-card[_ngcontent-%COMP%]   .ticket-top-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin-bottom: 6px;\n}\n.my-tickets-section[_ngcontent-%COMP%]   .ticket-card[_ngcontent-%COMP%]   .ticket-top-row[_ngcontent-%COMP%]   .ticket-id-tag[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 800;\n  color: var(--app-theme-color, #a000e2);\n}\n.my-tickets-section[_ngcontent-%COMP%]   .ticket-card[_ngcontent-%COMP%]   .ticket-top-row[_ngcontent-%COMP%]   .ticket-status-pill[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 800;\n  padding: 3px 8px;\n  border-radius: 99px;\n}\n.my-tickets-section[_ngcontent-%COMP%]   .ticket-card[_ngcontent-%COMP%]   .ticket-top-row[_ngcontent-%COMP%]   .ticket-status-pill.open-pill[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  color: #059669;\n}\n.my-tickets-section[_ngcontent-%COMP%]   .ticket-card[_ngcontent-%COMP%]   .ticket-top-row[_ngcontent-%COMP%]   .ticket-status-pill.closed-pill[_ngcontent-%COMP%] {\n  background: #f1f5f9;\n  color: #64748b;\n}\n.my-tickets-section[_ngcontent-%COMP%]   .ticket-card[_ngcontent-%COMP%]   .ticket-title[_ngcontent-%COMP%] {\n  font-size: 14.5px;\n  font-weight: 750;\n  color: #0f172a;\n  margin: 0 0 4px;\n}\n.my-tickets-section[_ngcontent-%COMP%]   .ticket-card[_ngcontent-%COMP%]   .ticket-desc[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #64748b;\n  line-height: 1.4;\n  margin: 0 0 10px;\n}\n.my-tickets-section[_ngcontent-%COMP%]   .ticket-card[_ngcontent-%COMP%]   .ticket-footer-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding-top: 8px;\n  border-top: 1px solid #f8fafc;\n}\n.my-tickets-section[_ngcontent-%COMP%]   .ticket-card[_ngcontent-%COMP%]   .ticket-footer-row[_ngcontent-%COMP%]   .ticket-time[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 4px;\n  font-size: 11px;\n  color: #94a3b8;\n}\n.my-tickets-section[_ngcontent-%COMP%]   .empty-tickets-box[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  text-align: center;\n  padding: 40px 20px;\n}\n.my-tickets-section[_ngcontent-%COMP%]   .empty-tickets-box[_ngcontent-%COMP%]   .empty-icon-circle[_ngcontent-%COMP%] {\n  width: 72px;\n  height: 72px;\n  border-radius: 50%;\n  background: rgba(160, 0, 226, 0.1);\n  color: var(--app-theme-color, #a000e2);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 34px;\n  margin-bottom: 16px;\n}\n.my-tickets-section[_ngcontent-%COMP%]   .empty-tickets-box[_ngcontent-%COMP%]   .empty-title[_ngcontent-%COMP%] {\n  font-size: 17px;\n  font-weight: 800;\n  color: #0f172a;\n  margin: 0 0 4px;\n}\n.my-tickets-section[_ngcontent-%COMP%]   .empty-tickets-box[_ngcontent-%COMP%]   .empty-subtitle[_ngcontent-%COMP%] {\n  font-size: 13px;\n  color: #64748b;\n  line-height: 1.5;\n  max-width: 270px;\n  margin: 0 0 20px;\n}\n.my-tickets-section[_ngcontent-%COMP%]   .empty-tickets-box[_ngcontent-%COMP%]   .btn-raise-ticket-cta[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #a000e2 0%,\n      #7e00b3 100%);\n  color: #ffffff;\n  border: none;\n  border-radius: 12px;\n  padding: 10px 20px;\n  font-size: 13px;\n  font-weight: 750;\n  cursor: pointer;\n  display: inline-flex;\n  align-items: center;\n}\n.bottom-nav-spacer[_ngcontent-%COMP%] {\n  min-height: calc(80px + env(safe-area-inset-bottom, 0px));\n  height: calc(80px + env(safe-area-inset-bottom, 0px));\n  width: 100%;\n}\n/*# sourceMappingURL=support.page.css.map */"] });
var SupportPage = _SupportPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(SupportPage, { className: "SupportPage", filePath: "src/app/pages/support/support.page.ts", lineNumber: 60 });
})();
export {
  SupportPage
};
//# sourceMappingURL=support.page-ZMVNXCB3.js.map
