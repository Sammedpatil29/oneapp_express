import {
  Checkout
} from "./chunk-MAWNBYKT.js";
import "./chunk-OE5MTPUR.js";
import {
  addIcons,
  arrowBackOutline
} from "./chunk-FJYXZAS7.js";
import {
  IonAvatar,
  IonButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonIcon,
  IonItem,
  IonLabel,
  IonList,
  IonTitle,
  IonToolbar
} from "./chunk-CJE2NDTY.js";
import {
  CommonModule,
  FormsModule,
  HttpClient,
  NavController,
  NgForOf,
  NgIf,
  Observable,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵinject,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate
} from "./chunk-Z7XNNJSA.js";
import "./chunk-XR3JUECC.js";
import {
  registerPlugin
} from "./chunk-FH4NU4VH.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/services/razorpay.service.ts
var _RazorpayService = class _RazorpayService {
  constructor(http) {
    this.http = http;
  }
  payWithRazorpayCardOVA(amount, name, email, contact) {
    return new Observable((observer) => {
      const options = {
        description: "Test Payment",
        currency: "INR",
        key: "rzp_live_p6MXH1oq4BBYPk",
        amount,
        name: name || "MyApp",
        prefill: {
          email: email || "",
          contact: contact || "",
          name: name || ""
        },
        theme: { color: "#050505ff" }
      };
      RazorpayCheckout.open(options, (success) => {
        observer.next(success);
        observer.complete();
      }, (error) => {
        observer.error(error);
      });
    });
  }
};
_RazorpayService.\u0275fac = function RazorpayService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _RazorpayService)(\u0275\u0275inject(HttpClient));
};
_RazorpayService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _RazorpayService, factory: _RazorpayService.\u0275fac, providedIn: "root" });
var RazorpayService = _RazorpayService;

// src/app/pages/payment/payment.page.ts
function PaymentPage_ion_list_10_ion_item_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-item", 2);
    \u0275\u0275listener("click", function PaymentPage_ion_list_10_ion_item_1_Template_ion_item_click_0_listener() {
      const app_r2 = \u0275\u0275restoreView(_r1).$implicit;
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.payWith(app_r2.id));
    });
    \u0275\u0275elementStart(1, "ion-avatar", 1);
    \u0275\u0275element(2, "img", 8);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "ion-label");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const app_r2 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(2);
    \u0275\u0275property("src", ctx_r2.getIcon(app_r2.icon), \u0275\u0275sanitizeUrl);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(app_r2.displayName);
  }
}
function PaymentPage_ion_list_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-list");
    \u0275\u0275template(1, PaymentPage_ion_list_10_ion_item_1_Template, 5, 2, "ion-item", 7);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275property("ngForOf", ctx_r2.upiApps);
  }
}
var CFBridge = registerPlugin("CFBridge");
var _PaymentPage = class _PaymentPage {
  constructor(http, razorpayService, navCtrl) {
    this.http = http;
    this.razorpayService = razorpayService;
    this.navCtrl = navCtrl;
    addIcons({ arrowBackOutline });
  }
  goBack() {
    this.navCtrl.back();
  }
  ngOnInit() {
  }
  showUPIApps() {
    return __async(this, null, function* () {
      const appsResponse = yield CFBridge.getUPIApps();
      this.upiApps = appsResponse.apps.map((app) => ({
        displayName: app.displayName,
        id: app.id,
        icon: app.icon
      }));
      console.log(this.upiApps);
    });
  }
  payWith(appId) {
    return __async(this, null, function* () {
      try {
        const response = yield CFBridge.startPaymentUPI({
          appId,
          tokenData: "PB9JCVXpkI6ICc5RnIsICN4MzUIJiOicGbhJye.f3QfiEDMwIXZkJ3T0NXZUJiOiQWSyVGZy9mIsIiUOlkI6ISej5WZyJXdDJXZkJ3biwiIwAjLwATMiojI05Wdv1WQyVGZy9mIsIjMzUTM1UTN3EjOiAHelJCLiQWOxQDNlhDOwMTY4YjI6ICdsF2cfJye.lkDkcBLJURs2CSd-jnD5gJltdsSV2AN3v-2TJfjIXPPjtuY0HXX4jI8MpG0jNiDl2W",
          // from backend
          orderId: "TestOrder001",
          orderCurrency: "INR",
          orderAmount: "100.00",
          customerName: "John Doe",
          customerPhone: "9876543210",
          customerEmail: "john@example.com",
          stage: "TEST"
          // or 'PROD'
          // Optional: orderNote, notifyUrl, appName, paymentModes, etc.
        });
        console.log("Payment response:", response);
      } catch (err) {
        console.error("Payment failed:", err);
      }
    });
  }
  getIcon(icon) {
    return `data:image/png;base64,${icon}`;
  }
  payWithRazorpay() {
    return __async(this, null, function* () {
      const options = {
        key: "rzp_test_mumd7Md1QvW8oy",
        amount: "100",
        description: "Great offers",
        image: "https://i.imgur.com/3g7nmJC.png",
        order_id: "order_Cp10EhSaf7wLbS",
        //Order ID generated in Step 1
        currency: "INR",
        name: "Acme Corp",
        prefill: {
          email: "gaurav.kumar@example.com",
          contact: "9191919191"
        },
        theme: {
          color: "#3399cc"
        }
      };
      try {
        let data = yield Checkout.open(options);
        console.log(data.response + "AcmeCorp");
      } catch (error) {
        console.log("grgrg", error);
      }
    });
  }
  startWebPayment() {
    return __async(this, null, function* () {
      const paymentData = {
        orderId: "ORDER12345",
        orderAmount: 1e3,
        // Amount in paisa (1000 = 10 INR)
        customerName: "John Doe",
        customerEmail: "john.doe@example.com",
        customerPhone: "1234567890",
        orderCurrency: "INR",
        orderNote: "Test web payment",
        appId: "TEST101213018eca30f9343a22e293f110312101",
        secretKey: "cfsk_ma_test_f55d92e2301e996007f075cb84ec0492_1ae48a5f"
      };
      try {
        const response = yield CFBridge.startPaymentWEB({
          orderId: paymentData.orderId,
          orderAmount: paymentData.orderAmount,
          customerName: paymentData.customerName,
          customerEmail: paymentData.customerEmail,
          customerPhone: paymentData.customerPhone,
          orderCurrency: paymentData.orderCurrency,
          orderNote: paymentData.orderNote,
          appId: paymentData.appId,
          secretKey: paymentData.secretKey
        });
        console.log("Payment Response:", response);
        if (response.status === "success") {
          console.log("Payment was successful!");
        } else {
          console.log("Payment failed!");
        }
      } catch (error) {
        console.error("Error during payment:", error);
      }
    });
  }
  openPaymentGateway() {
    const options = {
      key: "rzp_live_p6MXH1oq4BBYPk",
      // Replace with your Razorpay Key
      amount: 100,
      // Amount in paise (1 INR = 100 paise)
      currency: "INR",
      // Currency
      name: "demoCompany",
      // Your company name
      description: "Payment for selected plan",
      // image: 'https://example.com/logo.png', // Optional: Add your logo
      handler: (response) => {
        console.log("payment done");
      },
      error_handler: (error) => {
        alert("Payment Failed: " + error.description);
      },
      prefill: {
        name: "sammed",
        email: "sammed@gmail.com",
        contact: "9591420068"
      },
      notes: {
        message: "Thank you for choosing demoCompany"
      },
      theme: {
        color: "#000000ff"
        // Customize the theme color
      }
    };
    const razorpay = new Razorpay(options);
    razorpay.open();
  }
  payWithRazorpaycardova() {
    var options = {
      description: "Test Payment",
      currency: "INR",
      key: "rzp_test_mumd7Md1QvW8oy",
      amount: 100,
      // amount in paise
      name: "Pintu Events",
      prefill: {
        email: "",
        contact: "",
        name: ""
      },
      theme: { color: "#050505ff" }
    };
    RazorpayCheckout.open(options, (success) => {
      alert("Payment Success: " + success.razorpay_payment_id);
    }, (error) => {
      alert("Error: " + error.description);
    });
  }
  razorpayServiceOpen() {
    this.razorpayService.payWithRazorpayCardOVA(100, "John Doe", "john@example.com", "9876543210").subscribe({
      next: (result) => {
        console.log("Payment Success:", result.razorpay_payment_id);
        alert(result.razorpay_payment_id);
      },
      error: (err) => {
        console.error("Payment Failed:", err.description);
        alert(err.description);
      }
    });
  }
};
_PaymentPage.\u0275fac = function PaymentPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _PaymentPage)(\u0275\u0275directiveInject(HttpClient), \u0275\u0275directiveInject(RazorpayService), \u0275\u0275directiveInject(NavController));
};
_PaymentPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _PaymentPage, selectors: [["app-payment"]], decls: 11, vars: 2, consts: [[1, "ion-no-border", "bg-white", "pt-2"], ["slot", "start"], [3, "click"], ["name", "arrow-back-outline", "color", "dark"], [1, "fw-bold", "text-dark"], [3, "fullscreen"], [4, "ngIf"], [3, "click", 4, "ngFor", "ngForTrackby", "ngForOf"], [3, "src"]], template: function PaymentPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar")(2, "ion-buttons", 1)(3, "ion-button", 2);
    \u0275\u0275listener("click", function PaymentPage_Template_ion_button_click_3_listener() {
      return ctx.goBack();
    });
    \u0275\u0275element(4, "ion-icon", 3);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "ion-title", 4);
    \u0275\u0275text(6, "Payment");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(7, "ion-content", 5)(8, "ion-button", 2);
    \u0275\u0275listener("click", function PaymentPage_Template_ion_button_click_8_listener() {
      return ctx.razorpayServiceOpen();
    });
    \u0275\u0275text(9, "Pay via UPI");
    \u0275\u0275elementEnd();
    \u0275\u0275template(10, PaymentPage_ion_list_10_Template, 2, 1, "ion-list", 6);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance(7);
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance(3);
    \u0275\u0275property("ngIf", ctx.upiApps);
  }
}, dependencies: [IonButtons, IonIcon, IonList, IonItem, IonLabel, IonAvatar, IonButton, IonContent, IonHeader, IonTitle, IonToolbar, CommonModule, NgForOf, NgIf, FormsModule], encapsulation: 2 });
var PaymentPage = _PaymentPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(PaymentPage, { className: "PaymentPage", filePath: "src/app/pages/payment/payment.page.ts", lineNumber: 26 });
})();
export {
  PaymentPage
};
//# sourceMappingURL=payment.page-CASZRCOF.js.map
