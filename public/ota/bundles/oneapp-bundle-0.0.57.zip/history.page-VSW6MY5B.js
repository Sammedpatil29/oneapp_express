import {
  AuthService
} from "./chunk-EB6T6TPT.js";
import {
  environment
} from "./chunk-YJYUHAOC.js";
import "./chunk-OE5MTPUR.js";
import {
  addIcons,
  alertCircleOutline,
  arrowBackOutline,
  arrowDownOutline,
  bicycleOutline,
  checkmark,
  checkmarkCircleOutline,
  chevronForward,
  closeCircle,
  closeCircleOutline,
  closeOutline,
  flashOutline,
  optionsOutline,
  receiptOutline,
  refreshOutline,
  timeOutline
} from "./chunk-FJYXZAS7.js";
import {
  IonButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonIcon,
  IonModal,
  IonRefresher,
  IonRefresherContent,
  IonSkeletonText,
  IonTitle,
  IonToolbar
} from "./chunk-CJE2NDTY.js";
import {
  CommonModule,
  DatePipe,
  FormsModule,
  HttpClient,
  HttpHeaders,
  NavController,
  NgClass,
  Router,
  catchError,
  of,
  timeout,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵinject,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIdentity,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1
} from "./chunk-Z7XNNJSA.js";
import "./chunk-XR3JUECC.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/components/history/history.service.ts
var _HistoryService = class _HistoryService {
  constructor(http) {
    this.http = http;
    this.url = environment.apiUrl;
  }
  getHistory(params, token) {
    let headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.post(`${this.url}/api/history`, params, { headers });
  }
};
_HistoryService.\u0275fac = function HistoryService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _HistoryService)(\u0275\u0275inject(HttpClient));
};
_HistoryService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _HistoryService, factory: _HistoryService.\u0275fac, providedIn: "root" });
var HistoryService = _HistoryService;

// src/app/pages/history/history.page.ts
var _c0 = () => [0, 0.8, 0.95];
var _c1 = () => [1, 2, 3];
var _forTrack0 = ($index, $item) => $item.id || $index;
function HistoryPage_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 11);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r0.activeOrdersCount);
  }
}
function HistoryPage_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 12);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("(", ctx_r0.completedOrdersCount, ")");
  }
}
function HistoryPage_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 16);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r0.activeFiltersCount);
  }
}
function HistoryPage_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 17)(1, "span", 24);
    \u0275\u0275text(2, " Showing ");
    \u0275\u0275elementStart(3, "strong");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275text(5, " filtered orders ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "button", 25);
    \u0275\u0275listener("click", function HistoryPage_Conditional_25_Template_button_click_6_listener() {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.clearAllFilters());
    });
    \u0275\u0275elementStart(7, "span");
    \u0275\u0275text(8, "Clear Filters");
    \u0275\u0275elementEnd();
    \u0275\u0275element(9, "ion-icon", 26);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r0.filteredHistory.length);
  }
}
function HistoryPage_Conditional_27_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 27)(1, "div", 28);
    \u0275\u0275element(2, "ion-skeleton-text", 29)(3, "ion-skeleton-text", 30);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "div", 31);
    \u0275\u0275element(5, "ion-skeleton-text", 32)(6, "ion-skeleton-text", 33);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "div", 34);
    \u0275\u0275element(8, "ion-skeleton-text", 35)(9, "ion-skeleton-text", 36);
    \u0275\u0275elementEnd()();
  }
}
function HistoryPage_Conditional_27_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 19);
    \u0275\u0275repeaterCreate(1, HistoryPage_Conditional_27_For_2_Template, 10, 0, "div", 27, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance();
    \u0275\u0275repeater(\u0275\u0275pureFunction0(0, _c1));
  }
}
function HistoryPage_Conditional_28_For_2_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 49)(1, "div", 56);
    \u0275\u0275element(2, "span", 57)(3, "span", 58)(4, "span", 59);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 60)(6, "span", 61);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "span", 61);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const item_r4 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate(item_r4.pickup_address || "Pickup Location");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(item_r4.destination_address || "Drop Location");
  }
}
function HistoryPage_Conditional_28_For_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "article", 38);
    \u0275\u0275listener("click", function HistoryPage_Conditional_28_For_2_Template_article_click_0_listener() {
      const item_r4 = \u0275\u0275restoreView(_r3).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.openDetails(item_r4));
    });
    \u0275\u0275elementStart(1, "div", 39)(2, "div", 40)(3, "span", 41);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "span", 42);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "div", 43);
    \u0275\u0275element(8, "ion-icon", 44);
    \u0275\u0275elementStart(9, "span");
    \u0275\u0275text(10);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(11, "div", 45)(12, "h3", 46);
    \u0275\u0275text(13);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "p", 47);
    \u0275\u0275element(15, "ion-icon", 48);
    \u0275\u0275elementStart(16, "span");
    \u0275\u0275text(17);
    \u0275\u0275pipe(18, "date");
    \u0275\u0275elementEnd()();
    \u0275\u0275template(19, HistoryPage_Conditional_28_For_2_Conditional_19_Template, 10, 2, "div", 49);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "div", 50)(21, "div", 51)(22, "span", 52);
    \u0275\u0275text(23, "Total Paid");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(24, "span", 53);
    \u0275\u0275text(25);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(26, "div", 54)(27, "span");
    \u0275\u0275text(28, "View Details");
    \u0275\u0275elementEnd();
    \u0275\u0275element(29, "ion-icon", 55);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const item_r4 = ctx.$implicit;
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(2);
    \u0275\u0275classProp("ride-tag", ctx_r0.isRideType(item_r4.type))("grocery-tag", !ctx_r0.isRideType(item_r4.type));
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r0.isRideType(item_r4.type) ? "\u{1F6F5}" : "\u{1F966}");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r0.isRideType(item_r4.type) ? "Ride" : "Grocery");
    \u0275\u0275advance();
    \u0275\u0275property("ngClass", ctx_r0.getStatusClass(item_r4.status));
    \u0275\u0275advance();
    \u0275\u0275property("name", ctx_r0.getStatusIcon(item_r4.status));
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r0.formatStatus(item_r4.status));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(item_r4.title || (ctx_r0.isRideType(item_r4.type) ? "Daily Commute Ride" : "Grocery Delivery"));
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(18, 13, item_r4.created_at, "dd MMM yyyy, hh:mm a"));
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r0.isRideType(item_r4.type) && (item_r4.pickup_address || item_r4.destination_address) ? 19 : -1);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1("\u20B9", item_r4.finalCost || item_r4.amount || 0, "");
  }
}
function HistoryPage_Conditional_28_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 20);
    \u0275\u0275repeaterCreate(1, HistoryPage_Conditional_28_For_2_Template, 30, 16, "article", 37, _forTrack0);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r0.filteredHistory);
  }
}
function HistoryPage_Conditional_29_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0, " No orders match your current filter settings. Try adjusting or clearing your filters. ");
  }
}
function HistoryPage_Conditional_29_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0, " You don't have any active orders in progress right now. Any ongoing groceries or rides will show up here! ");
  }
}
function HistoryPage_Conditional_29_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0, " You haven't completed any orders yet. Groceries delivered in 10-15 mins & rides in 2 mins! ");
  }
}
function HistoryPage_Conditional_29_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 67);
    \u0275\u0275listener("click", function HistoryPage_Conditional_29_Conditional_9_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r5);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.clearAllFilters());
    });
    \u0275\u0275element(1, "ion-icon", 68);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3, "Reset Filters");
    \u0275\u0275elementEnd()();
  }
}
function HistoryPage_Conditional_29_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 67);
    \u0275\u0275listener("click", function HistoryPage_Conditional_29_Conditional_10_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.goToHome());
    });
    \u0275\u0275element(1, "ion-icon", 69);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3, "Explore Services");
    \u0275\u0275elementEnd()();
  }
}
function HistoryPage_Conditional_29_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 21)(1, "div", 62);
    \u0275\u0275element(2, "ion-icon", 63);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "h3", 64);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p", 65);
    \u0275\u0275template(6, HistoryPage_Conditional_29_Conditional_6_Template, 1, 0)(7, HistoryPage_Conditional_29_Conditional_7_Template, 1, 0)(8, HistoryPage_Conditional_29_Conditional_8_Template, 1, 0);
    \u0275\u0275elementEnd();
    \u0275\u0275template(9, HistoryPage_Conditional_29_Conditional_9_Template, 4, 0, "button", 66)(10, HistoryPage_Conditional_29_Conditional_10_Template, 4, 0, "button", 66);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1(" ", ctx_r0.activeFiltersCount > 0 ? "No Matching Orders" : ctx_r0.activeTab === "active" ? "No Active Orders" : "No Completed Orders", " ");
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r0.activeFiltersCount > 0 ? 6 : ctx_r0.activeTab === "active" ? 7 : 8);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx_r0.activeFiltersCount > 0 ? 9 : 10);
  }
}
function HistoryPage_ng_template_32_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 74);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("", ctx_r0.activeFiltersCount, " active");
  }
}
function HistoryPage_ng_template_32_Conditional_32_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 83);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Conditional_32_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r8);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.filterStatus = "in_progress");
    });
    \u0275\u0275text(1, "Preparing / Placed");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "button", 83);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Conditional_32_Template_button_click_2_listener() {
      \u0275\u0275restoreView(_r8);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.filterStatus = "on_the_way");
    });
    \u0275\u0275text(3, "On The Way");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275classProp("active", ctx_r0.filterStatus === "in_progress");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r0.filterStatus === "on_the_way");
  }
}
function HistoryPage_ng_template_32_Conditional_33_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 83);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Conditional_33_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r9);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.filterStatus = "delivered");
    });
    \u0275\u0275text(1, "Delivered / Done");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "button", 83);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Conditional_33_Template_button_click_2_listener() {
      \u0275\u0275restoreView(_r9);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.filterStatus = "cancelled");
    });
    \u0275\u0275text(3, "Cancelled / Failed");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275classProp("active", ctx_r0.filterStatus === "delivered");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r0.filterStatus === "cancelled");
  }
}
function HistoryPage_ng_template_32_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 70)(1, "header", 71)(2, "div", 72)(3, "h3", 73);
    \u0275\u0275text(4, "Filter Orders");
    \u0275\u0275elementEnd();
    \u0275\u0275template(5, HistoryPage_ng_template_32_Conditional_5_Template, 2, 1, "span", 74);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "div", 75)(7, "button", 76);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Template_button_click_7_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.clearAllFilters());
    });
    \u0275\u0275text(8, " Reset ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "button", 77);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Template_button_click_9_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.closeFilterModal());
    });
    \u0275\u0275element(10, "ion-icon", 78);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(11, "div", 79)(12, "div", 80)(13, "h4", 81);
    \u0275\u0275text(14, "Service Type");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "div", 82)(16, "button", 83);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Template_button_click_16_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.filterCategory = "all");
    });
    \u0275\u0275text(17, "All Services");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "button", 83);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Template_button_click_18_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.filterCategory = "grocery");
    });
    \u0275\u0275text(19, "\u{1F966} Groceries");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "button", 83);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Template_button_click_20_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.filterCategory = "ride");
    });
    \u0275\u0275text(21, "\u{1F6F5} Rides");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(22, "button", 83);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Template_button_click_22_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.filterCategory = "dineout");
    });
    \u0275\u0275text(23, "\u{1F37D}\uFE0F Dineout");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(24, "button", 83);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Template_button_click_24_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.filterCategory = "event");
    });
    \u0275\u0275text(25, "\u{1F39F}\uFE0F Events");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(26, "div", 80)(27, "h4", 81);
    \u0275\u0275text(28, "Order Status");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(29, "div", 82)(30, "button", 83);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Template_button_click_30_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.filterStatus = "all");
    });
    \u0275\u0275text(31, "All Statuses");
    \u0275\u0275elementEnd();
    \u0275\u0275template(32, HistoryPage_ng_template_32_Conditional_32_Template, 4, 4)(33, HistoryPage_ng_template_32_Conditional_33_Template, 4, 4);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(34, "div", 80)(35, "h4", 81);
    \u0275\u0275text(36, "Time Period");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(37, "div", 82)(38, "button", 83);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Template_button_click_38_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.filterTimeframe = "all");
    });
    \u0275\u0275text(39, "All Time");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(40, "button", 83);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Template_button_click_40_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.filterTimeframe = "today");
    });
    \u0275\u0275text(41, "Today (24h)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(42, "button", 83);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Template_button_click_42_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.filterTimeframe = "7days");
    });
    \u0275\u0275text(43, "Last 7 Days");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(44, "button", 83);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Template_button_click_44_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.filterTimeframe = "30days");
    });
    \u0275\u0275text(45, "Last 30 Days");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(46, "div", 80)(47, "h4", 81);
    \u0275\u0275text(48, "Order Amount");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(49, "div", 82)(50, "button", 83);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Template_button_click_50_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.filterPriceRange = "all");
    });
    \u0275\u0275text(51, "Any Amount");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(52, "button", 83);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Template_button_click_52_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.filterPriceRange = "under_200");
    });
    \u0275\u0275text(53, "Under \u20B9200");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(54, "button", 83);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Template_button_click_54_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.filterPriceRange = "200_500");
    });
    \u0275\u0275text(55, "\u20B9200 - \u20B9500");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(56, "button", 83);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Template_button_click_56_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.filterPriceRange = "500_1000");
    });
    \u0275\u0275text(57, "\u20B9500 - \u20B91,000");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(58, "button", 83);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Template_button_click_58_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.filterPriceRange = "above_1000");
    });
    \u0275\u0275text(59, "\u20B91,000+");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(60, "div", 80)(61, "h4", 81);
    \u0275\u0275text(62, "Sort By");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(63, "div", 82)(64, "button", 83);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Template_button_click_64_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.filterSort = "newest");
    });
    \u0275\u0275text(65, "Newest First");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(66, "button", 83);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Template_button_click_66_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.filterSort = "oldest");
    });
    \u0275\u0275text(67, "Oldest First");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(68, "button", 83);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Template_button_click_68_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.filterSort = "price_high");
    });
    \u0275\u0275text(69, "Amount: High to Low");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(70, "button", 83);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Template_button_click_70_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.filterSort = "price_low");
    });
    \u0275\u0275text(71, "Amount: Low to High");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(72, "footer", 84)(73, "button", 85);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Template_button_click_73_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.clearAllFilters());
    });
    \u0275\u0275text(74, " Clear All ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(75, "button", 86);
    \u0275\u0275listener("click", function HistoryPage_ng_template_32_Template_button_click_75_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.applyFilters());
    });
    \u0275\u0275text(76);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(5);
    \u0275\u0275conditional(ctx_r0.activeFiltersCount > 0 ? 5 : -1);
    \u0275\u0275advance(11);
    \u0275\u0275classProp("active", ctx_r0.filterCategory === "all");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r0.filterCategory === "grocery");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r0.filterCategory === "ride");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r0.filterCategory === "dineout");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r0.filterCategory === "event");
    \u0275\u0275advance(6);
    \u0275\u0275classProp("active", ctx_r0.filterStatus === "all");
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r0.activeTab === "active" ? 32 : 33);
    \u0275\u0275advance(6);
    \u0275\u0275classProp("active", ctx_r0.filterTimeframe === "all");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r0.filterTimeframe === "today");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r0.filterTimeframe === "7days");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r0.filterTimeframe === "30days");
    \u0275\u0275advance(6);
    \u0275\u0275classProp("active", ctx_r0.filterPriceRange === "all");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r0.filterPriceRange === "under_200");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r0.filterPriceRange === "200_500");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r0.filterPriceRange === "500_1000");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r0.filterPriceRange === "above_1000");
    \u0275\u0275advance(6);
    \u0275\u0275classProp("active", ctx_r0.filterSort === "newest");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r0.filterSort === "oldest");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r0.filterSort === "price_high");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r0.filterSort === "price_low");
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1(" Show ", ctx_r0.filteredHistory.length, " Orders ");
  }
}
var _HistoryPage = class _HistoryPage {
  // Backwards compatibility getter
  get selectedCategory() {
    return this.filterCategory;
  }
  get activeOrdersCount() {
    return this.history.filter((item) => this.isActiveOrder(item)).length;
  }
  get completedOrdersCount() {
    return this.history.filter((item) => this.isCompletedOrder(item)).length;
  }
  get activeFiltersCount() {
    let count = 0;
    if (this.filterCategory !== "all")
      count++;
    if (this.filterStatus !== "all")
      count++;
    if (this.filterTimeframe !== "all")
      count++;
    if (this.filterSort !== "newest")
      count++;
    if (this.filterPriceRange !== "all")
      count++;
    return count;
  }
  goBack() {
    this.navCtrl.back();
  }
  constructor(router, navCtrl, authService, historyService) {
    this.router = router;
    this.navCtrl = navCtrl;
    this.authService = authService;
    this.historyService = historyService;
    this.history = [];
    this.filteredHistory = [];
    this.isLoading = false;
    this.token = "";
    this.activeTab = "active";
    this.isFilterModalOpen = false;
    this.filterCategory = "all";
    this.filterStatus = "all";
    this.filterTimeframe = "all";
    this.filterSort = "newest";
    this.filterPriceRange = "all";
    addIcons({
      arrowDownOutline,
      receiptOutline,
      timeOutline,
      chevronForward,
      flashOutline,
      checkmarkCircleOutline,
      closeCircleOutline,
      bicycleOutline,
      alertCircleOutline,
      arrowBackOutline,
      optionsOutline,
      closeOutline,
      refreshOutline,
      checkmark,
      closeCircle
    });
  }
  ngOnInit() {
    return __async(this, null, function* () {
      this.token = (yield this.authService.getToken()) || "";
      this.getHistory();
    });
  }
  getHistory() {
    this.isLoading = true;
    const params = { type: "all" };
    this.historyService.getHistory(params, this.token).pipe(timeout(8e3), catchError((err) => {
      console.warn("History fetch error or timeout:", err);
      return of({ data: [] });
    })).subscribe({
      next: (res) => {
        this.history = (res == null ? void 0 : res.data) || [];
        if (this.activeOrdersCount > 0) {
          this.activeTab = "active";
        } else {
          this.activeTab = "completed";
        }
        this.applyFilter();
        this.isLoading = false;
      },
      error: () => {
        this.history = [];
        this.isLoading = false;
      }
    });
  }
  handleRefresh(event) {
    const params = { type: "all" };
    this.historyService.getHistory(params, this.token).subscribe({
      next: (res) => {
        this.history = (res == null ? void 0 : res.data) || [];
        this.applyFilter();
        event.target.complete();
      },
      error: () => event.target.complete()
    });
  }
  setActiveTab(tab) {
    this.activeTab = tab;
    if (this.filterStatus !== "all") {
      this.filterStatus = "all";
    }
    this.applyFilter();
  }
  setCategory(cat) {
    this.filterCategory = cat;
    this.applyFilter();
  }
  // Filter Modal Controls
  openFilterModal() {
    this.isFilterModalOpen = true;
  }
  closeFilterModal() {
    this.isFilterModalOpen = false;
  }
  applyFilters() {
    this.applyFilter();
    this.closeFilterModal();
  }
  clearAllFilters() {
    this.filterCategory = "all";
    this.filterStatus = "all";
    this.filterTimeframe = "all";
    this.filterSort = "newest";
    this.filterPriceRange = "all";
    this.applyFilter();
  }
  isActiveOrder(item) {
    if (!item || !item.status)
      return false;
    const s = (item.status || "").toLowerCase().trim();
    const terminatedStatuses = [
      "completed",
      "delivered",
      "done",
      "resolved",
      "cancelled",
      "failed",
      "rejected"
    ];
    return !terminatedStatuses.includes(s);
  }
  isCompletedOrder(item) {
    return !this.isActiveOrder(item);
  }
  applyFilter() {
    let list = [...this.history];
    if (this.activeTab === "active") {
      list = list.filter((item) => this.isActiveOrder(item));
    } else if (this.activeTab === "completed") {
      list = list.filter((item) => this.isCompletedOrder(item));
    }
    if (this.filterCategory !== "all") {
      if (this.filterCategory === "ride") {
        list = list.filter((item) => this.isRideType(item.type));
      } else if (this.filterCategory === "grocery") {
        list = list.filter((item) => (item.type || "").toLowerCase() === "grocery");
      } else if (this.filterCategory === "dineout") {
        list = list.filter((item) => (item.type || "").toLowerCase() === "dineout");
      } else if (this.filterCategory === "event") {
        list = list.filter((item) => (item.type || "").toLowerCase() === "event");
      }
    }
    if (this.filterStatus !== "all") {
      const s = this.filterStatus.toLowerCase();
      if (s === "delivered") {
        list = list.filter((item) => ["completed", "delivered", "done", "resolved"].includes((item.status || "").toLowerCase()));
      } else if (s === "cancelled") {
        list = list.filter((item) => ["cancelled", "failed", "rejected"].includes((item.status || "").toLowerCase()));
      } else if (s === "on_the_way") {
        list = list.filter((item) => (item.status || "").toLowerCase().includes("way") || (item.status || "").toLowerCase() === "dispatched");
      } else if (s === "in_progress") {
        list = list.filter((item) => ["pending", "paid", "processing", "preparing", "placed", "accepted"].includes((item.status || "").toLowerCase()));
      }
    }
    if (this.filterTimeframe !== "all") {
      const now = (/* @__PURE__ */ new Date()).getTime();
      list = list.filter((item) => {
        if (!item.created_at)
          return true;
        const itemTime = new Date(item.created_at).getTime();
        const diffHours = (now - itemTime) / (1e3 * 60 * 60);
        if (this.filterTimeframe === "today") {
          return diffHours <= 24;
        } else if (this.filterTimeframe === "7days") {
          return diffHours <= 24 * 7;
        } else if (this.filterTimeframe === "30days") {
          return diffHours <= 24 * 30;
        }
        return true;
      });
    }
    if (this.filterPriceRange !== "all") {
      list = list.filter((item) => {
        const cost = Number(item.finalCost) || 0;
        if (this.filterPriceRange === "under_200")
          return cost < 200;
        if (this.filterPriceRange === "200_500")
          return cost >= 200 && cost <= 500;
        if (this.filterPriceRange === "500_1000")
          return cost > 500 && cost <= 1e3;
        if (this.filterPriceRange === "above_1000")
          return cost > 1e3;
        return true;
      });
    }
    if (this.filterSort === "newest") {
      list.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    } else if (this.filterSort === "oldest") {
      list.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
    } else if (this.filterSort === "price_high") {
      list.sort((a, b) => (Number(b.finalCost) || 0) - (Number(a.finalCost) || 0));
    } else if (this.filterSort === "price_low") {
      list.sort((a, b) => (Number(a.finalCost) || 0) - (Number(b.finalCost) || 0));
    }
    this.filteredHistory = list;
  }
  isRideType(type) {
    if (!type)
      return false;
    const t = type.toLowerCase();
    return t.includes("ride") || t.includes("cab") || t.includes("bike") || t.includes("auto") || t.includes("commute");
  }
  getStatusClass(status) {
    if (!status)
      return "status-muted";
    const s = status.toLowerCase();
    if (s === "completed" || s === "delivered" || s === "done" || s === "resolved") {
      return "status-success";
    }
    if (s === "pending" || s === "paid" || s === "active" || s === "processing" || s === "on_the_way") {
      return "status-pending";
    }
    if (s === "cancelled" || s === "failed" || s === "rejected") {
      return "status-danger";
    }
    return "status-muted";
  }
  getStatusIcon(status) {
    if (!status)
      return "time-outline";
    const s = status.toLowerCase();
    if (s === "completed" || s === "delivered" || s === "done" || s === "resolved") {
      return "checkmark-circle-outline";
    }
    if (s === "cancelled" || s === "failed" || s === "rejected") {
      return "close-circle-outline";
    }
    return "time-outline";
  }
  formatStatus(status) {
    if (!status)
      return "Pending";
    const s = status.toLowerCase();
    if (s === "paid")
      return "Upcoming";
    if (s === "on_the_way")
      return "On the way";
    return s.charAt(0).toUpperCase() + s.slice(1);
  }
  openDetails(item) {
    if (!item)
      return;
    if (item.type === "grocery") {
      this.router.navigate([`/layout/grocery-layout/grocery-order-details/${item.id || item.orderId}`], {
        state: { from: "history" }
      });
    } else if (item.type === "dineout") {
      this.router.navigate([`/layout/dineout-layout/dineout-track/${item.id}`], {
        state: { from: "history" }
      });
    } else {
      this.router.navigate(["/layout/rides/tracking"], {
        state: { orderId: item.id || item.orderId }
      });
    }
  }
  goToHome() {
    this.router.navigate(["/layout/home"]);
  }
};
_HistoryPage.\u0275fac = function HistoryPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _HistoryPage)(\u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(AuthService), \u0275\u0275directiveInject(HistoryService));
};
_HistoryPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _HistoryPage, selectors: [["app-history"]], decls: 33, vars: 17, consts: [[1, "ion-no-border", "bg-white", "pt-2"], ["slot", "start"], [3, "click"], ["name", "arrow-back-outline", "color", "dark"], [1, "fw-bold", "text-dark"], [1, "history-content-page", 3, "fullscreen"], ["slot", "fixed", 1, "custom-refresher", 3, "ionRefresh"], ["pullingIcon", "arrow-down-outline", "refreshingSpinner", "crescent"], [1, "orders-top-row"], [1, "orders-tabs-wrapper"], ["type", "button", 1, "order-tab-btn", 3, "click"], [1, "active-tab-badge"], [1, "completed-tab-count"], ["type", "button", "title", "Filter Orders", "aria-label", "Filter", 1, "btn-order-filter", 3, "click"], ["name", "options-outline"], [1, "filter-label"], [1, "filter-count-badge"], [1, "active-filter-chips-bar"], [1, "history-body-container"], [1, "skeletons-list"], [1, "orders-cards-list"], [1, "empty-state-wrapper", "animate__animated", "animate__fadeIn"], [1, "bottom-nav-spacer"], [3, "didDismiss", "isOpen", "initialBreakpoint", "breakpoints", "handle"], [1, "filter-results-text"], ["type", "button", 1, "btn-clear-filters-chip", 3, "click"], ["name", "close-circle"], [1, "history-skeleton-card"], [1, "sk-header"], ["animated", "", 2, "width", "35%", "height", "16px", "border-radius", "6px"], ["animated", "", 2, "width", "25%", "height", "20px", "border-radius", "99px"], [1, "sk-body", "my-3"], ["animated", "", 2, "width", "70%", "height", "20px", "border-radius", "6px", "margin-bottom", "8px"], ["animated", "", 2, "width", "45%", "height", "14px", "border-radius", "4px"], [1, "sk-footer"], ["animated", "", 2, "width", "30%", "height", "18px", "border-radius", "4px"], ["animated", "", 2, "width", "25%", "height", "32px", "border-radius", "10px"], ["role", "button", "tabindex", "0", 1, "modern-order-card"], ["role", "button", "tabindex", "0", 1, "modern-order-card", 3, "click"], [1, "card-top-bar"], [1, "service-tag"], [1, "tag-icon"], [1, "tag-label"], [1, "status-chip", 3, "ngClass"], [3, "name"], [1, "card-main-content"], [1, "order-title"], [1, "order-timestamp"], ["name", "time-outline"], [1, "ride-route-strip"], [1, "card-bottom-footer"], [1, "cost-box"], [1, "cost-label"], [1, "cost-amount"], [1, "card-action-btn"], ["name", "chevron-forward"], [1, "route-dots-col"], [1, "dot-pickup"], [1, "dot-line"], [1, "dot-drop"], [1, "route-texts-col"], [1, "addr-text", "text-truncate"], [1, "empty-icon-halo"], ["name", "receipt-outline"], [1, "empty-title"], [1, "empty-subtitle"], ["type", "button", 1, "btn-start-shopping"], ["type", "button", 1, "btn-start-shopping", 3, "click"], ["name", "refresh-outline", 1, "me-1"], ["name", "flash-outline", 1, "me-1"], [1, "sheet-container", "filter-sheet-container"], [1, "sheet-header"], [1, "sheet-header-left"], [1, "sheet-title"], [1, "sheet-count-tag"], [1, "sheet-header-right"], ["type", "button", 1, "btn-sheet-reset", 3, "click"], ["type", "button", "aria-label", "Close", 1, "btn-sheet-close", 3, "click"], ["name", "close-outline"], [1, "sheet-scroll-body"], [1, "filter-section-block"], [1, "filter-block-title"], [1, "chips-selector-row"], ["type", "button", 1, "choice-chip", 3, "click"], [1, "sheet-footer"], ["type", "button", 1, "btn-sheet-clear", 3, "click"], ["type", "button", 1, "btn-sheet-apply", 3, "click"]], template: function HistoryPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar")(2, "ion-buttons", 1)(3, "ion-button", 2);
    \u0275\u0275listener("click", function HistoryPage_Template_ion_button_click_3_listener() {
      return ctx.goBack();
    });
    \u0275\u0275element(4, "ion-icon", 3);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "ion-title", 4);
    \u0275\u0275text(6, "Activity & Orders");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(7, "ion-content", 5)(8, "ion-refresher", 6);
    \u0275\u0275listener("ionRefresh", function HistoryPage_Template_ion_refresher_ionRefresh_8_listener($event) {
      return ctx.handleRefresh($event);
    });
    \u0275\u0275element(9, "ion-refresher-content", 7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "div", 8)(11, "div", 9)(12, "button", 10);
    \u0275\u0275listener("click", function HistoryPage_Template_button_click_12_listener() {
      return ctx.setActiveTab("active");
    });
    \u0275\u0275elementStart(13, "span");
    \u0275\u0275text(14, "Active");
    \u0275\u0275elementEnd();
    \u0275\u0275template(15, HistoryPage_Conditional_15_Template, 2, 1, "span", 11);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "button", 10);
    \u0275\u0275listener("click", function HistoryPage_Template_button_click_16_listener() {
      return ctx.setActiveTab("completed");
    });
    \u0275\u0275elementStart(17, "span");
    \u0275\u0275text(18, "Completed");
    \u0275\u0275elementEnd();
    \u0275\u0275template(19, HistoryPage_Conditional_19_Template, 2, 1, "span", 12);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(20, "button", 13);
    \u0275\u0275listener("click", function HistoryPage_Template_button_click_20_listener() {
      return ctx.openFilterModal();
    });
    \u0275\u0275element(21, "ion-icon", 14);
    \u0275\u0275elementStart(22, "span", 15);
    \u0275\u0275text(23, "Filter");
    \u0275\u0275elementEnd();
    \u0275\u0275template(24, HistoryPage_Conditional_24_Template, 2, 1, "span", 16);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(25, HistoryPage_Conditional_25_Template, 10, 1, "div", 17);
    \u0275\u0275elementStart(26, "main", 18);
    \u0275\u0275template(27, HistoryPage_Conditional_27_Template, 3, 1, "div", 19)(28, HistoryPage_Conditional_28_Template, 3, 0, "div", 20)(29, HistoryPage_Conditional_29_Template, 11, 3, "div", 21);
    \u0275\u0275element(30, "div", 22);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(31, "ion-modal", 23);
    \u0275\u0275listener("didDismiss", function HistoryPage_Template_ion_modal_didDismiss_31_listener() {
      return ctx.closeFilterModal();
    });
    \u0275\u0275template(32, HistoryPage_ng_template_32_Template, 77, 41, "ng-template");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(7);
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance(5);
    \u0275\u0275classProp("active", ctx.activeTab === "active");
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx.activeOrdersCount > 0 ? 15 : -1);
    \u0275\u0275advance();
    \u0275\u0275classProp("active", ctx.activeTab === "completed");
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx.completedOrdersCount > 0 ? 19 : -1);
    \u0275\u0275advance();
    \u0275\u0275classProp("active", ctx.activeFiltersCount > 0);
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx.activeFiltersCount > 0 ? 24 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(!ctx.isLoading && ctx.activeFiltersCount > 0 ? 25 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx.isLoading ? 27 : ctx.filteredHistory && ctx.filteredHistory.length > 0 ? 28 : 29);
    \u0275\u0275advance(4);
    \u0275\u0275property("isOpen", ctx.isFilterModalOpen)("initialBreakpoint", 0.8)("breakpoints", \u0275\u0275pureFunction0(16, _c0))("handle", true);
  }
}, dependencies: [
  CommonModule,
  NgClass,
  DatePipe,
  FormsModule,
  IonHeader,
  IonToolbar,
  IonButtons,
  IonButton,
  IonTitle,
  IonContent,
  IonRefresher,
  IonRefresherContent,
  IonSkeletonText,
  IonIcon,
  IonModal
], styles: ["\n\n.history-content-page[_ngcontent-%COMP%] {\n  --background: #f8fafc;\n  --overflow: auto;\n  position: relative;\n}\n.custom-refresher[_ngcontent-%COMP%] {\n  z-index: 100;\n}\nion-header[_ngcontent-%COMP%] {\n  --background: #ffffff;\n  background: #ffffff;\n  border-bottom: 1px solid #f1f5f9;\n}\nion-toolbar[_ngcontent-%COMP%] {\n  --background: #ffffff;\n}\n.orders-top-row[_ngcontent-%COMP%] {\n  position: sticky;\n  top: 0;\n  z-index: 20;\n  background: #ffffff;\n  border-bottom: 1px solid #f1f5f9;\n  padding: 10px 16px;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 12px;\n  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.03);\n}\n.orders-top-row[_ngcontent-%COMP%]   .orders-tabs-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  background: #f1f5f9;\n  border-radius: 14px;\n  padding: 3px;\n  gap: 2px;\n  flex: 1;\n  max-width: 270px;\n}\n.orders-top-row[_ngcontent-%COMP%]   .orders-tabs-wrapper[_ngcontent-%COMP%]   .order-tab-btn[_ngcontent-%COMP%] {\n  flex: 1;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  gap: 6px;\n  padding: 8px 12px;\n  border-radius: 11px;\n  border: none;\n  background: transparent;\n  color: #64748b;\n  font-size: 13px;\n  font-weight: 700;\n  cursor: pointer;\n  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);\n  white-space: nowrap;\n}\n.orders-top-row[_ngcontent-%COMP%]   .orders-tabs-wrapper[_ngcontent-%COMP%]   .order-tab-btn[_ngcontent-%COMP%]:active {\n  transform: scale(0.97);\n}\n.orders-top-row[_ngcontent-%COMP%]   .orders-tabs-wrapper[_ngcontent-%COMP%]   .order-tab-btn.active[_ngcontent-%COMP%] {\n  background: #ffffff;\n  color: #0f172a;\n  font-weight: 800;\n  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.08);\n}\n.orders-top-row[_ngcontent-%COMP%]   .orders-tabs-wrapper[_ngcontent-%COMP%]   .order-tab-btn[_ngcontent-%COMP%]   .active-tab-badge[_ngcontent-%COMP%] {\n  background: #10b981;\n  color: #ffffff;\n  font-size: 10.5px;\n  font-weight: 800;\n  padding: 1px 6px;\n  border-radius: 99px;\n  line-height: 1.3;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n}\n.orders-top-row[_ngcontent-%COMP%]   .orders-tabs-wrapper[_ngcontent-%COMP%]   .order-tab-btn[_ngcontent-%COMP%]   .completed-tab-count[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  font-weight: 600;\n  color: #94a3b8;\n}\n.orders-top-row[_ngcontent-%COMP%]   .btn-order-filter[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  gap: 6px;\n  height: 38px;\n  padding: 0 14px;\n  border-radius: 12px;\n  background: #f8fafc;\n  border: 1.5px solid #e2e8f0;\n  color: #334155;\n  font-size: 12.5px;\n  font-weight: 750;\n  cursor: pointer;\n  flex-shrink: 0;\n  transition: all 0.2s ease;\n  position: relative;\n}\n.orders-top-row[_ngcontent-%COMP%]   .btn-order-filter[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 16px;\n  color: #64748b;\n}\n.orders-top-row[_ngcontent-%COMP%]   .btn-order-filter[_ngcontent-%COMP%]:active {\n  transform: scale(0.96);\n}\n.orders-top-row[_ngcontent-%COMP%]   .btn-order-filter.active[_ngcontent-%COMP%] {\n  background: #fdf4ff;\n  border-color: #a000e2;\n  color: #a000e2;\n}\n.orders-top-row[_ngcontent-%COMP%]   .btn-order-filter.active[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  color: #a000e2;\n}\n.orders-top-row[_ngcontent-%COMP%]   .btn-order-filter[_ngcontent-%COMP%]   .filter-count-badge[_ngcontent-%COMP%] {\n  width: 18px;\n  height: 18px;\n  border-radius: 50%;\n  background: #a000e2;\n  color: #ffffff;\n  font-size: 10px;\n  font-weight: 800;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin-left: 2px;\n}\n.active-filter-chips-bar[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 8px 16px;\n  background: #faf5ff;\n  border-bottom: 1px solid #f3e8ff;\n}\n.active-filter-chips-bar[_ngcontent-%COMP%]   .filter-results-text[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #6b21a8;\n}\n.active-filter-chips-bar[_ngcontent-%COMP%]   .filter-results-text[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  font-weight: 800;\n  color: #a000e2;\n}\n.active-filter-chips-bar[_ngcontent-%COMP%]   .btn-clear-filters-chip[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  border: none;\n  background: transparent;\n  color: #a000e2;\n  font-size: 11.5px;\n  font-weight: 750;\n  cursor: pointer;\n  padding: 0;\n}\n.active-filter-chips-bar[_ngcontent-%COMP%]   .btn-clear-filters-chip[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n}\n.history-body-container[_ngcontent-%COMP%] {\n  padding: 16px;\n  display: flex;\n  flex-direction: column;\n  gap: 14px;\n}\n.orders-cards-list[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 14px;\n}\n.modern-order-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border: 1px solid #f1f5f9;\n  border-radius: 18px;\n  padding: 16px;\n  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.04);\n  cursor: pointer;\n  transition: transform 0.18s ease, box-shadow 0.18s ease;\n}\n.modern-order-card[_ngcontent-%COMP%]:active {\n  transform: scale(0.985);\n  border-color: rgba(160, 0, 226, 0.3);\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-top-bar[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin-bottom: 10px;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-top-bar[_ngcontent-%COMP%]   .service-tag[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n  padding: 4px 10px;\n  border-radius: 99px;\n  font-size: 11px;\n  font-weight: 750;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-top-bar[_ngcontent-%COMP%]   .service-tag.grocery-tag[_ngcontent-%COMP%] {\n  background: rgba(16, 185, 129, 0.12);\n  color: #059669;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-top-bar[_ngcontent-%COMP%]   .service-tag.ride-tag[_ngcontent-%COMP%] {\n  background: rgba(160, 0, 226, 0.12);\n  color: #a000e2;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-top-bar[_ngcontent-%COMP%]   .status-chip[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  padding: 4px 10px;\n  border-radius: 99px;\n  font-size: 11px;\n  font-weight: 750;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-top-bar[_ngcontent-%COMP%]   .status-chip[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-top-bar[_ngcontent-%COMP%]   .status-chip.status-success[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  color: #059669;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-top-bar[_ngcontent-%COMP%]   .status-chip.status-pending[_ngcontent-%COMP%] {\n  background: #eff6ff;\n  color: #2563eb;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-top-bar[_ngcontent-%COMP%]   .status-chip.status-danger[_ngcontent-%COMP%] {\n  background: #fef2f2;\n  color: #dc2626;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-top-bar[_ngcontent-%COMP%]   .status-chip.status-muted[_ngcontent-%COMP%] {\n  background: #f8fafc;\n  color: #64748b;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-main-content[_ngcontent-%COMP%] {\n  margin-bottom: 12px;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-main-content[_ngcontent-%COMP%]   .order-title[_ngcontent-%COMP%] {\n  font-size: 15.5px;\n  font-weight: 750;\n  color: #0f172a;\n  margin: 0 0 4px;\n  line-height: 1.3;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-main-content[_ngcontent-%COMP%]   .order-timestamp[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 5px;\n  font-size: 11.5px;\n  color: #64748b;\n  margin: 0 0 8px;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-main-content[_ngcontent-%COMP%]   .order-timestamp[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 13px;\n  color: #94a3b8;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-main-content[_ngcontent-%COMP%]   .ride-route-strip[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 10px;\n  background: #f8fafc;\n  border-radius: 12px;\n  padding: 10px 12px;\n  margin-top: 8px;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-main-content[_ngcontent-%COMP%]   .ride-route-strip[_ngcontent-%COMP%]   .route-dots-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: space-between;\n  padding: 4px 0;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-main-content[_ngcontent-%COMP%]   .ride-route-strip[_ngcontent-%COMP%]   .route-dots-col[_ngcontent-%COMP%]   .dot-pickup[_ngcontent-%COMP%] {\n  width: 8px;\n  height: 8px;\n  border-radius: 50%;\n  background: #10b981;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-main-content[_ngcontent-%COMP%]   .ride-route-strip[_ngcontent-%COMP%]   .route-dots-col[_ngcontent-%COMP%]   .dot-line[_ngcontent-%COMP%] {\n  width: 1.5px;\n  height: 16px;\n  background: #cbd5e1;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-main-content[_ngcontent-%COMP%]   .ride-route-strip[_ngcontent-%COMP%]   .route-dots-col[_ngcontent-%COMP%]   .dot-drop[_ngcontent-%COMP%] {\n  width: 8px;\n  height: 8px;\n  border-radius: 50%;\n  background: #ef4444;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-main-content[_ngcontent-%COMP%]   .ride-route-strip[_ngcontent-%COMP%]   .route-texts-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n  gap: 6px;\n  overflow: hidden;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-main-content[_ngcontent-%COMP%]   .ride-route-strip[_ngcontent-%COMP%]   .route-texts-col[_ngcontent-%COMP%]   .addr-text[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 600;\n  color: #334155;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-bottom-footer[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding-top: 10px;\n  border-top: 1px solid #f1f5f9;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-bottom-footer[_ngcontent-%COMP%]   .cost-box[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-bottom-footer[_ngcontent-%COMP%]   .cost-box[_ngcontent-%COMP%]   .cost-label[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 700;\n  color: #94a3b8;\n  text-transform: uppercase;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-bottom-footer[_ngcontent-%COMP%]   .cost-box[_ngcontent-%COMP%]   .cost-amount[_ngcontent-%COMP%] {\n  font-size: 16.5px;\n  font-weight: 850;\n  color: #0f172a;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-bottom-footer[_ngcontent-%COMP%]   .card-action-btn[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  background: rgba(160, 0, 226, 0.08);\n  color: var(--app-theme-color, #a000e2);\n  border-radius: 99px;\n  padding: 6px 14px;\n  font-size: 12.5px;\n  font-weight: 750;\n}\n.modern-order-card[_ngcontent-%COMP%]   .card-bottom-footer[_ngcontent-%COMP%]   .card-action-btn[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n}\n.skeletons-list[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 14px;\n}\n.history-skeleton-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 18px;\n  padding: 16px;\n  border: 1px solid #f1f5f9;\n}\n.history-skeleton-card[_ngcontent-%COMP%]   .sk-header[_ngcontent-%COMP%], \n.history-skeleton-card[_ngcontent-%COMP%]   .sk-footer[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n.empty-state-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  text-align: center;\n  padding: 48px 24px;\n}\n.empty-state-wrapper[_ngcontent-%COMP%]   .empty-icon-halo[_ngcontent-%COMP%] {\n  width: 80px;\n  height: 80px;\n  border-radius: 50%;\n  background: rgba(160, 0, 226, 0.1);\n  color: var(--app-theme-color, #a000e2);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 38px;\n  margin-bottom: 18px;\n}\n.empty-state-wrapper[_ngcontent-%COMP%]   .empty-title[_ngcontent-%COMP%] {\n  font-size: 18px;\n  font-weight: 800;\n  color: #0f172a;\n  margin: 0 0 6px;\n}\n.empty-state-wrapper[_ngcontent-%COMP%]   .empty-subtitle[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  color: #64748b;\n  line-height: 1.5;\n  max-width: 290px;\n  margin: 0 0 22px;\n}\n.empty-state-wrapper[_ngcontent-%COMP%]   .btn-start-shopping[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #a000e2 0%,\n      #7e00b3 100%);\n  color: #ffffff;\n  border: none;\n  border-radius: 14px;\n  padding: 12px 24px;\n  font-size: 14px;\n  font-weight: 750;\n  cursor: pointer;\n  box-shadow: 0 6px 18px rgba(160, 0, 226, 0.28);\n  display: inline-flex;\n  align-items: center;\n}\n.empty-state-wrapper[_ngcontent-%COMP%]   .btn-start-shopping[_ngcontent-%COMP%]:active {\n  transform: scale(0.96);\n}\n.bottom-nav-spacer[_ngcontent-%COMP%] {\n  min-height: calc(80px + env(safe-area-inset-bottom, 0px));\n  height: calc(80px + env(safe-area-inset-bottom, 0px));\n  width: 100%;\n}\nion-modal[_ngcontent-%COMP%] {\n  --border-radius: 24px 24px 0 0;\n  --background: #ffffff;\n}\n.sheet-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  background: #ffffff;\n  height: 100%;\n  padding-bottom: max(env(safe-area-inset-bottom, 0px), 16px);\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-header[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 16px 20px 12px;\n  border-bottom: 1px solid #f1f5f9;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-header[_ngcontent-%COMP%]   .sheet-title[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 850;\n  color: #0f172a;\n  margin: 0;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-header[_ngcontent-%COMP%]   .sheet-header-left[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-header[_ngcontent-%COMP%]   .sheet-header-left[_ngcontent-%COMP%]   .sheet-count-tag[_ngcontent-%COMP%] {\n  background: #fdf4ff;\n  color: #a000e2;\n  border: 1px solid #f5d0fe;\n  font-size: 11px;\n  font-weight: 750;\n  padding: 2px 8px;\n  border-radius: 6px;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-header[_ngcontent-%COMP%]   .sheet-header-right[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-header[_ngcontent-%COMP%]   .sheet-header-right[_ngcontent-%COMP%]   .btn-sheet-reset[_ngcontent-%COMP%] {\n  background: transparent;\n  border: none;\n  color: #ef4444;\n  font-size: 13px;\n  font-weight: 750;\n  cursor: pointer;\n  padding: 0;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-header[_ngcontent-%COMP%]   .sheet-header-right[_ngcontent-%COMP%]   .btn-sheet-close[_ngcontent-%COMP%] {\n  width: 32px;\n  height: 32px;\n  border-radius: 50%;\n  background: #f1f5f9;\n  border: none;\n  color: #64748b;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 18px;\n  cursor: pointer;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-scroll-body[_ngcontent-%COMP%] {\n  flex: 1;\n  overflow-y: auto;\n  padding: 14px 18px;\n  display: flex;\n  flex-direction: column;\n  gap: 18px;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-scroll-body[_ngcontent-%COMP%]   .filter-section-block[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-scroll-body[_ngcontent-%COMP%]   .filter-section-block[_ngcontent-%COMP%]   .filter-block-title[_ngcontent-%COMP%] {\n  font-size: 12.5px;\n  font-weight: 800;\n  color: #0f172a;\n  margin: 0;\n  text-transform: uppercase;\n  letter-spacing: 0.3px;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-scroll-body[_ngcontent-%COMP%]   .filter-section-block[_ngcontent-%COMP%]   .chips-selector-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  flex-wrap: wrap;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-scroll-body[_ngcontent-%COMP%]   .filter-section-block[_ngcontent-%COMP%]   .chips-selector-row[_ngcontent-%COMP%]   .choice-chip[_ngcontent-%COMP%] {\n  border: 1.5px solid #e2e8f0;\n  background: #f8fafc;\n  color: #475569;\n  font-size: 12px;\n  font-weight: 700;\n  padding: 8px 14px;\n  border-radius: 12px;\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-scroll-body[_ngcontent-%COMP%]   .filter-section-block[_ngcontent-%COMP%]   .chips-selector-row[_ngcontent-%COMP%]   .choice-chip.active[_ngcontent-%COMP%] {\n  background: #fdf4ff;\n  border-color: #a000e2;\n  color: #a000e2;\n  font-weight: 800;\n  box-shadow: 0 2px 6px rgba(160, 0, 226, 0.12);\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-scroll-body[_ngcontent-%COMP%]   .filter-section-block[_ngcontent-%COMP%]   .chips-selector-row[_ngcontent-%COMP%]   .choice-chip[_ngcontent-%COMP%]:active {\n  transform: scale(0.96);\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-footer[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  padding: 12px 18px 4px;\n  border-top: 1px solid #f1f5f9;\n  background: #ffffff;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-footer[_ngcontent-%COMP%]   .btn-sheet-clear[_ngcontent-%COMP%] {\n  height: 46px;\n  padding: 0 16px;\n  border-radius: 12px;\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n  color: #64748b;\n  font-size: 13px;\n  font-weight: 750;\n  cursor: pointer;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-footer[_ngcontent-%COMP%]   .btn-sheet-apply[_ngcontent-%COMP%] {\n  flex: 1;\n  height: 46px;\n  border-radius: 12px;\n  background:\n    linear-gradient(\n      135deg,\n      #a000e2 0%,\n      #7e00b3 100%);\n  border: none;\n  color: #ffffff;\n  font-size: 13.5px;\n  font-weight: 800;\n  cursor: pointer;\n  box-shadow: 0 4px 14px rgba(160, 0, 226, 0.28);\n  transition: transform 0.15s ease;\n}\n.sheet-container[_ngcontent-%COMP%]   .sheet-footer[_ngcontent-%COMP%]   .btn-sheet-apply[_ngcontent-%COMP%]:active {\n  transform: scale(0.98);\n}\n/*# sourceMappingURL=history.page.css.map */"] });
var HistoryPage = _HistoryPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(HistoryPage, { className: "HistoryPage", filePath: "src/app/pages/history/history.page.ts", lineNumber: 63 });
})();
export {
  HistoryPage
};
//# sourceMappingURL=history.page-VSW6MY5B.js.map
