import {
  App
} from "./chunk-EBMCUG2R.js";
import {
  ToastController
} from "./chunk-OE5MTPUR.js";
import {
  addIcons,
  airplaneOutline,
  alertCircleOutline,
  cellularOutline,
  checkmarkCircle,
  cloudOfflineOutline,
  powerOutline,
  refreshOutline,
  wifiOutline
} from "./chunk-FJYXZAS7.js";
import {
  IonContent,
  IonIcon,
  IonSpinner
} from "./chunk-CJE2NDTY.js";
import {
  CommonModule,
  EventEmitter,
  NavController,
  Router,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate
} from "./chunk-Z7XNNJSA.js";
import {
  ImpactStyle,
  NotificationType
} from "./chunk-5T7BJTUX.js";
import {
  registerPlugin
} from "./chunk-FH4NU4VH.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// node_modules/@capacitor/network/dist/esm/index.js
var Network = registerPlugin("Network", {
  web: () => import("./web-VUFIRTZR.js").then((m) => new m.NetworkWeb())
});

// node_modules/@capacitor/haptics/dist/esm/index.js
var Haptics = registerPlugin("Haptics", {
  web: () => import("./web-BMGV7VVS.js").then((m) => new m.HapticsWeb())
});

// src/app/offline/offline.page.ts
function OfflinePage_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 14);
  }
}
function OfflinePage_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-spinner", 15);
  }
}
function OfflinePage_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 16);
  }
}
function OfflinePage_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1, "Connection Restored!");
    \u0275\u0275elementEnd();
  }
}
function OfflinePage_Conditional_21_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1, "No Internet Connection");
    \u0275\u0275elementEnd();
  }
}
function OfflinePage_Conditional_22_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 19)(1, "span");
    \u0275\u0275text(2, "\u0CB8\u0CCD\u0CB5\u0CB2\u0CCD\u0CAA \u0CA8\u0CC6\u0C9F\u0CCD\u0CB5\u0CB0\u0CCD\u0C95\u0CCD \u0C9A\u0CC6\u0C95\u0CCD \u0CAE\u0CBE\u0CA1\u0CCD\u0C95\u0CCB\u0CB0\u0CBF \u0CAC\u0CB0\u0CCD\u0CA4\u0CA4\u0CBF!");
    \u0275\u0275elementEnd()();
  }
}
function OfflinePage_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1, "You're back online. Redirecting to home...");
    \u0275\u0275elementEnd();
  }
}
function OfflinePage_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1, "Please check your cellular data or Wi-Fi network and try again.");
    \u0275\u0275elementEnd();
  }
}
function OfflinePage_Conditional_26_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 21);
    \u0275\u0275element(1, "ion-icon", 27);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx_r0.errorMessage);
  }
}
function OfflinePage_Conditional_27_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 22)(1, "div", 28);
    \u0275\u0275element(2, "ion-icon", 29);
    \u0275\u0275elementStart(3, "span");
    \u0275\u0275text(4, "Mobile Data");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "div", 28);
    \u0275\u0275element(6, "ion-icon", 30);
    \u0275\u0275elementStart(7, "span");
    \u0275\u0275text(8, "Airplane Mode");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "div", 28);
    \u0275\u0275element(10, "ion-icon", 31);
    \u0275\u0275elementStart(11, "span");
    \u0275\u0275text(12, "Wi-Fi Signal");
    \u0275\u0275elementEnd()()();
  }
}
function OfflinePage_Conditional_30_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 32);
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2, "Connected! Redirecting...");
    \u0275\u0275elementEnd();
  }
}
function OfflinePage_Conditional_31_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-spinner", 33);
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2, "Checking connection...");
    \u0275\u0275elementEnd();
  }
}
function OfflinePage_Conditional_32_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 34);
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2, "Try Again");
    \u0275\u0275elementEnd();
  }
}
var _OfflinePage = class _OfflinePage {
  constructor(navCtrl, router, toastCtrl) {
    this.navCtrl = navCtrl;
    this.router = router;
    this.toastCtrl = toastCtrl;
    this.onlineRestored = new EventEmitter();
    this.isChecking = false;
    this.isConnected = false;
    this.checkFailed = false;
    this.errorMessage = "";
    this.networkListener = null;
    this.resetTimeout = null;
    addIcons({
      cloudOfflineOutline,
      wifiOutline,
      refreshOutline,
      checkmarkCircle,
      cellularOutline,
      airplaneOutline,
      alertCircleOutline,
      powerOutline
    });
  }
  ngOnInit() {
    return __async(this, null, function* () {
      try {
        this.networkListener = yield Network.addListener("networkStatusChange", (changeEvent) => {
          if (changeEvent.connected) {
            this.handleOnlineRestoration();
          }
        });
      } catch (e) {
        console.warn("Network listener setup fallback:", e);
      }
      window.addEventListener("online", this.handleOnlineRestoration.bind(this));
      const initialStatus = yield Network.getStatus().catch(() => ({ connected: false }));
      if (initialStatus.connected) {
        this.handleOnlineRestoration();
      }
    });
  }
  ngOnDestroy() {
    if (this.networkListener) {
      this.networkListener.remove();
      this.networkListener = null;
    }
    window.removeEventListener("online", this.handleOnlineRestoration.bind(this));
    if (this.resetTimeout) {
      clearTimeout(this.resetTimeout);
    }
  }
  /**
   * Active retry action triggered by user tapping the button
   */
  retry() {
    return __async(this, null, function* () {
      if (this.isChecking || this.isConnected)
        return;
      this.isChecking = true;
      this.checkFailed = false;
      this.errorMessage = "";
      try {
        yield Haptics.impact({ style: ImpactStyle.Light });
      } catch {
      }
      const netStatus = yield Network.getStatus().catch(() => ({ connected: false }));
      yield new Promise((resolve) => setTimeout(resolve, 800));
      if (netStatus.connected) {
        yield this.handleOnlineRestoration();
      } else {
        this.isChecking = false;
        this.checkFailed = true;
        this.errorMessage = "Still offline. Please check your data connection.";
        try {
          yield Haptics.notification({ type: NotificationType.Warning });
        } catch {
        }
        if (this.resetTimeout) {
          clearTimeout(this.resetTimeout);
        }
        this.resetTimeout = setTimeout(() => {
          this.checkFailed = false;
        }, 4e3);
      }
    });
  }
  /**
   * Reconnection handler with success animation and smooth transition to Home
   */
  handleOnlineRestoration() {
    return __async(this, null, function* () {
      if (this.isConnected)
        return;
      this.isConnected = true;
      this.isChecking = false;
      this.checkFailed = false;
      try {
        yield Haptics.notification({ type: NotificationType.Success });
      } catch {
      }
      this.onlineRestored.emit();
      setTimeout(() => {
        this.navCtrl.navigateRoot("/layout/home", { animated: true, animationDirection: "forward" });
      }, 700);
    });
  }
  /**
   * Graceful exit option for users who don't want to wait
   */
  exitApp() {
    return __async(this, null, function* () {
      try {
        yield App.exitApp();
      } catch {
        this.navCtrl.navigateRoot("/layout/home");
      }
    });
  }
};
_OfflinePage.\u0275fac = function OfflinePage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _OfflinePage)(\u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(ToastController));
};
_OfflinePage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _OfflinePage, selectors: [["app-offline"]], outputs: { onlineRestored: "onlineRestored" }, decls: 37, vars: 17, consts: [[1, "offline-content", 3, "scrollY"], [1, "offline-viewport"], [1, "ambient-glow", "glow-top"], [1, "ambient-glow", "glow-bottom"], [1, "offline-header"], [1, "brand-pill"], [1, "brand-dot"], [1, "brand-text"], [1, "offline-center-stack"], [1, "radar-visual-wrapper"], [1, "ripple-ring", "ring-1"], [1, "ripple-ring", "ring-2"], [1, "ripple-ring", "ring-3"], [1, "center-icon-badge"], ["name", "checkmark-circle", 1, "status-icon", "icon-success"], ["name", "crescent", 1, "status-spinner"], ["name", "cloud-offline-outline", 1, "status-icon", "icon-offline"], [1, "message-text-group"], [1, "headline-title"], [1, "regional-pill"], [1, "sub-description"], [1, "error-notice-pill"], [1, "troubleshoot-chips-row"], [1, "offline-footer"], ["type", "button", "aria-label", "Retry network connection", 1, "btn-retry-main", 3, "click", "disabled"], ["type", "button", "aria-label", "Close or Exit App", 1, "btn-exit-subtle", 3, "click"], ["name", "power-outline"], ["name", "alert-circle-outline"], [1, "tip-chip"], ["name", "cellular-outline"], ["name", "airplane-outline"], ["name", "wifi-outline"], ["name", "checkmark-circle"], ["name", "crescent"], ["name", "refresh-outline"]], template: function OfflinePage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 0)(1, "div", 1);
    \u0275\u0275element(2, "div", 2)(3, "div", 3);
    \u0275\u0275elementStart(4, "header", 4)(5, "div", 5);
    \u0275\u0275element(6, "span", 6);
    \u0275\u0275elementStart(7, "span", 7);
    \u0275\u0275text(8, "Pintu Offline Mode");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(9, "main", 8)(10, "div", 9);
    \u0275\u0275element(11, "div", 10)(12, "div", 11)(13, "div", 12);
    \u0275\u0275elementStart(14, "div", 13);
    \u0275\u0275template(15, OfflinePage_Conditional_15_Template, 1, 0, "ion-icon", 14)(16, OfflinePage_Conditional_16_Template, 1, 0, "ion-spinner", 15)(17, OfflinePage_Conditional_17_Template, 1, 0, "ion-icon", 16);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(18, "div", 17)(19, "h1", 18);
    \u0275\u0275template(20, OfflinePage_Conditional_20_Template, 2, 0, "span")(21, OfflinePage_Conditional_21_Template, 2, 0, "span");
    \u0275\u0275elementEnd();
    \u0275\u0275template(22, OfflinePage_Conditional_22_Template, 3, 0, "div", 19);
    \u0275\u0275elementStart(23, "p", 20);
    \u0275\u0275template(24, OfflinePage_Conditional_24_Template, 2, 0, "span")(25, OfflinePage_Conditional_25_Template, 2, 0, "span");
    \u0275\u0275elementEnd()();
    \u0275\u0275template(26, OfflinePage_Conditional_26_Template, 4, 1, "div", 21)(27, OfflinePage_Conditional_27_Template, 13, 0, "div", 22);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(28, "footer", 23)(29, "button", 24);
    \u0275\u0275listener("click", function OfflinePage_Template_button_click_29_listener() {
      return ctx.retry();
    });
    \u0275\u0275template(30, OfflinePage_Conditional_30_Template, 3, 0)(31, OfflinePage_Conditional_31_Template, 3, 0)(32, OfflinePage_Conditional_32_Template, 3, 0);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(33, "button", 25);
    \u0275\u0275listener("click", function OfflinePage_Template_button_click_33_listener() {
      return ctx.exitApp();
    });
    \u0275\u0275element(34, "ion-icon", 26);
    \u0275\u0275elementStart(35, "span");
    \u0275\u0275text(36, "Exit Application");
    \u0275\u0275elementEnd()()()()();
  }
  if (rf & 2) {
    \u0275\u0275property("scrollY", false);
    \u0275\u0275advance(10);
    \u0275\u0275classProp("is-checking", ctx.isChecking)("is-connected", ctx.isConnected);
    \u0275\u0275advance(5);
    \u0275\u0275conditional(ctx.isConnected ? 15 : ctx.isChecking ? 16 : 17);
    \u0275\u0275advance(5);
    \u0275\u0275conditional(ctx.isConnected ? 20 : 21);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(!ctx.isConnected ? 22 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx.isConnected ? 24 : 25);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx.checkFailed && !ctx.isConnected ? 26 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(!ctx.isConnected ? 27 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275classProp("loading", ctx.isChecking)("success", ctx.isConnected);
    \u0275\u0275property("disabled", ctx.isChecking || ctx.isConnected);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.isConnected ? 30 : ctx.isChecking ? 31 : 32);
  }
}, dependencies: [CommonModule, IonContent, IonIcon, IonSpinner], styles: ["\n\n[_nghost-%COMP%] {\n  display: block;\n  width: 100%;\n  height: 100%;\n  height: 100dvh;\n  overflow: hidden;\n}\n.offline-content[_ngcontent-%COMP%] {\n  --background: #f8fafc;\n  --color: #0f172a;\n  --overflow: hidden;\n  height: 100%;\n  height: 100dvh;\n  overflow: hidden;\n}\n.offline-viewport[_ngcontent-%COMP%] {\n  position: relative;\n  height: 100%;\n  height: 100dvh;\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n  padding: max(env(safe-area-inset-top, 0px), 16px) 20px max(env(safe-area-inset-bottom, 0px), 16px);\n  box-sizing: border-box;\n  overflow: hidden;\n}\n.ambient-glow[_ngcontent-%COMP%] {\n  position: absolute;\n  border-radius: 50%;\n  filter: blur(70px);\n  pointer-events: none;\n  z-index: 0;\n}\n.ambient-glow.glow-top[_ngcontent-%COMP%] {\n  top: -40px;\n  right: -40px;\n  width: 200px;\n  height: 200px;\n  background:\n    radial-gradient(\n      circle,\n      rgba(239, 68, 68, 0.1) 0%,\n      transparent 70%);\n}\n.ambient-glow.glow-bottom[_ngcontent-%COMP%] {\n  bottom: 60px;\n  left: -40px;\n  width: 220px;\n  height: 220px;\n  background:\n    radial-gradient(\n      circle,\n      rgba(99, 102, 241, 0.08) 0%,\n      transparent 70%);\n}\n.offline-header[_ngcontent-%COMP%] {\n  position: relative;\n  z-index: 2;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  flex-shrink: 0;\n  padding-top: 4px;\n}\n.offline-header[_ngcontent-%COMP%]   .brand-pill[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 7px;\n  background: rgba(255, 255, 255, 0.9);\n  backdrop-filter: blur(12px);\n  -webkit-backdrop-filter: blur(12px);\n  border: 1px solid #e2e8f0;\n  padding: 5px 14px;\n  border-radius: 999px;\n  box-shadow: 0 2px 6px rgba(15, 23, 42, 0.04);\n}\n.offline-header[_ngcontent-%COMP%]   .brand-pill[_ngcontent-%COMP%]   .brand-dot[_ngcontent-%COMP%] {\n  width: 7px;\n  height: 7px;\n  border-radius: 50%;\n  background: #f43f5e;\n  box-shadow: 0 0 8px #f43f5e;\n  animation: _ngcontent-%COMP%_pulse-dot 2s infinite ease-in-out;\n}\n.offline-header[_ngcontent-%COMP%]   .brand-pill[_ngcontent-%COMP%]   .brand-text[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 750;\n  color: #64748b;\n  letter-spacing: 0.4px;\n  text-transform: uppercase;\n}\n.offline-center-stack[_ngcontent-%COMP%] {\n  position: relative;\n  z-index: 2;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  text-align: center;\n  width: 100%;\n  max-width: 380px;\n  margin: auto;\n  flex-shrink: 1;\n}\n.radar-visual-wrapper[_ngcontent-%COMP%] {\n  position: relative;\n  width: 124px;\n  height: 124px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin-bottom: 16px;\n  flex-shrink: 0;\n}\n.radar-visual-wrapper[_ngcontent-%COMP%]   .ripple-ring[_ngcontent-%COMP%] {\n  position: absolute;\n  border-radius: 50%;\n  border: 1.5px solid rgba(244, 63, 94, 0.25);\n  pointer-events: none;\n  animation: _ngcontent-%COMP%_ripple-wave 3s cubic-bezier(0.2, 0.8, 0.2, 1) infinite;\n}\n.radar-visual-wrapper[_ngcontent-%COMP%]   .ripple-ring.ring-1[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  animation-delay: 0s;\n}\n.radar-visual-wrapper[_ngcontent-%COMP%]   .ripple-ring.ring-2[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  animation-delay: 1s;\n}\n.radar-visual-wrapper[_ngcontent-%COMP%]   .ripple-ring.ring-3[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  animation-delay: 2s;\n}\n.radar-visual-wrapper.is-checking[_ngcontent-%COMP%]   .ripple-ring[_ngcontent-%COMP%] {\n  border-color: rgba(99, 102, 241, 0.35);\n  animation-duration: 1.6s;\n}\n.radar-visual-wrapper.is-checking[_ngcontent-%COMP%]   .center-icon-badge[_ngcontent-%COMP%] {\n  border-color: #c7d2fe;\n  box-shadow: 0 8px 26px rgba(99, 102, 241, 0.2);\n}\n.radar-visual-wrapper.is-connected[_ngcontent-%COMP%]   .ripple-ring[_ngcontent-%COMP%] {\n  border-color: rgba(16, 185, 129, 0.4);\n  animation: none;\n  transform: scale(1.05);\n  opacity: 0.5;\n}\n.radar-visual-wrapper.is-connected[_ngcontent-%COMP%]   .center-icon-badge[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  border-color: #a7f3d0;\n  box-shadow: 0 8px 26px rgba(16, 185, 129, 0.25);\n}\n.center-icon-badge[_ngcontent-%COMP%] {\n  position: relative;\n  z-index: 3;\n  width: 66px;\n  height: 66px;\n  border-radius: 50%;\n  background: #ffffff;\n  border: 1.5px solid #fee2e2;\n  box-shadow: 0 6px 20px rgba(244, 63, 94, 0.14);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  animation: _ngcontent-%COMP%_float-badge 3s ease-in-out infinite;\n  transition: all 0.35s cubic-bezier(0.4, 0, 0.2, 1);\n}\n.center-icon-badge[_ngcontent-%COMP%]   .status-icon[_ngcontent-%COMP%] {\n  font-size: 30px;\n}\n.center-icon-badge[_ngcontent-%COMP%]   .status-icon.icon-offline[_ngcontent-%COMP%] {\n  color: #f43f5e;\n}\n.center-icon-badge[_ngcontent-%COMP%]   .status-icon.icon-success[_ngcontent-%COMP%] {\n  color: #10b981;\n}\n.center-icon-badge[_ngcontent-%COMP%]   .status-spinner[_ngcontent-%COMP%] {\n  width: 28px;\n  height: 28px;\n  --color: #6366f1;\n  color: #6366f1;\n}\n.message-text-group[_ngcontent-%COMP%] {\n  margin-bottom: 12px;\n}\n.message-text-group[_ngcontent-%COMP%]   .headline-title[_ngcontent-%COMP%] {\n  font-size: 21px;\n  font-weight: 800;\n  color: #0f172a;\n  letter-spacing: -0.4px;\n  margin: 0 0 6px 0;\n  line-height: 1.25;\n}\n.message-text-group[_ngcontent-%COMP%]   .regional-pill[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  background: #fff1f2;\n  color: #e11d48;\n  border: 1px solid #fecdd3;\n  padding: 4px 12px;\n  border-radius: 999px;\n  font-size: 12.5px;\n  font-weight: 750;\n  margin: 2px 0 8px 0;\n  box-shadow: 0 2px 5px rgba(225, 29, 72, 0.06);\n}\n.message-text-group[_ngcontent-%COMP%]   .sub-description[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-weight: 500;\n  color: #64748b;\n  line-height: 1.45;\n  margin: 0;\n  padding: 0 12px;\n}\n.error-notice-pill[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n  background: #fef2f2;\n  border: 1px solid #fecaca;\n  color: #b91c1c;\n  padding: 6px 12px;\n  border-radius: 10px;\n  font-size: 11.5px;\n  font-weight: 600;\n  margin-bottom: 10px;\n  box-shadow: 0 2px 6px rgba(239, 68, 68, 0.06);\n}\n.error-notice-pill[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 15px;\n  flex-shrink: 0;\n}\n.troubleshoot-chips-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 7px;\n  width: 100%;\n  margin-top: 10px;\n  flex-wrap: wrap;\n}\n.troubleshoot-chips-row[_ngcontent-%COMP%]   .tip-chip[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  background: #ffffff;\n  border: 1px solid #e2e8f0;\n  border-radius: 999px;\n  padding: 6px 12px;\n  font-size: 11.5px;\n  font-weight: 650;\n  color: #475569;\n  box-shadow: 0 1px 3px rgba(15, 23, 42, 0.04);\n}\n.troubleshoot-chips-row[_ngcontent-%COMP%]   .tip-chip[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: #64748b;\n}\n.offline-footer[_ngcontent-%COMP%] {\n  position: relative;\n  z-index: 2;\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n  width: 100%;\n  max-width: 380px;\n  margin: 0 auto;\n  flex-shrink: 0;\n}\n.offline-footer[_ngcontent-%COMP%]   .btn-retry-main[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 46px;\n  border-radius: 13px;\n  border: none;\n  background: #0f172a;\n  color: #ffffff;\n  font-size: 13.5px;\n  font-weight: 700;\n  letter-spacing: 0.2px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 8px;\n  cursor: pointer;\n  box-shadow: 0 4px 12px rgba(15, 23, 42, 0.16);\n  transition: all 0.2s ease;\n}\n.offline-footer[_ngcontent-%COMP%]   .btn-retry-main[_ngcontent-%COMP%]:active {\n  transform: scale(0.985);\n  background: #1e293b;\n}\n.offline-footer[_ngcontent-%COMP%]   .btn-retry-main[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 17px;\n}\n.offline-footer[_ngcontent-%COMP%]   .btn-retry-main[_ngcontent-%COMP%]   ion-spinner[_ngcontent-%COMP%] {\n  width: 17px;\n  height: 17px;\n  --color: #ffffff;\n  color: #ffffff;\n}\n.offline-footer[_ngcontent-%COMP%]   .btn-retry-main.loading[_ngcontent-%COMP%] {\n  background: #475569;\n  cursor: wait;\n  opacity: 0.9;\n}\n.offline-footer[_ngcontent-%COMP%]   .btn-retry-main.success[_ngcontent-%COMP%] {\n  background: #10b981;\n  box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);\n}\n.offline-footer[_ngcontent-%COMP%]   .btn-retry-main[_ngcontent-%COMP%]:disabled {\n  cursor: not-allowed;\n}\n.offline-footer[_ngcontent-%COMP%]   .btn-exit-subtle[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 38px;\n  border-radius: 11px;\n  border: 1px solid #e2e8f0;\n  background: #ffffff;\n  color: #64748b;\n  font-size: 12.5px;\n  font-weight: 650;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 6px;\n  cursor: pointer;\n  transition: all 0.2s ease;\n}\n.offline-footer[_ngcontent-%COMP%]   .btn-exit-subtle[_ngcontent-%COMP%]:active {\n  background: #f8fafc;\n  color: #334155;\n  border-color: #cbd5e1;\n}\n.offline-footer[_ngcontent-%COMP%]   .btn-exit-subtle[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 15px;\n  color: #94a3b8;\n}\n@keyframes _ngcontent-%COMP%_ripple-wave {\n  0% {\n    transform: scale(0.65);\n    opacity: 0.9;\n  }\n  70% {\n    opacity: 0.25;\n  }\n  100% {\n    transform: scale(1.35);\n    opacity: 0;\n  }\n}\n@keyframes _ngcontent-%COMP%_float-badge {\n  0%, 100% {\n    transform: translateY(0);\n  }\n  50% {\n    transform: translateY(-3px);\n  }\n}\n@keyframes _ngcontent-%COMP%_pulse-dot {\n  0%, 100% {\n    transform: scale(1);\n    opacity: 1;\n  }\n  50% {\n    transform: scale(1.3);\n    opacity: 0.6;\n  }\n}\n/*# sourceMappingURL=offline.page.css.map */"] });
var OfflinePage = _OfflinePage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(OfflinePage, { className: "OfflinePage", filePath: "src/app/offline/offline.page.ts", lineNumber: 29 });
})();

export {
  Network,
  OfflinePage
};
//# sourceMappingURL=chunk-I5DZAUI5.js.map
