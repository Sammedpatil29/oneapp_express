import {
  DineoutService
} from "./chunk-POD6WOWG.js";
import {
  AuthService
} from "./chunk-EB6T6TPT.js";
import "./chunk-YJYUHAOC.js";
import {
  IonButton,
  IonButtons,
  IonContent,
  IonFooter,
  IonHeader,
  IonIcon,
  IonInput,
  IonSpinner,
  IonTitle,
  IonToolbar,
  IonicModule,
  LoadingController,
  NumericValueAccessorDirective,
  ToastController
} from "./chunk-OE5MTPUR.js";
import {
  addIcons,
  arrowBackOutline,
  arrowForwardCircleOutline,
  cashOutline,
  pricetagOutline,
  shieldCheckmarkOutline
} from "./chunk-FJYXZAS7.js";
import {
  CommonModule,
  DecimalPipe,
  FormsModule,
  NavController,
  NgControlStatus,
  NgIf,
  NgModel,
  NgZone,
  Platform,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-Z7XNNJSA.js";
import "./chunk-XR3JUECC.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/pages/dineout-paybill/dineout-paybill.page.ts
function dineoutPaybillPage_span_21_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1, "Calculate Final Bill");
    \u0275\u0275elementEnd();
  }
}
function dineoutPaybillPage_ion_spinner_22_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-spinner", 19);
  }
}
function dineoutPaybillPage_div_23_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 20)(1, "div", 21);
    \u0275\u0275text(2, "Bill Breakdown");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 22)(4, "div", 23)(5, "div", 24)(6, "span", 25);
    \u0275\u0275text(7, "Total Bill Amount");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "span", 26);
    \u0275\u0275text(9);
    \u0275\u0275pipe(10, "number");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(11, "div", 27)(12, "span", 25);
    \u0275\u0275element(13, "ion-icon", 28);
    \u0275\u0275text(14, " Dineout Discount ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "span", 29);
    \u0275\u0275text(16);
    \u0275\u0275pipe(17, "number");
    \u0275\u0275elementEnd()();
    \u0275\u0275element(18, "div", 30);
    \u0275\u0275elementStart(19, "div", 31)(20, "span", 25);
    \u0275\u0275text(21, "To Pay");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(22, "span", 29);
    \u0275\u0275text(23);
    \u0275\u0275pipe(24, "number");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(25, "div", 32);
    \u0275\u0275element(26, "ion-icon", 33);
    \u0275\u0275elementStart(27, "span");
    \u0275\u0275text(28);
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(9);
    \u0275\u0275textInterpolate1("\u20B9", \u0275\u0275pipeBind2(10, 5, ctx_r0.billData.originalAmount, "1.2-2"), "");
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate1("- \u20B9", \u0275\u0275pipeBind2(17, 8, ctx_r0.billData == null ? null : ctx_r0.billData.maxSavings, "1.2-2"), "");
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate1("\u20B9", \u0275\u0275pipeBind2(24, 11, ctx_r0.billData.finalAmount, "1.2-2"), "");
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate2("", ctx_r0.billData.bestOffer == null ? null : ctx_r0.billData.bestOffer.title, "", ctx_r0.billData.bestOffer == null ? null : ctx_r0.billData.bestOffer.description, "");
  }
}
function dineoutPaybillPage_ion_footer_25_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-footer", 34)(1, "div", 35)(2, "div", 36)(3, "small");
    \u0275\u0275text(4, "Total Payable");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "h3");
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "ion-button", 37);
    \u0275\u0275listener("click", function dineoutPaybillPage_ion_footer_25_Template_ion_button_click_7_listener() {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.processPayment());
    });
    \u0275\u0275text(8, " Pay Now ");
    \u0275\u0275element(9, "ion-icon", 38);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r0.billData.finalAmount, "");
  }
}
var _dineoutPaybillPage = class _dineoutPaybillPage {
  constructor(toastCtrl, loadingCtrl, navCtrl, dineOutService, authService, platform, zone) {
    this.toastCtrl = toastCtrl;
    this.loadingCtrl = loadingCtrl;
    this.navCtrl = navCtrl;
    this.dineOutService = dineOutService;
    this.authService = authService;
    this.platform = platform;
    this.zone = zone;
    this.enteredAmount = null;
    this.billData = null;
    this.isLoading = false;
    this.pollingInterval = null;
    this.isPaymentDetected = false;
    addIcons({ arrowBackOutline, cashOutline, pricetagOutline, arrowForwardCircleOutline, shieldCheckmarkOutline });
  }
  ngOnInit() {
    return __async(this, null, function* () {
      var _a;
      this.bookingId = history.state.bookingId;
      this.restaurantId = history.state.restaurantId;
      this.routeSource = (_a = history.state) == null ? void 0 : _a.from;
      this.token = yield this.authService.getToken();
    });
  }
  ngOnDestroy() {
    this.stopPolling();
  }
  goBack() {
    this.navCtrl.back();
  }
  calculateBill() {
    return __async(this, null, function* () {
      if (!this.enteredAmount || this.enteredAmount <= 0) {
        this.showToast("Please enter a valid bill amount", "warning");
        return;
      }
      this.isLoading = true;
      this.billData = null;
      let params = { "billAmount": this.enteredAmount };
      if (this.restaurantId)
        params["restaurantId"] = this.restaurantId;
      if (this.bookingId)
        params["bookingId"] = this.bookingId;
      this.dineOutService.calculateBill(this.token, params).subscribe({
        next: (res) => {
          if (res.success) {
            this.billData = res.data;
          } else {
            this.showToast(res.message || "Could not calculate offers", "warning");
          }
          this.isLoading = false;
        },
        error: (err) => {
          console.error("Failed to calculate bill:", err);
          this.showToast("Failed to calculate bill. Try again.", "danger");
          this.isLoading = false;
        }
      });
    });
  }
  processPayment() {
    return __async(this, null, function* () {
      var _a;
      if (!this.enteredAmount) {
        this.showToast("Please enter a valid bill amount", "warning");
        return;
      }
      const amountToPay = ((_a = this.billData) == null ? void 0 : _a.finalAmount) || this.enteredAmount;
      const loading = yield this.loadingCtrl.create({
        message: "Initiating Payment...",
        spinner: "crescent"
      });
      yield loading.present();
      const params = {
        billAmount: amountToPay,
        discount: this.enteredAmount - amountToPay,
        restaurantId: this.restaurantId,
        bookingId: this.bookingId
      };
      this.dineOutService.initiatePayment(this.token, params).subscribe({
        next: (res) => __async(this, null, function* () {
          yield loading.dismiss();
          if (res.success) {
            this.openRazorpay(res);
          } else {
            this.showToast(res.message || "Failed to initiate payment", "danger");
          }
        }),
        error: (err) => __async(this, null, function* () {
          yield loading.dismiss();
          console.error(err);
          this.showToast("Error initiating payment", "danger");
        })
      });
    });
  }
  openRazorpay(paymentData) {
    const userDetails = JSON.parse(localStorage.getItem("userDetails") || "{}");
    const options = {
      key: "rzp_test_S5RLYqr6y2I6xs",
      amount: paymentData.amount * 100,
      // Amount in paise
      currency: paymentData.currency,
      name: "Pintu Dineout",
      description: "Bill Payment",
      order_id: paymentData.razorpay_order_id,
      prefill: {
        email: userDetails.email || "",
        contact: userDetails.phone || "",
        name: userDetails.name || ""
      },
      theme: { color: "#0e4d2a" }
    };
    RazorpayCheckout.open(
      options,
      // Success Callback (Might not always fire if app killed)
      (success) => {
        console.log("Razorpay Success Callback Triggered");
        this.zone.run(() => {
          this.showToast("Processing Payment...", "secondary");
        });
      },
      // Error Callback
      (error) => {
        this.zone.run(() => {
          this.showToast("Payment Cancelled/Failed: " + error.description, "medium");
          this.stopPolling();
        });
      }
    );
    this.startPolling(paymentData.internal_order_id);
  }
  // --- POLLING LOGIC ---
  startPolling(internalOrderId) {
    console.log("Started polling for:", internalOrderId);
    this.stopPolling();
    this.pollingInterval = setInterval(() => {
      this.checkStatusFromBackend(internalOrderId);
    }, 3e3);
    setTimeout(() => {
      if (!this.isPaymentDetected && this.pollingInterval) {
        this.stopPolling();
        this.showToast("Payment verification timed out. Please check booking status.", "warning");
      }
    }, 12e4);
  }
  checkStatusFromBackend(internalOrderId) {
    this.dineOutService.verifyPayment(this.token, { orderId: internalOrderId }).subscribe({
      next: (res) => {
        if (res.success && (res.status === "paid" || res.status === "SUCCESS")) {
          this.handleSuccess(res, internalOrderId);
        } else if (res.status === "failed") {
          this.stopPolling();
          this.showToast("Payment Failed.", "danger");
        }
      },
      error: (err) => {
        console.log("Poll error", err);
      }
    });
  }
  stopPolling() {
    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
      this.pollingInterval = null;
    }
  }
  handleSuccess(res, internalOrderId) {
    if (this.isPaymentDetected)
      return;
    this.isPaymentDetected = true;
    this.stopPolling();
    this.zone.run(() => {
      this.showToast("Payment Successful! \u{1F389}", "success");
      const targetId = this.bookingId ? this.bookingId : internalOrderId;
      console.log("booking Id:", this.bookingId);
      console.log("restaurantId", internalOrderId);
      if (this.bookingId) {
        this.navCtrl.navigateRoot(`/layout/dineout-layout/dineout-track/${this.bookingId}`, {
          animated: true,
          animationDirection: "forward",
          state: { from: "paybill" }
        });
      } else {
        this.navCtrl.navigateRoot(`/layout/dineout-layout/dineout-track/${internalOrderId}`, {
          animated: true,
          animationDirection: "forward",
          state: { from: "paybill" }
        });
      }
    });
  }
  showToast(msg, color) {
    return __async(this, null, function* () {
      const toast = yield this.toastCtrl.create({
        message: msg,
        duration: 2e3,
        color,
        position: "bottom"
      });
      toast.present();
    });
  }
};
_dineoutPaybillPage.\u0275fac = function dineoutPaybillPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _dineoutPaybillPage)(\u0275\u0275directiveInject(ToastController), \u0275\u0275directiveInject(LoadingController), \u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(DineoutService), \u0275\u0275directiveInject(AuthService), \u0275\u0275directiveInject(Platform), \u0275\u0275directiveInject(NgZone));
};
_dineoutPaybillPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _dineoutPaybillPage, selectors: [["app-dineout-paybill"]], decls: 26, vars: 6, consts: [[1, "ion-no-border", "bg-white", "pt-2"], ["slot", "start"], [3, "click"], ["name", "arrow-back-outline", "color", "dark"], [1, "fw-bold", "text-dark"], [1, "bg-light"], [1, "content-wrapper"], [1, "header-section"], [1, "ticket-card", "input-section"], [1, "input-wrapper"], [1, "currency"], ["type", "number", "placeholder", "0", "inputmode", "decimal", 1, "amount-input", 3, "ngModelChange", "ngModel"], [1, "divider", "dashed"], ["expand", "block", 1, "action-btn", 3, "click", "disabled"], [4, "ngIf"], ["name", "dots", 4, "ngIf"], ["class", "animate__animated animate__fadeInUp", 4, "ngIf"], [2, "height", "100px"], ["class", "action-footer", 4, "ngIf"], ["name", "dots"], [1, "animate__animated", "animate__fadeInUp"], [1, "section-title"], [1, "ticket-card", "result-card"], [1, "details-grid-custom"], [1, "detail-row"], [1, "label"], [1, "value", "original"], [1, "detail-row", "discount"], ["name", "pricetag-outline"], [1, "value"], [1, "divider"], [1, "detail-row", "total"], [1, "offer-strip"], ["name", "shield-checkmark-outline"], [1, "action-footer"], [1, "pay-footer-content"], [1, "total-info"], [1, "pay-now-btn", 3, "click"], ["slot", "end", "name", "arrow-forward-circle-outline"]], template: function dineoutPaybillPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar")(2, "ion-buttons", 1)(3, "ion-button", 2);
    \u0275\u0275listener("click", function dineoutPaybillPage_Template_ion_button_click_3_listener() {
      return ctx.goBack();
    });
    \u0275\u0275element(4, "ion-icon", 3);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "ion-title", 4);
    \u0275\u0275text(6, "Pay Bill");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(7, "ion-content", 5)(8, "div", 6)(9, "div", 7)(10, "h2");
    \u0275\u0275text(11, "Enter Bill Amount");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "p");
    \u0275\u0275text(13, "We'll calculate your discount instantly");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(14, "div", 8)(15, "div", 9)(16, "span", 10);
    \u0275\u0275text(17, "\u20B9");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "ion-input", 11);
    \u0275\u0275twoWayListener("ngModelChange", function dineoutPaybillPage_Template_ion_input_ngModelChange_18_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.enteredAmount, $event) || (ctx.enteredAmount = $event);
      return $event;
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275element(19, "div", 12);
    \u0275\u0275elementStart(20, "ion-button", 13);
    \u0275\u0275listener("click", function dineoutPaybillPage_Template_ion_button_click_20_listener() {
      return ctx.calculateBill();
    });
    \u0275\u0275template(21, dineoutPaybillPage_span_21_Template, 2, 0, "span", 14)(22, dineoutPaybillPage_ion_spinner_22_Template, 1, 0, "ion-spinner", 15);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(23, dineoutPaybillPage_div_23_Template, 29, 14, "div", 16);
    \u0275\u0275elementEnd();
    \u0275\u0275element(24, "div", 17);
    \u0275\u0275elementEnd();
    \u0275\u0275template(25, dineoutPaybillPage_ion_footer_25_Template, 10, 1, "ion-footer", 18);
  }
  if (rf & 2) {
    \u0275\u0275advance(18);
    \u0275\u0275twoWayProperty("ngModel", ctx.enteredAmount);
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", ctx.isLoading);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", !ctx.isLoading);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", ctx.isLoading);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", ctx.billData);
    \u0275\u0275advance(2);
    \u0275\u0275property("ngIf", ctx.billData);
  }
}, dependencies: [IonicModule, IonButton, IonButtons, IonContent, IonFooter, IonHeader, IonIcon, IonInput, IonSpinner, IonTitle, IonToolbar, NumericValueAccessorDirective, CommonModule, NgIf, DecimalPipe, FormsModule, NgControlStatus, NgModel], styles: ["\n\n[_nghost-%COMP%] {\n  --bg-color: #f4f6f8;\n}\n.bg-light[_ngcontent-%COMP%] {\n  --background: var(--bg-color);\n}\n.content-wrapper[_ngcontent-%COMP%] {\n  padding: 20px;\n}\n.header-section[_ngcontent-%COMP%] {\n  margin-bottom: 20px;\n}\n.header-section[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  font-size: 22px;\n  font-weight: 800;\n  color: #111;\n  margin: 0 0 4px;\n}\n.header-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: #666;\n  margin: 0;\n}\n.section-title[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 700;\n  color: #555;\n  margin: 24px 0 10px;\n  text-transform: uppercase;\n  letter-spacing: 0.5px;\n}\n.ticket-card[_ngcontent-%COMP%] {\n  background: white;\n  border-radius: 16px;\n  padding: 20px;\n  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.06);\n  border: 1px solid #fff;\n}\n.ticket-card[_ngcontent-%COMP%]   .divider[_ngcontent-%COMP%] {\n  height: 1px;\n  background: #eee;\n  margin: 16px 0;\n}\n.ticket-card[_ngcontent-%COMP%]   .divider.dashed[_ngcontent-%COMP%] {\n  background: none;\n  border-top: 1px dashed #ddd;\n}\n.input-section[_ngcontent-%COMP%]   .input-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  background: #f8f9fa;\n  border-radius: 12px;\n  padding: 10px;\n}\n.input-section[_ngcontent-%COMP%]   .input-wrapper[_ngcontent-%COMP%]   .currency[_ngcontent-%COMP%] {\n  font-size: 28px;\n  font-weight: 700;\n  color: #333;\n  margin-right: 4px;\n}\n.input-section[_ngcontent-%COMP%]   .input-wrapper[_ngcontent-%COMP%]   .amount-input[_ngcontent-%COMP%] {\n  font-size: 32px;\n  font-weight: 800;\n  text-align: center;\n  --padding-top: 10px;\n  --padding-bottom: 10px;\n  --color: #111;\n  --placeholder-color: #ccc;\n}\n.input-section[_ngcontent-%COMP%]   .action-btn[_ngcontent-%COMP%] {\n  --background: var(--grocery-theme-color);\n  --border-radius: 10px;\n  height: 48px;\n  font-weight: 700;\n  font-size: 15px;\n  margin-top: 5px;\n}\n.result-card[_ngcontent-%COMP%] {\n  padding: 0;\n  overflow: hidden;\n}\n.result-card[_ngcontent-%COMP%]   .details-grid-custom[_ngcontent-%COMP%] {\n  padding: 20px;\n}\n.result-card[_ngcontent-%COMP%]   .details-grid-custom[_ngcontent-%COMP%]   .detail-row[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 12px;\n  font-size: 15px;\n}\n.result-card[_ngcontent-%COMP%]   .details-grid-custom[_ngcontent-%COMP%]   .detail-row[_ngcontent-%COMP%]   .label[_ngcontent-%COMP%] {\n  color: #555;\n  font-weight: 500;\n  display: flex;\n  align-items: center;\n  gap: 6px;\n}\n.result-card[_ngcontent-%COMP%]   .details-grid-custom[_ngcontent-%COMP%]   .detail-row[_ngcontent-%COMP%]   .value[_ngcontent-%COMP%] {\n  color: #111;\n  font-weight: 700;\n}\n.result-card[_ngcontent-%COMP%]   .details-grid-custom[_ngcontent-%COMP%]   .detail-row.discount[_ngcontent-%COMP%]   .label[_ngcontent-%COMP%], \n.result-card[_ngcontent-%COMP%]   .details-grid-custom[_ngcontent-%COMP%]   .detail-row.discount[_ngcontent-%COMP%]   .value[_ngcontent-%COMP%] {\n  color: var(--grocery-theme-color);\n}\n.result-card[_ngcontent-%COMP%]   .details-grid-custom[_ngcontent-%COMP%]   .detail-row.total[_ngcontent-%COMP%] {\n  margin-top: 4px;\n  margin-bottom: 0;\n}\n.result-card[_ngcontent-%COMP%]   .details-grid-custom[_ngcontent-%COMP%]   .detail-row.total[_ngcontent-%COMP%]   .label[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 700;\n  color: #111;\n}\n.result-card[_ngcontent-%COMP%]   .details-grid-custom[_ngcontent-%COMP%]   .detail-row.total[_ngcontent-%COMP%]   .value[_ngcontent-%COMP%] {\n  font-size: 22px;\n  font-weight: 800;\n  color: #111;\n}\n.result-card[_ngcontent-%COMP%]   .offer-strip[_ngcontent-%COMP%] {\n  background: var(--grocery-theme-color-light);\n  color: var(--grocery-theme-color);\n  padding: 12px;\n  font-size: 13px;\n  font-weight: 600;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 8px;\n  border-top: 1px dashed #ccebc4;\n}\n.action-footer[_ngcontent-%COMP%] {\n  background: white;\n  border-top: 1px solid #eee;\n  padding: 16px 20px 30px;\n  box-shadow: 0 -4px 15px rgba(0, 0, 0, 0.03);\n}\n.action-footer[_ngcontent-%COMP%]   .pay-footer-content[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n.action-footer[_ngcontent-%COMP%]   .pay-footer-content[_ngcontent-%COMP%]   .total-info[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n.action-footer[_ngcontent-%COMP%]   .pay-footer-content[_ngcontent-%COMP%]   .total-info[_ngcontent-%COMP%]   small[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #888;\n  text-transform: uppercase;\n  font-weight: 600;\n}\n.action-footer[_ngcontent-%COMP%]   .pay-footer-content[_ngcontent-%COMP%]   .total-info[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin: 2px 0 0;\n  font-size: 20px;\n  font-weight: 800;\n  color: #111;\n}\n.action-footer[_ngcontent-%COMP%]   .pay-footer-content[_ngcontent-%COMP%]   .pay-now-btn[_ngcontent-%COMP%] {\n  margin: 0;\n  height: 48px;\n  width: 160px;\n  --background: var(--grocery-theme-color);\n  --border-radius: 12px;\n  --box-shadow: 0 4px 12px var(--grocery-theme-color-light);\n  font-weight: 700;\n  font-size: 15px;\n}\n.animate__fadeInUp[_ngcontent-%COMP%] {\n  animation: _ngcontent-%COMP%_fadeInUp 0.5s ease-out;\n}\n@keyframes _ngcontent-%COMP%_fadeInUp {\n  from {\n    opacity: 0;\n    transform: translateY(15px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n/*# sourceMappingURL=dineout-paybill.page.css.map */"] });
var dineoutPaybillPage = _dineoutPaybillPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(dineoutPaybillPage, { className: "dineoutPaybillPage", filePath: "src/app/pages/dineout-paybill/dineout-paybill.page.ts", lineNumber: 19 });
})();
export {
  dineoutPaybillPage
};
//# sourceMappingURL=dineout-paybill.page-IUDXRKVX.js.map
