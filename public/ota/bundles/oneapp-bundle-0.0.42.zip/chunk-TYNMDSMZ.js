import{c as e}from"./chunk-OM4V5PPM.js";var t=e("Network",{web:()=>import("./chunk-F2ICOVPD.js").then(r=>new r.NetworkWeb)});export{t as a};
