import{a}from"./chunk-GJZKZXL4.js";import"./chunk-CVT7ZQ5I.js";export{a as startFocusVisible};
