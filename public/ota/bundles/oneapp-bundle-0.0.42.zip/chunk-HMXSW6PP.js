import{a as e}from"./chunk-6J7ALAHO.js";import{c as o}from"./chunk-OM4V5PPM.js";var n=o("Geolocation",{web:()=>import("./chunk-XNRDARFU.js").then(t=>new t.GeolocationWeb)});e();export{n as a};
