import{c as p}from"./chunk-OM4V5PPM.js";var o=p("App",{web:()=>import("./chunk-UCCIHDEP.js").then(e=>new e.AppWeb)});export{o as a};
