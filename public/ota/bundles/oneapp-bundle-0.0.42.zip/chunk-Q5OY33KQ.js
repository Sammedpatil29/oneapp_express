import{c as e}from"./chunk-OM4V5PPM.js";var t=e("Share",{web:()=>import("./chunk-KMHJWJOJ.js").then(r=>new r.ShareWeb)});export{t as a};
