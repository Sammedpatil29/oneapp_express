import{a as b}from"./chunk-5OMUW5VI.js";import{b as a}from"./chunk-OBXDPQ3V.js";import"./chunk-CVT7ZQ5I.js";export{a as GESTURE_CONTROLLER,b as createGesture};
