import {
  PharmacyCartService,
  PharmacyService
} from "./chunk-MLZCOJ7N.js";
import "./chunk-YJYUHAOC.js";
import "./chunk-OE5MTPUR.js";
import {
  add,
  addIcons,
  arrowBack,
  arrowForward,
  bagHandleOutline,
  checkmarkCircle,
  closeOutline,
  flaskOutline,
  medkitOutline,
  receiptOutline,
  remove,
  searchOutline,
  shieldCheckmarkOutline,
  sparklesOutline,
  timeOutline,
  trendingUpOutline,
  waterOutline
} from "./chunk-FJYXZAS7.js";
import {
  IonContent,
  IonHeader,
  IonIcon,
  IonToolbar
} from "./chunk-CJE2NDTY.js";
import {
  ActivatedRoute,
  CommonModule,
  DefaultValueAccessor,
  FormsModule,
  NavController,
  NgControlStatus,
  NgModel,
  Router,
  Subscription,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIdentity,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-Z7XNNJSA.js";
import "./chunk-XR3JUECC.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import "./chunk-6B6DTIB5.js";

// src/app/pages/pharmacy-search/pharmacy-search.page.ts
var _forTrack0 = ($index, $item) => $item.id;
function PharmacySearchPage_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 21);
    \u0275\u0275listener("click", function PharmacySearchPage_Conditional_8_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.clearSearch());
    });
    \u0275\u0275element(1, "ion-icon", 22);
    \u0275\u0275elementEnd();
  }
}
function PharmacySearchPage_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 12);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.medSummary.itemCount);
  }
}
function PharmacySearchPage_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 14);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.labSummary.itemCount);
  }
}
function PharmacySearchPage_Conditional_22_Conditional_6_For_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 29);
    \u0275\u0275listener("click", function PharmacySearchPage_Conditional_22_Conditional_6_For_1_Template_button_click_0_listener() {
      const tag_r4 = \u0275\u0275restoreView(_r3).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.applyTrendingTag(tag_r4));
    });
    \u0275\u0275element(1, "ion-icon", 30);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const tag_r4 = ctx.$implicit;
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(tag_r4);
  }
}
function PharmacySearchPage_Conditional_22_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275repeaterCreate(0, PharmacySearchPage_Conditional_22_Conditional_6_For_1_Template, 4, 1, "button", 28, \u0275\u0275repeaterTrackByIdentity);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275repeater(ctx_r1.medTrendingTags);
  }
}
function PharmacySearchPage_Conditional_22_Conditional_7_For_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 32);
    \u0275\u0275listener("click", function PharmacySearchPage_Conditional_22_Conditional_7_For_1_Template_button_click_0_listener() {
      const tag_r6 = \u0275\u0275restoreView(_r5).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.applyTrendingTag(tag_r6));
    });
    \u0275\u0275element(1, "ion-icon", 30);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const tag_r6 = ctx.$implicit;
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(tag_r6);
  }
}
function PharmacySearchPage_Conditional_22_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275repeaterCreate(0, PharmacySearchPage_Conditional_22_Conditional_7_For_1_Template, 4, 1, "button", 31, \u0275\u0275repeaterTrackByIdentity);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275repeater(ctx_r1.labTrendingTags);
  }
}
function PharmacySearchPage_Conditional_22_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 17)(1, "div", 23);
    \u0275\u0275element(2, "ion-icon", 24);
    \u0275\u0275elementStart(3, "h4");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "div", 25);
    \u0275\u0275template(6, PharmacySearchPage_Conditional_22_Conditional_6_Template, 2, 0)(7, PharmacySearchPage_Conditional_22_Conditional_7_Template, 2, 0);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "div", 26);
    \u0275\u0275element(9, "ion-icon", 27);
    \u0275\u0275elementStart(10, "div")(11, "h6");
    \u0275\u0275text(12, "Looking for something specific?");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "p");
    \u0275\u0275text(14);
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("Trending in ", ctx_r1.searchType === "medicine" ? "Medicines" : "Lab Tests", "");
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.searchType === "medicine" ? 6 : 7);
    \u0275\u0275advance(8);
    \u0275\u0275textInterpolate1(" ", ctx_r1.searchType === "medicine" ? "Type brand names like Dolo, Volini or symptoms like Headache, Cough." : "Search for packages like Full Body Checkup, CBC, or conditions like Diabetes, Thyroid.", " ");
  }
}
function PharmacySearchPage_Conditional_23_Conditional_0_For_5_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 38);
    \u0275\u0275text(1, "Rx");
    \u0275\u0275elementEnd();
  }
}
function PharmacySearchPage_Conditional_23_Conditional_0_For_5_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 41);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const med_r8 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("", med_r8.discountPercent, "% OFF");
  }
}
function PharmacySearchPage_Conditional_23_Conditional_0_For_5_Conditional_12_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 54);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const use_r9 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(use_r9);
  }
}
function PharmacySearchPage_Conditional_23_Conditional_0_For_5_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 46);
    \u0275\u0275repeaterCreate(1, PharmacySearchPage_Conditional_23_Conditional_0_For_5_Conditional_12_For_2_Template, 2, 1, "span", 54, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const med_r8 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275repeater(med_r8.uses);
  }
}
function PharmacySearchPage_Conditional_23_Conditional_0_For_5_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 50);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const med_r8 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("\u20B9", med_r8.mrp, "");
  }
}
function PharmacySearchPage_Conditional_23_Conditional_0_For_5_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 55);
    \u0275\u0275listener("click", function PharmacySearchPage_Conditional_23_Conditional_0_For_5_Conditional_19_Template_button_click_0_listener($event) {
      \u0275\u0275restoreView(_r10);
      const med_r8 = \u0275\u0275nextContext().$implicit;
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.addMedicine(med_r8, $event));
    });
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2, "ADD");
    \u0275\u0275elementEnd();
    \u0275\u0275element(3, "ion-icon", 56);
    \u0275\u0275elementEnd();
  }
}
function PharmacySearchPage_Conditional_23_Conditional_0_For_5_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 53)(1, "button", 57);
    \u0275\u0275listener("click", function PharmacySearchPage_Conditional_23_Conditional_0_For_5_Conditional_20_Template_button_click_1_listener($event) {
      \u0275\u0275restoreView(_r11);
      const med_r8 = \u0275\u0275nextContext().$implicit;
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.decrementMedicine(med_r8, $event));
    });
    \u0275\u0275element(2, "ion-icon", 58);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 59);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "button", 57);
    \u0275\u0275listener("click", function PharmacySearchPage_Conditional_23_Conditional_0_For_5_Conditional_20_Template_button_click_5_listener($event) {
      \u0275\u0275restoreView(_r11);
      const med_r8 = \u0275\u0275nextContext().$implicit;
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.incrementMedicine(med_r8, $event));
    });
    \u0275\u0275element(6, "ion-icon", 56);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const med_r8 = \u0275\u0275nextContext().$implicit;
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r1.getMedicineQty(med_r8.id));
  }
}
function PharmacySearchPage_Conditional_23_Conditional_0_For_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 37);
    \u0275\u0275listener("click", function PharmacySearchPage_Conditional_23_Conditional_0_For_5_Template_div_click_0_listener() {
      const med_r8 = \u0275\u0275restoreView(_r7).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.openMedicineDetails(med_r8.id));
    });
    \u0275\u0275template(1, PharmacySearchPage_Conditional_23_Conditional_0_For_5_Conditional_1_Template, 2, 0, "span", 38);
    \u0275\u0275elementStart(2, "div", 39);
    \u0275\u0275element(3, "img", 40);
    \u0275\u0275template(4, PharmacySearchPage_Conditional_23_Conditional_0_For_5_Conditional_4_Template, 2, 1, "span", 41);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 42)(6, "span", 43);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "h5", 44);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "span", 45);
    \u0275\u0275text(11);
    \u0275\u0275elementEnd();
    \u0275\u0275template(12, PharmacySearchPage_Conditional_23_Conditional_0_For_5_Conditional_12_Template, 3, 0, "div", 46);
    \u0275\u0275elementStart(13, "div", 47)(14, "div", 48)(15, "span", 49);
    \u0275\u0275text(16);
    \u0275\u0275elementEnd();
    \u0275\u0275template(17, PharmacySearchPage_Conditional_23_Conditional_0_For_5_Conditional_17_Template, 2, 1, "span", 50);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "div", 51);
    \u0275\u0275template(19, PharmacySearchPage_Conditional_23_Conditional_0_For_5_Conditional_19_Template, 4, 0, "button", 52)(20, PharmacySearchPage_Conditional_23_Conditional_0_For_5_Conditional_20_Template, 7, 1, "div", 53);
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const med_r8 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275conditional(med_r8.prescriptionRequired ? 1 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275property("src", med_r8.image, \u0275\u0275sanitizeUrl)("alt", med_r8.name);
    \u0275\u0275advance();
    \u0275\u0275conditional(med_r8.discountPercent > 0 ? 4 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(med_r8.brand);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(med_r8.name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", med_r8.dosageForm, " \u2022 ", med_r8.packSize, "");
    \u0275\u0275advance();
    \u0275\u0275conditional(med_r8.uses && med_r8.uses.length > 0 ? 12 : -1);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("\u20B9", med_r8.price, "");
    \u0275\u0275advance();
    \u0275\u0275conditional(med_r8.mrp > med_r8.price ? 17 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.getMedicineQty(med_r8.id) === 0 ? 19 : 20);
  }
}
function PharmacySearchPage_Conditional_23_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 34)(1, "span");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(3, "div", 35);
    \u0275\u0275repeaterCreate(4, PharmacySearchPage_Conditional_23_Conditional_0_For_5_Template, 21, 12, "div", 36, _forTrack0);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("Found ", ctx_r1.filteredMedicines.length, ' medicines for "', ctx_r1.searchQuery, '"');
    \u0275\u0275advance(2);
    \u0275\u0275repeater(ctx_r1.filteredMedicines);
  }
}
function PharmacySearchPage_Conditional_23_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 33)(1, "div", 60);
    \u0275\u0275element(2, "ion-icon", 11);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "h4");
    \u0275\u0275text(4, "No medicines found");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p");
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "button", 61);
    \u0275\u0275listener("click", function PharmacySearchPage_Conditional_23_Conditional_1_Template_button_click_7_listener() {
      \u0275\u0275restoreView(_r12);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.clearSearch());
    });
    \u0275\u0275text(8, " Clear Search ");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1(`We couldn't find any medicine matching "`, ctx_r1.searchQuery, '". Please check the spelling or try a different term.');
  }
}
function PharmacySearchPage_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275template(0, PharmacySearchPage_Conditional_23_Conditional_0_Template, 6, 2)(1, PharmacySearchPage_Conditional_23_Conditional_1_Template, 9, 1, "div", 33);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275conditional(ctx_r1.filteredMedicines.length > 0 ? 0 : 1);
  }
}
function PharmacySearchPage_Conditional_24_Conditional_0_For_5_For_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 68);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const tag_r15 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(tag_r15);
  }
}
function PharmacySearchPage_Conditional_24_Conditional_0_For_5_For_30_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 78);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const p_r16 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(p_r16);
  }
}
function PharmacySearchPage_Conditional_24_Conditional_0_For_5_Conditional_31_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 79);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const test_r14 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("+", test_r14.parameters.length - 3, " more");
  }
}
function PharmacySearchPage_Conditional_24_Conditional_0_For_5_Conditional_37_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 86);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "span", 87);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const test_r14 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("\u20B9", test_r14.mrp, "");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("", test_r14.discountPercent, "% OFF");
  }
}
function PharmacySearchPage_Conditional_24_Conditional_0_For_5_Conditional_41_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 88);
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2, "ADDED");
    \u0275\u0275elementEnd();
  }
}
function PharmacySearchPage_Conditional_24_Conditional_0_For_5_Conditional_42_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 56);
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2, "BOOK TEST");
    \u0275\u0275elementEnd();
  }
}
function PharmacySearchPage_Conditional_24_Conditional_0_For_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 65);
    \u0275\u0275listener("click", function PharmacySearchPage_Conditional_24_Conditional_0_For_5_Template_div_click_0_listener() {
      const test_r14 = \u0275\u0275restoreView(_r13).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.openLabTestDetails(test_r14.id));
    });
    \u0275\u0275elementStart(1, "div", 66)(2, "div", 67);
    \u0275\u0275repeaterCreate(3, PharmacySearchPage_Conditional_24_Conditional_0_For_5_For_4_Template, 2, 1, "span", 68, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "h4", 69);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "p", 70);
    \u0275\u0275text(8);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "div", 71)(10, "div", 72);
    \u0275\u0275element(11, "ion-icon", 13);
    \u0275\u0275elementStart(12, "span");
    \u0275\u0275text(13);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(14, "div", 72);
    \u0275\u0275element(15, "ion-icon", 73);
    \u0275\u0275elementStart(16, "span");
    \u0275\u0275text(17);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(18, "div", 72);
    \u0275\u0275element(19, "ion-icon", 74);
    \u0275\u0275elementStart(20, "span");
    \u0275\u0275text(21);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(22, "div", 72);
    \u0275\u0275element(23, "ion-icon", 75);
    \u0275\u0275elementStart(24, "span");
    \u0275\u0275text(25);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(26, "div", 76)(27, "span", 77);
    \u0275\u0275text(28, "Includes:");
    \u0275\u0275elementEnd();
    \u0275\u0275repeaterCreate(29, PharmacySearchPage_Conditional_24_Conditional_0_For_5_For_30_Template, 2, 1, "span", 78, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275template(31, PharmacySearchPage_Conditional_24_Conditional_0_For_5_Conditional_31_Template, 2, 1, "span", 79);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(32, "div", 80)(33, "div", 81)(34, "div", 82)(35, "span", 83);
    \u0275\u0275text(36);
    \u0275\u0275elementEnd();
    \u0275\u0275template(37, PharmacySearchPage_Conditional_24_Conditional_0_For_5_Conditional_37_Template, 4, 2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(38, "span", 84);
    \u0275\u0275text(39, "Free home sample collection available");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(40, "button", 85);
    \u0275\u0275listener("click", function PharmacySearchPage_Conditional_24_Conditional_0_For_5_Template_button_click_40_listener($event) {
      const test_r14 = \u0275\u0275restoreView(_r13).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.toggleLabTest(test_r14, $event));
    });
    \u0275\u0275template(41, PharmacySearchPage_Conditional_24_Conditional_0_For_5_Conditional_41_Template, 3, 0)(42, PharmacySearchPage_Conditional_24_Conditional_0_For_5_Conditional_42_Template, 3, 0);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const test_r14 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275classProp("booked", ctx_r1.isLabBooked(test_r14.id));
    \u0275\u0275advance(3);
    \u0275\u0275repeater(test_r14.tags);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(test_r14.name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(test_r14.description);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate1("", test_r14.testCount, " Tests");
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(test_r14.fastingRequirement);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("Reports in ", test_r14.reportTimeHours, " hrs");
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(test_r14.sampleType);
    \u0275\u0275advance(4);
    \u0275\u0275repeater(test_r14.parameters.slice(0, 3));
    \u0275\u0275advance(2);
    \u0275\u0275conditional(test_r14.parameters.length > 3 ? 31 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate1("\u20B9", test_r14.price, "");
    \u0275\u0275advance();
    \u0275\u0275conditional(test_r14.mrp > test_r14.price ? 37 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275classProp("booked", ctx_r1.isLabBooked(test_r14.id));
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.isLabBooked(test_r14.id) ? 41 : 42);
  }
}
function PharmacySearchPage_Conditional_24_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 62)(1, "span");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(3, "div", 63);
    \u0275\u0275repeaterCreate(4, PharmacySearchPage_Conditional_24_Conditional_0_For_5_Template, 43, 14, "div", 64, _forTrack0);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("Found ", ctx_r1.filteredLabTests.length, ' tests & packages for "', ctx_r1.searchQuery, '"');
    \u0275\u0275advance(2);
    \u0275\u0275repeater(ctx_r1.filteredLabTests);
  }
}
function PharmacySearchPage_Conditional_24_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 33)(1, "div", 89);
    \u0275\u0275element(2, "ion-icon", 13);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "h4");
    \u0275\u0275text(4, "No lab tests found");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p");
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "button", 90);
    \u0275\u0275listener("click", function PharmacySearchPage_Conditional_24_Conditional_1_Template_button_click_7_listener() {
      \u0275\u0275restoreView(_r17);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.clearSearch());
    });
    \u0275\u0275text(8, " Clear Search ");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1(`We couldn't find any test or package matching "`, ctx_r1.searchQuery, '". Try searching for CBC, Thyroid, Full Body, or Fever.');
  }
}
function PharmacySearchPage_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275template(0, PharmacySearchPage_Conditional_24_Conditional_0_Template, 6, 2)(1, PharmacySearchPage_Conditional_24_Conditional_1_Template, 9, 1, "div", 33);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275conditional(ctx_r1.filteredLabTests.length > 0 ? 0 : 1);
  }
}
function PharmacySearchPage_Conditional_26_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "aside", 91);
    \u0275\u0275listener("click", function PharmacySearchPage_Conditional_26_Template_aside_click_0_listener() {
      \u0275\u0275restoreView(_r18);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.goToCart());
    });
    \u0275\u0275elementStart(1, "div", 92)(2, "div", 93)(3, "div", 94);
    \u0275\u0275element(4, "ion-icon", 95);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 96)(6, "span", 97);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "span", 98);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(10, "div", 99)(11, "button", 100);
    \u0275\u0275listener("click", function PharmacySearchPage_Conditional_26_Template_button_click_11_listener($event) {
      \u0275\u0275restoreView(_r18);
      const ctx_r1 = \u0275\u0275nextContext();
      ctx_r1.goToCart();
      return \u0275\u0275resetView($event.stopPropagation());
    });
    \u0275\u0275elementStart(12, "span");
    \u0275\u0275text(13, "View Cart");
    \u0275\u0275elementEnd();
    \u0275\u0275element(14, "ion-icon", 101);
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate2("", ctx_r1.medSummary.itemCount, " ", ctx_r1.medSummary.itemCount === 1 ? "item" : "items", " added");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r1.medSummary.grandTotal, "");
  }
}
function PharmacySearchPage_Conditional_27_Template(rf, ctx) {
  if (rf & 1) {
    const _r19 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "aside", 102);
    \u0275\u0275listener("click", function PharmacySearchPage_Conditional_27_Template_aside_click_0_listener() {
      \u0275\u0275restoreView(_r19);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.goToCart());
    });
    \u0275\u0275elementStart(1, "div", 92)(2, "div", 93)(3, "div", 103);
    \u0275\u0275element(4, "ion-icon", 13);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 96)(6, "span", 97);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "span", 98);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(10, "div", 99)(11, "button", 104);
    \u0275\u0275listener("click", function PharmacySearchPage_Conditional_27_Template_button_click_11_listener($event) {
      \u0275\u0275restoreView(_r19);
      const ctx_r1 = \u0275\u0275nextContext();
      ctx_r1.goToCart();
      return \u0275\u0275resetView($event.stopPropagation());
    });
    \u0275\u0275elementStart(12, "span");
    \u0275\u0275text(13, "View Cart");
    \u0275\u0275elementEnd();
    \u0275\u0275element(14, "ion-icon", 101);
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate2("", ctx_r1.labSummary.itemCount, " ", ctx_r1.labSummary.itemCount === 1 ? "test" : "tests", " added");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r1.labSummary.grandTotal, "");
  }
}
var _PharmacySearchPage = class _PharmacySearchPage {
  constructor(route, router, navCtrl, cartService, pharmacyService) {
    this.route = route;
    this.router = router;
    this.navCtrl = navCtrl;
    this.cartService = cartService;
    this.pharmacyService = pharmacyService;
    this.searchType = "medicine";
    this.searchQuery = "";
    this.allMedicines = [];
    this.allLabTests = [];
    this.filteredMedicines = [];
    this.filteredLabTests = [];
    this.medTrendingTags = [
      "Dolo 650",
      "Paracetamol",
      "Cough Syrup",
      "Vitamin C",
      "Volini Spray",
      "Digene",
      "Betadine",
      "Electral ORS"
    ];
    this.labTrendingTags = [
      "Full Body Checkup",
      "CBC with ESR",
      "Thyroid Profile",
      "HbA1c Diabetes",
      "Lipid Profile",
      "Vitamin D & B12",
      "Liver Function Test",
      "Kidney Function"
    ];
    this.medSummary = { itemCount: 0, subtotal: 0, totalMrp: 0, savings: 0, fee: 0, grandTotal: 0 };
    this.labSummary = { itemCount: 0, subtotal: 0, totalMrp: 0, savings: 0, fee: 0, grandTotal: 0 };
    this.subs = new Subscription();
    addIcons({
      arrowBack,
      searchOutline,
      closeOutline,
      medkitOutline,
      flaskOutline,
      add,
      remove,
      checkmarkCircle,
      timeOutline,
      waterOutline,
      receiptOutline,
      sparklesOutline,
      bagHandleOutline,
      arrowForward,
      trendingUpOutline,
      shieldCheckmarkOutline
    });
  }
  ngOnInit() {
    this.subs.add(this.pharmacyService.getMedicines().subscribe((meds) => {
      this.allMedicines = meds;
      if (this.searchQuery.trim() && this.searchType === "medicine") {
        this.onSearchInput();
      }
    }));
    this.subs.add(this.pharmacyService.getLabTests().subscribe((tests) => {
      this.allLabTests = tests;
      if (this.searchQuery.trim() && this.searchType === "lab") {
        this.onSearchInput();
      }
    }));
    this.subs.add(this.route.queryParams.subscribe((params) => {
      if (params["type"] === "lab" || params["type"] === "lab_tests") {
        this.searchType = "lab";
      } else {
        this.searchType = "medicine";
      }
      if (params["q"]) {
        this.searchQuery = params["q"];
        this.onSearchInput();
      }
    }));
    this.subs.add(this.cartService.medicineSummary$.subscribe((sum) => {
      this.medSummary = sum;
    }));
    this.subs.add(this.cartService.labSummary$.subscribe((sum) => {
      this.labSummary = sum;
    }));
  }
  ngOnDestroy() {
    this.subs.unsubscribe();
  }
  goBack() {
    this.navCtrl.navigateBack("/layout/pharmacy");
  }
  setSearchType(type) {
    this.searchType = type;
    this.onSearchInput();
  }
  onSearchInput() {
    const q = this.searchQuery.trim().toLowerCase();
    if (!q) {
      this.filteredMedicines = [];
      this.filteredLabTests = [];
      return;
    }
    if (this.searchType === "medicine") {
      this.filteredMedicines = this.allMedicines.filter((m) => {
        const nameMatch = m.name.toLowerCase().includes(q);
        const brandMatch = m.brand.toLowerCase().includes(q);
        const categoryMatch = m.category.toLowerCase().includes(q);
        const descMatch = m.description.toLowerCase().includes(q);
        const usesMatch = m.uses ? m.uses.some((u) => u.toLowerCase().includes(q)) : false;
        return nameMatch || brandMatch || categoryMatch || descMatch || usesMatch;
      });
    } else {
      this.filteredLabTests = this.allLabTests.filter((t) => {
        const nameMatch = t.name.toLowerCase().includes(q);
        const categoryMatch = t.category.toLowerCase().includes(q);
        const descMatch = t.description.toLowerCase().includes(q);
        const tagMatch = t.tags.some((tag) => tag.toLowerCase().includes(q));
        const paramMatch = t.parameters.some((p) => p.toLowerCase().includes(q));
        return nameMatch || categoryMatch || descMatch || tagMatch || paramMatch;
      });
    }
  }
  clearSearch() {
    this.searchQuery = "";
    this.filteredMedicines = [];
    this.filteredLabTests = [];
  }
  applyTrendingTag(tag) {
    this.searchQuery = tag;
    this.onSearchInput();
  }
  // Medicine Actions
  getMedicineQty(itemId) {
    return this.cartService.getMedicineQuantity(itemId);
  }
  addMedicine(item, event) {
    if (event)
      event.stopPropagation();
    this.cartService.addMedicine(item, 1);
  }
  incrementMedicine(item, event) {
    if (event)
      event.stopPropagation();
    const qty = this.getMedicineQty(item.id);
    this.cartService.updateMedicineQuantity(item.id, qty + 1);
  }
  decrementMedicine(item, event) {
    if (event)
      event.stopPropagation();
    const qty = this.getMedicineQty(item.id);
    this.cartService.updateMedicineQuantity(item.id, qty - 1);
  }
  // Lab Actions
  isLabBooked(testId) {
    return this.cartService.isLabTestInCart(testId);
  }
  toggleLabTest(test, event) {
    if (event)
      event.stopPropagation();
    this.cartService.toggleLabTest(test);
  }
  openMedicineDetails(id) {
    this.navCtrl.navigateForward(`/layout/pharmacy/medicine/${id}`);
  }
  openLabTestDetails(id) {
    this.navCtrl.navigateForward(`/layout/pharmacy/test/${id}`);
  }
  goToCart() {
    this.router.navigate(["/layout/pharmacy/cart"], {
      queryParams: { type: this.searchType }
    });
  }
  proceedToCheckout() {
    this.router.navigate(["/layout/pharmacy/cart"], {
      queryParams: { type: this.searchType, action: "pay" }
    });
  }
};
_PharmacySearchPage.\u0275fac = function PharmacySearchPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _PharmacySearchPage)(\u0275\u0275directiveInject(ActivatedRoute), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(PharmacyCartService), \u0275\u0275directiveInject(PharmacyService));
};
_PharmacySearchPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _PharmacySearchPage, selectors: [["app-pharmacy-search"]], decls: 28, vars: 15, consts: [[1, "search-header", "ion-no-border"], [1, "search-toolbar"], [1, "search-top-row"], ["type", "button", "aria-label", "Go Back", 1, "btn-back", 3, "click"], ["name", "arrow-back"], [1, "search-box-wrap"], ["name", "search-outline", 1, "search-box-icon"], ["type", "search", "autofocus", "", 1, "search-input", 3, "ngModelChange", "placeholder", "ngModel"], ["type", "button", "aria-label", "Clear search", 1, "btn-clear"], [1, "search-scope-tabs"], ["type", "button", 1, "scope-tab-btn", 3, "click"], ["name", "medkit-outline"], [1, "scope-badge"], ["name", "flask-outline"], [1, "scope-badge", "lab"], [1, "search-content"], [1, "search-body-container"], [1, "trending-section", "animate__animated", "animate__fadeIn"], [1, "bottom-spacer"], ["slot", "fixed", 1, "docked-search-cart", "medicine", "animate__animated", "animate__fadeInUp"], ["slot", "fixed", 1, "docked-search-cart", "lab", "animate__animated", "animate__fadeInUp"], ["type", "button", "aria-label", "Clear search", 1, "btn-clear", 3, "click"], ["name", "close-outline"], [1, "trending-header"], ["name", "trending-up-outline"], [1, "trending-chips-wrap"], [1, "search-tip-card"], ["name", "sparkles-outline"], ["type", "button", 1, "trending-chip"], ["type", "button", 1, "trending-chip", 3, "click"], ["name", "search-outline"], ["type", "button", 1, "trending-chip", "lab"], ["type", "button", 1, "trending-chip", "lab", 3, "click"], [1, "no-results-state", "animate__animated", "animate__fadeIn"], [1, "results-meta-row"], [1, "medicines-results-grid"], ["role", "button", "tabindex", "0", 1, "med-search-card"], ["role", "button", "tabindex", "0", 1, "med-search-card", 3, "click"], [1, "rx-pill"], [1, "med-thumb-wrap"], ["loading", "lazy", 3, "src", "alt"], [1, "discount-badge"], [1, "med-details-col"], [1, "med-brand"], [1, "med-name"], [1, "med-pack"], [1, "med-uses-row"], [1, "med-card-footer"], [1, "med-price-col"], [1, "sell-price"], [1, "mrp-price"], [1, "med-action-col"], ["type", "button", 1, "btn-add-action"], [1, "stepper-wrap"], [1, "use-tag"], ["type", "button", 1, "btn-add-action", 3, "click"], ["name", "add"], ["type", "button", 1, "btn-step", 3, "click"], ["name", "remove"], [1, "step-num"], [1, "empty-icon-circle"], ["type", "button", 1, "btn-reset-search", 3, "click"], [1, "results-meta-row", "lab"], [1, "lab-results-list"], ["role", "button", "tabindex", "0", 1, "lab-search-card", 3, "booked"], ["role", "button", "tabindex", "0", 1, "lab-search-card", 3, "click"], [1, "test-top-row"], [1, "test-tags"], [1, "tag-badge"], [1, "test-title"], [1, "test-desc"], [1, "test-meta-grid"], [1, "meta-item"], ["name", "time-outline"], ["name", "receipt-outline"], ["name", "water-outline"], [1, "test-params-row"], [1, "params-header"], [1, "param-bullet"], [1, "param-more"], [1, "test-card-footer"], [1, "price-stack"], [1, "price-line"], [1, "final-price"], [1, "sample-note"], ["type", "button", 1, "btn-book-action", 3, "click"], [1, "strike-price"], [1, "save-chip"], ["name", "checkmark-circle"], [1, "empty-icon-circle", "lab"], ["type", "button", 1, "btn-reset-search", "lab", 3, "click"], ["slot", "fixed", 1, "docked-search-cart", "medicine", "animate__animated", "animate__fadeInUp", 3, "click"], [1, "docked-inner"], [1, "docked-left"], [1, "icon-wrap"], ["name", "bag-handle-outline"], [1, "text-wrap"], [1, "cart-items-count"], [1, "cart-total-price"], [1, "docked-actions"], ["type", "button", 1, "btn-view-cart-docked", 3, "click"], ["name", "arrow-forward"], ["slot", "fixed", 1, "docked-search-cart", "lab", "animate__animated", "animate__fadeInUp", 3, "click"], [1, "icon-wrap", "lab"], ["type", "button", 1, "btn-view-cart-docked", "lab", 3, "click"]], template: function PharmacySearchPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar", 1)(2, "div", 2)(3, "button", 3);
    \u0275\u0275listener("click", function PharmacySearchPage_Template_button_click_3_listener() {
      return ctx.goBack();
    });
    \u0275\u0275element(4, "ion-icon", 4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 5);
    \u0275\u0275element(6, "ion-icon", 6);
    \u0275\u0275elementStart(7, "input", 7);
    \u0275\u0275twoWayListener("ngModelChange", function PharmacySearchPage_Template_input_ngModelChange_7_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.searchQuery, $event) || (ctx.searchQuery = $event);
      return $event;
    });
    \u0275\u0275listener("ngModelChange", function PharmacySearchPage_Template_input_ngModelChange_7_listener() {
      return ctx.onSearchInput();
    });
    \u0275\u0275elementEnd();
    \u0275\u0275template(8, PharmacySearchPage_Conditional_8_Template, 2, 0, "button", 8);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "div", 9)(10, "button", 10);
    \u0275\u0275listener("click", function PharmacySearchPage_Template_button_click_10_listener() {
      return ctx.setSearchType("medicine");
    });
    \u0275\u0275element(11, "ion-icon", 11);
    \u0275\u0275elementStart(12, "span");
    \u0275\u0275text(13, "Medicines");
    \u0275\u0275elementEnd();
    \u0275\u0275template(14, PharmacySearchPage_Conditional_14_Template, 2, 1, "span", 12);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "button", 10);
    \u0275\u0275listener("click", function PharmacySearchPage_Template_button_click_15_listener() {
      return ctx.setSearchType("lab");
    });
    \u0275\u0275element(16, "ion-icon", 13);
    \u0275\u0275elementStart(17, "span");
    \u0275\u0275text(18, "Lab Tests");
    \u0275\u0275elementEnd();
    \u0275\u0275template(19, PharmacySearchPage_Conditional_19_Template, 2, 1, "span", 14);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(20, "ion-content", 15)(21, "main", 16);
    \u0275\u0275template(22, PharmacySearchPage_Conditional_22_Template, 15, 3, "section", 17)(23, PharmacySearchPage_Conditional_23_Template, 2, 1)(24, PharmacySearchPage_Conditional_24_Template, 2, 1);
    \u0275\u0275element(25, "div", 18);
    \u0275\u0275elementEnd();
    \u0275\u0275template(26, PharmacySearchPage_Conditional_26_Template, 15, 3, "aside", 19)(27, PharmacySearchPage_Conditional_27_Template, 15, 3, "aside", 20);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance(7);
    \u0275\u0275property("placeholder", ctx.searchType === "medicine" ? "Search medicines, cough, vitamins..." : "Search blood tests, CBC, health packages...");
    \u0275\u0275twoWayProperty("ngModel", ctx.searchQuery);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.searchQuery ? 8 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx.searchType === "medicine");
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx.medSummary.itemCount > 0 ? 14 : -1);
    \u0275\u0275advance();
    \u0275\u0275classProp("active", ctx.searchType === "lab");
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx.labSummary.itemCount > 0 ? 19 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(!ctx.searchQuery.trim() ? 22 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.searchQuery.trim() && ctx.searchType === "medicine" ? 23 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.searchQuery.trim() && ctx.searchType === "lab" ? 24 : -1);
    \u0275\u0275advance();
    \u0275\u0275classProp("has-cart", ctx.searchType === "medicine" && ctx.medSummary.itemCount > 0 || ctx.searchType === "lab" && ctx.labSummary.itemCount > 0);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.searchType === "medicine" && ctx.medSummary.itemCount > 0 ? 26 : ctx.searchType === "lab" && ctx.labSummary.itemCount > 0 ? 27 : -1);
  }
}, dependencies: [
  CommonModule,
  FormsModule,
  DefaultValueAccessor,
  NgControlStatus,
  NgModel,
  IonContent,
  IonHeader,
  IonToolbar,
  IonIcon
], styles: ['@charset "UTF-8";\n\n\n\n[_nghost-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  width: 100%;\n  height: 100%;\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  overflow: hidden;\n  --theme-medicine: #059669;\n  --theme-medicine-light: #ecfdf5;\n  --theme-lab: #0284c7;\n  --theme-lab-light: #f0f9ff;\n  --card-bg: #ffffff;\n  --text-main: #0f172a;\n  --text-sub: #64748b;\n  --border-light: #e2e8f0;\n}\n.search-content[_ngcontent-%COMP%] {\n  flex: 1;\n  width: 100%;\n  height: 100%;\n  position: relative;\n}\n.search-header[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-bottom: 1px solid var(--border-light);\n  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.03);\n  padding: 0 !important;\n  margin: 0 !important;\n  --ion-safe-area-top: 0px;\n  flex-shrink: 0;\n}\n.search-toolbar[_ngcontent-%COMP%] {\n  --background: #ffffff;\n  --padding-top: env(safe-area-inset-top, 0px);\n  --padding-bottom: 8px;\n  --padding-start: 12px;\n  --padding-end: 12px;\n}\n.search-top-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  margin-bottom: 10px;\n}\n.btn-back[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n  border-radius: 12px;\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  color: #1e293b;\n  font-size: 20px;\n  cursor: pointer;\n  flex-shrink: 0;\n  transition: all 0.2s ease;\n}\n.btn-back[_ngcontent-%COMP%]:active {\n  background: #f1f5f9;\n  transform: scale(0.95);\n}\n.search-box-wrap[_ngcontent-%COMP%] {\n  flex: 1;\n  display: flex;\n  align-items: center;\n  background: #f1f5f9;\n  border: 1.5px solid transparent;\n  border-radius: 12px;\n  padding: 0 12px;\n  height: 44px;\n  transition: all 0.2s ease;\n}\n.search-box-wrap[_ngcontent-%COMP%]:focus-within {\n  background: #ffffff;\n  border-color: #059669;\n  box-shadow: 0 0 0 3px rgba(5, 150, 105, 0.12);\n}\n.search-box-wrap[_ngcontent-%COMP%]   .search-box-icon[_ngcontent-%COMP%] {\n  font-size: 20px;\n  color: #94a3b8;\n  margin-right: 8px;\n  flex-shrink: 0;\n}\n.search-box-wrap[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%] {\n  flex: 1;\n  border: none;\n  outline: none;\n  background: transparent;\n  font-size: 14px;\n  color: #0f172a;\n  font-weight: 500;\n  width: 100%;\n}\n.search-box-wrap[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%]::placeholder {\n  color: #94a3b8;\n  font-weight: 400;\n}\n.search-box-wrap[_ngcontent-%COMP%]   .btn-clear[_ngcontent-%COMP%] {\n  background: transparent;\n  border: none;\n  color: #64748b;\n  font-size: 18px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  padding: 4px;\n  cursor: pointer;\n}\n.search-scope-tabs[_ngcontent-%COMP%] {\n  display: flex;\n  background: #f1f5f9;\n  border-radius: 10px;\n  padding: 3px;\n  gap: 4px;\n}\n.scope-tab-btn[_ngcontent-%COMP%] {\n  flex: 1;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 6px;\n  padding: 8px 12px;\n  border-radius: 8px;\n  border: none;\n  background: transparent;\n  font-size: 13px;\n  font-weight: 600;\n  color: #64748b;\n  cursor: pointer;\n  transition: all 0.2s ease;\n}\n.scope-tab-btn[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 16px;\n}\n.scope-tab-btn.active[_ngcontent-%COMP%] {\n  background: #ffffff;\n  color: #059669;\n  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.06);\n}\n.scope-tab-btn.active[_ngcontent-%COMP%]:last-child {\n  color: #0284c7;\n}\n.scope-tab-btn[_ngcontent-%COMP%]   .scope-badge[_ngcontent-%COMP%] {\n  background: #059669;\n  color: #ffffff;\n  font-size: 10px;\n  font-weight: 700;\n  padding: 1px 6px;\n  border-radius: 10px;\n}\n.scope-tab-btn[_ngcontent-%COMP%]   .scope-badge.lab[_ngcontent-%COMP%] {\n  background: #0284c7;\n}\n.search-content[_ngcontent-%COMP%] {\n  --background: #f8fafc;\n}\n.search-body-container[_ngcontent-%COMP%] {\n  padding: 16px 14px;\n}\n.trending-section[_ngcontent-%COMP%]   .trending-header[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  margin-bottom: 12px;\n}\n.trending-section[_ngcontent-%COMP%]   .trending-header[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n  color: #64748b;\n}\n.trending-section[_ngcontent-%COMP%]   .trending-header[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 14px;\n  font-weight: 700;\n  color: #334155;\n  letter-spacing: -0.2px;\n}\n.trending-section[_ngcontent-%COMP%]   .trending-chips-wrap[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px;\n  margin-bottom: 24px;\n}\n.trending-section[_ngcontent-%COMP%]   .trending-chip[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n  background: #ffffff;\n  border: 1px solid #e2e8f0;\n  padding: 7px 12px;\n  border-radius: 20px;\n  font-size: 13px;\n  font-weight: 500;\n  color: #1e293b;\n  cursor: pointer;\n  transition: all 0.2s ease;\n}\n.trending-section[_ngcontent-%COMP%]   .trending-chip[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: #059669;\n}\n.trending-section[_ngcontent-%COMP%]   .trending-chip.lab[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  color: #0284c7;\n}\n.trending-section[_ngcontent-%COMP%]   .trending-chip[_ngcontent-%COMP%]:active {\n  background: #f1f5f9;\n  transform: scale(0.96);\n}\n.trending-section[_ngcontent-%COMP%]   .search-tip-card[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 12px;\n  background: #eff6ff;\n  border: 1px dashed #bfdbfe;\n  border-radius: 12px;\n  padding: 12px 14px;\n}\n.trending-section[_ngcontent-%COMP%]   .search-tip-card[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 20px;\n  color: #2563eb;\n  flex-shrink: 0;\n  margin-top: 2px;\n}\n.trending-section[_ngcontent-%COMP%]   .search-tip-card[_ngcontent-%COMP%]   h6[_ngcontent-%COMP%] {\n  margin: 0 0 4px 0;\n  font-size: 13px;\n  font-weight: 700;\n  color: #1e40af;\n}\n.trending-section[_ngcontent-%COMP%]   .search-tip-card[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 12px;\n  line-height: 1.4;\n  color: #3b82f6;\n}\n.results-meta-row[_ngcontent-%COMP%] {\n  margin-bottom: 12px;\n  font-size: 12px;\n  font-weight: 600;\n  color: #059669;\n}\n.results-meta-row.lab[_ngcontent-%COMP%] {\n  color: #0284c7;\n}\n.medicines-results-grid[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n}\n.med-search-card[_ngcontent-%COMP%] {\n  position: relative;\n  display: flex;\n  gap: 12px;\n  background: #ffffff;\n  border-radius: 14px;\n  padding: 12px;\n  border: 1px solid #e2e8f0;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);\n  cursor: pointer;\n  transition: transform 0.15s ease;\n}\n.med-search-card[_ngcontent-%COMP%]:active {\n  transform: scale(0.985);\n}\n.med-search-card[_ngcontent-%COMP%]   .rx-pill[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 10px;\n  left: 10px;\n  z-index: 2;\n  background: #ef4444;\n  color: #ffffff;\n  font-size: 9px;\n  font-weight: 800;\n  padding: 2px 5px;\n  border-radius: 4px;\n}\n.med-search-card[_ngcontent-%COMP%]   .med-thumb-wrap[_ngcontent-%COMP%] {\n  position: relative;\n  width: 80px;\n  height: 80px;\n  border-radius: 10px;\n  overflow: hidden;\n  background: #f8fafc;\n  flex-shrink: 0;\n}\n.med-search-card[_ngcontent-%COMP%]   .med-thumb-wrap[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n.med-search-card[_ngcontent-%COMP%]   .med-thumb-wrap[_ngcontent-%COMP%]   .discount-badge[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  background: rgba(16, 185, 129, 0.9);\n  color: #ffffff;\n  font-size: 9px;\n  font-weight: 700;\n  text-align: center;\n  padding: 2px 0;\n}\n.med-search-card[_ngcontent-%COMP%]   .med-details-col[_ngcontent-%COMP%] {\n  flex: 1;\n  display: flex;\n  flex-direction: column;\n}\n.med-search-card[_ngcontent-%COMP%]   .med-brand[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 700;\n  color: #64748b;\n  text-transform: uppercase;\n  letter-spacing: 0.3px;\n}\n.med-search-card[_ngcontent-%COMP%]   .med-name[_ngcontent-%COMP%] {\n  margin: 2px 0;\n  font-size: 14px;\n  font-weight: 700;\n  color: #0f172a;\n  line-height: 1.3;\n}\n.med-search-card[_ngcontent-%COMP%]   .med-pack[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #64748b;\n  margin-bottom: 6px;\n}\n.med-search-card[_ngcontent-%COMP%]   .med-uses-row[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 4px;\n  margin-bottom: 8px;\n}\n.med-search-card[_ngcontent-%COMP%]   .med-uses-row[_ngcontent-%COMP%]   .use-tag[_ngcontent-%COMP%] {\n  background: #f1f5f9;\n  color: #475569;\n  font-size: 10px;\n  padding: 2px 6px;\n  border-radius: 4px;\n}\n.med-search-card[_ngcontent-%COMP%]   .med-card-footer[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin-top: auto;\n}\n.med-search-card[_ngcontent-%COMP%]   .med-price-col[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: baseline;\n  gap: 6px;\n}\n.med-search-card[_ngcontent-%COMP%]   .med-price-col[_ngcontent-%COMP%]   .sell-price[_ngcontent-%COMP%] {\n  font-size: 15px;\n  font-weight: 800;\n  color: #0f172a;\n}\n.med-search-card[_ngcontent-%COMP%]   .med-price-col[_ngcontent-%COMP%]   .mrp-price[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #94a3b8;\n  text-decoration: line-through;\n}\n.med-search-card[_ngcontent-%COMP%]   .btn-add-action[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  background: #ecfdf5;\n  border: 1.5px solid #10b981;\n  color: #059669;\n  padding: 6px 14px;\n  border-radius: 8px;\n  font-size: 12px;\n  font-weight: 700;\n  cursor: pointer;\n  transition: all 0.2s ease;\n}\n.med-search-card[_ngcontent-%COMP%]   .btn-add-action[_ngcontent-%COMP%]:active {\n  background: #10b981;\n  color: #ffffff;\n  transform: scale(0.95);\n}\n.med-search-card[_ngcontent-%COMP%]   .stepper-wrap[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  background: #10b981;\n  border-radius: 8px;\n  overflow: hidden;\n}\n.med-search-card[_ngcontent-%COMP%]   .stepper-wrap[_ngcontent-%COMP%]   .btn-step[_ngcontent-%COMP%] {\n  background: transparent;\n  border: none;\n  color: #ffffff;\n  width: 28px;\n  height: 28px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  cursor: pointer;\n  font-size: 14px;\n}\n.med-search-card[_ngcontent-%COMP%]   .stepper-wrap[_ngcontent-%COMP%]   .btn-step[_ngcontent-%COMP%]:active {\n  background: rgba(0, 0, 0, 0.15);\n}\n.med-search-card[_ngcontent-%COMP%]   .stepper-wrap[_ngcontent-%COMP%]   .step-num[_ngcontent-%COMP%] {\n  color: #ffffff;\n  font-size: 13px;\n  font-weight: 700;\n  padding: 0 6px;\n  min-width: 20px;\n  text-align: center;\n}\n.lab-results-list[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 14px;\n}\n.lab-search-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 14px;\n  padding: 14px;\n  border: 1.5px solid #e2e8f0;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);\n  cursor: pointer;\n  transition: all 0.2s ease;\n}\n.lab-search-card.booked[_ngcontent-%COMP%] {\n  border-color: #0284c7;\n  background: #f0f9ff;\n}\n.lab-search-card[_ngcontent-%COMP%]   .test-tags[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 6px;\n  margin-bottom: 6px;\n}\n.lab-search-card[_ngcontent-%COMP%]   .test-tags[_ngcontent-%COMP%]   .tag-badge[_ngcontent-%COMP%] {\n  background: #f0fdf4;\n  color: #15803d;\n  font-size: 10px;\n  font-weight: 700;\n  padding: 2px 6px;\n  border-radius: 4px;\n  border: 1px solid #bbf7d0;\n}\n.lab-search-card[_ngcontent-%COMP%]   .test-title[_ngcontent-%COMP%] {\n  margin: 0 0 4px 0;\n  font-size: 15px;\n  font-weight: 700;\n  color: #0f172a;\n}\n.lab-search-card[_ngcontent-%COMP%]   .test-desc[_ngcontent-%COMP%] {\n  margin: 0 0 10px 0;\n  font-size: 12px;\n  color: #64748b;\n  line-height: 1.4;\n}\n.lab-search-card[_ngcontent-%COMP%]   .test-meta-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 6px;\n  background: #f8fafc;\n  border-radius: 8px;\n  padding: 8px;\n  margin-bottom: 10px;\n}\n.lab-search-card[_ngcontent-%COMP%]   .test-meta-grid[_ngcontent-%COMP%]   .meta-item[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  font-size: 11px;\n  color: #334155;\n  font-weight: 500;\n}\n.lab-search-card[_ngcontent-%COMP%]   .test-meta-grid[_ngcontent-%COMP%]   .meta-item[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: #0284c7;\n}\n.lab-search-card[_ngcontent-%COMP%]   .test-params-row[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #475569;\n  margin-bottom: 12px;\n  line-height: 1.5;\n}\n.lab-search-card[_ngcontent-%COMP%]   .test-params-row[_ngcontent-%COMP%]   .params-header[_ngcontent-%COMP%] {\n  font-weight: 700;\n  color: #1e293b;\n  margin-right: 4px;\n}\n.lab-search-card[_ngcontent-%COMP%]   .test-params-row[_ngcontent-%COMP%]   .param-bullet[_ngcontent-%COMP%] {\n  background: #f1f5f9;\n  padding: 2px 6px;\n  border-radius: 4px;\n  margin-right: 4px;\n  display: inline-block;\n  margin-bottom: 3px;\n}\n.lab-search-card[_ngcontent-%COMP%]   .test-params-row[_ngcontent-%COMP%]   .param-more[_ngcontent-%COMP%] {\n  color: #0284c7;\n  font-weight: 600;\n}\n.lab-search-card[_ngcontent-%COMP%]   .test-card-footer[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding-top: 10px;\n  border-top: 1px dashed #e2e8f0;\n}\n.lab-search-card[_ngcontent-%COMP%]   .price-stack[_ngcontent-%COMP%]   .price-line[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: baseline;\n  gap: 6px;\n}\n.lab-search-card[_ngcontent-%COMP%]   .price-stack[_ngcontent-%COMP%]   .price-line[_ngcontent-%COMP%]   .final-price[_ngcontent-%COMP%] {\n  font-size: 17px;\n  font-weight: 800;\n  color: #0f172a;\n}\n.lab-search-card[_ngcontent-%COMP%]   .price-stack[_ngcontent-%COMP%]   .price-line[_ngcontent-%COMP%]   .strike-price[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #94a3b8;\n  text-decoration: line-through;\n}\n.lab-search-card[_ngcontent-%COMP%]   .price-stack[_ngcontent-%COMP%]   .price-line[_ngcontent-%COMP%]   .save-chip[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 700;\n  background: #fee2e2;\n  color: #b91c1c;\n  padding: 2px 6px;\n  border-radius: 4px;\n}\n.lab-search-card[_ngcontent-%COMP%]   .price-stack[_ngcontent-%COMP%]   .sample-note[_ngcontent-%COMP%] {\n  display: block;\n  font-size: 10px;\n  color: #10b981;\n  font-weight: 600;\n  margin-top: 2px;\n}\n.lab-search-card[_ngcontent-%COMP%]   .btn-book-action[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n  background: #0284c7;\n  color: #ffffff;\n  border: none;\n  padding: 8px 16px;\n  border-radius: 8px;\n  font-size: 13px;\n  font-weight: 700;\n  cursor: pointer;\n  transition: all 0.2s ease;\n}\n.lab-search-card[_ngcontent-%COMP%]   .btn-book-action.booked[_ngcontent-%COMP%] {\n  background: #10b981;\n}\n.lab-search-card[_ngcontent-%COMP%]   .btn-book-action[_ngcontent-%COMP%]:active {\n  transform: scale(0.95);\n}\n.no-results-state[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  text-align: center;\n  padding: 40px 20px;\n}\n.no-results-state[_ngcontent-%COMP%]   .empty-icon-circle[_ngcontent-%COMP%] {\n  width: 64px;\n  height: 64px;\n  border-radius: 50%;\n  background: #ecfdf5;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  color: #059669;\n  font-size: 32px;\n  margin-bottom: 16px;\n}\n.no-results-state[_ngcontent-%COMP%]   .empty-icon-circle.lab[_ngcontent-%COMP%] {\n  background: #f0f9ff;\n  color: #0284c7;\n}\n.no-results-state[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  margin: 0 0 6px 0;\n  font-size: 16px;\n  font-weight: 700;\n  color: #0f172a;\n}\n.no-results-state[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0 0 20px 0;\n  font-size: 13px;\n  color: #64748b;\n  line-height: 1.5;\n  max-width: 280px;\n}\n.no-results-state[_ngcontent-%COMP%]   .btn-reset-search[_ngcontent-%COMP%] {\n  background: #059669;\n  color: #ffffff;\n  border: none;\n  padding: 10px 20px;\n  border-radius: 8px;\n  font-size: 13px;\n  font-weight: 600;\n  cursor: pointer;\n}\n.no-results-state[_ngcontent-%COMP%]   .btn-reset-search.lab[_ngcontent-%COMP%] {\n  background: #0284c7;\n}\n.bottom-spacer[_ngcontent-%COMP%] {\n  height: 20px;\n}\n.bottom-spacer.has-cart[_ngcontent-%COMP%] {\n  height: 90px;\n}\n.docked-search-cart[_ngcontent-%COMP%] {\n  bottom: 16px;\n  left: 14px;\n  right: 14px;\n  z-index: 99;\n}\n.docked-search-cart[_ngcontent-%COMP%]   .docked-inner[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  background: #059669;\n  color: #ffffff;\n  border-radius: 14px;\n  padding: 12px 16px;\n  box-shadow: 0 8px 24px rgba(5, 150, 105, 0.35);\n}\n.docked-search-cart.lab[_ngcontent-%COMP%]   .docked-inner[_ngcontent-%COMP%] {\n  background: #0284c7;\n  box-shadow: 0 8px 24px rgba(2, 132, 199, 0.35);\n}\n.docked-search-cart[_ngcontent-%COMP%]   .docked-left[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n}\n.docked-search-cart[_ngcontent-%COMP%]   .docked-left[_ngcontent-%COMP%]   .icon-wrap[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 38px;\n  border-radius: 10px;\n  background: rgba(255, 255, 255, 0.2);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 20px;\n}\n.docked-search-cart[_ngcontent-%COMP%]   .docked-left[_ngcontent-%COMP%]   .text-wrap[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n.docked-search-cart[_ngcontent-%COMP%]   .docked-left[_ngcontent-%COMP%]   .text-wrap[_ngcontent-%COMP%]   .cart-items-count[_ngcontent-%COMP%] {\n  font-size: 12px;\n  opacity: 0.9;\n  font-weight: 500;\n}\n.docked-search-cart[_ngcontent-%COMP%]   .docked-left[_ngcontent-%COMP%]   .text-wrap[_ngcontent-%COMP%]   .cart-total-price[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 800;\n}\n.docked-search-cart[_ngcontent-%COMP%]   .docked-actions[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  flex-shrink: 0;\n}\n.docked-search-cart[_ngcontent-%COMP%]   .docked-actions[_ngcontent-%COMP%]   .btn-view-cart-docked[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 5px;\n  background: #ffffff;\n  color: #059669;\n  border: none;\n  padding: 8px 16px;\n  border-radius: 99px;\n  font-size: 12.5px;\n  font-weight: 850;\n  cursor: pointer;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.12);\n  transition: all 0.15s ease;\n}\n.docked-search-cart[_ngcontent-%COMP%]   .docked-actions[_ngcontent-%COMP%]   .btn-view-cart-docked.lab[_ngcontent-%COMP%] {\n  color: #0284c7;\n}\n.docked-search-cart[_ngcontent-%COMP%]   .docked-actions[_ngcontent-%COMP%]   .btn-view-cart-docked[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n}\n.docked-search-cart[_ngcontent-%COMP%]   .docked-actions[_ngcontent-%COMP%]   .btn-view-cart-docked[_ngcontent-%COMP%]:active {\n  transform: scale(0.95);\n}\n/*# sourceMappingURL=pharmacy-search.page.css.map */'] });
var PharmacySearchPage = _PharmacySearchPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(PharmacySearchPage, { className: "PharmacySearchPage", filePath: "src/app/pages/pharmacy-search/pharmacy-search.page.ts", lineNumber: 56 });
})();
export {
  PharmacySearchPage
};
//# sourceMappingURL=pharmacy-search.page-JRLIT4FC.js.map
