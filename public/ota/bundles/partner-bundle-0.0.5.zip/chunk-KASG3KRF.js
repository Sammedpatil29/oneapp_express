var t={production:!0,apiUrl:"https://pintu-api.democompany.in.net",socketUrl:"https://pintu-api.democompany.in.net"};export{t as a};
