import {
  App
} from "./chunk-EBMCUG2R.js";
import {
  BehaviorSubject,
  ɵɵdefineInjectable
} from "./chunk-Z7XNNJSA.js";
import {
  Capacitor,
  registerPlugin
} from "./chunk-FH4NU4VH.js";
import {
  __async,
  __spreadProps,
  __spreadValues
} from "./chunk-6B6DTIB5.js";

// node_modules/@capawesome/capacitor-app-update/dist/esm/definitions.js
var AppUpdateAvailability;
(function(AppUpdateAvailability2) {
  AppUpdateAvailability2[AppUpdateAvailability2["UNKNOWN"] = 0] = "UNKNOWN";
  AppUpdateAvailability2[AppUpdateAvailability2["UPDATE_NOT_AVAILABLE"] = 1] = "UPDATE_NOT_AVAILABLE";
  AppUpdateAvailability2[AppUpdateAvailability2["UPDATE_AVAILABLE"] = 2] = "UPDATE_AVAILABLE";
  AppUpdateAvailability2[AppUpdateAvailability2["UPDATE_IN_PROGRESS"] = 3] = "UPDATE_IN_PROGRESS";
})(AppUpdateAvailability || (AppUpdateAvailability = {}));
var FlexibleUpdateInstallStatus;
(function(FlexibleUpdateInstallStatus2) {
  FlexibleUpdateInstallStatus2[FlexibleUpdateInstallStatus2["UNKNOWN"] = 0] = "UNKNOWN";
  FlexibleUpdateInstallStatus2[FlexibleUpdateInstallStatus2["PENDING"] = 1] = "PENDING";
  FlexibleUpdateInstallStatus2[FlexibleUpdateInstallStatus2["DOWNLOADING"] = 2] = "DOWNLOADING";
  FlexibleUpdateInstallStatus2[FlexibleUpdateInstallStatus2["INSTALLING"] = 3] = "INSTALLING";
  FlexibleUpdateInstallStatus2[FlexibleUpdateInstallStatus2["INSTALLED"] = 4] = "INSTALLED";
  FlexibleUpdateInstallStatus2[FlexibleUpdateInstallStatus2["FAILED"] = 5] = "FAILED";
  FlexibleUpdateInstallStatus2[FlexibleUpdateInstallStatus2["CANCELED"] = 6] = "CANCELED";
  FlexibleUpdateInstallStatus2[FlexibleUpdateInstallStatus2["DOWNLOADED"] = 11] = "DOWNLOADED";
})(FlexibleUpdateInstallStatus || (FlexibleUpdateInstallStatus = {}));
var AppUpdateResultCode;
(function(AppUpdateResultCode2) {
  AppUpdateResultCode2[AppUpdateResultCode2["OK"] = 0] = "OK";
  AppUpdateResultCode2[AppUpdateResultCode2["CANCELED"] = 1] = "CANCELED";
  AppUpdateResultCode2[AppUpdateResultCode2["FAILED"] = 2] = "FAILED";
  AppUpdateResultCode2[AppUpdateResultCode2["NOT_AVAILABLE"] = 3] = "NOT_AVAILABLE";
  AppUpdateResultCode2[AppUpdateResultCode2["NOT_ALLOWED"] = 4] = "NOT_ALLOWED";
  AppUpdateResultCode2[AppUpdateResultCode2["INFO_MISSING"] = 5] = "INFO_MISSING";
})(AppUpdateResultCode || (AppUpdateResultCode = {}));

// node_modules/@capawesome/capacitor-app-update/dist/esm/index.js
var AppUpdate = registerPlugin("AppUpdate", {
  web: () => import("./web-7LJGKTH6.js").then((m) => new m.AppUpdateWeb())
});

// src/app/services/play-store-update.service.ts
var PLAY_STORE_PACKAGE_NAME = "io.ionic.oneapp";
var PLAY_STORE_URL = "https://play.google.com/store/apps/details?id=io.ionic.oneapp";
var PLAY_STORE_MARKET_URI = "market://details?id=io.ionic.oneapp";
var _PlayStoreUpdateService = class _PlayStoreUpdateService {
  get isMandatoryUpdateRequired() {
    return this._state.value.isMandatoryUpdateRequired;
  }
  constructor() {
    this._state = new BehaviorSubject({
      isChecking: false,
      isMandatoryUpdateRequired: false,
      availableVersionName: "",
      currentVersionName: "",
      updateInfo: null
    });
    this.state$ = this._state.asObservable();
  }
  /**
   * Initializes update check on app launch & sets up resume listener
   */
  initialize() {
    return __async(this, null, function* () {
      yield this.checkForPlayStoreUpdate();
      try {
        App.addListener("appStateChange", (state) => __async(this, null, function* () {
          if (state.isActive) {
            console.log("\u{1F504} [PlayStoreUpdate] App resumed, re-verifying update status...");
            yield this.checkForPlayStoreUpdate();
          }
        }));
      } catch (err) {
        console.warn("\u26A0\uFE0F [PlayStoreUpdate] Could not bind appStateChange listener:", err);
      }
    });
  }
  /**
   * Checks for Google Play Store updates using the official Google Play In-App Updates API.
   */
  checkForPlayStoreUpdate() {
    return __async(this, null, function* () {
      if (!Capacitor.isNativePlatform()) {
        console.log("\u2139\uFE0F [PlayStoreUpdate] Not on native Android, skipping Play Store update check.");
        return false;
      }
      this._state.next(__spreadProps(__spreadValues({}, this._state.value), {
        isChecking: true
      }));
      try {
        console.log("\u{1F50D} [PlayStoreUpdate] Checking Google Play Store update info...");
        const info = yield AppUpdate.getAppUpdateInfo();
        console.log("\u{1F4E6} [PlayStoreUpdate] Update info received:", JSON.stringify(info));
        const isUpdateAvailable = info.updateAvailability === AppUpdateAvailability.UPDATE_AVAILABLE || info.updateAvailability === AppUpdateAvailability.UPDATE_IN_PROGRESS;
        if (isUpdateAvailable) {
          console.log(`\u{1F680} [PlayStoreUpdate] New version available on Google Play! Current: ${info.currentVersionName}, Available: ${info.availableVersionName}`);
          if (info.immediateUpdateAllowed || Capacitor.getPlatform() === "android") {
            try {
              console.log("\u{1F4F2} [PlayStoreUpdate] Triggering performImmediateUpdate() via Google Play UI...");
              const result = yield AppUpdate.performImmediateUpdate();
              console.log("\u{1F4F2} [PlayStoreUpdate] performImmediateUpdate result:", JSON.stringify(result));
            } catch (updateErr) {
              console.warn("\u26A0\uFE0F [PlayStoreUpdate] performImmediateUpdate failed or cancelled, activating mandatory dialog:", updateErr);
            }
          }
          this._state.next({
            isChecking: false,
            isMandatoryUpdateRequired: true,
            availableVersionName: info.availableVersionName || "Latest",
            currentVersionName: info.currentVersionName || "",
            updateInfo: info
          });
          return true;
        } else {
          console.log("\u2705 [PlayStoreUpdate] App is up to date on Google Play Store.");
          this._state.next({
            isChecking: false,
            isMandatoryUpdateRequired: false,
            availableVersionName: info.availableVersionName,
            currentVersionName: info.currentVersionName,
            updateInfo: info
          });
          return false;
        }
      } catch (err) {
        console.warn("\u274C [PlayStoreUpdate] Error checking Play Store updates:", err);
        this._state.next(__spreadProps(__spreadValues({}, this._state.value), {
          isChecking: false
        }));
        return false;
      }
    });
  }
  /**
   * Opens Google Play Store directly to the app's listing page.
   */
  redirectToPlayStore() {
    return __async(this, null, function* () {
      try {
        yield AppUpdate.openAppStore({
          androidPackageName: PLAY_STORE_PACKAGE_NAME
        });
      } catch (err) {
        console.warn("\u26A0\uFE0F [PlayStoreUpdate] openAppStore failed, opening market / web link directly:", err);
        try {
          window.open(PLAY_STORE_MARKET_URI, "_system");
        } catch (marketErr) {
          window.open(PLAY_STORE_URL, "_system");
        }
      }
    });
  }
};
_PlayStoreUpdateService.\u0275fac = function PlayStoreUpdateService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _PlayStoreUpdateService)();
};
_PlayStoreUpdateService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _PlayStoreUpdateService, factory: _PlayStoreUpdateService.\u0275fac, providedIn: "root" });
var PlayStoreUpdateService = _PlayStoreUpdateService;

export {
  PlayStoreUpdateService
};
//# sourceMappingURL=chunk-7T6YL63B.js.map
