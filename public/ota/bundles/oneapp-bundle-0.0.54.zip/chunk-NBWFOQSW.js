import {
  addIcons,
  alertCircleOutline,
  refreshOutline
} from "./chunk-FJYXZAS7.js";
import {
  IonButton,
  IonIcon,
  IonicModule
} from "./chunk-OE5MTPUR.js";
import {
  CommonModule,
  EventEmitter,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵlistener,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1
} from "./chunk-Z7XNNJSA.js";

// src/app/components/error/error.component.ts
var _ErrorComponent = class _ErrorComponent {
  constructor() {
    this.title = "Something went wrong";
    this.subtitle = "We couldn't fetch the data. Please try again.";
    this.buttonText = "Retry";
    this.reload = new EventEmitter();
    addIcons({ refreshOutline, alertCircleOutline });
  }
  onRetry() {
    this.reload.emit();
  }
};
_ErrorComponent.\u0275fac = function ErrorComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _ErrorComponent)();
};
_ErrorComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _ErrorComponent, selectors: [["app-error"]], inputs: { title: "title", subtitle: "subtitle", buttonText: "buttonText" }, outputs: { reload: "reload" }, decls: 10, vars: 3, consts: [[1, "error-container"], [1, "icon-circle"], ["name", "alert-circle-outline"], ["mode", "ios", "fill", "outline", 1, "book-btn", 3, "click"], ["name", "refresh-outline", "slot", "start"]], template: function ErrorComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 0)(1, "div", 1);
    \u0275\u0275element(2, "ion-icon", 2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "h3");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p");
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "ion-button", 3);
    \u0275\u0275listener("click", function ErrorComponent_Template_ion_button_click_7_listener() {
      return ctx.onRetry();
    });
    \u0275\u0275element(8, "ion-icon", 4);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx.title);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx.subtitle);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" ", ctx.buttonText, " ");
  }
}, dependencies: [CommonModule, IonicModule, IonButton, IonIcon], styles: ["\n\n.error-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  height: 100%;\n  padding: 40px 20px;\n  text-align: center;\n  background-color: transparent;\n}\n.error-container[_ngcontent-%COMP%]   .icon-circle[_ngcontent-%COMP%] {\n  width: 80px;\n  height: 80px;\n  background-color: #fdecea;\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin-bottom: 20px;\n}\n.error-container[_ngcontent-%COMP%]   .icon-circle[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 40px;\n  color: #eb445a;\n}\n.error-container[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin: 0 0 8px;\n  font-size: 18px;\n  font-weight: 700;\n  color: #333;\n}\n.error-container[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0 0 25px;\n  font-size: 14px;\n  color: #666;\n  max-width: 250px;\n  line-height: 1.5;\n}\n.error-container[_ngcontent-%COMP%]   ion-button[_ngcontent-%COMP%] {\n  --border-radius: 8px;\n  --border-width: 1px;\n  font-weight: 600;\n  min-width: 140px;\n}\n/*# sourceMappingURL=error.component.css.map */"] });
var ErrorComponent = _ErrorComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(ErrorComponent, { className: "ErrorComponent", filePath: "src/app/components/error/error.component.ts", lineNumber: 14 });
})();

export {
  ErrorComponent
};
//# sourceMappingURL=chunk-NBWFOQSW.js.map
