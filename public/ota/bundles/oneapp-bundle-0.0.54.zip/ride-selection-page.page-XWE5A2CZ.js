import {
  RideSelectionComponent
} from "./chunk-FMXOWUSF.js";
import "./chunk-EB6T6TPT.js";
import "./chunk-YJYUHAOC.js";
import "./chunk-OE5MTPUR.js";
import {
  IonContent
} from "./chunk-CJE2NDTY.js";
import {
  CommonModule,
  FormsModule,
  Router,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵproperty
} from "./chunk-Z7XNNJSA.js";
import "./chunk-XR3JUECC.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import "./chunk-6B6DTIB5.js";

// src/app/pages/ride-selection-page/ride-selection-page.page.ts
var _RideSelectionPagePage = class _RideSelectionPagePage {
  constructor(router) {
    var _a, _b;
    this.router = router;
    const nav = this.router.getCurrentNavigation();
    this.tripData = ((_b = (_a = nav == null ? void 0 : nav.extras) == null ? void 0 : _a.state) == null ? void 0 : _b["data"]) || null;
    console.log("Received trip data:", this.tripData);
  }
  ngOnInit() {
  }
};
_RideSelectionPagePage.\u0275fac = function RideSelectionPagePage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _RideSelectionPagePage)(\u0275\u0275directiveInject(Router));
};
_RideSelectionPagePage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _RideSelectionPagePage, selectors: [["app-ride-selection-page"]], decls: 2, vars: 2, consts: [[3, "fullscreen"], [3, "tripData"]], template: function RideSelectionPagePage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 0);
    \u0275\u0275element(1, "app-ride-selection", 1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance();
    \u0275\u0275property("tripData", ctx.tripData);
  }
}, dependencies: [IonContent, CommonModule, FormsModule, RideSelectionComponent], encapsulation: 2 });
var RideSelectionPagePage = _RideSelectionPagePage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(RideSelectionPagePage, { className: "RideSelectionPagePage", filePath: "src/app/pages/ride-selection-page/ride-selection-page.page.ts", lineNumber: 15 });
})();
export {
  RideSelectionPagePage
};
//# sourceMappingURL=ride-selection-page.page-XWE5A2CZ.js.map
