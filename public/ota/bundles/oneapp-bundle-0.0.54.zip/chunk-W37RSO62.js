import {
  ToastController
} from "./chunk-CJE2NDTY.js";
import {
  BehaviorSubject,
  ɵɵdefineInjectable,
  ɵɵinject
} from "./chunk-Z7XNNJSA.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/services/app-dialog.service.ts
var CLOSED_STATE = {
  isOpen: false,
  type: "info",
  title: "",
  message: "",
  confirmText: "OK",
  cancelText: "Cancel",
  showCancel: false
};
var _AppDialogService = class _AppDialogService {
  get isAlertOpen() {
    return this._state.value.isOpen;
  }
  constructor(toastCtrl) {
    this.toastCtrl = toastCtrl;
    this._state = new BehaviorSubject(CLOSED_STATE);
    this.state$ = this._state.asObservable();
  }
  // ─── Simple Alert (one button, centred) ───────────────────────────────────
  showAlert(title, message, type = "info", confirmText = "OK") {
    return new Promise((resolve) => {
      this._state.next({
        isOpen: true,
        type,
        title,
        message,
        confirmText,
        cancelText: "Cancel",
        showCancel: false,
        onConfirm: () => resolve(),
        onCancel: () => resolve()
      });
    });
  }
  // ─── Confirm Dialog (two buttons side-by-side) ───────────────────────────
  showConfirm(options) {
    return new Promise((resolve) => {
      this._state.next({
        isOpen: true,
        type: "confirm",
        title: options.title,
        message: options.message,
        confirmText: options.confirmText || "Yes",
        cancelText: options.cancelText || "No",
        showCancel: true,
        onConfirm: () => resolve(true),
        onCancel: () => resolve(false)
      });
    });
  }
  // ─── Danger Confirm (destructive — e.g. logout, delete) ──────────────────
  showDangerConfirm(options) {
    return new Promise((resolve) => {
      this._state.next({
        isOpen: true,
        type: "warning",
        title: options.title,
        message: options.message,
        confirmText: options.confirmText || "Yes, Proceed",
        cancelText: options.cancelText || "Cancel",
        showCancel: true,
        onConfirm: () => resolve(true),
        onCancel: () => resolve(false)
      });
    });
  }
  // ─── Called by layout when the modal resolves ─────────────────────────────
  handleConfirm() {
    var _a;
    const s = this._state.value;
    this._state.next(CLOSED_STATE);
    (_a = s.onConfirm) == null ? void 0 : _a.call(s);
  }
  handleCancel() {
    var _a;
    const s = this._state.value;
    this._state.next(CLOSED_STATE);
    (_a = s.onCancel) == null ? void 0 : _a.call(s);
  }
  // ─── Quick Toast fallback ────────────────────────────────────────────────
  showToast(message, color = "dark", duration = 2500) {
    return __async(this, null, function* () {
      const t = yield this.toastCtrl.create({
        message,
        duration,
        color,
        position: "bottom",
        cssClass: "custom-app-toast"
      });
      yield t.present();
    });
  }
};
_AppDialogService.\u0275fac = function AppDialogService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _AppDialogService)(\u0275\u0275inject(ToastController));
};
_AppDialogService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _AppDialogService, factory: _AppDialogService.\u0275fac, providedIn: "root" });
var AppDialogService = _AppDialogService;

export {
  AppDialogService
};
//# sourceMappingURL=chunk-W37RSO62.js.map
