import {
  GroceryService
} from "./chunk-UOJDERHI.js";
import {
  add,
  addIcons,
  arrowBack,
  arrowBackOutline,
  caretForwardOutline,
  closeCircleOutline,
  remove,
  timeOutline,
  trendingUpOutline
} from "./chunk-FJYXZAS7.js";
import {
  AuthService
} from "./chunk-EB6T6TPT.js";
import "./chunk-YJYUHAOC.js";
import "./chunk-OE5MTPUR.js";
import {
  IonContent,
  IonHeader,
  IonIcon,
  IonSearchbar,
  IonSkeletonText,
  IonToolbar
} from "./chunk-CJE2NDTY.js";
import {
  ChangeDetectorRef,
  CommonModule,
  FormsModule,
  NavController,
  NgForOf,
  NgIf,
  Router,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2
} from "./chunk-Z7XNNJSA.js";
import "./chunk-XR3JUECC.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/pages/grocery-search/grocery-search.page.ts
var _c0 = () => [1, 2, 3, 4, 5, 6, 7, 8];
function GrocerySearchPage_div_7_div_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 13)(1, "div", 14);
    \u0275\u0275element(2, "ion-skeleton-text", 15);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 16);
    \u0275\u0275element(4, "ion-skeleton-text", 17)(5, "ion-skeleton-text", 18);
    \u0275\u0275elementStart(6, "div", 19);
    \u0275\u0275element(7, "ion-skeleton-text", 20);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "div", 21);
    \u0275\u0275element(9, "ion-skeleton-text", 22);
    \u0275\u0275elementEnd()();
  }
}
function GrocerySearchPage_div_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 10)(1, "div", 11);
    \u0275\u0275template(2, GrocerySearchPage_div_7_div_2_Template, 10, 0, "div", 12);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(2);
    \u0275\u0275property("ngForOf", \u0275\u0275pureFunction0(1, _c0));
  }
}
function GrocerySearchPage_div_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div")(1, "div", 23)(2, "p");
    \u0275\u0275text(3, "Try searching for 'Anything'");
    \u0275\u0275elementEnd()()();
  }
}
function GrocerySearchPage_div_9_div_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 27);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate2(" Found ", ctx_r0.results.length, ' results for "', ctx_r0.query, '" ');
  }
}
function GrocerySearchPage_div_9_div_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 28);
    \u0275\u0275element(1, "img", 29);
    \u0275\u0275elementStart(2, "h3");
    \u0275\u0275text(3, "No items found");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "p");
    \u0275\u0275text(5, "Try searching for 'Milk' or 'Bread'");
    \u0275\u0275elementEnd()();
  }
}
function GrocerySearchPage_div_9_div_4_div_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 40);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const p_r2 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("", p_r2.discount, "% OFF");
  }
}
function GrocerySearchPage_div_9_div_4_span_12_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 41);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const p_r2 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("\u20B9", p_r2.oldPrice, "");
  }
}
function GrocerySearchPage_div_9_div_4_button_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "button", 42);
    \u0275\u0275text(1, " OUT OF STOCK ");
    \u0275\u0275elementEnd();
  }
}
function GrocerySearchPage_div_9_div_4_button_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 43);
    \u0275\u0275listener("click", function GrocerySearchPage_div_9_div_4_button_15_Template_button_click_0_listener($event) {
      \u0275\u0275restoreView(_r3);
      const p_r2 = \u0275\u0275nextContext().$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      $event.stopPropagation();
      return \u0275\u0275resetView(ctx_r0.increase(p_r2.id));
    });
    \u0275\u0275text(1, " ADD ");
    \u0275\u0275elementEnd();
  }
}
function GrocerySearchPage_div_9_div_4_div_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 44)(1, "div", 45);
    \u0275\u0275listener("click", function GrocerySearchPage_div_9_div_4_div_16_Template_div_click_1_listener($event) {
      \u0275\u0275restoreView(_r4);
      const p_r2 = \u0275\u0275nextContext().$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      $event.stopPropagation();
      return \u0275\u0275resetView(ctx_r0.decrease(p_r2.id));
    });
    \u0275\u0275text(2, "-");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 46);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 47);
    \u0275\u0275listener("click", function GrocerySearchPage_div_9_div_4_div_16_Template_div_click_5_listener($event) {
      \u0275\u0275restoreView(_r4);
      const p_r2 = \u0275\u0275nextContext().$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      $event.stopPropagation();
      return \u0275\u0275resetView(ctx_r0.increase(p_r2.id));
    });
    \u0275\u0275text(6, "+");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const p_r2 = \u0275\u0275nextContext().$implicit;
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r0.getQty(p_r2.id));
  }
}
function GrocerySearchPage_div_9_div_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 13)(1, "div", 30);
    \u0275\u0275element(2, "img", 31);
    \u0275\u0275template(3, GrocerySearchPage_div_9_div_4_div_3_Template, 2, 1, "div", 32);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "div", 33)(5, "h6");
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "small");
    \u0275\u0275text(8);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "div", 34)(10, "span", 35);
    \u0275\u0275text(11);
    \u0275\u0275elementEnd();
    \u0275\u0275template(12, GrocerySearchPage_div_9_div_4_span_12_Template, 2, 1, "span", 36);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(13, "div", 21);
    \u0275\u0275template(14, GrocerySearchPage_div_9_div_4_button_14_Template, 2, 0, "button", 37)(15, GrocerySearchPage_div_9_div_4_button_15_Template, 2, 0, "button", 38)(16, GrocerySearchPage_div_9_div_4_div_16_Template, 7, 1, "div", 39);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const p_r2 = ctx.$implicit;
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(2);
    \u0275\u0275property("src", p_r2.img, \u0275\u0275sanitizeUrl);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", p_r2.discount > 0);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(p_r2.name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(p_r2.weight);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("\u20B9", p_r2.price, "");
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", p_r2.discount > 0);
    \u0275\u0275advance(2);
    \u0275\u0275property("ngIf", p_r2.stock === 0);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", p_r2.stock !== 0 && ctx_r0.getQty(p_r2.id) === 0);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", p_r2.stock !== 0 && ctx_r0.getQty(p_r2.id) > 0);
  }
}
function GrocerySearchPage_div_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 24);
    \u0275\u0275template(1, GrocerySearchPage_div_9_div_1_Template, 2, 2, "div", 25)(2, GrocerySearchPage_div_9_div_2_Template, 6, 0, "div", 26);
    \u0275\u0275elementStart(3, "div", 11);
    \u0275\u0275template(4, GrocerySearchPage_div_9_div_4_Template, 17, 9, "div", 12);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", ctx_r0.results.length > 0);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", ctx_r0.results.length === 0);
    \u0275\u0275advance(2);
    \u0275\u0275property("ngForOf", ctx_r0.results);
  }
}
var _GrocerySearchPage = class _GrocerySearchPage {
  constructor(navCtrl, groceryService, authService, cdr, router) {
    this.navCtrl = navCtrl;
    this.groceryService = groceryService;
    this.authService = authService;
    this.cdr = cdr;
    this.router = router;
    this.query = "";
    this.cartItems = [];
    this.isLoading = false;
    this.recentSearches = ["Milk", "Bread", "Eggs", "Chips"];
    this.trending = [
      { name: "Summer Drinks", img: "https://cdn-icons-png.flaticon.com/512/2405/2405479.png" },
      { name: "Mangoes", img: "https://cdn-icons-png.flaticon.com/512/1625/1625048.png" },
      { name: "Ice Cream", img: "https://cdn-icons-png.flaticon.com/512/1046/1046771.png" },
      { name: "Sunscreen", img: "https://cdn-icons-png.flaticon.com/512/2855/2855353.png" }
    ];
    this.allProducts = [];
    this.results = [];
    addIcons({ arrowBack, arrowBackOutline, timeOutline, closeCircleOutline, caretForwardOutline, trendingUpOutline, add, remove });
  }
  ngOnInit() {
    return __async(this, null, function* () {
      this.token = yield this.authService.getToken();
      this.groceryService.cart$.subscribe((items) => {
        this.cartItems = items;
        this.cdr.detectChanges();
      });
    });
  }
  // Search Logic
  onSearchChange(event) {
    const val = event.target.value;
    this.query = val;
    if (val && val.trim().length >= 3) {
      this.isLoading = true;
      this.groceryService.searchProducts(this.query).subscribe((res) => {
        this.results = res.data.products;
        this.isLoading = false;
        this.cdr.detectChanges();
      });
    } else {
      this.results = [];
      this.isLoading = false;
    }
  }
  // Clear History
  clearHistory() {
    this.recentSearches = [];
  }
  increase(productId) {
    this.groceryService.increaseQty(productId, this.token).subscribe();
  }
  decrease(productId) {
    var _a;
    (_a = this.groceryService.decreaseQty(productId, this.token)) == null ? void 0 : _a.subscribe();
  }
  getQty(productId) {
    if (!this.cartItems || this.cartItems.length === 0)
      return 0;
    const item = this.cartItems.find((i) => String(i.productId) === String(productId));
    return item ? item.quantity : 0;
  }
  goToDetails(product) {
    this.navCtrl.navigateForward([`/layout/grocery-layout/grocery-item-details/${product == null ? void 0 : product.id}`], {
      state: { productId: product == null ? void 0 : product.id }
    });
  }
  back() {
    this.navCtrl.back();
  }
};
_GrocerySearchPage.\u0275fac = function GrocerySearchPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _GrocerySearchPage)(\u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(GroceryService), \u0275\u0275directiveInject(AuthService), \u0275\u0275directiveInject(ChangeDetectorRef), \u0275\u0275directiveInject(Router));
};
_GrocerySearchPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _GrocerySearchPage, selectors: [["app-grocery-search"]], decls: 11, vars: 5, consts: [[1, "ion-no-border", "bg-white", "pt-2"], [1, "search-header"], ["name", "arrow-back-outline", 1, "back-icon", 3, "click"], [1, "input-wrapper"], ["placeholder", 'Search "paneer"', "inputmode", "search", "animated", "true", "autofocus", "true", "showCancelButton", "never", 3, "ionInput", "debounce"], [1, "bg-light", 3, "fullscreen"], ["class", "results-container", "style", "padding-top: 10px;", 4, "ngIf"], [4, "ngIf"], ["class", "results-container", 4, "ngIf"], [2, "height", "100px"], [1, "results-container", 2, "padding-top", "10px"], [1, "product-list"], ["class", "p-item", 4, "ngFor", "ngForOf"], [1, "p-item"], [1, "img-box", 2, "background", "#f4f4f4"], ["animated", "", 2, "width", "100%", "height", "100%", "margin", "0"], [1, "info", 2, "width", "100%", "padding-right", "10px"], ["animated", "", 2, "width", "70%", "height", "16px", "border-radius", "4px"], ["animated", "", 2, "width", "40%", "height", "12px", "margin-top", "8px", "border-radius", "4px"], [2, "margin-top", "10px"], ["animated", "", 2, "width", "60px", "height", "18px", "border-radius", "4px"], [1, "action-box"], ["animated", "", 2, "width", "70px", "height", "32px", "border-radius", "6px"], [1, "d-flex", "align-items-center", "justify-content-center", "mt-5"], [1, "results-container"], ["class", "result-count", 4, "ngIf"], ["class", "empty-state", 4, "ngIf"], [1, "result-count"], [1, "empty-state"], ["src", "https://cdn-icons-png.flaticon.com/512/6134/6134065.png", "alt", "No Data"], [1, "img-box"], [3, "src"], ["class", "disc", 4, "ngIf"], [1, "info"], [1, "price-box"], [1, "curr"], ["class", "old", 4, "ngIf"], ["class", "add-btn", "disabled", "", "style", "opacity: 0.7; background-color: #dcdcdc; color: #555; border: none;", 4, "ngIf"], ["class", "add-btn", 3, "click", 4, "ngIf"], ["class", "qty-counter", 4, "ngIf"], [1, "disc"], [1, "old"], ["disabled", "", 1, "add-btn", 2, "opacity", "0.7", "background-color", "#dcdcdc", "color", "#555", "border", "none"], [1, "add-btn", 3, "click"], [1, "qty-counter"], [1, "minus", 3, "click"], [1, "count"], [1, "plus", 3, "click"]], template: function GrocerySearchPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar")(2, "div", 1)(3, "ion-icon", 2);
    \u0275\u0275listener("click", function GrocerySearchPage_Template_ion_icon_click_3_listener() {
      return ctx.back();
    });
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "div", 3)(5, "ion-searchbar", 4);
    \u0275\u0275listener("ionInput", function GrocerySearchPage_Template_ion_searchbar_ionInput_5_listener($event) {
      return ctx.onSearchChange($event);
    });
    \u0275\u0275elementEnd()()()()();
    \u0275\u0275elementStart(6, "ion-content", 5);
    \u0275\u0275template(7, GrocerySearchPage_div_7_Template, 3, 2, "div", 6)(8, GrocerySearchPage_div_8_Template, 4, 0, "div", 7)(9, GrocerySearchPage_div_9_Template, 5, 3, "div", 8);
    \u0275\u0275element(10, "div", 9);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance(5);
    \u0275\u0275property("debounce", 250);
    \u0275\u0275advance();
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", ctx.isLoading);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", !ctx.isLoading && ctx.query.length === 0);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", !ctx.isLoading && ctx.query.length > 0);
  }
}, dependencies: [IonSkeletonText, IonIcon, IonSearchbar, IonToolbar, IonHeader, IonContent, CommonModule, NgForOf, NgIf, FormsModule], styles: ["\n\nion-content[_ngcontent-%COMP%] {\n  --background: #f5f7fd;\n}\nion-toolbar[_ngcontent-%COMP%] {\n  --background: #fff;\n  border-bottom: 1px solid #f0f0f0;\n  padding-bottom: 5px;\n}\n.search-header[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  padding: 0 10px;\n  gap: 10px;\n}\n.search-header[_ngcontent-%COMP%]   .back-icon[_ngcontent-%COMP%] {\n  font-size: 24px;\n  color: #333;\n}\n.search-header[_ngcontent-%COMP%]   .input-wrapper[_ngcontent-%COMP%] {\n  flex: 1;\n}\n.search-header[_ngcontent-%COMP%]   .input-wrapper[_ngcontent-%COMP%]   ion-searchbar[_ngcontent-%COMP%] {\n  --box-shadow: none;\n  --background: #f1f2f6;\n  --border-radius: 12px;\n  --placeholder-color: #888;\n  --color: #222;\n  padding: 0;\n  height: 45px;\n}\n.section[_ngcontent-%COMP%] {\n  background: #fff;\n  padding: 15px;\n  margin-bottom: 10px;\n}\n.section[_ngcontent-%COMP%]   .sec-head[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 15px;\n}\n.section[_ngcontent-%COMP%]   .sec-head[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%] {\n  font-size: 15px;\n  font-weight: 700;\n  color: #444;\n  margin: 0;\n}\n.section[_ngcontent-%COMP%]   .sec-head[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #a000e2;\n  font-weight: 600;\n  cursor: pointer;\n}\n.section[_ngcontent-%COMP%]   .history-list[_ngcontent-%COMP%]   .h-item[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  padding: 12px 0;\n  border-bottom: 1px solid #f9f9f9;\n  color: #555;\n}\n.section[_ngcontent-%COMP%]   .history-list[_ngcontent-%COMP%]   .h-item[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n  color: #a000e2;\n}\n.section[_ngcontent-%COMP%]   .history-list[_ngcontent-%COMP%]   .h-item[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  flex: 1;\n  font-size: 14px;\n}\n.section[_ngcontent-%COMP%]   .history-list[_ngcontent-%COMP%]   .h-item[_ngcontent-%COMP%]   .remove[_ngcontent-%COMP%] {\n  color: #ccc;\n}\n.section[_ngcontent-%COMP%]   .history-list[_ngcontent-%COMP%]   .h-item[_ngcontent-%COMP%]:last-child {\n  border: none;\n}\n.section[_ngcontent-%COMP%]   .trending-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(4, 1fr);\n  gap: 10px;\n}\n.section[_ngcontent-%COMP%]   .trending-grid[_ngcontent-%COMP%]   .t-card[_ngcontent-%COMP%] {\n  background: #f8f9fa;\n  border-radius: 12px;\n  padding: 10px;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  gap: 5px;\n  text-align: center;\n}\n.section[_ngcontent-%COMP%]   .trending-grid[_ngcontent-%COMP%]   .t-card[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n  object-fit: contain;\n}\n.section[_ngcontent-%COMP%]   .trending-grid[_ngcontent-%COMP%]   .t-card[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 600;\n  color: #555;\n  line-height: 1.2;\n}\n.results-container[_ngcontent-%COMP%] {\n  padding: 15px;\n}\n.results-container[_ngcontent-%COMP%]   .result-count[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #777;\n  margin-bottom: 15px;\n}\n.results-container[_ngcontent-%COMP%]   .empty-state[_ngcontent-%COMP%] {\n  text-align: center;\n  margin-top: 50px;\n}\n.results-container[_ngcontent-%COMP%]   .empty-state[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 100px;\n  opacity: 0.5;\n  margin-bottom: 20px;\n}\n.results-container[_ngcontent-%COMP%]   .empty-state[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  font-size: 18px;\n  color: #333;\n  margin: 0;\n  font-weight: 700;\n}\n.results-container[_ngcontent-%COMP%]   .empty-state[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  color: #888;\n  font-size: 14px;\n}\n.results-container[_ngcontent-%COMP%]   .product-list[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n}\n.results-container[_ngcontent-%COMP%]   .product-list[_ngcontent-%COMP%]   .p-item[_ngcontent-%COMP%] {\n  background: #fff;\n  border-radius: 12px;\n  padding: 10px;\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  border: 1px solid #eee;\n}\n.results-container[_ngcontent-%COMP%]   .product-list[_ngcontent-%COMP%]   .p-item[_ngcontent-%COMP%]   .img-box[_ngcontent-%COMP%] {\n  width: 60px;\n  height: 60px;\n  position: relative;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.results-container[_ngcontent-%COMP%]   .product-list[_ngcontent-%COMP%]   .p-item[_ngcontent-%COMP%]   .img-box[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  max-height: 50px;\n  max-width: 100%;\n  object-fit: contain;\n}\n.results-container[_ngcontent-%COMP%]   .product-list[_ngcontent-%COMP%]   .p-item[_ngcontent-%COMP%]   .img-box[_ngcontent-%COMP%]   .disc[_ngcontent-%COMP%] {\n  position: absolute;\n  top: -5px;\n  left: -5px;\n  background: #5c6bc0;\n  color: white;\n  font-size: 8px;\n  padding: 2px 4px;\n  border-radius: 4px;\n  font-weight: 700;\n}\n.results-container[_ngcontent-%COMP%]   .product-list[_ngcontent-%COMP%]   .p-item[_ngcontent-%COMP%]   .info[_ngcontent-%COMP%] {\n  flex: 1;\n}\n.results-container[_ngcontent-%COMP%]   .product-list[_ngcontent-%COMP%]   .p-item[_ngcontent-%COMP%]   .info[_ngcontent-%COMP%]   h6[_ngcontent-%COMP%] {\n  margin: 0 0 4px;\n  font-size: 14px;\n  font-weight: 600;\n  color: #222;\n}\n.results-container[_ngcontent-%COMP%]   .product-list[_ngcontent-%COMP%]   .p-item[_ngcontent-%COMP%]   .info[_ngcontent-%COMP%]   small[_ngcontent-%COMP%] {\n  color: #888;\n  font-size: 12px;\n  display: block;\n  margin-bottom: 4px;\n}\n.results-container[_ngcontent-%COMP%]   .product-list[_ngcontent-%COMP%]   .p-item[_ngcontent-%COMP%]   .info[_ngcontent-%COMP%]   .price-box[_ngcontent-%COMP%]   .curr[_ngcontent-%COMP%] {\n  font-weight: 700;\n  font-size: 14px;\n  color: #222;\n  margin-right: 6px;\n}\n.results-container[_ngcontent-%COMP%]   .product-list[_ngcontent-%COMP%]   .p-item[_ngcontent-%COMP%]   .info[_ngcontent-%COMP%]   .price-box[_ngcontent-%COMP%]   .old[_ngcontent-%COMP%] {\n  font-size: 11px;\n  text-decoration: line-through;\n  color: #999;\n}\n.results-container[_ngcontent-%COMP%]   .product-list[_ngcontent-%COMP%]   .p-item[_ngcontent-%COMP%]   .action-box[_ngcontent-%COMP%]   .add-btn[_ngcontent-%COMP%] {\n  background: #fff;\n  border: 1px solid #a000e2;\n  color: #a000e2;\n  font-size: 12px;\n  font-weight: 800;\n  padding: 6px 16px;\n  border-radius: 6px;\n  text-transform: uppercase;\n}\n.results-container[_ngcontent-%COMP%]   .product-list[_ngcontent-%COMP%]   .p-item[_ngcontent-%COMP%]   .action-box[_ngcontent-%COMP%]   .counter[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  background: #a000e2;\n  border-radius: 6px;\n  height: 30px;\n  min-width: 75px;\n  justify-content: space-between;\n  padding: 0 5px;\n  color: white;\n  font-weight: bold;\n  font-size: 16px;\n  box-shadow: 0 2px 5px rgba(255, 50, 105, 0.2);\n}\n.results-container[_ngcontent-%COMP%]   .product-list[_ngcontent-%COMP%]   .p-item[_ngcontent-%COMP%]   .action-box[_ngcontent-%COMP%]   .counter[_ngcontent-%COMP%]   .val[_ngcontent-%COMP%] {\n  font-size: 13px;\n}\n.cart-footer[_ngcontent-%COMP%] {\n  padding: 10px 15px 20px;\n  background: transparent;\n  position: absolute;\n  bottom: 0;\n  width: 100%;\n  pointer-events: none;\n}\n.cart-footer[_ngcontent-%COMP%]   .cart-bar[_ngcontent-%COMP%] {\n  pointer-events: auto;\n  background: #3d0374;\n  border-radius: 12px;\n  padding: 12px 16px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  color: white;\n  box-shadow: 0 10px 20px rgba(61, 3, 116, 0.3);\n}\n.cart-footer[_ngcontent-%COMP%]   .cart-bar[_ngcontent-%COMP%]   .cart-info[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  line-height: 1.2;\n}\n.cart-footer[_ngcontent-%COMP%]   .cart-bar[_ngcontent-%COMP%]   .cart-info[_ngcontent-%COMP%]   small[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 700;\n  opacity: 0.8;\n  letter-spacing: 0.5px;\n}\n.cart-footer[_ngcontent-%COMP%]   .cart-bar[_ngcontent-%COMP%]   .cart-info[_ngcontent-%COMP%]   h6[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 16px;\n  font-weight: 700;\n}\n.cart-footer[_ngcontent-%COMP%]   .cart-bar[_ngcontent-%COMP%]   .cart-info[_ngcontent-%COMP%]   .tax[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 400;\n  opacity: 0.7;\n}\n.cart-footer[_ngcontent-%COMP%]   .cart-bar[_ngcontent-%COMP%]   .view-cart-btn[_ngcontent-%COMP%] {\n  font-weight: 700;\n  font-size: 14px;\n  display: flex;\n  align-items: center;\n  gap: 5px;\n}\n.qty-counter[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  background: #a000e2;\n  border-radius: 6px;\n  height: 28px;\n  box-shadow: 0 2px 5px rgba(255, 50, 105, 0.3);\n}\n.qty-counter[_ngcontent-%COMP%]   .minus[_ngcontent-%COMP%], \n.qty-counter[_ngcontent-%COMP%]   .plus[_ngcontent-%COMP%] {\n  width: 25px;\n  height: 100%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  color: white;\n  font-weight: bold;\n  font-size: 16px;\n}\n.qty-counter[_ngcontent-%COMP%]   .count[_ngcontent-%COMP%] {\n  color: white;\n  font-weight: 700;\n  font-size: 12px;\n  min-width: 15px;\n  text-align: center;\n}\n/*# sourceMappingURL=grocery-search.page.css.map */"] });
var GrocerySearchPage = _GrocerySearchPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(GrocerySearchPage, { className: "GrocerySearchPage", filePath: "src/app/pages/grocery-search/grocery-search.page.ts", lineNumber: 19 });
})();
export {
  GrocerySearchPage
};
//# sourceMappingURL=grocery-search.page-4HQKEO3P.js.map
