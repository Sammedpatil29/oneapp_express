import {
  registerPlugin
} from "./chunk-FH4NU4VH.js";

// node_modules/@capacitor/share/dist/esm/index.js
var Share = registerPlugin("Share", {
  web: () => import("./web-J7XPZFNR.js").then((m) => new m.ShareWeb())
});

export {
  Share
};
//# sourceMappingURL=chunk-XS4AIG4E.js.map
