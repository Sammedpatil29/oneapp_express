import {
  WebPlugin
} from "./chunk-FH4NU4VH.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// node_modules/@capawesome/capacitor-app-update/dist/esm/web.js
var AppUpdateWeb = class extends WebPlugin {
  getAppUpdateInfo() {
    return __async(this, null, function* () {
      throw new Error("Web platform is not supported.");
    });
  }
  openAppStore() {
    return __async(this, null, function* () {
      throw new Error("Web platform is not supported.");
    });
  }
  performImmediateUpdate() {
    return __async(this, null, function* () {
      throw new Error("Web platform is not supported.");
    });
  }
  startFlexibleUpdate() {
    return __async(this, null, function* () {
      throw new Error("Web platform is not supported.");
    });
  }
  completeFlexibleUpdate() {
    return __async(this, null, function* () {
      throw new Error("Web platform is not supported.");
    });
  }
};
export {
  AppUpdateWeb
};
//# sourceMappingURL=web-7LJGKTH6.js.map
