import {
  IonRouterOutlet
} from "./chunk-CJE2NDTY.js";
import {
  CommonModule,
  ɵsetClassDebugInfo,
  ɵɵdefineComponent,
  ɵɵelement
} from "./chunk-Z7XNNJSA.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import "./chunk-6B6DTIB5.js";

// src/app/pages/property-layout/property-layout.page.ts
var _PropertyLayoutPage = class _PropertyLayoutPage {
  constructor() {
  }
};
_PropertyLayoutPage.\u0275fac = function PropertyLayoutPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _PropertyLayoutPage)();
};
_PropertyLayoutPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _PropertyLayoutPage, selectors: [["app-property-layout"]], decls: 1, vars: 0, template: function PropertyLayoutPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-router-outlet");
  }
}, dependencies: [IonRouterOutlet, CommonModule], encapsulation: 2 });
var PropertyLayoutPage = _PropertyLayoutPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(PropertyLayoutPage, { className: "PropertyLayoutPage", filePath: "src/app/pages/property-layout/property-layout.page.ts", lineNumber: 12 });
})();
export {
  PropertyLayoutPage
};
//# sourceMappingURL=property-layout.page-2KCUAV2M.js.map
