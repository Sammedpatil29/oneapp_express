import {
  AdmobConsentStatus
} from "./chunk-3YO22OKP.js";
import {
  WebPlugin
} from "./chunk-FH4NU4VH.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// node_modules/@capacitor-community/admob/dist/esm/consent/privacy-options-requirement-status.enum.js
var PrivacyOptionsRequirementStatus;
(function(PrivacyOptionsRequirementStatus2) {
  PrivacyOptionsRequirementStatus2["NOT_REQUIRED"] = "NOT_REQUIRED";
  PrivacyOptionsRequirementStatus2["REQUIRED"] = "REQUIRED";
  PrivacyOptionsRequirementStatus2["UNKNOWN"] = "UNKNOWN";
})(PrivacyOptionsRequirementStatus || (PrivacyOptionsRequirementStatus = {}));

// node_modules/@capacitor-community/admob/dist/esm/web.js
var AdMobWeb = class extends WebPlugin {
  initialize() {
    return __async(this, null, function* () {
      console.log("initialize");
    });
  }
  requestTrackingAuthorization() {
    return __async(this, null, function* () {
      console.log("requestTrackingAuthorization");
    });
  }
  trackingAuthorizationStatus() {
    return __async(this, null, function* () {
      return {
        status: "authorized"
      };
    });
  }
  requestConsentInfo(options) {
    return __async(this, null, function* () {
      console.log("requestConsentInfo", options);
      return {
        status: AdmobConsentStatus.REQUIRED,
        isConsentFormAvailable: true,
        canRequestAds: true,
        privacyOptionsRequirementStatus: PrivacyOptionsRequirementStatus.REQUIRED
      };
    });
  }
  showPrivacyOptionsForm() {
    return __async(this, null, function* () {
      console.log("showPrivacyOptionsForm");
    });
  }
  showConsentForm() {
    return __async(this, null, function* () {
      console.log("showConsentForm");
      return {
        status: AdmobConsentStatus.REQUIRED,
        canRequestAds: true,
        privacyOptionsRequirementStatus: PrivacyOptionsRequirementStatus.REQUIRED
      };
    });
  }
  resetConsentInfo() {
    return __async(this, null, function* () {
      console.log("resetConsentInfo");
    });
  }
  setApplicationMuted(options) {
    return __async(this, null, function* () {
      console.log("setApplicationMuted", options);
    });
  }
  setApplicationVolume(options) {
    return __async(this, null, function* () {
      console.log("setApplicationVolume", options);
    });
  }
  showBanner(options) {
    return __async(this, null, function* () {
      console.log("showBanner", options);
    });
  }
  // Hide the banner, remove it from screen, but can show it later
  hideBanner() {
    return __async(this, null, function* () {
      console.log("hideBanner");
    });
  }
  // Resume the banner, show it after hide
  resumeBanner() {
    return __async(this, null, function* () {
      console.log("resumeBanner");
    });
  }
  // Destroy the banner, remove it from screen.
  removeBanner() {
    return __async(this, null, function* () {
      console.log("removeBanner");
    });
  }
  prepareInterstitial(options) {
    return __async(this, null, function* () {
      console.log("prepareInterstitial", options);
      return {
        adUnitId: options.adId
      };
    });
  }
  showInterstitial() {
    return __async(this, null, function* () {
      console.log("showInterstitial");
    });
  }
  prepareRewardVideoAd(options) {
    return __async(this, null, function* () {
      console.log(options);
      return {
        adUnitId: options.adId
      };
    });
  }
  showRewardVideoAd() {
    return __async(this, null, function* () {
      return {
        type: "",
        amount: 0
      };
    });
  }
  prepareRewardInterstitialAd(options) {
    return __async(this, null, function* () {
      console.log(options);
      return {
        adUnitId: options.adId
      };
    });
  }
  showRewardInterstitialAd() {
    return __async(this, null, function* () {
      return {
        type: "",
        amount: 0
      };
    });
  }
};
export {
  AdMobWeb
};
//# sourceMappingURL=web-K2IH32HP.js.map
