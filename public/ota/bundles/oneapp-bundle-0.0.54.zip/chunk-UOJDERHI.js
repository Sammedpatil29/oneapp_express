import {
  environment
} from "./chunk-YJYUHAOC.js";
import {
  BehaviorSubject,
  HttpClient,
  HttpHeaders,
  tap,
  ɵɵdefineInjectable,
  ɵɵinject
} from "./chunk-Z7XNNJSA.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-6B6DTIB5.js";

// src/app/services/grocery.service.ts
var _GroceryService = class _GroceryService {
  constructor(http) {
    this.http = http;
    this.apiUrl = environment.apiUrl;
    this._cartSubject = new BehaviorSubject([]);
    this.cart$ = this._cartSubject.asObservable();
    this._summarySubject = new BehaviorSubject({ itemCount: 0, totalAmount: 0 });
    this.summary$ = this._summarySubject.asObservable();
  }
  getCartItems(token) {
    let headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.get(`${this.apiUrl}/api/grocery-home`, { headers }).pipe(tap((responseItems) => {
      const rawCart = responseItems.data && responseItems.data.cart ? responseItems.data.cart : [];
      const cartData = rawCart.map((item) => {
        const keys = Object.keys(item);
        if (keys.length > 0) {
          const id = keys[0];
          const qty = item[id];
          return { productId: String(id), quantity: Number(qty) };
        }
        return null;
      }).filter((item) => item !== null);
      const itemData = {
        itemCount: responseItems.data.itemCount || 0,
        totalAmount: responseItems.data.totalPrice || 0
      };
      console.log("\u{1F4E6} API Cart Items:", cartData);
      console.log("\u{1F4B0} API Summary:", itemData);
      this._cartSubject.next(cartData);
      this._summarySubject.next(itemData);
    }));
  }
  increaseQty(productId, token) {
    const currentItems = this._cartSubject.value;
    const item = currentItems.find((i) => String(i.productId) === String(productId));
    const newQty = item ? item.quantity + 1 : 1;
    return this.updateCartApi(productId, newQty, token);
  }
  decreaseQty(productId, token) {
    const currentItems = this._cartSubject.value;
    const item = currentItems.find((i) => String(i.productId) === String(productId));
    if (!item)
      return;
    const newQty = item.quantity - 1;
    return this.updateCartApi(productId, newQty, token);
  }
  updateCartApi(productId, quantity, token) {
    const payload = { productId, quantity };
    let headers = new HttpHeaders({ "Authorization": `Bearer ${token}` });
    return this.http.post(`${this.apiUrl}/api/grocery/cart/update`, payload, { headers }).pipe(tap((res) => {
      const currentItems = this._cartSubject.value;
      const index = currentItems.findIndex((i) => String(i.productId) === String(productId));
      let updatedItems = [...currentItems];
      if (quantity <= 0) {
        updatedItems = updatedItems.filter((i) => String(i.productId) !== String(productId));
      } else {
        if (index > -1) {
          updatedItems[index] = __spreadProps(__spreadValues({}, updatedItems[index]), { quantity });
        } else {
          updatedItems.push({ productId: String(productId), quantity });
        }
      }
      const itemData = {
        itemCount: res.itemCount || 0,
        totalAmount: res.totalPrice || 0
      };
      console.log("\u{1F4B0} Updated Summary from API:", itemData);
      this._cartSubject.next(updatedItems);
      this._summarySubject.next(itemData);
    }));
  }
  getCategories(params) {
    return this.http.post(`${this.apiUrl}/api/grocery-home/category`, params);
  }
  getProductsByCategory(params) {
    return this.http.post(`${this.apiUrl}/api/grocery-home/productbycategory`, params);
  }
  getItemDetails(id) {
    return this.http.get(`${this.apiUrl}/api/grocery/${id}`);
  }
  getProductsByTerm(term) {
    let params = { term };
    return this.http.post(`${this.apiUrl}/api/grocery-home/section`, params);
  }
  searchProducts(term) {
    let params = { searchTerm: term };
    return this.http.post(`${this.apiUrl}/api/grocery-home/search`, params);
  }
  getCartdata(token, couponCode) {
    let headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.get(`${this.apiUrl}/api/grocery/cart?coupon=${couponCode}`, { headers });
  }
  placeGroceryOrder(token, params) {
    let headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.post(`${this.apiUrl}/api/grocery-order/create`, params, { headers });
  }
  clearCart() {
    this._cartSubject.next([]);
    this._summarySubject.next({ itemCount: 0, totalAmount: 0 });
  }
  verifyPayment(params) {
    return this.http.post(`${this.apiUrl}/api/grocery-order/verify-status`, params);
  }
  getOrderById(token, id) {
    let headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.get(`${this.apiUrl}/api/grocery-order/${id}`, { headers });
  }
  cancelOrder(params) {
    let headers = {
      "Authorization": `Bearer ${localStorage.getItem("auth-token")}`
    };
    return this.http.post(`${this.apiUrl}/api/grocery-order/cancel`, params, { headers });
  }
};
_GroceryService.\u0275fac = function GroceryService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _GroceryService)(\u0275\u0275inject(HttpClient));
};
_GroceryService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _GroceryService, factory: _GroceryService.\u0275fac, providedIn: "root" });
var GroceryService = _GroceryService;

export {
  GroceryService
};
//# sourceMappingURL=chunk-UOJDERHI.js.map
