import {
  WebPlugin
} from "./chunk-FH4NU4VH.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// node_modules/@capacitor/splash-screen/dist/esm/web.js
var SplashScreenWeb = class extends WebPlugin {
  show(_options) {
    return __async(this, null, function* () {
      return void 0;
    });
  }
  hide(_options) {
    return __async(this, null, function* () {
      return void 0;
    });
  }
};
export {
  SplashScreenWeb
};
//# sourceMappingURL=web-R2JB5DOO.js.map
