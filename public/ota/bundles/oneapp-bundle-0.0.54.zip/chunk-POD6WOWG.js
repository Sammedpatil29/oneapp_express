import {
  environment
} from "./chunk-YJYUHAOC.js";
import {
  HttpClient,
  HttpHeaders,
  ɵɵdefineInjectable,
  ɵɵinject
} from "./chunk-Z7XNNJSA.js";

// src/app/services/dineout.service.ts
var _DineoutService = class _DineoutService {
  constructor(http) {
    this.http = http;
    this.url = environment.apiUrl;
  }
  getRestaurants() {
    let city = localStorage.getItem("selectedCity") || "Athani";
    return this.http.get(`${this.url}/api/dineout?city=${city}`);
  }
  getRestaurantDetails(restaurantId) {
    return this.http.get(`${this.url}/api/dineout/${restaurantId}`);
  }
  createOrder(token, params) {
    let headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.post(`${this.url}/api/dineout/orders/create`, params, { headers });
  }
  orderById(id) {
    let params = {
      "orderId": id
    };
    return this.http.post(`${this.url}/api/dineout/orders/details`, params);
  }
  cancelOrder(id, token) {
    let params = {
      "orderId": id
    };
    let headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.post(`${this.url}/api/dineout/orders/cancel`, params, { headers });
  }
  uploadBill(token, params) {
    let headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.post(`${this.url}/api/dineout/orders/upload-bill`, params, { headers });
  }
  calculateBill(token, params) {
    let headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.post(`${this.url}/api/dineout/orders/calculate-bill`, params, { headers });
  }
  initiatePayment(token, params) {
    let headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.post(`${this.url}/api/dineout/orders/payment/create`, params, { headers });
  }
  verifyPayment(token, params) {
    let headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.post(`${this.url}/api/dineout/orders/payment/verify`, params, { headers });
  }
};
_DineoutService.\u0275fac = function DineoutService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _DineoutService)(\u0275\u0275inject(HttpClient));
};
_DineoutService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _DineoutService, factory: _DineoutService.\u0275fac, providedIn: "root" });
var DineoutService = _DineoutService;

export {
  DineoutService
};
//# sourceMappingURL=chunk-POD6WOWG.js.map
