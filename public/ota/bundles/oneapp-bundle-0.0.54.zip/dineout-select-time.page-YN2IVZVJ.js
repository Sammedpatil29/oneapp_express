import {
  DineoutService
} from "./chunk-POD6WOWG.js";
import {
  ErrorComponent
} from "./chunk-NBWFOQSW.js";
import {
  addIcons,
  arrowBack,
  arrowBackOutline,
  calendarOutline,
  checkmarkCircle,
  chevronDownOutline,
  giftOutline,
  informationCircleOutline,
  moonOutline,
  timeOutline
} from "./chunk-FJYXZAS7.js";
import {
  AuthService
} from "./chunk-EB6T6TPT.js";
import "./chunk-YJYUHAOC.js";
import {
  IonButton,
  IonButtons,
  IonContent,
  IonFooter,
  IonHeader,
  IonIcon,
  IonSkeletonText,
  IonTitle,
  IonToolbar,
  IonicModule,
  LoadingController,
  ToastController
} from "./chunk-OE5MTPUR.js";
import {
  ActivatedRoute,
  CommonModule,
  FormsModule,
  NavController,
  NgForOf,
  NgIf,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementContainerEnd,
  ɵɵelementContainerStart,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1
} from "./chunk-Z7XNNJSA.js";
import "./chunk-XR3JUECC.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/pages/dineout-select-time/dineout-select-time.page.ts
var _c0 = () => [1, 2, 3, 4, 5];
var _c1 = () => [1, 2, 3, 4];
var _c2 = () => [1, 2, 3, 4, 5, 6, 7, 8];
function DineoutSelectTimePage_Conditional_8_ion_skeleton_text_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-skeleton-text", 22);
  }
}
function DineoutSelectTimePage_Conditional_8_ion_skeleton_text_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-skeleton-text", 23);
  }
}
function DineoutSelectTimePage_Conditional_8_ion_skeleton_text_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-skeleton-text", 24);
  }
}
function DineoutSelectTimePage_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 6);
    \u0275\u0275element(1, "ion-skeleton-text", 10);
    \u0275\u0275elementStart(2, "div", 11);
    \u0275\u0275element(3, "ion-skeleton-text", 12);
    \u0275\u0275elementStart(4, "div", 13);
    \u0275\u0275template(5, DineoutSelectTimePage_Conditional_8_ion_skeleton_text_5_Template, 1, 0, "ion-skeleton-text", 14);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "div", 11);
    \u0275\u0275element(7, "ion-skeleton-text", 15);
    \u0275\u0275elementStart(8, "div", 13);
    \u0275\u0275template(9, DineoutSelectTimePage_Conditional_8_ion_skeleton_text_9_Template, 1, 0, "ion-skeleton-text", 16);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(10, "div", 11);
    \u0275\u0275element(11, "ion-skeleton-text", 17);
    \u0275\u0275elementStart(12, "div", 18);
    \u0275\u0275template(13, DineoutSelectTimePage_Conditional_8_ion_skeleton_text_13_Template, 1, 0, "ion-skeleton-text", 19);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(14, "div", 11);
    \u0275\u0275element(15, "ion-skeleton-text", 20)(16, "ion-skeleton-text", 21);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(5);
    \u0275\u0275property("ngForOf", \u0275\u0275pureFunction0(3, _c0));
    \u0275\u0275advance(4);
    \u0275\u0275property("ngForOf", \u0275\u0275pureFunction0(4, _c1));
    \u0275\u0275advance(4);
    \u0275\u0275property("ngForOf", \u0275\u0275pureFunction0(5, _c2));
  }
}
function DineoutSelectTimePage_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "app-error", 25);
    \u0275\u0275listener("reload", function DineoutSelectTimePage_Conditional_9_Template_app_error_reload_0_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.loadRestaurantData());
    });
    \u0275\u0275elementEnd();
  }
}
function DineoutSelectTimePage_Conditional_10_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 26);
    \u0275\u0275element(1, "img", 37);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" Get ", ctx_r1.offers[0].title, " on your bill payment ");
  }
}
function DineoutSelectTimePage_Conditional_10_div_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 38);
    \u0275\u0275listener("click", function DineoutSelectTimePage_Conditional_10_div_6_Template_div_click_0_listener() {
      const g_r4 = \u0275\u0275restoreView(_r3).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.selectGuest(g_r4));
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const g_r4 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275classProp("selected", ctx_r1.selectedGuest === g_r4);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", g_r4, " ");
  }
}
function DineoutSelectTimePage_Conditional_10_div_11_div_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 44)(1, "span");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const d_r7 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(d_r7.month);
  }
}
function DineoutSelectTimePage_Conditional_10_div_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 39);
    \u0275\u0275listener("click", function DineoutSelectTimePage_Conditional_10_div_11_Template_div_click_0_listener() {
      const i_r6 = \u0275\u0275restoreView(_r5).index;
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.selectDate(i_r6));
    });
    \u0275\u0275template(1, DineoutSelectTimePage_Conditional_10_div_11_div_1_Template, 3, 1, "div", 40);
    \u0275\u0275elementStart(2, "div", 41)(3, "div", 42);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 43);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const d_r7 = ctx.$implicit;
    const i_r6 = ctx.index;
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", d_r7.date === "01" || i_r6 === 0 && d_r7.day !== "Today");
    \u0275\u0275advance();
    \u0275\u0275classProp("selected", ctx_r1.selectedDateIdx === i_r6);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(d_r7.date);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(d_r7.day);
  }
}
function DineoutSelectTimePage_Conditional_10_div_15_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 47);
    \u0275\u0275listener("click", function DineoutSelectTimePage_Conditional_10_div_15_div_1_Template_div_click_0_listener() {
      const t_r9 = \u0275\u0275restoreView(_r8).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(!t_r9.disabled && ctx_r1.selectTime(t_r9.time));
    });
    \u0275\u0275elementStart(1, "span", 48);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const t_r9 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275classProp("selected", ctx_r1.selectedTimeSlot === t_r9.time)("disabled", t_r9.disabled);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(t_r9.time);
  }
}
function DineoutSelectTimePage_Conditional_10_div_15_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 45);
    \u0275\u0275template(1, DineoutSelectTimePage_Conditional_10_div_15_div_1_Template, 3, 5, "div", 46);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275property("ngForOf", ctx_r1.timeSlots);
  }
}
function DineoutSelectTimePage_Conditional_10_div_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 49);
    \u0275\u0275text(1, " No slots available for this date. ");
    \u0275\u0275elementEnd();
  }
}
function DineoutSelectTimePage_Conditional_10_div_17_ng_container_1_div_3_div_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "div", 63);
  }
}
function DineoutSelectTimePage_Conditional_10_div_17_ng_container_1_div_3_div_12_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 64)(1, "span", 65);
    \u0275\u0275text(2, "New Users Only");
    \u0275\u0275elementEnd()();
  }
}
function DineoutSelectTimePage_Conditional_10_div_17_ng_container_1_div_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 54);
    \u0275\u0275listener("click", function DineoutSelectTimePage_Conditional_10_div_17_ng_container_1_div_3_Template_div_click_0_listener() {
      const off_r11 = \u0275\u0275restoreView(_r10).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(4);
      return \u0275\u0275resetView(ctx_r1.selectOffer(off_r11));
    });
    \u0275\u0275elementStart(1, "div", 55)(2, "div", 56);
    \u0275\u0275template(3, DineoutSelectTimePage_Conditional_10_div_17_ng_container_1_div_3_div_3_Template, 1, 0, "div", 57);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "div", 58)(5, "div", 59);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "div", 60);
    \u0275\u0275text(8);
    \u0275\u0275elementStart(9, "span", 61);
    \u0275\u0275text(10, "\u2022");
    \u0275\u0275elementEnd();
    \u0275\u0275text(11);
    \u0275\u0275elementEnd();
    \u0275\u0275template(12, DineoutSelectTimePage_Conditional_10_div_17_ng_container_1_div_3_div_12_Template, 3, 0, "div", 62);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const off_r11 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(4);
    \u0275\u0275classProp("selected", ctx_r1.selectedOffer === off_r11);
    \u0275\u0275advance(3);
    \u0275\u0275property("ngIf", ctx_r1.selectedOffer === off_r11);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(off_r11.title);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" ", off_r11.description, " ");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" Cover charge: \u20B9", ctx_r1.coverCharge, "/guest ");
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", off_r11.applicable_for === "NEW_USER");
  }
}
function DineoutSelectTimePage_Conditional_10_div_17_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainerStart(0);
    \u0275\u0275elementStart(1, "h3");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275template(3, DineoutSelectTimePage_Conditional_10_div_17_ng_container_1_div_3_Template, 13, 7, "div", 51);
    \u0275\u0275elementStart(4, "div", 52);
    \u0275\u0275element(5, "ion-icon", 53);
    \u0275\u0275elementStart(6, "p")(7, "strong");
    \u0275\u0275text(8, "Note:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(9, " Selecting an offer here is for reference. You can apply the actual offer while paying your bill at the restaurant. ");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("Select offer for ", ctx_r1.selectedTimeSlot, "");
    \u0275\u0275advance();
    \u0275\u0275property("ngForOf", ctx_r1.offers);
  }
}
function DineoutSelectTimePage_Conditional_10_div_17_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainerStart(0);
    \u0275\u0275elementStart(1, "h3");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 66)(4, "div", 67);
    \u0275\u0275element(5, "ion-icon", 68);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "h4");
    \u0275\u0275text(7, "Great food needs no discount!");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "p");
    \u0275\u0275text(9, "While there are no active offers for this slot, we promise a dining experience worth every penny.");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("Offers for ", ctx_r1.selectedTimeSlot, "");
  }
}
function DineoutSelectTimePage_Conditional_10_div_17_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 11);
    \u0275\u0275template(1, DineoutSelectTimePage_Conditional_10_div_17_ng_container_1_Template, 10, 2, "ng-container", 50)(2, DineoutSelectTimePage_Conditional_10_div_17_ng_container_2_Template, 10, 1, "ng-container", 50);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", ctx_r1.offers.length > 0);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", ctx_r1.offers.length === 0);
  }
}
function DineoutSelectTimePage_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275template(0, DineoutSelectTimePage_Conditional_10_Conditional_0_Template, 3, 1, "div", 26);
    \u0275\u0275elementStart(1, "div", 6)(2, "div", 11)(3, "h3");
    \u0275\u0275text(4, "Number of guest(s)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 27);
    \u0275\u0275template(6, DineoutSelectTimePage_Conditional_10_div_6_Template, 2, 3, "div", 28);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "div", 11)(8, "h3");
    \u0275\u0275text(9, "When are you visiting?");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "div", 29);
    \u0275\u0275template(11, DineoutSelectTimePage_Conditional_10_div_11_Template, 7, 5, "div", 30);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(12, "div", 31)(13, "div", 32);
    \u0275\u0275text(14, "Select Slot");
    \u0275\u0275elementEnd();
    \u0275\u0275template(15, DineoutSelectTimePage_Conditional_10_div_15_Template, 2, 1, "div", 33)(16, DineoutSelectTimePage_Conditional_10_div_16_Template, 2, 0, "div", 34);
    \u0275\u0275elementEnd();
    \u0275\u0275template(17, DineoutSelectTimePage_Conditional_10_div_17_Template, 3, 2, "div", 35);
    \u0275\u0275elementEnd();
    \u0275\u0275element(18, "div", 36);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275conditional(ctx_r1.offers.length > 0 ? 0 : -1);
    \u0275\u0275advance(6);
    \u0275\u0275property("ngForOf", ctx_r1.guests);
    \u0275\u0275advance(5);
    \u0275\u0275property("ngForOf", ctx_r1.dates);
    \u0275\u0275advance(4);
    \u0275\u0275property("ngIf", ctx_r1.timeSlots.length > 0);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", ctx_r1.timeSlots.length === 0);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", ctx_r1.selectedTimeSlot);
  }
}
var _DineoutSelectTimePage = class _DineoutSelectTimePage {
  constructor(route, navCtrl, dineoutService, toastCtrl, loadingCtrl, authServcie) {
    this.route = route;
    this.navCtrl = navCtrl;
    this.dineoutService = dineoutService;
    this.toastCtrl = toastCtrl;
    this.loadingCtrl = loadingCtrl;
    this.authServcie = authServcie;
    this.restaurantName = "";
    this.operatingHours = [];
    this.offers = [];
    this.guests = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
    this.selectedGuest = 2;
    this.dates = [];
    this.selectedDateIdx = 0;
    this.timeSlots = [];
    this.selectedTimeSlot = "";
    this.selectedOffer = null;
    this.coverCharge = 0;
    this.isLoading = true;
    this.isError = false;
    this.token = "";
    addIcons({
      arrowBack,
      arrowBackOutline,
      calendarOutline,
      timeOutline,
      moonOutline,
      chevronDownOutline,
      checkmarkCircle,
      informationCircleOutline,
      giftOutline
    });
  }
  goBack() {
    this.navCtrl.navigateBack("/layout/dineout-layout/dineout");
  }
  ngOnInit() {
    return __async(this, null, function* () {
      this.token = yield this.authServcie.getToken();
      this.restaurantId = this.route.snapshot.paramMap.get("id");
      if (this.restaurantId) {
        this.loadRestaurantData();
      }
    });
  }
  loadRestaurantData() {
    this.isLoading = true;
    this.isError = false;
    this.dineoutService.getRestaurantDetails(this.restaurantId).subscribe((res) => {
      const data = res.data;
      this.restaurantName = data.name;
      this.operatingHours = data.openingHours || [];
      this.offers = data.offers || [];
      if (this.offers.length > 0)
        this.selectedOffer = this.offers[0];
      this.generateDates();
      if (this.dates.length > 0) {
        this.selectDate(0);
      }
      this.isLoading = false;
    }, (err) => {
      console.error(err);
      this.isLoading = false;
      this.isError = true;
    });
  }
  generateDates() {
    if (!this.operatingHours || this.operatingHours.length === 0)
      return;
    const today = /* @__PURE__ */ new Date();
    const tempDates = [];
    for (let i = 0; i < 15; i++) {
      const d = new Date(today);
      d.setDate(today.getDate() + i);
      const dayName = d.toLocaleDateString("en-US", { weekday: "long" });
      const config = this.operatingHours.find((h) => h.day === dayName);
      if (config) {
        tempDates.push({
          fullDate: d,
          date: d.getDate().toString().padStart(2, "0"),
          day: i === 0 ? "Today" : d.toLocaleDateString("en-US", { weekday: "short" }),
          month: d.toLocaleDateString("en-US", { month: "short" }),
          dayConfig: config
        });
      }
    }
    this.dates = tempDates;
  }
  selectDate(index) {
    this.selectedDateIdx = index;
    const selectedDateObj = this.dates[index];
    const now = /* @__PURE__ */ new Date();
    const isToday = selectedDateObj.fullDate.getDate() === now.getDate() && selectedDateObj.fullDate.getMonth() === now.getMonth();
    if (selectedDateObj && selectedDateObj.dayConfig) {
      this.generateTimeSlots(selectedDateObj.dayConfig.slots, isToday);
    }
  }
  generateTimeSlots(ranges, isToday) {
    let allSlots = [];
    if (ranges) {
      ranges.forEach((range) => {
        const parts = range.split(" - ");
        if (parts.length === 2) {
          const slots = this.createSlotsFromRange(parts[0], parts[1], isToday);
          allSlots = [...allSlots, ...slots];
        }
      });
    }
    this.timeSlots = allSlots;
    const firstAvailable = this.timeSlots.find((s) => !s.disabled);
    this.selectedTimeSlot = firstAvailable ? firstAvailable.time : "";
  }
  createSlotsFromRange(startStr, endStr, isToday) {
    const generated = [];
    let startDate = this.parseTime(startStr);
    let endDate = this.parseTime(endStr);
    const now = /* @__PURE__ */ new Date();
    if (endDate < startDate)
      endDate.setDate(endDate.getDate() + 1);
    let current = new Date(startDate);
    while (current < endDate) {
      const timeString = current.toLocaleTimeString("en-US", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: true
      });
      const isDisabled = isToday && current < now;
      generated.push({
        time: timeString,
        disabled: isDisabled
      });
      current.setMinutes(current.getMinutes() + 30);
    }
    return generated;
  }
  parseTime(timeStr) {
    const d = /* @__PURE__ */ new Date();
    const [time, modifier] = timeStr.split(" ");
    let [hours, minutes] = time.split(":");
    let h = parseInt(hours);
    const m = parseInt(minutes);
    if (h === 12 && modifier === "AM")
      h = 0;
    else if (h !== 12 && modifier === "PM")
      h += 12;
    d.setHours(h, m, 0, 0);
    return d;
  }
  selectGuest(num) {
    this.selectedGuest = num;
  }
  selectTime(time) {
    this.selectedTimeSlot = time;
  }
  selectOffer(offer) {
    this.selectedOffer = offer;
  }
  proceed() {
    if (!this.selectedGuest || !this.selectedTimeSlot || this.selectedDateIdx === void 0 || this.selectedDateIdx < 0) {
      console.error("Please select guest count, date, and time slot.");
      return;
    }
    this.isLoading = true;
    this.isError = false;
    const selectedDateObj = this.dates[this.selectedDateIdx];
    const d = selectedDateObj.fullDate;
    const year = d.getFullYear();
    const month = (d.getMonth() + 1).toString().padStart(2, "0");
    const day = d.getDate().toString().padStart(2, "0");
    const formattedDate = `${year}-${month}-${day}`;
    const payload = {
      restaurantId: this.restaurantId || 1,
      // Ensure restaurantId is available in your class
      restaurantName: this.restaurantName,
      guestCount: this.selectedGuest,
      date: formattedDate,
      timeSlot: this.selectedTimeSlot,
      offerApplied: this.selectedOffer ? {
        type: this.selectedOffer.type || "FLAT",
        // Ensure these properties exist on your offer object
        title: this.selectedOffer.title,
        value: this.selectedOffer.value || 0,
        description: this.selectedOffer.description
      } : null,
      billDetails: {
        coverChargePerHead: this.coverCharge || 0,
        totalAmount: this.coverCharge,
        verification: {
          discount: "00.00",
          verifiedAt: /* @__PURE__ */ new Date(),
          finalAmount: "0.00",
          originalAmount: "0.00"
        }
      }
    };
    this.dineoutService.createOrder(this.token, payload).subscribe({
      next: (response) => {
        this.isLoading = false;
        console.log("Order Created Successfully", response);
        this.navCtrl.navigateRoot(`/layout/dineout-layout/dineout-track/${response.data.id}`, {
          state: {
            from: "time-slot"
          }
        });
      },
      error: (error) => {
        this.isLoading = false;
        this.isError = true;
        console.error("Failed to create order", error);
      }
    });
  }
  presentToast(message, color) {
    return __async(this, null, function* () {
      const toast = yield this.toastCtrl.create({
        message,
        duration: 2500,
        color,
        position: "bottom",
        buttons: [{ text: "OK", role: "cancel" }]
      });
      toast.present();
    });
  }
};
_DineoutSelectTimePage.\u0275fac = function DineoutSelectTimePage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _DineoutSelectTimePage)(\u0275\u0275directiveInject(ActivatedRoute), \u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(DineoutService), \u0275\u0275directiveInject(ToastController), \u0275\u0275directiveInject(LoadingController), \u0275\u0275directiveInject(AuthService));
};
_DineoutSelectTimePage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _DineoutSelectTimePage, selectors: [["app-dineout-select-time"]], decls: 14, vars: 2, consts: [[1, "ion-no-border", "bg-white", "pt-2"], ["slot", "start"], [3, "click"], ["name", "arrow-back-outline", "color", "dark"], [1, "fw-bold", "text-dark"], [1, "bg-white"], [1, "content-padding"], ["title", "Oops! Slots Selection failed to load"], [1, "sticky-footer"], [1, "proceed-btn", 3, "click", "disabled"], ["animated", "", 2, "width", "100%", "height", "36px", "border-radius", "4px", "margin-bottom", "24px", "opacity", "0.5"], [1, "section"], ["animated", "", 2, "width", "40%", "height", "20px", "margin-bottom", "12px", "border-radius", "4px"], [2, "display", "flex", "gap", "10px", "overflow", "hidden"], ["animated", "", "style", "width: 50px; height: 45px; border-radius: 8px;", 4, "ngFor", "ngForOf"], ["animated", "", 2, "width", "50%", "height", "20px", "margin-bottom", "12px", "border-radius", "4px"], ["animated", "", "style", "min-width: 72px; height: 75px; border-radius: 12px;", 4, "ngFor", "ngForOf"], ["animated", "", 2, "width", "30%", "height", "20px", "margin-bottom", "12px", "border-radius", "4px"], [2, "display", "grid", "grid-template-columns", "repeat(4, 1fr)", "gap", "10px"], ["animated", "", "style", "height: 40px; border-radius: 8px;", 4, "ngFor", "ngForOf"], ["animated", "", 2, "width", "60%", "height", "20px", "margin-bottom", "12px", "border-radius", "4px"], ["animated", "", 2, "width", "100%", "height", "90px", "border-radius", "12px"], ["animated", "", 2, "width", "50px", "height", "45px", "border-radius", "8px"], ["animated", "", 2, "min-width", "72px", "height", "75px", "border-radius", "12px"], ["animated", "", 2, "height", "40px", "border-radius", "8px"], ["title", "Oops! Slots Selection failed to load", 3, "reload"], [1, "green-banner"], [1, "scroll-row"], ["class", "guest-chip", 3, "selected", "click", 4, "ngFor", "ngForOf"], [1, "scroll-row", "dates-row"], ["class", "date-card-wrapper", 3, "click", 4, "ngFor", "ngForOf"], [1, "section", "slots-container"], [1, "slot-header"], ["class", "slots-grid", 4, "ngIf"], ["class", "no-slots", 4, "ngIf"], ["class", "section", 4, "ngIf"], [2, "height", "100px"], ["src", "https://cdn-icons-png.flaticon.com/512/2534/2534204.png", "width", "16"], [1, "guest-chip", 3, "click"], [1, "date-card-wrapper", 3, "click"], ["class", "month-separator", 4, "ngIf"], [1, "date-card"], [1, "d-val"], [1, "d-day"], [1, "month-separator"], [1, "slots-grid"], ["class", "time-chip", 3, "selected", "disabled", "click", 4, "ngFor", "ngForOf"], [1, "time-chip", 3, "click"], [1, "t-val"], [1, "no-slots"], [4, "ngIf"], ["class", "offer-card", 3, "selected", "click", 4, "ngFor", "ngForOf"], [1, "offer-note"], ["name", "information-circle-outline"], [1, "offer-card", 3, "click"], [1, "radio-row"], [1, "custom-radio"], ["class", "dot", 4, "ngIf"], [1, "text-col"], [1, "main-offer"], [1, "sub-offer"], [1, "dot-sep"], ["class", "tag-row", 4, "ngIf"], [1, "dot"], [1, "tag-row"], [1, "user-tag"], [1, "no-offer-card"], [1, "icon-circle"], ["name", "gift-outline"]], template: function DineoutSelectTimePage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar")(2, "ion-buttons", 1)(3, "ion-button", 2);
    \u0275\u0275listener("click", function DineoutSelectTimePage_Template_ion_button_click_3_listener() {
      return ctx.goBack();
    });
    \u0275\u0275element(4, "ion-icon", 3);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "ion-title", 4);
    \u0275\u0275text(6, "Book Table");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(7, "ion-content", 5);
    \u0275\u0275template(8, DineoutSelectTimePage_Conditional_8_Template, 17, 6, "div", 6)(9, DineoutSelectTimePage_Conditional_9_Template, 1, 0, "app-error", 7)(10, DineoutSelectTimePage_Conditional_10_Template, 19, 6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "ion-footer", 8)(12, "button", 9);
    \u0275\u0275listener("click", function DineoutSelectTimePage_Template_button_click_12_listener() {
      return ctx.proceed();
    });
    \u0275\u0275text(13, " Book Slot Now ");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(8);
    \u0275\u0275conditional(ctx.isLoading ? 8 : ctx.isError ? 9 : 10);
    \u0275\u0275advance(4);
    \u0275\u0275property("disabled", ctx.isLoading);
  }
}, dependencies: [IonicModule, IonButton, IonButtons, IonContent, IonFooter, IonHeader, IonIcon, IonSkeletonText, IonTitle, IonToolbar, CommonModule, NgForOf, NgIf, FormsModule, ErrorComponent], styles: ["\n\n[_nghost-%COMP%] {\n  --green-accent: #24963f;\n}\nion-toolbar[_ngcontent-%COMP%] {\n  --background: #fff;\n}\nion-toolbar[_ngcontent-%COMP%]   .header-title[_ngcontent-%COMP%] {\n  padding-left: 0;\n}\nion-toolbar[_ngcontent-%COMP%]   .header-title[_ngcontent-%COMP%]   .main-text[_ngcontent-%COMP%] {\n  font-size: 18px;\n  font-weight: 700;\n  color: #111;\n  line-height: 1.2;\n}\nion-toolbar[_ngcontent-%COMP%]   .header-title[_ngcontent-%COMP%]   .sub-text[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #666;\n  font-weight: 400;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.bg-white[_ngcontent-%COMP%] {\n  --background: #fff;\n}\n.green-banner[_ngcontent-%COMP%] {\n  background: #e8f8ee;\n  color: #0f5132;\n  font-size: 12px;\n  font-weight: 600;\n  padding: 8px 16px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 8px;\n}\n.green-banner[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  filter: invert(26%) sepia(13%) saturate(1966%) hue-rotate(94deg) brightness(96%) contrast(93%);\n}\n.content-padding[_ngcontent-%COMP%] {\n  padding: 20px 16px;\n}\nh3[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 700;\n  color: #111;\n  margin: 0 0 12px 0;\n}\n.section[_ngcontent-%COMP%] {\n  margin-bottom: 28px;\n}\n.scroll-row[_ngcontent-%COMP%] {\n  display: flex;\n  overflow-x: auto;\n  gap: 10px;\n  padding-bottom: 5px;\n  padding-right: 5px;\n}\n.scroll-row[_ngcontent-%COMP%]::-webkit-scrollbar {\n  display: none;\n}\n.guest-chip[_ngcontent-%COMP%] {\n  min-width: 50px;\n  height: 45px;\n  border: 1px solid #e0e0e0;\n  border-radius: 8px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-weight: 600;\n  color: #333;\n  font-size: 16px;\n  transition: all 0.2s;\n  color: var(--grocery-theme-color);\n}\n.guest-chip.selected[_ngcontent-%COMP%] {\n  border-color: var(--grocery-theme-color);\n  background: var(--grocery-theme-color-light);\n  color: var(--grocery-theme-color);\n}\n.dates-row[_ngcontent-%COMP%] {\n  align-items: center;\n}\n.date-card-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.month-separator[_ngcontent-%COMP%] {\n  writing-mode: vertical-rl;\n  text-orientation: mixed;\n  transform: rotate(180deg);\n  background: #f4f5f8;\n  padding: 8px 4px;\n  border-radius: 20px;\n  font-size: 10px;\n  color: #666;\n  height: 60px;\n  text-align: center;\n}\n.date-card[_ngcontent-%COMP%] {\n  min-width: 72px;\n  padding: 10px 0;\n  border: 1px solid #e0e0e0;\n  border-radius: 12px;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  position: relative;\n}\n.date-card[_ngcontent-%COMP%]   .d-val[_ngcontent-%COMP%] {\n  font-size: 18px;\n  font-weight: 700;\n  color: var(--grocery-theme-color);\n}\n.date-card[_ngcontent-%COMP%]   .d-day[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #666;\n  margin-bottom: 6px;\n}\n.date-card[_ngcontent-%COMP%]   .d-offer[_ngcontent-%COMP%] {\n  background: var(--green-accent);\n  color: white;\n  font-size: 10px;\n  padding: 2px 6px;\n  border-radius: 10px;\n  font-weight: 700;\n}\n.date-card.selected[_ngcontent-%COMP%] {\n  background: var(--grocery-theme-color-light);\n  border-color: var(--grocery-theme-color);\n}\n.date-card.selected[_ngcontent-%COMP%]   .d-val[_ngcontent-%COMP%] {\n  color: var(--grocery-theme-color);\n}\n.date-card.selected[_ngcontent-%COMP%]   .d-day[_ngcontent-%COMP%] {\n  color: #333;\n}\n.slots-container[_ngcontent-%COMP%] {\n  background: #f9f9f9;\n  padding: 16px;\n  border-radius: 16px;\n}\n.slot-header[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  font-size: 14px;\n  font-weight: 700;\n  color: #111;\n  margin-bottom: 12px;\n}\n.slots-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(4, 1fr);\n  gap: 10px;\n}\n.time-chip[_ngcontent-%COMP%] {\n  background: white;\n  border: 1px solid transparent;\n  border-radius: 8px;\n  padding: 8px 2px;\n  text-align: center;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);\n}\n.time-chip[_ngcontent-%COMP%]   .t-val[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 700;\n  color: #333;\n  margin-bottom: 2px;\n}\n.time-chip[_ngcontent-%COMP%]   .t-off[_ngcontent-%COMP%] {\n  font-size: 10px;\n  color: #666;\n}\n.time-chip.selected[_ngcontent-%COMP%] {\n  border-color: var(--grocery-theme-color);\n  background: var(--grocery-theme-color-light);\n}\n.time-chip.selected[_ngcontent-%COMP%]   .t-val[_ngcontent-%COMP%], \n.time-chip.selected[_ngcontent-%COMP%]   .t-off[_ngcontent-%COMP%] {\n  color: var(--grocery-theme-color);\n}\n.time-chip.disabled[_ngcontent-%COMP%] {\n  opacity: 0.4;\n  pointer-events: none;\n  background: #f0f0f0;\n}\n.no-slots[_ngcontent-%COMP%] {\n  font-size: 13px;\n  color: #888;\n  text-align: center;\n  width: 100%;\n  padding: 10px;\n}\n.view-more[_ngcontent-%COMP%] {\n  text-align: center;\n  font-size: 12px;\n  color: var(--grocery-theme-color);\n  font-weight: 700;\n  margin-top: 15px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 4px;\n}\n.offer-card[_ngcontent-%COMP%] {\n  border: 1px solid #e0e0e0;\n  border-radius: 12px;\n  padding: 16px;\n  position: relative;\n}\n.offer-card.selected[_ngcontent-%COMP%] {\n  border-color: var(--grocery-theme-color);\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);\n}\n.offer-card[_ngcontent-%COMP%]   .card-header[_ngcontent-%COMP%] {\n  margin-bottom: 10px;\n}\n.offer-card[_ngcontent-%COMP%]   .card-header[_ngcontent-%COMP%]   .brand-logo[_ngcontent-%COMP%] {\n  color: #de5646;\n  font-weight: 800;\n  font-style: italic;\n  font-size: 16px;\n}\n.offer-card[_ngcontent-%COMP%]   .card-header[_ngcontent-%COMP%]   .brand-logo[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: #de5646;\n  font-weight: 400;\n  letter-spacing: 1px;\n  font-size: 12px;\n}\n.offer-card[_ngcontent-%COMP%]   .radio-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-start;\n  gap: 10px;\n}\n.offer-card[_ngcontent-%COMP%]   .custom-radio[_ngcontent-%COMP%] {\n  width: 18px;\n  height: 18px;\n  border: 2px solid var(--grocery-theme-color);\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin-top: 2px;\n}\n.offer-card[_ngcontent-%COMP%]   .custom-radio[_ngcontent-%COMP%]   .dot[_ngcontent-%COMP%] {\n  width: 10px;\n  height: 10px;\n  background: var(--grocery-theme-color);\n  border-radius: 50%;\n}\n.offer-card[_ngcontent-%COMP%]   .text-col[_ngcontent-%COMP%]   .main-offer[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 700;\n  color: #111;\n  margin-bottom: 4px;\n}\n.offer-card[_ngcontent-%COMP%]   .text-col[_ngcontent-%COMP%]   .sub-offer[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #666;\n}\n.sticky-footer[_ngcontent-%COMP%] {\n  background: white;\n  padding: 12px 16px 20px;\n  box-shadow: 0 -4px 10px rgba(0, 0, 0, 0.05);\n}\n.sticky-footer[_ngcontent-%COMP%]   .proceed-btn[_ngcontent-%COMP%] {\n  width: 100%;\n  background: var(--grocery-theme-color);\n  color: white;\n  border: none;\n  padding: 14px;\n  border-radius: 8px;\n  font-size: 16px;\n  font-weight: 700;\n  letter-spacing: 0.5px;\n}\n.sticky-footer[_ngcontent-%COMP%]   .proceed-btn[_ngcontent-%COMP%]:active {\n  opacity: 0.9;\n  transform: scale(0.98);\n}\n.offer-card[_ngcontent-%COMP%] {\n  border: 1px solid #e0e0e0;\n  border-radius: 12px;\n  padding: 16px;\n  position: relative;\n  background: #fff;\n  transition: all 0.2s ease;\n  margin-bottom: 12px;\n}\n.offer-card.selected[_ngcontent-%COMP%] {\n  border-color: var(--grocery-theme-color);\n  background-color: var(--grocery-theme-color-light);\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);\n}\n.offer-card.selected[_ngcontent-%COMP%]   .custom-radio[_ngcontent-%COMP%] {\n  border-color: var(--grocery-theme-color);\n}\n.offer-card[_ngcontent-%COMP%]   .card-header[_ngcontent-%COMP%] {\n  margin-bottom: 10px;\n  padding-bottom: 8px;\n  border-bottom: 1px dashed #eee;\n}\n.offer-card[_ngcontent-%COMP%]   .card-header[_ngcontent-%COMP%]   .brand-logo[_ngcontent-%COMP%] {\n  color: #de5646;\n  font-weight: 800;\n  font-style: italic;\n  font-size: 14px;\n}\n.offer-card[_ngcontent-%COMP%]   .card-header[_ngcontent-%COMP%]   .brand-logo[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: #de5646;\n  font-weight: 600;\n  letter-spacing: 1px;\n  font-size: 10px;\n  background: #ffebe9;\n  padding: 2px 6px;\n  border-radius: 4px;\n  margin-left: 4px;\n}\n.offer-card[_ngcontent-%COMP%]   .radio-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-start;\n  gap: 12px;\n}\n.offer-card[_ngcontent-%COMP%]   .custom-radio[_ngcontent-%COMP%] {\n  width: 20px;\n  height: 20px;\n  border: 2px solid #ccc;\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin-top: 2px;\n  flex-shrink: 0;\n}\n.offer-card[_ngcontent-%COMP%]   .custom-radio[_ngcontent-%COMP%]   .dot[_ngcontent-%COMP%] {\n  width: 10px;\n  height: 10px;\n  background: var(--grocery-theme-color);\n  border-radius: 50%;\n}\n.offer-card[_ngcontent-%COMP%]   .text-col[_ngcontent-%COMP%] {\n  flex: 1;\n}\n.offer-card[_ngcontent-%COMP%]   .text-col[_ngcontent-%COMP%]   .main-offer[_ngcontent-%COMP%] {\n  font-size: 15px;\n  font-weight: 700;\n  color: #111;\n  margin-bottom: 4px;\n}\n.offer-card[_ngcontent-%COMP%]   .text-col[_ngcontent-%COMP%]   .sub-offer[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #666;\n  line-height: 1.4;\n}\n.offer-card[_ngcontent-%COMP%]   .text-col[_ngcontent-%COMP%]   .sub-offer[_ngcontent-%COMP%]   .dot-sep[_ngcontent-%COMP%] {\n  margin: 0 4px;\n  color: #ccc;\n}\n.offer-card[_ngcontent-%COMP%]   .text-col[_ngcontent-%COMP%]   .tag-row[_ngcontent-%COMP%] {\n  margin-top: 6px;\n}\n.offer-card[_ngcontent-%COMP%]   .text-col[_ngcontent-%COMP%]   .tag-row[_ngcontent-%COMP%]   .user-tag[_ngcontent-%COMP%] {\n  font-size: 10px;\n  background: #e3f2fd;\n  color: #1565c0;\n  padding: 2px 6px;\n  border-radius: 4px;\n  font-weight: 600;\n}\n.offer-note[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-start;\n  gap: 8px;\n  background: #f8f9fa;\n  border: 1px dashed #ced4da;\n  padding: 10px 12px;\n  border-radius: 8px;\n  margin-top: 16px;\n}\n.offer-note[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n  color: #6c757d;\n  min-width: 18px;\n  margin-top: 2px;\n}\n.offer-note[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 11px;\n  color: #555;\n  line-height: 1.4;\n}\n.offer-note[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: #333;\n}\n.no-offer-card[_ngcontent-%COMP%] {\n  text-align: center;\n  padding: 24px 16px;\n  background: #fff;\n  border: 1px solid #eee;\n  border-radius: 12px;\n  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.03);\n}\n.no-offer-card[_ngcontent-%COMP%]   .icon-circle[_ngcontent-%COMP%] {\n  width: 48px;\n  height: 48px;\n  background: var(--grocery-theme-color-light);\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin: 0 auto 12px;\n}\n.no-offer-card[_ngcontent-%COMP%]   .icon-circle[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 24px;\n  color: var(--grocery-theme-color);\n}\n.no-offer-card[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  margin: 0 0 6px;\n  font-size: 15px;\n  font-weight: 700;\n  color: #111;\n}\n.no-offer-card[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 12px;\n  color: #666;\n  line-height: 1.5;\n}\n/*# sourceMappingURL=dineout-select-time.page.css.map */"] });
var DineoutSelectTimePage = _DineoutSelectTimePage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(DineoutSelectTimePage, { className: "DineoutSelectTimePage", filePath: "src/app/pages/dineout-select-time/dineout-select-time.page.ts", lineNumber: 22 });
})();
export {
  DineoutSelectTimePage
};
//# sourceMappingURL=dineout-select-time.page-YN2IVZVJ.js.map
