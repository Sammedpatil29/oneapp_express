import {
  Host,
  h,
  registerInstance
} from "./chunk-L4P3BNFI.js";
import "./chunk-6B6DTIB5.js";

// node_modules/@ionic/core/dist/esm/ion-segment-content.entry.js
var segmentContentCss = ":host{scroll-snap-align:center;scroll-snap-stop:always;-ms-flex-negative:0;flex-shrink:0;width:100%}";
var IonSegmentContentStyle0 = segmentContentCss;
var SegmentContent = class {
  constructor(hostRef) {
    registerInstance(this, hostRef);
  }
  render() {
    return h(Host, {
      key: "03684b2999ac64fe13e376fd7e7f279976e9d4f2"
    }, h("slot", {
      key: "143031075bf33ca19e7cfd76fc8a67b83ccaf11c"
    }));
  }
};
SegmentContent.style = IonSegmentContentStyle0;
export {
  SegmentContent as ion_segment_content
};
/*! Bundled license information:

@ionic/core/dist/esm/ion-segment-content.entry.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
//# sourceMappingURL=ion-segment-content.entry-5V6OXG4P.js.map
