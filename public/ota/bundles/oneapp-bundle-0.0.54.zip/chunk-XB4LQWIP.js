import {
  environment
} from "./chunk-YJYUHAOC.js";
import {
  App
} from "./chunk-EBMCUG2R.js";
import {
  HttpClient,
  HttpHeaders,
  ɵɵdefineInjectable,
  ɵɵinject
} from "./chunk-Z7XNNJSA.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/services/profile.service.ts
var _ProfileService = class _ProfileService {
  constructor(http) {
    this.http = http;
    this.profileUrl = "https://oneapp-backend.onrender.com/api/users/";
    this.suggestion = "https://oneapp-backend.onrender.com/api/suggestions/";
    this.updateDetails = "https://oneapp-backend.onrender.com/api/address/";
    this.bannerUrl = "https://oneapp-backend.onrender.com/api/banner/banners/";
    this.url = environment.apiUrl;
  }
  // getProfileData(params:any){
  //   return this.http.post(`${this.profileUrl}user-by-token/`, params)
  // }
  getProfileData(token) {
    const headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.get(`${this.url}/user`, { headers });
  }
  getAppVersion() {
    return __async(this, null, function* () {
      try {
        const appInfo = yield App.getInfo();
        const appVersion = appInfo.version;
        console.log("App Version:", appVersion);
        return appVersion;
      } catch (error) {
        console.error("Error retrieving app version", error);
        return null;
      }
    });
  }
  deleteProfilePermanently(params, id) {
    return this.http.post(`${this.profileUrl}delete-user/`, params);
  }
  postSuggestion(params, token) {
    let headers;
    if (token) {
      headers = new HttpHeaders({ "Authorization": `Bearer ${token}` });
    }
    return this.http.post(`${this.url}/api/suggestions`, params, headers ? { headers } : {});
  }
  updateUser(params, token) {
    const headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.patch(`${this.url}/user`, params, { headers });
  }
  getBanners(type) {
    return this.http.get(`${this.bannerUrl}?type=${type}`);
  }
};
_ProfileService.\u0275fac = function ProfileService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _ProfileService)(\u0275\u0275inject(HttpClient));
};
_ProfileService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _ProfileService, factory: _ProfileService.\u0275fac, providedIn: "root" });
var ProfileService = _ProfileService;

export {
  ProfileService
};
//# sourceMappingURL=chunk-XB4LQWIP.js.map
