import {
  environment
} from "./chunk-YJYUHAOC.js";
import {
  BehaviorSubject,
  ɵɵdefineInjectable
} from "./chunk-Z7XNNJSA.js";
import {
  Capacitor,
  registerPlugin
} from "./chunk-FH4NU4VH.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// node_modules/@capacitor-community/admob/dist/esm/definitions.js
var MaxAdContentRating;
(function(MaxAdContentRating2) {
  MaxAdContentRating2["General"] = "General";
  MaxAdContentRating2["ParentalGuidance"] = "ParentalGuidance";
  MaxAdContentRating2["Teen"] = "Teen";
  MaxAdContentRating2["MatureAudience"] = "MatureAudience";
})(MaxAdContentRating || (MaxAdContentRating = {}));

// node_modules/@capacitor-community/admob/dist/esm/banner/banner-ad-plugin-events.enum.js
var BannerAdPluginEvents;
(function(BannerAdPluginEvents2) {
  BannerAdPluginEvents2["SizeChanged"] = "bannerAdSizeChanged";
  BannerAdPluginEvents2["Loaded"] = "bannerAdLoaded";
  BannerAdPluginEvents2["FailedToLoad"] = "bannerAdFailedToLoad";
  BannerAdPluginEvents2["Opened"] = "bannerAdOpened";
  BannerAdPluginEvents2["Closed"] = "bannerAdClosed";
  BannerAdPluginEvents2["AdImpression"] = "bannerAdImpression";
})(BannerAdPluginEvents || (BannerAdPluginEvents = {}));

// node_modules/@capacitor-community/admob/dist/esm/banner/banner-ad-position.enum.js
var BannerAdPosition;
(function(BannerAdPosition2) {
  BannerAdPosition2["TOP_CENTER"] = "TOP_CENTER";
  BannerAdPosition2["CENTER"] = "CENTER";
  BannerAdPosition2["BOTTOM_CENTER"] = "BOTTOM_CENTER";
})(BannerAdPosition || (BannerAdPosition = {}));

// node_modules/@capacitor-community/admob/dist/esm/banner/banner-ad-size.enum.js
var BannerAdSize;
(function(BannerAdSize2) {
  BannerAdSize2["BANNER"] = "BANNER";
  BannerAdSize2["FULL_BANNER"] = "FULL_BANNER";
  BannerAdSize2["LARGE_BANNER"] = "LARGE_BANNER";
  BannerAdSize2["MEDIUM_RECTANGLE"] = "MEDIUM_RECTANGLE";
  BannerAdSize2["LEADERBOARD"] = "LEADERBOARD";
  BannerAdSize2["ADAPTIVE_BANNER"] = "ADAPTIVE_BANNER";
  BannerAdSize2["SMART_BANNER"] = "SMART_BANNER";
})(BannerAdSize || (BannerAdSize = {}));

// node_modules/@capacitor-community/admob/dist/esm/interstitial/interstitial-ad-plugin-events.enum.js
var InterstitialAdPluginEvents;
(function(InterstitialAdPluginEvents2) {
  InterstitialAdPluginEvents2["Loaded"] = "interstitialAdLoaded";
  InterstitialAdPluginEvents2["FailedToLoad"] = "interstitialAdFailedToLoad";
  InterstitialAdPluginEvents2["Showed"] = "interstitialAdShowed";
  InterstitialAdPluginEvents2["FailedToShow"] = "interstitialAdFailedToShow";
  InterstitialAdPluginEvents2["Dismissed"] = "interstitialAdDismissed";
})(InterstitialAdPluginEvents || (InterstitialAdPluginEvents = {}));

// node_modules/@capacitor-community/admob/dist/esm/reward-interstitial/reward-interstitial-ad-plugin-events.enum.js
var RewardInterstitialAdPluginEvents;
(function(RewardInterstitialAdPluginEvents2) {
  RewardInterstitialAdPluginEvents2["Loaded"] = "onRewardedInterstitialAdLoaded";
  RewardInterstitialAdPluginEvents2["FailedToLoad"] = "onRewardedInterstitialAdFailedToLoad";
  RewardInterstitialAdPluginEvents2["Showed"] = "onRewardedInterstitialAdShowed";
  RewardInterstitialAdPluginEvents2["FailedToShow"] = "onRewardedInterstitialAdFailedToShow";
  RewardInterstitialAdPluginEvents2["Dismissed"] = "onRewardedInterstitialAdDismissed";
  RewardInterstitialAdPluginEvents2["Rewarded"] = "onRewardedInterstitialAdReward";
})(RewardInterstitialAdPluginEvents || (RewardInterstitialAdPluginEvents = {}));

// node_modules/@capacitor-community/admob/dist/esm/reward/reward-ad-plugin-events.enum.js
var RewardAdPluginEvents;
(function(RewardAdPluginEvents2) {
  RewardAdPluginEvents2["Loaded"] = "onRewardedVideoAdLoaded";
  RewardAdPluginEvents2["FailedToLoad"] = "onRewardedVideoAdFailedToLoad";
  RewardAdPluginEvents2["Showed"] = "onRewardedVideoAdShowed";
  RewardAdPluginEvents2["FailedToShow"] = "onRewardedVideoAdFailedToShow";
  RewardAdPluginEvents2["Dismissed"] = "onRewardedVideoAdDismissed";
  RewardAdPluginEvents2["Rewarded"] = "onRewardedVideoAdReward";
})(RewardAdPluginEvents || (RewardAdPluginEvents = {}));

// node_modules/@capacitor-community/admob/dist/esm/consent/consent-debug-geography.enum.js
var AdmobConsentDebugGeography;
(function(AdmobConsentDebugGeography2) {
  AdmobConsentDebugGeography2[AdmobConsentDebugGeography2["DISABLED"] = 0] = "DISABLED";
  AdmobConsentDebugGeography2[AdmobConsentDebugGeography2["EEA"] = 1] = "EEA";
  AdmobConsentDebugGeography2[AdmobConsentDebugGeography2["NOT_EEA"] = 2] = "NOT_EEA";
  AdmobConsentDebugGeography2[AdmobConsentDebugGeography2["US"] = 3] = "US";
  AdmobConsentDebugGeography2[AdmobConsentDebugGeography2["OTHER"] = 4] = "OTHER";
})(AdmobConsentDebugGeography || (AdmobConsentDebugGeography = {}));

// node_modules/@capacitor-community/admob/dist/esm/index.js
var AdMob = registerPlugin("AdMob", {
  web: () => import("./web-K2IH32HP.js").then((m) => new m.AdMobWeb())
});

// src/app/services/admob.service.ts
var _AdmobService = class _AdmobService {
  constructor() {
    this.GOOGLE_TEST_BANNER_ID = "ca-app-pub-3940256099942544/6300978111";
    this.GOOGLE_TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712";
    this.GOOGLE_TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917";
    this.isInitialized = false;
    this.isBannerVisible = false;
    this.isBannerLoadedSubject = new BehaviorSubject(false);
    this.isBannerLoaded$ = this.isBannerLoadedSubject.asObservable();
    if (Capacitor.isNativePlatform()) {
      this.removeBanner().catch(() => {
      });
      if (this.isAdsEnabled()) {
        this.initialize();
      } else {
        console.log("\u{1F6D1} [AdMob] Ads are disabled via configuration (admob.enabled = false).");
      }
    }
  }
  /**
   * Check if ads are enabled in the environment configuration
   */
  isAdsEnabled() {
    var _a, _b;
    return ((_b = (_a = environment) == null ? void 0 : _a.admob) == null ? void 0 : _b.enabled) === true;
  }
  /**
   * Check if running on Android/iOS native runtime
   */
  isNative() {
    return Capacitor.isNativePlatform();
  }
  /**
   * Initialize AdMob SDK and register banner lifecycle listeners
   */
  initialize() {
    return __async(this, null, function* () {
      var _a, _b, _c;
      if (!this.isNative()) {
        console.log("\u2139\uFE0F [AdMob] Web platform detected - Native ads are disabled in browser mode.");
        return;
      }
      if (!this.isAdsEnabled()) {
        console.log("\u{1F6D1} [AdMob] Ads disabled in environment. Skipping initialization.");
        return;
      }
      if (this.isInitialized) {
        return;
      }
      try {
        const isTesting = (_c = (_b = (_a = environment) == null ? void 0 : _a.admob) == null ? void 0 : _b.isTesting) != null ? _c : true;
        yield AdMob.initialize({
          initializeForTesting: isTesting
        });
        this.isInitialized = true;
        console.log("\u2705 [AdMob] Google Mobile Ads SDK initialized successfully.");
        this.registerBannerListeners();
      } catch (error) {
        console.error("\u274C [AdMob] Initialization failed:", error);
      }
    });
  }
  /**
   * Register event listeners for Banner Ad
   */
  registerBannerListeners() {
    AdMob.addListener(BannerAdPluginEvents.Loaded, () => {
      console.log("\u{1F4E2} [AdMob] Banner Ad Loaded");
      this.isBannerLoadedSubject.next(true);
    });
    AdMob.addListener(BannerAdPluginEvents.FailedToLoad, (error) => {
      console.warn("\u26A0\uFE0F [AdMob] Banner Ad Failed to Load:", error);
      this.isBannerLoadedSubject.next(false);
    });
    AdMob.addListener(BannerAdPluginEvents.Opened, () => {
      console.log("\u{1F4E2} [AdMob] Banner Ad Opened");
    });
    AdMob.addListener(BannerAdPluginEvents.Closed, () => {
      console.log("\u{1F4E2} [AdMob] Banner Ad Closed");
    });
    AdMob.addListener(BannerAdPluginEvents.SizeChanged, (size) => {
      console.log("\u{1F4E2} [AdMob] Banner Ad Size Changed:", size);
    });
  }
  /**
   * Show a Banner Ad on the screen
   * @param customOptions Custom position, margin, adSize, etc.
   */
  showBanner(customOptions) {
    return __async(this, null, function* () {
      var _a, _b;
      if (!this.isNative() || !this.isAdsEnabled()) {
        if (this.isNative()) {
          this.removeBanner().catch(() => {
          });
        }
        return;
      }
      if (!this.isInitialized) {
        yield this.initialize();
      }
      const envConfig = (_a = environment) == null ? void 0 : _a.admob;
      const adUnitId = (envConfig == null ? void 0 : envConfig.bannerAdUnitId) || this.GOOGLE_TEST_BANNER_ID;
      const isTesting = (_b = envConfig == null ? void 0 : envConfig.isTesting) != null ? _b : true;
      const options = {
        adId: adUnitId,
        adSize: (customOptions == null ? void 0 : customOptions.adSize) || BannerAdSize.ADAPTIVE_BANNER,
        position: (customOptions == null ? void 0 : customOptions.position) || BannerAdPosition.BOTTOM_CENTER,
        margin: (customOptions == null ? void 0 : customOptions.margin) !== void 0 ? customOptions.margin : 60,
        isTesting
      };
      try {
        yield AdMob.showBanner(options);
        this.isBannerVisible = true;
        console.log("\u{1F3AF} [AdMob] showBanner requested with adUnitId:", adUnitId);
      } catch (error) {
        console.error("\u274C [AdMob] Failed to show banner:", error);
      }
    });
  }
  /**
   * Hide the banner ad (keeps it in memory to resume quickly)
   */
  hideBanner() {
    return __async(this, null, function* () {
      if (!this.isNative() || !this.isBannerVisible) {
        return;
      }
      try {
        yield AdMob.hideBanner();
        this.isBannerVisible = false;
        console.log("\u{1F648} [AdMob] Banner hidden");
      } catch (error) {
        console.warn("\u26A0\uFE0F [AdMob] Error hiding banner:", error);
      }
    });
  }
  /**
   * Resume displaying a previously hidden banner ad
   */
  resumeBanner() {
    return __async(this, null, function* () {
      if (!this.isNative() || !this.isAdsEnabled()) {
        return;
      }
      try {
        yield AdMob.resumeBanner();
        this.isBannerVisible = true;
        console.log("\u{1F441}\uFE0F [AdMob] Banner resumed");
      } catch (error) {
        console.warn("\u26A0\uFE0F [AdMob] Error resuming banner:", error);
      }
    });
  }
  /**
   * Destroy and remove the banner ad from the view hierarchy
   */
  removeBanner() {
    return __async(this, null, function* () {
      if (!this.isNative()) {
        return;
      }
      try {
        yield AdMob.removeBanner();
        this.isBannerVisible = false;
        this.isBannerLoadedSubject.next(false);
        console.log("\u{1F5D1}\uFE0F [AdMob] Banner removed");
      } catch (error) {
        console.warn("\u26A0\uFE0F [AdMob] Error removing banner:", error);
      }
    });
  }
  /**
   * Show Interstitial Ad (for future full-screen ad opportunities)
   */
  showInterstitial() {
    return __async(this, null, function* () {
      var _a, _b;
      if (!this.isNative() || !this.isAdsEnabled()) {
        return;
      }
      if (!this.isInitialized) {
        yield this.initialize();
      }
      const envConfig = (_a = environment) == null ? void 0 : _a.admob;
      const adUnitId = (envConfig == null ? void 0 : envConfig.interstitialAdUnitId) || this.GOOGLE_TEST_INTERSTITIAL_ID;
      const isTesting = (_b = envConfig == null ? void 0 : envConfig.isTesting) != null ? _b : true;
      try {
        yield AdMob.prepareInterstitial({
          adId: adUnitId,
          isTesting
        });
        yield AdMob.showInterstitial();
        console.log("\u{1F3AF} [AdMob] Interstitial ad shown");
      } catch (error) {
        console.error("\u274C [AdMob] Failed to show interstitial:", error);
      }
    });
  }
  /**
   * Show Rewarded Video Ad (e.g. for bonus wallet points / discounts)
   */
  showRewardVideo() {
    return __async(this, null, function* () {
      var _a, _b;
      if (!this.isNative() || !this.isAdsEnabled()) {
        return false;
      }
      if (!this.isInitialized) {
        yield this.initialize();
      }
      const envConfig = (_a = environment) == null ? void 0 : _a.admob;
      const adUnitId = (envConfig == null ? void 0 : envConfig.rewardedAdUnitId) || this.GOOGLE_TEST_REWARDED_ID;
      const isTesting = (_b = envConfig == null ? void 0 : envConfig.isTesting) != null ? _b : true;
      try {
        yield AdMob.prepareRewardVideoAd({
          adId: adUnitId,
          isTesting
        });
        const rewardItem = yield AdMob.showRewardVideoAd();
        console.log("\u{1F381} [AdMob] User rewarded:", rewardItem);
        return true;
      } catch (error) {
        console.error("\u274C [AdMob] Failed to show reward ad:", error);
        return false;
      }
    });
  }
  /**
   * Compatibility methods for legacy banner ad requests (e.g. track-order page)
   */
  displayBannerAd(adUnitId) {
    if (this.isNative() && this.isAdsEnabled()) {
      this.showBanner();
    } else if (this.isNative()) {
      this.removeBanner().catch(() => {
      });
    }
  }
  initBannerAd(adUnitId) {
    if (this.isNative() && this.isAdsEnabled()) {
      this.showBanner();
    } else if (this.isNative()) {
      this.removeBanner().catch(() => {
      });
    }
  }
};
_AdmobService.\u0275fac = function AdmobService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _AdmobService)();
};
_AdmobService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _AdmobService, factory: _AdmobService.\u0275fac, providedIn: "root" });
var AdmobService = _AdmobService;

export {
  AdmobService
};
//# sourceMappingURL=chunk-RNU3LUBM.js.map
