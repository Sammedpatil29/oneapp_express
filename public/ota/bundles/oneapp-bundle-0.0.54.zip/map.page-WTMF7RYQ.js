import {
  AddressSaveFormComponent
} from "./chunk-D7TJKUA6.js";
import {
  LocationService
} from "./chunk-4TQR4WSH.js";
import "./chunk-V444GY6B.js";
import "./chunk-QH3WR2OQ.js";
import {
  addIcons,
  arrowBackOutline,
  bookmarkOutline,
  briefcaseOutline,
  checkmarkCircle,
  closeCircle,
  homeOutline,
  locateOutline,
  location,
  locationOutline,
  navigateOutline,
  refreshOutline,
  searchOutline
} from "./chunk-FJYXZAS7.js";
import {
  AuthService
} from "./chunk-EB6T6TPT.js";
import "./chunk-YJYUHAOC.js";
import "./chunk-OE5MTPUR.js";
import {
  IonButton,
  IonButtons,
  IonContent,
  IonFooter,
  IonHeader,
  IonIcon,
  IonModal,
  IonSpinner,
  IonTitle,
  IonToast,
  IonToolbar
} from "./chunk-CJE2NDTY.js";
import {
  ActivatedRoute,
  CommonModule,
  DefaultValueAccessor,
  FormsModule,
  NavController,
  NgControlStatus,
  NgModel,
  NgZone,
  Router,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵloadQuery,
  ɵɵnamespaceHTML,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵpureFunction2,
  ɵɵqueryRefresh,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty,
  ɵɵviewQuery
} from "./chunk-Z7XNNJSA.js";
import "./chunk-XR3JUECC.js";
import "./chunk-FH4NU4VH.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/pages/map/map.page.ts
var _c0 = ["map"];
var _c1 = () => [0, 1];
var _c2 = (a0, a1) => ({ lat: a0, lng: a1 });
var _forTrack0 = ($index, $item) => $item.place_id;
function MapPage_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-spinner", 10);
  }
}
function MapPage_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 43);
    \u0275\u0275listener("click", function MapPage_Conditional_12_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r2);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.clearSearch());
    });
    \u0275\u0275element(1, "ion-icon", 44);
    \u0275\u0275elementEnd();
  }
}
function MapPage_Conditional_13_For_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 46);
    \u0275\u0275listener("click", function MapPage_Conditional_13_For_2_Template_div_click_0_listener() {
      const p_r5 = \u0275\u0275restoreView(_r4).$implicit;
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.selectPrediction(p_r5));
    });
    \u0275\u0275elementStart(1, "div", 47);
    \u0275\u0275element(2, "ion-icon", 48);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 49)(4, "span", 50);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span", 51);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const p_r5 = ctx.$implicit;
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate((p_r5.structured_formatting == null ? null : p_r5.structured_formatting.main_text) || p_r5.description);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate((p_r5.structured_formatting == null ? null : p_r5.structured_formatting.secondary_text) || "");
  }
}
function MapPage_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 12);
    \u0275\u0275repeaterCreate(1, MapPage_Conditional_13_For_2_Template, 8, 2, "div", 45, _forTrack0);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r2.predictions);
  }
}
function MapPage_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1, "Detecting location...");
    \u0275\u0275elementEnd();
  }
}
function MapPage_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "span", 52);
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2, "Order delivers here");
    \u0275\u0275elementEnd();
  }
}
function MapPage_Conditional_21_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "span", 53);
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2, "Out of delivery area");
    \u0275\u0275elementEnd();
  }
}
function MapPage_Conditional_35_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 30);
    \u0275\u0275element(1, "span", 54);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("Property Location Pin \u2022 ", ctx_r2.currentServiceAreaName || ctx_r2.mainAreaName || "Service Area", "");
  }
}
function MapPage_Conditional_36_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 30);
    \u0275\u0275element(1, "span", 54);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("Delivering to ", ctx_r2.currentServiceAreaName || ctx_r2.mainAreaName || "Service Area", " \u2022 10-15 Min Delivery");
  }
}
function MapPage_Conditional_37_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 31);
    \u0275\u0275element(1, "span", 55);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("Location Not Serviceable \u2022 Move pin inside ", ctx_r2.nearestServiceAreaName || "Service Area", "");
  }
}
function MapPage_Conditional_45_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1, "Fetching address details...");
    \u0275\u0275elementEnd();
  }
}
function MapPage_Conditional_46_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 38);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r2.currentAddress || "Loading exact address...");
  }
}
function MapPage_Conditional_49_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-spinner", 56);
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2, "Verifying location...");
    \u0275\u0275elementEnd();
  }
}
function MapPage_Conditional_50_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1, "Use This Property Location");
    \u0275\u0275elementEnd();
    \u0275\u0275element(2, "ion-icon", 57);
  }
}
function MapPage_Conditional_51_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
    \u0275\u0275element(2, "ion-icon", 58);
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r2.isSaveAddressFlow ? "Save Address" : "Confirm Location");
    \u0275\u0275advance();
    \u0275\u0275property("name", ctx_r2.isSaveAddressFlow ? "bookmark-outline" : "navigate-outline");
  }
}
function MapPage_Conditional_52_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1, "Location Not Serviceable");
    \u0275\u0275elementEnd();
  }
}
function MapPage_ng_template_54_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "app-address-save-form", 59);
    \u0275\u0275listener("addressSaved", function MapPage_ng_template_54_Template_app_address_save_form_addressSaved_0_listener($event) {
      \u0275\u0275restoreView(_r6);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.onAddressSaved($event));
    })("cancel", function MapPage_ng_template_54_Template_app_address_save_form_cancel_0_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.closeAddressModal());
    });
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275property("initialCoords", \u0275\u0275pureFunction2(3, _c2, (ctx_r2.latLng == null ? null : ctx_r2.latLng.lat) ? ctx_r2.latLng.lat() : 12.8556, (ctx_r2.latLng == null ? null : ctx_r2.latLng.lng) ? ctx_r2.latLng.lng() : 77.6818))("initialAddress", ctx_r2.currentAddress)("routeSource", ctx_r2.routeSource);
  }
}
var _MapPage = class _MapPage {
  // Save Address Flow check
  get isSaveAddressFlow() {
    const src = String(this.routeSource || "").toLowerCase();
    return src === "profile" || src === "savedaddress" || src === "savedaddresses" || src === "addaddress";
  }
  // Property Listing Flow check
  get isPropertyListingFlow() {
    const src = String(this.routeSource || this.route.snapshot.queryParams["from"] || localStorage.getItem("map_picker_source") || "").toLowerCase();
    return src === "property_register" || src === "property" || src === "property-register";
  }
  constructor(navCtrl, router, route, locationService, authService, ngZone) {
    this.navCtrl = navCtrl;
    this.router = router;
    this.route = route;
    this.locationService = locationService;
    this.authService = authService;
    this.ngZone = ngZone;
    this.currentAddress = "";
    this.mainAreaName = "";
    this.inside = true;
    this.isPolygonLoading = false;
    this.isDragging = false;
    this.isSaving = false;
    this.isLoading = false;
    this.isModalOpen = false;
    this.isToastOpen = false;
    this.toastMessage = "";
    this.searchQuery = "";
    this.predictions = [];
    this.isSearching = false;
    this.polygonCoords = [];
    this.servicePolygons = [];
    this.allActiveAreas = [];
    this.currentServiceAreaName = "";
    this.nearestServiceAreaName = "";
    this.userLiveMarker = null;
    this.userLiveAccuracyCircle = null;
    this.userLiveWatchId = null;
    this.liveCoords = null;
    addIcons({
      arrowBackOutline,
      locateOutline,
      refreshOutline,
      searchOutline,
      closeCircle,
      location,
      locationOutline,
      checkmarkCircle,
      homeOutline,
      briefcaseOutline,
      bookmarkOutline,
      navigateOutline
    });
  }
  ngOnInit() {
    return __async(this, null, function* () {
      this.token = yield this.authService.getToken();
      this.updateRouteSource();
      this.fetchServiceArea();
    });
  }
  ionViewWillEnter() {
    this.updateRouteSource();
  }
  updateRouteSource() {
    var _a;
    const qFrom = this.route.snapshot.queryParams["from"];
    const stateData = (_a = history.state) == null ? void 0 : _a.data;
    const storageSource = localStorage.getItem("map_picker_source");
    this.routeSource = qFrom || stateData || storageSource || this.routeSource;
  }
  ngAfterViewInit() {
    this.initializeLocation();
  }
  fetchServiceArea() {
    this.locationService.getPolygonData().subscribe({
      next: (res) => {
        var _a, _b;
        this.serviceAreaData = res == null ? void 0 : res.data;
        this.allActiveAreas = Array.isArray((_a = res == null ? void 0 : res.data) == null ? void 0 : _a.allAreas) ? res.data.allAreas : [];
        this.polygonCoords = ((_b = res == null ? void 0 : res.data) == null ? void 0 : _b.polygon) || [];
        this.isPolygonLoading = false;
        if (this.map && this.allActiveAreas.length > 0) {
          this.renderAllPolygons();
          const center = this.map.getCenter();
          if (center) {
            this.validateServiceArea(center.lat(), center.lng());
          }
        }
      },
      error: () => {
        this.isPolygonLoading = false;
      }
    });
  }
  initializeLocation() {
    var _a;
    const savedLoc = localStorage.getItem("location");
    if (savedLoc) {
      try {
        const parsed = JSON.parse(savedLoc);
        if ((parsed == null ? void 0 : parsed.lat) && (parsed == null ? void 0 : parsed.lng)) {
          this.latLng = new google.maps.LatLng(parsed.lat, parsed.lng);
        }
      } catch (e) {
      }
    }
    if (!this.latLng) {
      const defaultCenter = ((_a = this.allActiveAreas[0]) == null ? void 0 : _a.center) || { lat: 12.8556, lng: 77.6818 };
      this.latLng = new google.maps.LatLng(defaultCenter.lat, defaultCenter.lng);
    }
    this.setupMap();
  }
  setupMap() {
    var _a, _b;
    if (!((_a = this.mapElement) == null ? void 0 : _a.nativeElement) || typeof google === "undefined")
      return;
    const mapOptions = {
      center: this.latLng || new google.maps.LatLng(12.8556, 77.6818),
      zoom: 16,
      disableDefaultUI: true,
      clickableIcons: false,
      gestureHandling: "greedy"
    };
    this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
    if ((_b = google.maps) == null ? void 0 : _b.places) {
      this.autocompleteService = new google.maps.places.AutocompleteService();
    }
    if (this.allActiveAreas.length > 0) {
      this.renderAllPolygons();
    } else if (this.serviceAreaData) {
      this.renderPolygon(this.serviceAreaData);
    }
    this.trackLiveUserLocation();
    google.maps.event.addListener(this.map, "dragstart", () => {
      this.ngZone.run(() => {
        this.isDragging = true;
        this.predictions = [];
      });
    });
    google.maps.event.addListener(this.map, "idle", () => {
      this.ngZone.run(() => {
        this.isDragging = false;
        const center = this.map.getCenter();
        if (center) {
          this.updateLocationInfo(center.lat(), center.lng());
        }
      });
    });
  }
  renderAllPolygons() {
    if (!this.map || !this.allActiveAreas || this.allActiveAreas.length === 0 || typeof google === "undefined")
      return;
    if (this.servicePolygons && this.servicePolygons.length > 0) {
      for (const p of this.servicePolygons) {
        p.setMap(null);
      }
    }
    this.servicePolygons = [];
    if (this.servicePolygon) {
      this.servicePolygon.setMap(null);
      this.servicePolygon = null;
    }
    for (const area of this.allActiveAreas) {
      if (area.polygon && Array.isArray(area.polygon) && area.polygon.length >= 3) {
        const poly = new google.maps.Polygon({
          paths: area.polygon,
          strokeColor: area.strokeColor || "#a000e2",
          strokeOpacity: 0.85,
          strokeWeight: 2.5,
          fillColor: area.areaColor || "#a000e2",
          fillOpacity: 0.1,
          map: this.map
        });
        this.servicePolygons.push(poly);
      }
    }
  }
  renderPolygon(data) {
    if (!this.map || !this.polygonCoords || this.polygonCoords.length === 0)
      return;
    if (this.servicePolygon) {
      this.servicePolygon.setMap(null);
    }
    this.servicePolygon = new google.maps.Polygon({
      paths: this.polygonCoords,
      strokeColor: data.border_color || "#a000e2",
      strokeOpacity: 0.85,
      strokeWeight: 2.5,
      fillColor: data.inside_color || "#a000e2",
      fillOpacity: 0.1,
      map: this.map
    });
  }
  updateLocationInfo(lat, lng) {
    if (typeof google === "undefined")
      return;
    const geocoder = new google.maps.Geocoder();
    this.isPolygonLoading = true;
    geocoder.geocode({ location: { lat, lng } }, (results, status) => {
      this.ngZone.run(() => {
        if (status === "OK" && results[0]) {
          this.currentAddress = results[0].formatted_address;
          this.extractMainAreaName(results[0]);
          this.validateServiceArea(lat, lng);
        } else {
          this.currentAddress = "Unable to fetch address";
        }
        this.isPolygonLoading = false;
      });
    });
  }
  extractMainAreaName(result) {
    var _a, _b, _c, _d;
    if (!result)
      return;
    const comps = result.address_components || [];
    const subloc = (_a = comps.find((c) => c.types.includes("sublocality_level_1") || c.types.includes("sublocality"))) == null ? void 0 : _a.long_name;
    const neighbor = (_b = comps.find((c) => c.types.includes("neighborhood"))) == null ? void 0 : _b.long_name;
    const locality = (_c = comps.find((c) => c.types.includes("locality"))) == null ? void 0 : _c.long_name;
    const route = (_d = comps.find((c) => c.types.includes("route"))) == null ? void 0 : _d.long_name;
    this.mainAreaName = subloc || neighbor || route || locality || (result.formatted_address ? result.formatted_address.split(",")[0] : "Selected Location");
  }
  validateServiceArea(lat, lng) {
    var _a, _b, _c;
    if (!this.allActiveAreas || this.allActiveAreas.length === 0 || typeof google === "undefined") {
      this.inside = true;
      this.currentServiceAreaName = "";
      return;
    }
    const point = new google.maps.LatLng(lat, lng);
    let matchedArea = null;
    for (let i = 0; i < this.allActiveAreas.length; i++) {
      const area = this.allActiveAreas[i];
      const poly = this.servicePolygons[i];
      if (poly && google.maps.geometry.poly.containsLocation(point, poly)) {
        matchedArea = area;
        break;
      } else if (!poly && area.polygon && area.polygon.length >= 3) {
        const tempPoly = new google.maps.Polygon({ paths: area.polygon });
        if (google.maps.geometry.poly.containsLocation(point, tempPoly)) {
          matchedArea = area;
          break;
        }
      }
    }
    if (matchedArea) {
      this.inside = true;
      this.currentServiceAreaName = matchedArea.cityName || "Service Area";
    } else {
      this.inside = false;
      this.currentServiceAreaName = "";
      let minDist = Infinity;
      let closest = null;
      for (const area of this.allActiveAreas) {
        if (((_a = area.center) == null ? void 0 : _a.lat) && ((_b = area.center) == null ? void 0 : _b.lng)) {
          const d = Math.hypot(area.center.lat - lat, area.center.lng - lng);
          if (d < minDist) {
            minDist = d;
            closest = area;
          }
        }
      }
      this.nearestServiceAreaName = (closest == null ? void 0 : closest.cityName) || ((_c = this.allActiveAreas[0]) == null ? void 0 : _c.cityName) || "Service Area";
    }
  }
  onSearchInput() {
    var _a;
    if (!this.searchQuery || this.searchQuery.trim().length < 2) {
      this.predictions = [];
      this.isSearching = false;
      return;
    }
    if (!this.autocompleteService && typeof google !== "undefined" && ((_a = google.maps) == null ? void 0 : _a.places)) {
      this.autocompleteService = new google.maps.places.AutocompleteService();
    }
    if (!this.autocompleteService)
      return;
    this.isSearching = true;
    this.autocompleteService.getPlacePredictions({
      input: this.searchQuery,
      componentRestrictions: { country: "in" },
      locationBias: this.latLng ? { radius: 3e4, center: this.latLng } : void 0
    }, (predictions, status) => {
      this.ngZone.run(() => {
        this.isSearching = false;
        if (status === google.maps.places.PlacesServiceStatus.OK && predictions) {
          this.predictions = predictions;
        } else {
          this.predictions = [];
        }
      });
    });
  }
  selectPrediction(p) {
    var _a;
    this.searchQuery = ((_a = p.structured_formatting) == null ? void 0 : _a.main_text) || p.description;
    this.predictions = [];
    if (typeof google === "undefined")
      return;
    const geocoder = new google.maps.Geocoder();
    geocoder.geocode({ placeId: p.place_id }, (results, status) => {
      this.ngZone.run(() => {
        if (status === "OK" && results[0]) {
          const loc = results[0].geometry.location;
          this.latLng = loc;
          if (this.map) {
            this.map.panTo(loc);
            this.map.setZoom(17);
          }
          this.currentAddress = results[0].formatted_address;
          this.extractMainAreaName(results[0]);
          this.validateServiceArea(loc.lat(), loc.lng());
        }
      });
    });
  }
  clearSearch() {
    this.searchQuery = "";
    this.predictions = [];
  }
  updateUserLiveLocationMarker(lat, lng) {
    if (!this.map || typeof google === "undefined")
      return;
    this.liveCoords = { lat, lng };
    const position = new google.maps.LatLng(lat, lng);
    if (this.userLiveMarker) {
      this.userLiveMarker.setPosition(position);
    } else {
      this.userLiveMarker = new google.maps.Marker({
        position,
        map: this.map,
        icon: {
          path: google.maps.SymbolPath.CIRCLE,
          scale: 7.5,
          fillColor: "#2563eb",
          fillOpacity: 1,
          strokeColor: "#ffffff",
          strokeWeight: 2.5
        },
        title: "Your Live Location",
        zIndex: 9999
      });
    }
    if (this.userLiveAccuracyCircle) {
      this.userLiveAccuracyCircle.setCenter(position);
    } else {
      this.userLiveAccuracyCircle = new google.maps.Circle({
        strokeColor: "#3b82f6",
        strokeOpacity: 0.35,
        strokeWeight: 1,
        fillColor: "#60a5fa",
        fillOpacity: 0.15,
        map: this.map,
        center: position,
        radius: 20
      });
    }
  }
  trackLiveUserLocation() {
    return __async(this, null, function* () {
      try {
        const pos = yield this.locationService.getDetailedPosition();
        if (pos && pos.coords) {
          this.ngZone.run(() => {
            this.updateUserLiveLocationMarker(pos.coords.latitude, pos.coords.longitude);
          });
        }
      } catch (e) {
      }
      try {
        this.userLiveWatchId = yield this.locationService.watchPosition((pos) => {
          if (pos == null ? void 0 : pos.coords) {
            this.ngZone.run(() => {
              this.updateUserLiveLocationMarker(pos.coords.latitude, pos.coords.longitude);
            });
          }
        });
      } catch (e) {
      }
    });
  }
  getCurrentLocation(showNotice = true) {
    return __async(this, null, function* () {
      try {
        this.isPolygonLoading = true;
        const pos = yield this.locationService.getDetailedPosition();
        if (pos == null ? void 0 : pos.coords) {
          const { latitude, longitude } = pos.coords;
          const coords = new google.maps.LatLng(latitude, longitude);
          this.latLng = coords;
          this.updateUserLiveLocationMarker(latitude, longitude);
          if (this.map) {
            this.map.panTo(coords);
            this.map.setZoom(17);
          }
        } else {
          if (showNotice) {
            this.showToast("Please enable device location/GPS to detect your live location.");
          }
        }
      } catch (e) {
        if (showNotice) {
          this.showToast("Could not fetch GPS location. Please check location permissions.");
        }
      } finally {
        this.isPolygonLoading = false;
      }
    });
  }
  ngOnDestroy() {
    if (this.userLiveWatchId) {
      this.locationService.clearWatch(this.userLiveWatchId);
    }
    if (this.userLiveMarker) {
      this.userLiveMarker.setMap(null);
      this.userLiveMarker = null;
    }
    if (this.userLiveAccuracyCircle) {
      this.userLiveAccuracyCircle.setMap(null);
      this.userLiveAccuracyCircle = null;
    }
  }
  backtoServiceArea() {
    var _a, _b, _c;
    if (!this.map || !this.allActiveAreas || this.allActiveAreas.length === 0)
      return;
    const center = this.map.getCenter();
    let target = (_a = this.allActiveAreas[0]) == null ? void 0 : _a.center;
    if (center && this.allActiveAreas.length > 1) {
      let minDist = Infinity;
      const cLat = center.lat();
      const cLng = center.lng();
      for (const area of this.allActiveAreas) {
        if (((_b = area.center) == null ? void 0 : _b.lat) && ((_c = area.center) == null ? void 0 : _c.lng)) {
          const d = Math.hypot(area.center.lat - cLat, area.center.lng - cLng);
          if (d < minDist) {
            minDist = d;
            target = area.center;
          }
        }
      }
    }
    if ((target == null ? void 0 : target.lat) && (target == null ? void 0 : target.lng)) {
      this.map.panTo(new google.maps.LatLng(target.lat, target.lng));
      this.map.setZoom(15);
    }
  }
  openSaveAddressModal() {
    if (!this.map)
      return;
    const center = this.map.getCenter();
    this.latLng = center;
    this.isModalOpen = true;
  }
  onAddressSaved(savedAddr) {
    this.isModalOpen = false;
    this.showToast("Address saved successfully!");
    if (this.isSaveAddressFlow) {
      this.navCtrl.back();
    } else if (this.routeSource === "home" || !this.routeSource) {
      this.router.navigate(["/layout/home"], { replaceUrl: true });
    } else {
      this.navCtrl.back();
    }
  }
  closeAddressModal() {
    this.isModalOpen = false;
  }
  confirmLocation() {
    if (!this.map)
      return;
    const center = this.map.getCenter();
    if (!center)
      return;
    const lat = typeof center.lat === "function" ? center.lat() : center.lat;
    const lng = typeof center.lng === "function" ? center.lng() : center.lng;
    let addressVal = this.currentAddress;
    if (!addressVal || addressVal.includes("Loading") || addressVal.includes("Fetching")) {
      addressVal = this.mainAreaName || this.currentServiceAreaName || `Location (${Number(lat).toFixed(4)}, ${Number(lng).toFixed(4)})`;
    }
    const areaVal = this.mainAreaName || this.currentServiceAreaName || (addressVal ? addressVal.split(",")[0] : "Selected Area");
    const locationData = {
      lat: Number(lat),
      lng: Number(lng),
      address: addressVal,
      area: areaVal,
      city: this.currentServiceAreaName || "Jamkhandi"
    };
    if (this.isSaveAddressFlow) {
      this.openSaveAddressModal();
      return;
    }
    if (this.isPropertyListingFlow) {
      localStorage.setItem("property_selected_location", JSON.stringify(locationData));
      localStorage.removeItem("map_picker_source");
      this.showToast("Property location pinned successfully!");
      this.router.navigate(["/layout/property/register"], {
        queryParams: {
          from_map: "1",
          lat: locationData.lat,
          lng: locationData.lng,
          address: locationData.address,
          area: locationData.area,
          city: locationData.city,
          t: Date.now()
        }
      });
      return;
    }
    this.locationService.setAddress(locationData);
    localStorage.setItem("location", JSON.stringify(locationData));
    if (this.routeSource === "grocery") {
      this.router.navigate(["/layout/grocery-layout"], { replaceUrl: true });
    } else if (this.routeSource === "rides") {
      this.router.navigate(["/layout/rides"], { replaceUrl: true });
    } else {
      this.router.navigate(["/layout/home"], { replaceUrl: true });
    }
  }
  showToast(message) {
    this.toastMessage = message;
    this.isToastOpen = true;
  }
  goBack() {
    if (this.isPropertyListingFlow) {
      localStorage.removeItem("map_picker_source");
      this.router.navigate(["/layout/property/register"]);
      return;
    }
    this.navCtrl.back();
  }
};
_MapPage.\u0275fac = function MapPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _MapPage)(\u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(ActivatedRoute), \u0275\u0275directiveInject(LocationService), \u0275\u0275directiveInject(AuthService), \u0275\u0275directiveInject(NgZone));
};
_MapPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _MapPage, selectors: [["app-map"]], viewQuery: function MapPage_Query(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275viewQuery(_c0, 5);
  }
  if (rf & 2) {
    let _t;
    \u0275\u0275queryRefresh(_t = \u0275\u0275loadQuery()) && (ctx.mapElement = _t.first);
  }
}, decls: 56, vars: 29, consts: [["map", ""], [1, "ion-no-border", "bg-white", "pt-2", "map-header"], ["slot", "start"], [3, "click"], ["name", "arrow-back-outline", "color", "dark"], [1, "fw-bold", "text-dark"], [1, "map-search-bar-wrap"], [1, "map-search-box"], ["name", "search-outline", 1, "search-icon"], ["type", "text", "placeholder", "Search for area, street, landmark...", 1, "search-input", 3, "ngModelChange", "input", "ngModel"], ["name", "crescent", 1, "search-spinner"], ["type", "button", 1, "btn-clear-search"], [1, "predictions-dropdown"], [1, "map-page-content", 3, "fullscreen", "scrollY"], ["id", "map", 1, "map-container"], [1, "center-delivery-pin"], [1, "pin-status-pill"], [1, "pin-marker-head"], ["viewBox", "0 0 36 46", "fill", "none", "xmlns", "http://www.w3.org/2000/svg", 1, "pin-svg"], ["d", "M18 0C8.05887 0 0 8.05887 0 18C0 31.5 18 46 18 46C18 46 36 31.5 36 18C36 8.05887 27.9411 0 18 0Z"], ["cx", "18", "cy", "18", "r", "7", "fill", "white"], ["cx", "18", "cy", "18", "r", "3.5"], [1, "pin-ground-shadow"], [1, "map-floating-controls"], ["type", "button", "title", "Current Live Location", "aria-label", "Current Live Location", 1, "map-fab-btn", "gps-fab", 3, "click"], ["name", "locate-outline"], [1, "map-location-sheet", "ion-no-border"], [1, "sheet-inner"], [1, "sheet-drag-handle"], [1, "sheet-status-row"], [1, "status-badge", "available"], [1, "status-badge", "unavailable"], [1, "sheet-address-row"], [1, "address-icon-box"], ["name", "location"], [1, "address-text-col"], [1, "area-title", "text-truncate"], [1, "full-address-text"], [1, "text-truncate"], [1, "sheet-action-row"], ["type", "button", 1, "btn-confirm-location", 3, "click", "disabled"], [1, "address-save-form-modal", 3, "didDismiss", "isOpen", "breakpoints", "initialBreakpoint", "handle"], [3, "didDismiss", "isOpen", "message", "duration"], ["type", "button", 1, "btn-clear-search", 3, "click"], ["name", "close-circle"], [1, "prediction-item"], [1, "prediction-item", 3, "click"], [1, "pred-icon-box"], ["name", "location-outline"], [1, "pred-text-col"], [1, "pred-main"], [1, "pred-sub"], [1, "pulse-dot", "green"], [1, "pulse-dot", "red"], [1, "status-dot", "green"], [1, "status-dot", "red"], ["name", "crescent"], ["name", "checkmark-circle"], [3, "name"], [3, "addressSaved", "cancel", "initialCoords", "initialAddress", "routeSource"]], template: function MapPage_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-header", 1)(1, "ion-toolbar")(2, "ion-buttons", 2)(3, "ion-button", 3);
    \u0275\u0275listener("click", function MapPage_Template_ion_button_click_3_listener() {
      \u0275\u0275restoreView(_r1);
      return \u0275\u0275resetView(ctx.goBack());
    });
    \u0275\u0275element(4, "ion-icon", 4);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "ion-title", 5);
    \u0275\u0275text(6, "Select Delivery Location");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "div", 6)(8, "div", 7);
    \u0275\u0275element(9, "ion-icon", 8);
    \u0275\u0275elementStart(10, "input", 9);
    \u0275\u0275twoWayListener("ngModelChange", function MapPage_Template_input_ngModelChange_10_listener($event) {
      \u0275\u0275restoreView(_r1);
      \u0275\u0275twoWayBindingSet(ctx.searchQuery, $event) || (ctx.searchQuery = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275listener("input", function MapPage_Template_input_input_10_listener() {
      \u0275\u0275restoreView(_r1);
      return \u0275\u0275resetView(ctx.onSearchInput());
    });
    \u0275\u0275elementEnd();
    \u0275\u0275template(11, MapPage_Conditional_11_Template, 1, 0, "ion-spinner", 10)(12, MapPage_Conditional_12_Template, 2, 0, "button", 11);
    \u0275\u0275elementEnd();
    \u0275\u0275template(13, MapPage_Conditional_13_Template, 3, 0, "div", 12);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(14, "ion-content", 13);
    \u0275\u0275element(15, "div", 14, 0);
    \u0275\u0275elementStart(17, "div", 15)(18, "div", 16);
    \u0275\u0275template(19, MapPage_Conditional_19_Template, 2, 0, "span")(20, MapPage_Conditional_20_Template, 3, 0)(21, MapPage_Conditional_21_Template, 3, 0);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(22, "div", 17);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(23, "svg", 18);
    \u0275\u0275element(24, "path", 19)(25, "circle", 20)(26, "circle", 21);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275element(27, "div", 22);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(28, "div", 23)(29, "button", 24);
    \u0275\u0275listener("click", function MapPage_Template_button_click_29_listener() {
      \u0275\u0275restoreView(_r1);
      return \u0275\u0275resetView(ctx.getCurrentLocation(true));
    });
    \u0275\u0275element(30, "ion-icon", 25);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(31, "ion-footer", 26)(32, "div", 27);
    \u0275\u0275element(33, "div", 28);
    \u0275\u0275elementStart(34, "div", 29);
    \u0275\u0275template(35, MapPage_Conditional_35_Template, 4, 1, "div", 30)(36, MapPage_Conditional_36_Template, 4, 1, "div", 30)(37, MapPage_Conditional_37_Template, 4, 1, "div", 31);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(38, "div", 32)(39, "div", 33);
    \u0275\u0275element(40, "ion-icon", 34);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(41, "div", 35)(42, "h4", 36);
    \u0275\u0275text(43);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(44, "p", 37);
    \u0275\u0275template(45, MapPage_Conditional_45_Template, 2, 0, "span")(46, MapPage_Conditional_46_Template, 2, 1, "span", 38);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(47, "div", 39)(48, "button", 40);
    \u0275\u0275listener("click", function MapPage_Template_button_click_48_listener() {
      \u0275\u0275restoreView(_r1);
      return \u0275\u0275resetView(ctx.confirmLocation());
    });
    \u0275\u0275template(49, MapPage_Conditional_49_Template, 3, 0)(50, MapPage_Conditional_50_Template, 3, 0)(51, MapPage_Conditional_51_Template, 3, 2)(52, MapPage_Conditional_52_Template, 2, 0, "span");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(53, "ion-modal", 41);
    \u0275\u0275listener("didDismiss", function MapPage_Template_ion_modal_didDismiss_53_listener() {
      \u0275\u0275restoreView(_r1);
      return \u0275\u0275resetView(ctx.closeAddressModal());
    });
    \u0275\u0275template(54, MapPage_ng_template_54_Template, 1, 6, "ng-template");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(55, "ion-toast", 42);
    \u0275\u0275listener("didDismiss", function MapPage_Template_ion_toast_didDismiss_55_listener() {
      \u0275\u0275restoreView(_r1);
      return \u0275\u0275resetView(ctx.isToastOpen = false);
    });
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance(10);
    \u0275\u0275twoWayProperty("ngModel", ctx.searchQuery);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.isSearching ? 11 : ctx.searchQuery ? 12 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx.predictions.length > 0 ? 13 : -1);
    \u0275\u0275advance();
    \u0275\u0275property("fullscreen", false)("scrollY", false);
    \u0275\u0275advance(3);
    \u0275\u0275classProp("pin-dragging", ctx.isDragging);
    \u0275\u0275advance();
    \u0275\u0275classProp("in-service", ctx.inside)("out-service", !ctx.inside);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.isPolygonLoading ? 19 : ctx.inside ? 20 : 21);
    \u0275\u0275advance(5);
    \u0275\u0275attribute("fill", ctx.inside ? "#a000e2" : "#dc2626");
    \u0275\u0275advance(2);
    \u0275\u0275attribute("fill", ctx.inside ? "#a000e2" : "#dc2626");
    \u0275\u0275advance(9);
    \u0275\u0275conditional(ctx.isPropertyListingFlow ? 35 : ctx.inside ? 36 : 37);
    \u0275\u0275advance(4);
    \u0275\u0275classProp("is-serviceable", ctx.inside || ctx.isPropertyListingFlow);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1(" ", ctx.mainAreaName || ctx.currentServiceAreaName || "Selected Location", " ");
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx.isPolygonLoading ? 45 : 46);
    \u0275\u0275advance(3);
    \u0275\u0275property("disabled", !ctx.inside && !ctx.isPropertyListingFlow || ctx.isPolygonLoading);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.isPolygonLoading ? 49 : ctx.isPropertyListingFlow ? 50 : ctx.inside ? 51 : 52);
    \u0275\u0275advance(4);
    \u0275\u0275property("isOpen", ctx.isModalOpen)("breakpoints", \u0275\u0275pureFunction0(28, _c1))("initialBreakpoint", 1)("handle", true);
    \u0275\u0275advance(2);
    \u0275\u0275property("isOpen", ctx.isToastOpen)("message", ctx.toastMessage)("duration", 2500);
  }
}, dependencies: [
  CommonModule,
  FormsModule,
  DefaultValueAccessor,
  NgControlStatus,
  NgModel,
  IonHeader,
  IonToolbar,
  IonButtons,
  IonButton,
  IonTitle,
  IonContent,
  IonIcon,
  IonSpinner,
  IonModal,
  IonFooter,
  IonToast,
  AddressSaveFormComponent
], styles: ["\n\n[_nghost-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  width: 100%;\n  height: 100%;\n}\nion-header.map-header[_ngcontent-%COMP%] {\n  --background: #ffffff;\n  background: #ffffff;\n  box-shadow: 0 4px 18px rgba(0, 0, 0, 0.05);\n  position: relative;\n  z-index: 100;\n  border-bottom: 1px solid #f1f5f9;\n}\nion-header.map-header[_ngcontent-%COMP%]   ion-toolbar[_ngcontent-%COMP%] {\n  --background: #ffffff;\n  --min-height: 48px;\n}\nion-header.map-header[_ngcontent-%COMP%]   ion-toolbar[_ngcontent-%COMP%]   ion-title[_ngcontent-%COMP%] {\n  font-size: 17px;\n  font-weight: 700;\n  color: #0f172a;\n}\nion-header.map-header[_ngcontent-%COMP%]   ion-toolbar[_ngcontent-%COMP%]   ion-button[_ngcontent-%COMP%] {\n  --padding-start: 8px;\n  --padding-end: 8px;\n  font-size: 22px;\n}\n.map-search-bar-wrap[_ngcontent-%COMP%] {\n  padding: 0 16px 12px 16px;\n  position: relative;\n  width: 100%;\n}\n.map-search-bar-wrap[_ngcontent-%COMP%]   .map-search-box[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  background: #f8fafc;\n  border: 1.5px solid #e2e8f0;\n  border-radius: 12px;\n  height: 44px;\n  padding: 0 12px;\n  gap: 10px;\n  transition: all 0.2s ease;\n}\n.map-search-bar-wrap[_ngcontent-%COMP%]   .map-search-box[_ngcontent-%COMP%]:focus-within {\n  border-color: #a000e2;\n  background: #ffffff;\n  box-shadow: 0 0 0 3px rgba(160, 0, 226, 0.08);\n}\n.map-search-bar-wrap[_ngcontent-%COMP%]   .map-search-box[_ngcontent-%COMP%]   .search-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n  color: #94a3b8;\n  flex-shrink: 0;\n}\n.map-search-bar-wrap[_ngcontent-%COMP%]   .map-search-box[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%] {\n  flex: 1;\n  border: none;\n  outline: none;\n  background: transparent;\n  font-size: 13.5px;\n  color: #1e293b;\n  font-weight: 500;\n  min-width: 0;\n}\n.map-search-bar-wrap[_ngcontent-%COMP%]   .map-search-box[_ngcontent-%COMP%]   .search-input[_ngcontent-%COMP%]::placeholder {\n  color: #94a3b8;\n  font-weight: 400;\n}\n.map-search-bar-wrap[_ngcontent-%COMP%]   .map-search-box[_ngcontent-%COMP%]   .search-spinner[_ngcontent-%COMP%] {\n  width: 18px;\n  height: 18px;\n  --color: #a000e2;\n  flex-shrink: 0;\n}\n.map-search-bar-wrap[_ngcontent-%COMP%]   .map-search-box[_ngcontent-%COMP%]   .btn-clear-search[_ngcontent-%COMP%] {\n  background: none;\n  border: none;\n  padding: 0;\n  display: flex;\n  align-items: center;\n  color: #94a3b8;\n  font-size: 18px;\n  cursor: pointer;\n  flex-shrink: 0;\n}\n.map-search-bar-wrap[_ngcontent-%COMP%]   .predictions-dropdown[_ngcontent-%COMP%] {\n  position: absolute;\n  top: calc(100% - 4px);\n  left: 16px;\n  right: 16px;\n  background: #ffffff;\n  border-radius: 14px;\n  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);\n  border: 1px solid #e2e8f0;\n  max-height: 240px;\n  overflow-y: auto;\n  z-index: 1000;\n}\n.map-search-bar-wrap[_ngcontent-%COMP%]   .predictions-dropdown[_ngcontent-%COMP%]   .prediction-item[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  padding: 12px 14px;\n  border-bottom: 1px solid #f8fafc;\n  cursor: pointer;\n  transition: background 0.15s;\n}\n.map-search-bar-wrap[_ngcontent-%COMP%]   .predictions-dropdown[_ngcontent-%COMP%]   .prediction-item[_ngcontent-%COMP%]:last-child {\n  border-bottom: none;\n}\n.map-search-bar-wrap[_ngcontent-%COMP%]   .predictions-dropdown[_ngcontent-%COMP%]   .prediction-item[_ngcontent-%COMP%]:active, \n.map-search-bar-wrap[_ngcontent-%COMP%]   .predictions-dropdown[_ngcontent-%COMP%]   .prediction-item[_ngcontent-%COMP%]:hover {\n  background: #f8fafc;\n}\n.map-search-bar-wrap[_ngcontent-%COMP%]   .predictions-dropdown[_ngcontent-%COMP%]   .prediction-item[_ngcontent-%COMP%]   .pred-icon-box[_ngcontent-%COMP%] {\n  width: 32px;\n  height: 32px;\n  border-radius: 8px;\n  background: #f3e8ff;\n  color: #a000e2;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 16px;\n  flex-shrink: 0;\n}\n.map-search-bar-wrap[_ngcontent-%COMP%]   .predictions-dropdown[_ngcontent-%COMP%]   .prediction-item[_ngcontent-%COMP%]   .pred-text-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  overflow: hidden;\n}\n.map-search-bar-wrap[_ngcontent-%COMP%]   .predictions-dropdown[_ngcontent-%COMP%]   .prediction-item[_ngcontent-%COMP%]   .pred-text-col[_ngcontent-%COMP%]   .pred-main[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  font-weight: 600;\n  color: #1e293b;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.map-search-bar-wrap[_ngcontent-%COMP%]   .predictions-dropdown[_ngcontent-%COMP%]   .prediction-item[_ngcontent-%COMP%]   .pred-text-col[_ngcontent-%COMP%]   .pred-sub[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  color: #64748b;\n  margin-top: 1px;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\nion-content.map-page-content[_ngcontent-%COMP%] {\n  --background: #f1f5f9;\n  position: relative;\n  height: 100%;\n}\nion-content.map-page-content[_ngcontent-%COMP%]   .map-container[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n}\n.center-delivery-pin[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -100%);\n  pointer-events: none;\n  z-index: 50;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  transition: transform 0.22s cubic-bezier(0.34, 1.56, 0.64, 1);\n}\n.center-delivery-pin.pin-dragging[_ngcontent-%COMP%] {\n  transform: translate(-50%, calc(-100% - 16px));\n}\n.center-delivery-pin.pin-dragging[_ngcontent-%COMP%]   .pin-ground-shadow[_ngcontent-%COMP%] {\n  transform: scale(0.6);\n  opacity: 0.2;\n}\n.center-delivery-pin[_ngcontent-%COMP%]   .pin-status-pill[_ngcontent-%COMP%] {\n  margin-bottom: 8px;\n  padding: 5px 12px;\n  border-radius: 20px;\n  font-size: 11.5px;\n  font-weight: 700;\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  white-space: nowrap;\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);\n  letter-spacing: 0.2px;\n}\n.center-delivery-pin[_ngcontent-%COMP%]   .pin-status-pill.in-service[_ngcontent-%COMP%] {\n  background: #10b981;\n  color: #ffffff;\n}\n.center-delivery-pin[_ngcontent-%COMP%]   .pin-status-pill.out-service[_ngcontent-%COMP%] {\n  background: #ef4444;\n  color: #ffffff;\n}\n.center-delivery-pin[_ngcontent-%COMP%]   .pin-status-pill[_ngcontent-%COMP%]   .pulse-dot[_ngcontent-%COMP%] {\n  width: 7px;\n  height: 7px;\n  border-radius: 50%;\n  display: inline-block;\n}\n.center-delivery-pin[_ngcontent-%COMP%]   .pin-status-pill[_ngcontent-%COMP%]   .pulse-dot.green[_ngcontent-%COMP%] {\n  background: #ffffff;\n  box-shadow: 0 0 0 2px rgba(255, 255, 255, 0.35);\n  animation: _ngcontent-%COMP%_dotPulse 1.5s infinite;\n}\n.center-delivery-pin[_ngcontent-%COMP%]   .pin-status-pill[_ngcontent-%COMP%]   .pulse-dot.red[_ngcontent-%COMP%] {\n  background: #ffffff;\n  box-shadow: 0 0 0 2px rgba(255, 255, 255, 0.35);\n}\n.center-delivery-pin[_ngcontent-%COMP%]   .pin-marker-head[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n.center-delivery-pin[_ngcontent-%COMP%]   .pin-marker-head[_ngcontent-%COMP%]   .pin-svg[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 48px;\n  filter: drop-shadow(0 6px 8px rgba(0, 0, 0, 0.2));\n}\n.center-delivery-pin[_ngcontent-%COMP%]   .pin-ground-shadow[_ngcontent-%COMP%] {\n  width: 16px;\n  height: 5px;\n  background: rgba(15, 23, 42, 0.3);\n  border-radius: 50%;\n  margin-top: -3px;\n  transition: all 0.22s ease;\n}\n@keyframes _ngcontent-%COMP%_dotPulse {\n  0% {\n    transform: scale(0.95);\n    opacity: 0.8;\n  }\n  50% {\n    transform: scale(1.2);\n    opacity: 1;\n  }\n  100% {\n    transform: scale(0.95);\n    opacity: 0.8;\n  }\n}\n.map-floating-controls[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 16px;\n  right: 16px;\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n  z-index: 40;\n}\n.map-floating-controls[_ngcontent-%COMP%]   .map-fab-btn[_ngcontent-%COMP%] {\n  width: 44px;\n  height: 44px;\n  border-radius: 12px;\n  border: none;\n  background: #ffffff;\n  box-shadow: 0 4px 14px rgba(0, 0, 0, 0.12);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 20px;\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n.map-floating-controls[_ngcontent-%COMP%]   .map-fab-btn[_ngcontent-%COMP%]:active {\n  transform: scale(0.92);\n}\n.map-floating-controls[_ngcontent-%COMP%]   .map-fab-btn.gps-fab[_ngcontent-%COMP%] {\n  background: var(--app-theme-color, #a000e2);\n  color: #ffffff;\n  box-shadow: 0 4px 14px rgba(160, 0, 226, 0.35);\n}\n.map-floating-controls[_ngcontent-%COMP%]   .map-fab-btn.gps-fab[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 22px;\n  color: #ffffff;\n}\n.map-floating-controls[_ngcontent-%COMP%]   .map-fab-btn.gps-fab[_ngcontent-%COMP%]:active {\n  background: #8b00c4;\n}\n.map-location-sheet[_ngcontent-%COMP%] {\n  --background: transparent;\n  background: transparent;\n}\n.map-location-sheet[_ngcontent-%COMP%]   .sheet-inner[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 24px 24px 0 0;\n  padding: 10px 18px calc(14px + env(safe-area-inset-bottom)) 18px;\n  box-shadow: 0 -8px 30px rgba(0, 0, 0, 0.08);\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n}\n.map-location-sheet[_ngcontent-%COMP%]   .sheet-drag-handle[_ngcontent-%COMP%] {\n  width: 36px;\n  height: 4px;\n  border-radius: 2px;\n  background: #cbd5e1;\n  margin: 0 auto;\n}\n.map-location-sheet[_ngcontent-%COMP%]   .sheet-status-row[_ngcontent-%COMP%]   .status-badge[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n  padding: 4px 10px;\n  border-radius: 20px;\n  font-size: 11.5px;\n  font-weight: 600;\n}\n.map-location-sheet[_ngcontent-%COMP%]   .sheet-status-row[_ngcontent-%COMP%]   .status-badge.available[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  color: #047857;\n  border: 1px solid #a7f3d0;\n}\n.map-location-sheet[_ngcontent-%COMP%]   .sheet-status-row[_ngcontent-%COMP%]   .status-badge.unavailable[_ngcontent-%COMP%] {\n  background: #fef2f2;\n  color: #b91c1c;\n  border: 1px solid #fecaca;\n}\n.map-location-sheet[_ngcontent-%COMP%]   .sheet-status-row[_ngcontent-%COMP%]   .status-badge[_ngcontent-%COMP%]   .status-dot[_ngcontent-%COMP%] {\n  width: 6px;\n  height: 6px;\n  border-radius: 50%;\n}\n.map-location-sheet[_ngcontent-%COMP%]   .sheet-status-row[_ngcontent-%COMP%]   .status-badge[_ngcontent-%COMP%]   .status-dot.green[_ngcontent-%COMP%] {\n  background: #10b981;\n}\n.map-location-sheet[_ngcontent-%COMP%]   .sheet-status-row[_ngcontent-%COMP%]   .status-badge[_ngcontent-%COMP%]   .status-dot.red[_ngcontent-%COMP%] {\n  background: #ef4444;\n}\n.map-location-sheet[_ngcontent-%COMP%]   .sheet-address-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-start;\n  gap: 12px;\n}\n.map-location-sheet[_ngcontent-%COMP%]   .sheet-address-row[_ngcontent-%COMP%]   .address-icon-box[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 38px;\n  border-radius: 12px;\n  background: #f1f5f9;\n  color: #64748b;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 20px;\n  flex-shrink: 0;\n}\n.map-location-sheet[_ngcontent-%COMP%]   .sheet-address-row[_ngcontent-%COMP%]   .address-icon-box.is-serviceable[_ngcontent-%COMP%] {\n  background: #f5f3ff;\n  color: #a000e2;\n}\n.map-location-sheet[_ngcontent-%COMP%]   .sheet-address-row[_ngcontent-%COMP%]   .address-text-col[_ngcontent-%COMP%] {\n  flex: 1;\n  overflow: hidden;\n}\n.map-location-sheet[_ngcontent-%COMP%]   .sheet-address-row[_ngcontent-%COMP%]   .address-text-col[_ngcontent-%COMP%]   .area-title[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 700;\n  color: #0f172a;\n  margin: 0 0 2px 0;\n  letter-spacing: -0.2px;\n}\n.map-location-sheet[_ngcontent-%COMP%]   .sheet-address-row[_ngcontent-%COMP%]   .address-text-col[_ngcontent-%COMP%]   .full-address-text[_ngcontent-%COMP%] {\n  font-size: 12.5px;\n  color: #64748b;\n  margin: 0;\n  line-height: 1.4;\n  display: -webkit-box;\n  -webkit-line-clamp: 2;\n  -webkit-box-orient: vertical;\n  overflow: hidden;\n}\n.map-location-sheet[_ngcontent-%COMP%]   .sheet-action-row[_ngcontent-%COMP%]   .btn-confirm-location[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 48px;\n  border-radius: 14px;\n  border: none;\n  background: #a000e2;\n  color: #ffffff;\n  font-size: 15px;\n  font-weight: 700;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 8px;\n  box-shadow: 0 4px 14px rgba(160, 0, 226, 0.28);\n  cursor: pointer;\n  transition: all 0.2s ease;\n}\n.map-location-sheet[_ngcontent-%COMP%]   .sheet-action-row[_ngcontent-%COMP%]   .btn-confirm-location[_ngcontent-%COMP%]:active {\n  transform: scale(0.98);\n}\n.map-location-sheet[_ngcontent-%COMP%]   .sheet-action-row[_ngcontent-%COMP%]   .btn-confirm-location[_ngcontent-%COMP%]:disabled {\n  background: #cbd5e1;\n  color: #64748b;\n  box-shadow: none;\n  cursor: not-allowed;\n}\n.map-location-sheet[_ngcontent-%COMP%]   .sheet-action-row[_ngcontent-%COMP%]   .btn-confirm-location[_ngcontent-%COMP%]   ion-spinner[_ngcontent-%COMP%] {\n  width: 18px;\n  height: 18px;\n  --color: #ffffff;\n}\n.map-location-sheet[_ngcontent-%COMP%]   .sheet-action-row[_ngcontent-%COMP%]   .btn-confirm-location[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 17px;\n}\n.address-save-form-modal[_ngcontent-%COMP%] {\n  --border-radius: 24px 24px 0 0;\n  --background: #ffffff;\n}\n.address-save-form-modal[_ngcontent-%COMP%]::part(content) {\n  border-radius: 24px 24px 0 0;\n  overflow: hidden;\n}\n/*# sourceMappingURL=map.page.css.map */"] });
var MapPage = _MapPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(MapPage, { className: "MapPage", filePath: "src/app/pages/map/map.page.ts", lineNumber: 63 });
})();
export {
  MapPage
};
//# sourceMappingURL=map.page-WTMF7RYQ.js.map
