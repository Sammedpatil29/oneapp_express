import {
  BehaviorSubject,
  ɵɵdefineInjectable
} from "./chunk-Z7XNNJSA.js";

// src/app/services/pintu-pocket.service.ts
var _PintuPocketService = class _PintuPocketService {
  constructor() {
    this.BALANCE_KEY = "pintu_pocket_balance";
    this.TXNS_KEY = "pintu_pocket_txns";
    this.balanceSubject = new BehaviorSubject(120);
    this.balance$ = this.balanceSubject.asObservable();
    this.transactionsSubject = new BehaviorSubject([]);
    this.transactions$ = this.transactionsSubject.asObservable();
    this.initPocket();
  }
  initPocket() {
    try {
      const savedBalance = localStorage.getItem(this.BALANCE_KEY);
      if (savedBalance !== null) {
        this.balanceSubject.next(parseFloat(savedBalance) || 0);
      } else {
        this.setBalance(120);
      }
      const savedTxns = localStorage.getItem(this.TXNS_KEY);
      if (savedTxns) {
        const parsed = JSON.parse(savedTxns);
        if (Array.isArray(parsed) && parsed.length > 0) {
          this.transactionsSubject.next(parsed);
          return;
        }
      }
      const seedTxns = [
        {
          id: "TXN-PNT-9821",
          type: "credit",
          title: "Welcome Joining Bonus",
          subtitle: "Signup reward credited to your Pintu Pocket",
          amount: 50,
          timestamp: new Date(Date.now() - 36e5 * 24).toISOString(),
          referenceId: "REF-JOIN-50",
          category: "bonus",
          status: "success"
        },
        {
          id: "TXN-PNT-8412",
          type: "credit",
          title: "Grocery Order Cashback",
          subtitle: "Super Saver 10% order reward",
          amount: 40,
          timestamp: new Date(Date.now() - 36e5 * 12).toISOString(),
          referenceId: "CB-GROC-7749",
          category: "cashback",
          status: "success"
        },
        {
          id: "TXN-PNT-7119",
          type: "credit",
          title: "Referral Reward",
          subtitle: "Friend completed their first order",
          amount: 30,
          timestamp: new Date(Date.now() - 36e5 * 4).toISOString(),
          referenceId: "REF-FRND-3841",
          category: "referral",
          status: "success"
        }
      ];
      this.saveTransactions(seedTxns);
    } catch (e) {
      console.warn("Failed to init Pintu Pocket storage:", e);
    }
  }
  get currentBalance() {
    return this.balanceSubject.value;
  }
  /**
   * Credits earned reward, welcome bonus, or order cashback to Pintu Pocket.
   * Note: Pintu Pocket cannot be manually loaded by users; it receives rewards & bonuses.
   */
  creditReward(amount, title, subtitle, category = "bonus") {
    if (amount <= 0)
      return false;
    const newBal = Math.round((this.currentBalance + amount) * 100) / 100;
    this.setBalance(newBal);
    const txn = {
      id: `TXN-PNT-${Math.floor(1e3 + Math.random() * 9e3)}`,
      type: "credit",
      title,
      subtitle,
      amount,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      referenceId: `RWD-${Date.now().toString().slice(-6)}`,
      category,
      status: "success"
    };
    const currentList = this.transactionsSubject.value;
    this.saveTransactions([txn, ...currentList]);
    return true;
  }
  /**
   * Spends / redeems available rewards towards an order.
   */
  spendMoney(amount, orderTitle, referenceId) {
    if (amount <= 0 || this.currentBalance < amount)
      return false;
    const newBal = Math.round((this.currentBalance - amount) * 100) / 100;
    this.setBalance(newBal);
    const txn = {
      id: `TXN-PNT-${Math.floor(1e3 + Math.random() * 9e3)}`,
      type: "debit",
      title: orderTitle || "Order Payment",
      subtitle: "Redeemed from Pintu Pocket",
      amount,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      referenceId: referenceId || `ORD-${Date.now().toString().slice(-6)}`,
      category: "spent",
      status: "success"
    };
    const currentList = this.transactionsSubject.value;
    this.saveTransactions([txn, ...currentList]);
    return true;
  }
  setBalance(balance) {
    this.balanceSubject.next(balance);
    try {
      localStorage.setItem(this.BALANCE_KEY, balance.toString());
    } catch (e) {
    }
  }
  saveTransactions(txns) {
    this.transactionsSubject.next(txns);
    try {
      localStorage.setItem(this.TXNS_KEY, JSON.stringify(txns));
    } catch (e) {
    }
  }
};
_PintuPocketService.\u0275fac = function PintuPocketService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _PintuPocketService)();
};
_PintuPocketService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _PintuPocketService, factory: _PintuPocketService.\u0275fac, providedIn: "root" });
var PintuPocketService = _PintuPocketService;

export {
  PintuPocketService
};
//# sourceMappingURL=chunk-PF5HLQEL.js.map
