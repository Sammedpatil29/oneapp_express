import {
  registerPlugin
} from "./chunk-FH4NU4VH.js";

// node_modules/@capacitor/network/dist/esm/index.js
var Network = registerPlugin("Network", {
  web: () => import("./web-VUFIRTZR.js").then((m) => new m.NetworkWeb())
});

export {
  Network
};
//# sourceMappingURL=chunk-TKIKIY3A.js.map
