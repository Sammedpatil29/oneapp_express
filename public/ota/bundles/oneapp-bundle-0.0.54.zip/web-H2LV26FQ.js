import {
  WebPlugin
} from "./chunk-FH4NU4VH.js";
import {
  __async,
  __publicField
} from "./chunk-6B6DTIB5.js";

// node_modules/@otakit/capacitor-updater/dist/esm/web.js
var _OtaKitWeb = class _OtaKitWeb extends WebPlugin {
  BUILTIN_BUNDLE = {
    id: "builtin",
    version: "0.0.0",
    status: "builtin"
  };
  getState() {
    return __async(this, null, function* () {
      return {
        current: this.BUILTIN_BUNDLE,
        fallback: this.BUILTIN_BUNDLE,
        staged: null,
        builtinVersion: this.BUILTIN_BUNDLE.version
      };
    });
  }
  check() {
    return __async(this, null, function* () {
      console.warn("OtaKit.check() is not supported on web");
      return {
        kind: "no_update"
      };
    });
  }
  download() {
    return __async(this, null, function* () {
      console.warn("OtaKit.download() is not supported on web");
      return {
        kind: "no_update"
      };
    });
  }
  apply() {
    return __async(this, null, function* () {
      console.warn("OtaKit.apply() is not supported on web");
      throw new Error("OtaKit.apply() is not supported on web");
    });
  }
  update() {
    return __async(this, null, function* () {
      yield this.download();
    });
  }
  notifyAppReady() {
    return __async(this, null, function* () {
    });
  }
  getLastFailure() {
    return __async(this, null, function* () {
      return null;
    });
  }
  static isValidChannelName(name) {
    if (!/^[A-Za-z0-9._-]{1,64}$/.test(name) || name.includes("..") || name === ".") {
      return false;
    }
    const lower = name.toLowerCase();
    return lower !== "base" && lower !== "default";
  }
  setChannel(options) {
    return __async(this, null, function* () {
      if (options.channel === null) {
        window.localStorage.removeItem(_OtaKitWeb.OVERRIDE_CHANNEL_KEY);
        return;
      }
      if (!_OtaKitWeb.isValidChannelName(options.channel)) {
        throw new Error(`Invalid channel name '${options.channel}': use 1-64 letters, numbers, '.', '_' or '-' (reserved names: base, default)`);
      }
      window.localStorage.setItem(_OtaKitWeb.OVERRIDE_CHANNEL_KEY, options.channel);
    });
  }
  getChannel() {
    return __async(this, null, function* () {
      const override = window.localStorage.getItem(_OtaKitWeb.OVERRIDE_CHANNEL_KEY);
      if (override !== null) {
        return {
          channel: override,
          source: "override"
        };
      }
      return {
        channel: null,
        source: "config"
      };
    });
  }
};
__publicField(_OtaKitWeb, "OVERRIDE_CHANNEL_KEY", "otakit_override_channel");
var OtaKitWeb = _OtaKitWeb;
export {
  OtaKitWeb
};
//# sourceMappingURL=web-H2LV26FQ.js.map
