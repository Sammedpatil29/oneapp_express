import {
  BehaviorSubject,
  ChangeDetectorRef,
  HttpClient,
  signal,
  ɵɵdefineInjectable,
  ɵɵdefinePipe,
  ɵɵdirectiveInject,
  ɵɵinject
} from "./chunk-Z7XNNJSA.js";
import {
  __spreadValues
} from "./chunk-6B6DTIB5.js";

// src/assets/i18n/en.json
var en_default = {
  app_language: "App Language",
  choose_preferred_language: "Choose your preferred display language",
  english: "English",
  jawari_kannada: "Jawari Kannada",
  home: "Home",
  orders: "Orders",
  profile: "Profile",
  cart: "Cart",
  search: "Search",
  search_placeholder: "Search for products, groceries...",
  settings: "App Settings",
  preferences: "Preferences",
  about_us: "About Us",
  privacy_policy: "Privacy Policy",
  terms_conditions: "Terms & Conditions",
  help_support: "Help & Support",
  support: "Support",
  contact_us: "Contact Us",
  saved_addresses: "Saved Addresses",
  payment_methods: "Payment Methods",
  notifications: "Notifications",
  check_for_updates: "Check for OTA Updates",
  up_to_date: "Up to date",
  update_ready: "Update Ready",
  log_out: "Log Out",
  logout_confirm: "Are you sure you want to log out?",
  cancel: "Cancel",
  ok: "OK",
  refresh: "Refresh",
  no_internet_connection: "No Internet Connection",
  check_network: "Please check your network and try again",
  delivery_in_minutes: "Delivery in Minutes",
  delivery_to: "Deliver to",
  view_cart: "View Cart",
  add_to_cart: "Add",
  properties: "Properties",
  real_estate: "Real Estate",
  minutes_app: "Minutes App",
  refer: "Refer",
  account: "Account",
  personal_details: "Personal Details",
  suggest_product_or_service: "Suggest a Product or Service",
  terms_of_service_privacy: "Terms of Service & Privacy",
  about_pintu: "About Pintu",
  appearance_theme: "Appearance & Theme",
  select_theme_mode: "Select your light or dark viewing mode",
  about_application: "About Application",
  app_version: "App Version",
  platform: "Platform",
  log_out_account: "Log Out of Account"
};

// src/assets/i18n/jawari.json
var jawari_default = {
  app_language: "App Bhashe",
  choose_preferred_language: "Nimaga ishtavaada bhashe aarisikori",
  english: "English",
  jawari_kannada: "Jawari Kannada",
  home: "Mani",
  orders: "Orders",
  profile: "Khata",
  cart: "Cheela",
  search: "Hudukri",
  search_placeholder: "Saamanu, kirana hudukri...",
  settings: "App Settings",
  preferences: "Aaykegalu",
  about_us: "Namma Bagge",
  privacy_policy: "Privacy Policy",
  terms_conditions: "Niyamagalu",
  help_support: "Help Beka?",
  support: "Sahaya",
  contact_us: "Contact Maadri",
  saved_addresses: "Save Maadid Vilasagalu",
  payment_methods: "Payment Vidhanagalu",
  notifications: "Notifications",
  check_for_updates: "Hosa update aiten nodri",
  up_to_date: "Ella latest aiti",
  update_ready: "ready aiti",
  log_out: "Horag banni",
  logout_confirm: "Khachitavaagi horag barbeka?",
  cancel: "Cancel",
  ok: "Sari",
  refresh: "Matte nodri",
  no_internet_connection: "Net band aagaiti",
  check_network: "Swalpa network check maadkori bartati!",
  delivery_in_minutes: "Nimishanall mutstevi",
  delivery_to: "Mutso jaaga",
  view_cart: "Cheela nodri",
  add_to_cart: "Haakri",
  properties: "Aastigalu",
  real_estate: "Real Estate",
  minutes_app: "Minutes App",
  refer: "Refer Maadri",
  account: "Khathe",
  personal_details: "Nimma Details",
  suggest_product_or_service: "Hosa item Suggest madri",
  terms_of_service_privacy: "Terms & Privacy Policy",
  about_pintu: "Pintu App Bagge",
  appearance_theme: "App theme Change Madri",
  select_theme_mode: "Light athava dark mode aarisikori",
  about_application: "App Bagge",
  app_version: "App Version",
  platform: "Platform",
  log_out_account: "Account Logout Madri"
};

// src/app/services/language.service.ts
var STORAGE_KEY = "pintu_language";
var _LanguageService = class _LanguageService {
  constructor(http) {
    this.http = http;
    this.languages = [
      { code: "en", name: "English", nativeName: "EN", subtitle: "Standard language" },
      { code: "jw", name: "Jawari Kannada", nativeName: "Jawari", subtitle: "Regional language" }
    ];
    this.dictionaries = {
      en: en_default,
      jw: jawari_default
    };
    this.currentLangSignal = signal("en");
    const saved = (localStorage.getItem(STORAGE_KEY) || "en").toLowerCase();
    const initialLang = saved === "jw" || saved === "hi" || saved === "kn" || saved === "jawari" ? "jw" : "en";
    this.currentLangSubject = new BehaviorSubject(initialLang);
    this.currentLang$ = this.currentLangSubject.asObservable();
    this.currentLangSignal.set(initialLang);
    this.loadJsonDictionary(initialLang);
  }
  getLanguages() {
    return this.languages;
  }
  getCurrentLanguage() {
    return this.currentLangSubject.value;
  }
  setLanguage(code) {
    const targetCode = code === "jw" || code === "hi" || code === "kn" || code === "jawari" ? "jw" : "en";
    localStorage.setItem(STORAGE_KEY, targetCode);
    this.currentLangSubject.next(targetCode);
    this.currentLangSignal.set(targetCode);
    this.loadJsonDictionary(targetCode);
  }
  loadJsonDictionary(lang) {
    const fileName = lang === "jw" ? "jawari.json" : "en.json";
    this.http.get(`assets/i18n/${fileName}`).subscribe({
      next: (dict) => {
        if (dict && typeof dict === "object") {
          this.dictionaries[lang] = __spreadValues(__spreadValues({}, this.dictionaries[lang]), dict);
        }
      },
      error: () => {
      }
    });
  }
  translate(key, fallback) {
    if (!key)
      return "";
    const lang = this.currentLangSubject.value;
    const dict = this.dictionaries[lang] || this.dictionaries["en"];
    if (dict && dict[key] !== void 0) {
      return dict[key];
    }
    if (this.dictionaries["en"] && this.dictionaries["en"][key] !== void 0) {
      return this.dictionaries["en"][key];
    }
    return fallback || key;
  }
  t(key, fallback) {
    return this.translate(key, fallback);
  }
};
_LanguageService.\u0275fac = function LanguageService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _LanguageService)(\u0275\u0275inject(HttpClient));
};
_LanguageService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _LanguageService, factory: _LanguageService.\u0275fac, providedIn: "root" });
var LanguageService = _LanguageService;

// src/app/pipes/translate.pipe.ts
var _TranslatePipe = class _TranslatePipe {
  constructor(languageService, cdr) {
    this.languageService = languageService;
    this.cdr = cdr;
    this.lastKey = "";
    this.lastValue = "";
    this.sub = this.languageService.currentLang$.subscribe(() => {
      if (this.lastKey) {
        this.lastValue = this.languageService.translate(this.lastKey, this.lastFallback);
        this.cdr.markForCheck();
      }
    });
  }
  transform(key, fallback) {
    if (!key)
      return "";
    this.lastKey = key;
    this.lastFallback = fallback;
    this.lastValue = this.languageService.translate(key, fallback);
    return this.lastValue;
  }
  ngOnDestroy() {
    if (this.sub) {
      this.sub.unsubscribe();
    }
  }
};
_TranslatePipe.\u0275fac = function TranslatePipe_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _TranslatePipe)(\u0275\u0275directiveInject(LanguageService, 16), \u0275\u0275directiveInject(ChangeDetectorRef, 16));
};
_TranslatePipe.\u0275pipe = /* @__PURE__ */ \u0275\u0275definePipe({ name: "translate", type: _TranslatePipe, pure: false });
var TranslatePipe = _TranslatePipe;

export {
  LanguageService,
  TranslatePipe
};
//# sourceMappingURL=chunk-EAEIPGUF.js.map
