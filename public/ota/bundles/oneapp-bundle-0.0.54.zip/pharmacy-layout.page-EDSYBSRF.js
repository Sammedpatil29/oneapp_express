import {
  IonRouterOutlet
} from "./chunk-CJE2NDTY.js";
import {
  CommonModule,
  FormsModule,
  ɵsetClassDebugInfo,
  ɵɵdefineComponent,
  ɵɵelement
} from "./chunk-Z7XNNJSA.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import "./chunk-6B6DTIB5.js";

// src/app/pages/pharmacy-layout/pharmacy-layout.page.ts
var _PharmacyLayoutPage = class _PharmacyLayoutPage {
  constructor() {
  }
};
_PharmacyLayoutPage.\u0275fac = function PharmacyLayoutPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _PharmacyLayoutPage)();
};
_PharmacyLayoutPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _PharmacyLayoutPage, selectors: [["app-pharmacy-layout"]], decls: 1, vars: 0, template: function PharmacyLayoutPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-router-outlet");
  }
}, dependencies: [IonRouterOutlet, CommonModule, FormsModule], styles: ["\n\n[_nghost-%COMP%] {\n  display: block;\n  width: 100%;\n  height: 100%;\n}\n/*# sourceMappingURL=pharmacy-layout.page.css.map */"] });
var PharmacyLayoutPage = _PharmacyLayoutPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(PharmacyLayoutPage, { className: "PharmacyLayoutPage", filePath: "src/app/pages/pharmacy-layout/pharmacy-layout.page.ts", lineNumber: 13 });
})();
export {
  PharmacyLayoutPage
};
//# sourceMappingURL=pharmacy-layout.page-EDSYBSRF.js.map
