import {
  DineoutService
} from "./chunk-POD6WOWG.js";
import {
  register
} from "./chunk-TXY46XHU.js";
import {
  addIcons,
  arrowBack,
  arrowBackOutline,
  bicycleOutline,
  callOutline,
  carOutline,
  cardOutline,
  chevronDownOutline,
  chevronUpOutline,
  closeOutline,
  heart,
  heartOutline,
  imagesOutline,
  informationCircleOutline,
  keyOutline,
  laptopOutline,
  leafOutline,
  locationOutline,
  musicalNotesOutline,
  navigateOutline,
  pawOutline,
  shareSocialOutline,
  snowOutline,
  star,
  timeOutline,
  tvOutline,
  wifiOutline,
  wineOutline
} from "./chunk-FJYXZAS7.js";
import "./chunk-YJYUHAOC.js";
import {
  IonButton,
  IonButtons,
  IonContent,
  IonFooter,
  IonHeader,
  IonIcon,
  IonModal,
  IonSkeletonText,
  IonTitle,
  IonToolbar,
  IonicModule
} from "./chunk-OE5MTPUR.js";
import {
  CommonModule,
  DomSanitizer,
  NavController,
  NgForOf,
  NgIf,
  SlicePipe,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementContainerEnd,
  ɵɵelementContainerStart,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnamespaceHTML,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind3,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIndex,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeResourceUrl,
  ɵɵsanitizeUrl,
  ɵɵstyleProp,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1
} from "./chunk-Z7XNNJSA.js";
import "./chunk-XR3JUECC.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-K3HSXS64.js";
import "./chunk-6B6DTIB5.js";

// src/app/pages/dineout-hotel-details/dineout-hotel-details.page.ts
var _c0 = () => [1, 2, 3, 4];
function DineoutHotelDetailsPage_Conditional_8_div_24_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div");
    \u0275\u0275element(1, "ion-skeleton-text", 37)(2, "ion-skeleton-text", 38);
    \u0275\u0275elementEnd();
  }
}
function DineoutHotelDetailsPage_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div")(1, "div", 13);
    \u0275\u0275element(2, "ion-skeleton-text", 14);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 15)(4, "div", 16)(5, "div", 17)(6, "div", 18);
    \u0275\u0275element(7, "ion-skeleton-text", 19)(8, "ion-skeleton-text", 20);
    \u0275\u0275elementEnd();
    \u0275\u0275element(9, "ion-skeleton-text", 21)(10, "ion-skeleton-text", 22);
    \u0275\u0275elementStart(11, "div", 23);
    \u0275\u0275element(12, "ion-skeleton-text", 24);
    \u0275\u0275elementStart(13, "div", 25);
    \u0275\u0275element(14, "ion-skeleton-text", 26)(15, "ion-skeleton-text", 26);
    \u0275\u0275elementEnd()()()()();
    \u0275\u0275elementStart(16, "div", 27);
    \u0275\u0275element(17, "ion-skeleton-text", 28);
    \u0275\u0275elementStart(18, "div", 29);
    \u0275\u0275element(19, "ion-skeleton-text", 30)(20, "ion-skeleton-text", 30);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(21, "div", 27);
    \u0275\u0275element(22, "ion-skeleton-text", 31);
    \u0275\u0275elementStart(23, "div", 32);
    \u0275\u0275template(24, DineoutHotelDetailsPage_Conditional_8_div_24_Template, 3, 0, "div", 33);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(25, "div", 27);
    \u0275\u0275element(26, "ion-skeleton-text", 31);
    \u0275\u0275elementStart(27, "div", 34);
    \u0275\u0275element(28, "ion-skeleton-text", 35)(29, "ion-skeleton-text", 36)(30, "ion-skeleton-text", 36);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    \u0275\u0275advance(24);
    \u0275\u0275property("ngForOf", \u0275\u0275pureFunction0(1, _c0));
  }
}
function DineoutHotelDetailsPage_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "app-error", 39);
    \u0275\u0275listener("reload", function DineoutHotelDetailsPage_Conditional_9_Template_app_error_reload_0_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.loadRestaurantDetails());
    });
    \u0275\u0275elementEnd();
  }
}
function DineoutHotelDetailsPage_Conditional_10_ng_container_36_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainerStart(0);
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2, "Closed,");
    \u0275\u0275elementEnd();
    \u0275\u0275text(3);
    \u0275\u0275elementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" Opens at ", ctx_r1.restaurant.openTime, " ");
  }
}
function DineoutHotelDetailsPage_Conditional_10_ng_container_37_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainerStart(0);
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2, "Open Now");
    \u0275\u0275elementEnd();
    \u0275\u0275elementContainerEnd();
  }
}
function DineoutHotelDetailsPage_Conditional_10_div_44_div_1_span_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const slot_r4 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(slot_r4);
  }
}
function DineoutHotelDetailsPage_Conditional_10_div_44_div_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 75)(1, "span", 76);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 77);
    \u0275\u0275template(4, DineoutHotelDetailsPage_Conditional_10_div_44_div_1_span_4_Template, 2, 1, "span", 33);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const time_r5 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(time_r5.day);
    \u0275\u0275advance(2);
    \u0275\u0275property("ngForOf", time_r5.slots);
  }
}
function DineoutHotelDetailsPage_Conditional_10_div_44_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 73);
    \u0275\u0275template(1, DineoutHotelDetailsPage_Conditional_10_div_44_div_1_Template, 5, 2, "div", 74);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275property("ngForOf", ctx_r1.restaurant.openingHours);
  }
}
function DineoutHotelDetailsPage_Conditional_10_Conditional_45_For_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 80)(1, "div", 81)(2, "div", 82)(3, "h2")(4, "span");
    \u0275\u0275text(5);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "p");
    \u0275\u0275text(7);
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const item_r6 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275classProp("full-width", (ctx_r1.restaurant == null ? null : ctx_r1.restaurant.offers == null ? null : ctx_r1.restaurant.offers.length) === 1);
    \u0275\u0275advance();
    \u0275\u0275styleProp("background", ctx_r1.getOfferBgStyle());
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(item_r6.title);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(item_r6.description);
  }
}
function DineoutHotelDetailsPage_Conditional_10_Conditional_45_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 60)(1, "h3", 61);
    \u0275\u0275text(2, "Offers for you");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 78);
    \u0275\u0275repeaterCreate(4, DineoutHotelDetailsPage_Conditional_10_Conditional_45_For_5_Template, 8, 6, "div", 79, \u0275\u0275repeaterTrackByIndex);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(4);
    \u0275\u0275repeater(ctx_r1.restaurant.offers);
  }
}
function DineoutHotelDetailsPage_Conditional_10_div_50_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 83);
    \u0275\u0275listener("click", function DineoutHotelDetailsPage_Conditional_10_div_50_Template_div_click_0_listener() {
      const i_r8 = \u0275\u0275restoreView(_r7).index;
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.openViewer(ctx_r1.restaurant.menuItems, i_r8, "img"));
    });
    \u0275\u0275elementStart(1, "div", 84);
    \u0275\u0275element(2, "img", 85);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "p");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const menu_r9 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275property("src", menu_r9.img, \u0275\u0275sanitizeUrl);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(menu_r9.title);
  }
}
function DineoutHotelDetailsPage_Conditional_10_div_55_div_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 89)(1, "span");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("+", ctx_r1.restaurant.restaurantPhotos.length - 6, " Photos");
  }
}
function DineoutHotelDetailsPage_Conditional_10_div_55_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 86);
    \u0275\u0275listener("click", function DineoutHotelDetailsPage_Conditional_10_div_55_Template_div_click_0_listener() {
      const i_r11 = \u0275\u0275restoreView(_r10).index;
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.openViewer(ctx_r1.restaurant.restaurantPhotos, i_r11));
    });
    \u0275\u0275element(1, "img", 87);
    \u0275\u0275template(2, DineoutHotelDetailsPage_Conditional_10_div_55_div_2_Template, 3, 1, "div", 88);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const photo_r12 = ctx.$implicit;
    const i_r11 = ctx.index;
    const last_r13 = ctx.last;
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275classProp("large", i_r11 === 0);
    \u0275\u0275advance();
    \u0275\u0275property("src", photo_r12, \u0275\u0275sanitizeUrl);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", last_r13 && ctx_r1.restaurant.restaurantPhotos.length > 6);
  }
}
function DineoutHotelDetailsPage_Conditional_10_div_61_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 90);
    \u0275\u0275element(1, "ion-icon", 55);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const item_r14 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275property("name", item_r14.icon);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(item_r14.name);
  }
}
function DineoutHotelDetailsPage_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementContainerStart(0);
    \u0275\u0275elementStart(1, "div", 13);
    \u0275\u0275element(2, "img", 40);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 15)(4, "div", 16)(5, "div", 41)(6, "span");
    \u0275\u0275element(7, "img", 42);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "span")(9, "b");
    \u0275\u0275text(10);
    \u0275\u0275elementEnd();
    \u0275\u0275text(11, " Star Rating from ");
    \u0275\u0275elementStart(12, "b");
    \u0275\u0275text(13);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "span");
    \u0275\u0275text(15, "\xA0");
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(16, "svg", 43)(17, "style");
    \u0275\u0275text(18, ".st0{fill:#3780ff}.st1{fill:#38b137}.st2{fill:#fa3913}.st3{fill:#fcbd06}");
    \u0275\u0275elementEnd();
    \u0275\u0275element(19, "path", 44)(20, "path", 45)(21, "path", 46)(22, "path", 47)(23, "path", 48)(24, "path", 49);
    \u0275\u0275elementEnd()();
    \u0275\u0275text(25, " users");
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(26, "div", 17)(27, "div", 18)(28, "h1", 50);
    \u0275\u0275text(29);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(30, "div", 51);
    \u0275\u0275text(31);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(32, "p", 52);
    \u0275\u0275text(33);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(34, "div", 23)(35, "div", 53);
    \u0275\u0275listener("click", function DineoutHotelDetailsPage_Conditional_10_Template_div_click_35_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.toggleHours());
    });
    \u0275\u0275template(36, DineoutHotelDetailsPage_Conditional_10_ng_container_36_Template, 4, 1, "ng-container", 54)(37, DineoutHotelDetailsPage_Conditional_10_ng_container_37_Template, 3, 0, "ng-container", 54);
    \u0275\u0275element(38, "ion-icon", 55);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(39, "div", 25)(40, "div", 56);
    \u0275\u0275listener("click", function DineoutHotelDetailsPage_Conditional_10_Template_div_click_40_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.openMap());
    });
    \u0275\u0275element(41, "ion-icon", 57);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(42, "div", 56);
    \u0275\u0275listener("click", function DineoutHotelDetailsPage_Conditional_10_Template_div_click_42_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.callRestaurant());
    });
    \u0275\u0275element(43, "ion-icon", 58);
    \u0275\u0275elementEnd()()();
    \u0275\u0275template(44, DineoutHotelDetailsPage_Conditional_10_div_44_Template, 2, 1, "div", 59);
    \u0275\u0275elementEnd()()();
    \u0275\u0275template(45, DineoutHotelDetailsPage_Conditional_10_Conditional_45_Template, 6, 0, "div", 60);
    \u0275\u0275elementStart(46, "div", 60)(47, "h3", 61);
    \u0275\u0275text(48, "Menu");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(49, "div", 62);
    \u0275\u0275template(50, DineoutHotelDetailsPage_Conditional_10_div_50_Template, 5, 2, "div", 63);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(51, "div", 60)(52, "h3", 61);
    \u0275\u0275text(53, "Photos");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(54, "div", 34);
    \u0275\u0275template(55, DineoutHotelDetailsPage_Conditional_10_div_55_Template, 3, 4, "div", 64);
    \u0275\u0275pipe(56, "slice");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(57, "div", 60)(58, "h3", 61);
    \u0275\u0275text(59, "Amenities");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(60, "div", 65);
    \u0275\u0275template(61, DineoutHotelDetailsPage_Conditional_10_div_61_Template, 4, 2, "div", 66);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(62, "div", 60)(63, "h3", 61);
    \u0275\u0275text(64, "Location");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(65, "div", 67)(66, "div", 68);
    \u0275\u0275element(67, "iframe", 69);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(68, "div", 70)(69, "div", 71)(70, "p");
    \u0275\u0275text(71);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(72, "div", 72);
    \u0275\u0275element(73, "ion-icon", 57);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(2);
    \u0275\u0275property("src", ctx_r1.restaurant.image, \u0275\u0275sanitizeUrl);
    \u0275\u0275advance(8);
    \u0275\u0275textInterpolate(ctx_r1.restaurant.rating);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx_r1.restaurant.ratingCount);
    \u0275\u0275advance(16);
    \u0275\u0275textInterpolate(ctx_r1.restaurant.name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" ", ctx_r1.restaurant.location, " ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.restaurant.tags);
    \u0275\u0275advance(2);
    \u0275\u0275classProp("closed", !ctx_r1.restaurant.isOpen)("open", ctx_r1.restaurant.isOpen);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", !ctx_r1.restaurant.isOpen);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", ctx_r1.restaurant.isOpen);
    \u0275\u0275advance();
    \u0275\u0275property("name", ctx_r1.showHours ? "chevron-up-outline" : "chevron-down-outline");
    \u0275\u0275advance(6);
    \u0275\u0275property("ngIf", ctx_r1.showHours);
    \u0275\u0275advance();
    \u0275\u0275conditional((ctx_r1.restaurant == null ? null : ctx_r1.restaurant.offers == null ? null : ctx_r1.restaurant.offers.length) > 0 ? 45 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275property("ngForOf", ctx_r1.restaurant.menuItems);
    \u0275\u0275advance(5);
    \u0275\u0275property("ngForOf", \u0275\u0275pipeBind3(56, 20, ctx_r1.restaurant.restaurantPhotos, 0, 6));
    \u0275\u0275advance(6);
    \u0275\u0275property("ngForOf", ctx_r1.restaurant.amenities);
    \u0275\u0275advance(6);
    \u0275\u0275property("src", ctx_r1.safeMapUrl, \u0275\u0275sanitizeResourceUrl);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r1.restaurant.address);
  }
}
function DineoutHotelDetailsPage_ng_template_13_swiper_container_3_swiper_slide_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "swiper-slide")(1, "div", 96);
    \u0275\u0275element(2, "img", 97);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const img_r16 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275property("src", img_r16, \u0275\u0275sanitizeUrl);
  }
}
function DineoutHotelDetailsPage_ng_template_13_swiper_container_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "swiper-container", 95);
    \u0275\u0275template(1, DineoutHotelDetailsPage_ng_template_13_swiper_container_3_swiper_slide_1_Template, 3, 1, "swiper-slide", 33);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275property("initialSlide", ctx_r1.viewerInitialIndex);
    \u0275\u0275advance();
    \u0275\u0275property("ngForOf", ctx_r1.viewerImages);
  }
}
function DineoutHotelDetailsPage_ng_template_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-content", 91)(1, "div", 92);
    \u0275\u0275listener("click", function DineoutHotelDetailsPage_ng_template_13_Template_div_click_1_listener() {
      \u0275\u0275restoreView(_r15);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.closeViewer());
    });
    \u0275\u0275element(2, "ion-icon", 93);
    \u0275\u0275elementEnd();
    \u0275\u0275template(3, DineoutHotelDetailsPage_ng_template_13_swiper_container_3_Template, 2, 2, "swiper-container", 94);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(3);
    \u0275\u0275property("ngIf", ctx_r1.isViewerOpen);
  }
}
register();
var _DineoutHotelDetailsPage = class _DineoutHotelDetailsPage {
  constructor(sanitizer, dineoutService, navCtrl) {
    this.sanitizer = sanitizer;
    this.dineoutService = dineoutService;
    this.navCtrl = navCtrl;
    this.activeSegment = "offers";
    this.showHours = false;
    this.isLoading = true;
    this.isError = false;
    this.isViewerOpen = false;
    this.viewerImages = [];
    this.viewerInitialIndex = 0;
    this.restaurant = {};
    this.bgColorStyle = [
      "linear-gradient(to right, #0e4d2a, #15663a)"
    ];
    addIcons({
      arrowBack,
      arrowBackOutline,
      shareSocialOutline,
      heartOutline,
      heart,
      star,
      timeOutline,
      callOutline,
      locationOutline,
      navigateOutline,
      imagesOutline,
      chevronDownOutline,
      chevronUpOutline,
      closeOutline,
      informationCircleOutline,
      wifiOutline,
      snowOutline,
      carOutline,
      wineOutline,
      musicalNotesOutline,
      cardOutline,
      keyOutline,
      pawOutline,
      laptopOutline,
      bicycleOutline,
      tvOutline,
      leafOutline
    });
  }
  ngOnInit() {
    this.restaurantId = window.location.pathname.split("/").pop();
    this.loadRestaurantDetails();
  }
  callRestaurant() {
    window.open(`tel:${this.restaurant.contact}`, "_self");
  }
  openMap() {
    const lat = this.restaurant.coords.lat;
    const lng = this.restaurant.coords.lng;
    const url = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;
    window.open(url, "_blank");
  }
  toggleHours() {
    this.showHours = !this.showHours;
  }
  getOfferBgStyle() {
    return this.bgColorStyle[Math.floor(Math.random() * this.bgColorStyle.length)];
  }
  checkRestaurantStatus() {
    var _a;
    const now = /* @__PURE__ */ new Date();
    const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const currentDay = days[now.getDay()];
    let isOpen = false;
    const todaySchedule = (_a = this.restaurant) == null ? void 0 : _a.openingHours.find((h) => h.day === currentDay);
    if (todaySchedule) {
      for (const slot of todaySchedule.slots) {
        if (this.isTimeInSlot(now, slot)) {
          isOpen = true;
          break;
        }
      }
    }
    if (!isOpen) {
      const yesterdayIndex = (now.getDay() + 6) % 7;
      const yesterdayDay = days[yesterdayIndex];
      const yesterdaySchedule = this.restaurant.openingHours.find((h) => h.day === yesterdayDay);
      if (yesterdaySchedule) {
        for (const slot of yesterdaySchedule.slots) {
          if (this.isTimeInSlot(now, slot, true)) {
            isOpen = true;
            break;
          }
        }
      }
    }
    this.restaurant.isOpen = isOpen;
    if (!isOpen) {
      this.updateNextOpenTime(now, currentDay);
    }
  }
  isTimeInSlot(now, slot, isYesterday = false) {
    const [startStr, endStr] = slot.split(" - ");
    const baseDate = new Date(now);
    if (isYesterday)
      baseDate.setDate(baseDate.getDate() - 1);
    const startTime = this.parseTime(startStr, baseDate);
    let endTime = this.parseTime(endStr, baseDate);
    if (endTime < startTime) {
      endTime.setDate(endTime.getDate() + 1);
    }
    return now >= startTime && now <= endTime;
  }
  parseTime(timeStr, baseDate) {
    const d = new Date(baseDate);
    const [time, modifier] = timeStr.split(" ");
    let [hours, minutes] = time.split(":").map(Number);
    if (hours === 12)
      hours = 0;
    if (modifier === "PM")
      hours += 12;
    d.setHours(hours, minutes, 0, 0);
    return d;
  }
  updateNextOpenTime(now, currentDay) {
    const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const dayIndex = days.indexOf(currentDay);
    const todaySchedule = this.restaurant.openingHours.find((h) => h.day === currentDay);
    if (todaySchedule) {
      for (const slot of todaySchedule.slots) {
        const [startStr] = slot.split(" - ");
        const startTime = this.parseTime(startStr, now);
        if (startTime > now) {
          this.restaurant.openTime = startStr;
          return;
        }
      }
    }
    for (let i = 1; i <= 7; i++) {
      const nextDayIndex = (dayIndex + i) % 7;
      const nextDay = days[nextDayIndex];
      const schedule = this.restaurant.openingHours.find((h) => h.day === nextDay);
      if (schedule && schedule.slots.length > 0) {
        const firstSlot = schedule.slots[0];
        const [startStr] = firstSlot.split(" - ");
        this.restaurant.openTime = `${nextDay} ${startStr}`;
        return;
      }
    }
  }
  openViewer(source, index, key) {
    if (key) {
      this.viewerImages = source.map((item) => item[key]);
    } else {
      this.viewerImages = source;
    }
    this.viewerInitialIndex = index;
    this.isViewerOpen = true;
  }
  closeViewer() {
    this.isViewerOpen = false;
  }
  goBack() {
    this.navCtrl.navigateBack("/layout/dineout-layout/dineout");
  }
  loadRestaurantDetails() {
    this.isLoading = true;
    this.isError = false;
    this.dineoutService.getRestaurantDetails(this.restaurantId).subscribe((res) => {
      console.log(res);
      this.restaurant = res.data;
      this.safeMapUrl = this.sanitizer.bypassSecurityTrustResourceUrl(this.restaurant.mapEmbedUrl);
      this.checkRestaurantStatus();
      this.isLoading = false;
    }, () => {
      this.isLoading = false;
      this.isError = true;
    });
  }
  bookTable() {
    this.navCtrl.navigateForward(`/layout/dineout-layout/dineout-select-time/${this.restaurantId}`);
  }
  payBillNow() {
    this.navCtrl.navigateForward(`/layout/dineout-layout/dineout-paybill`, {
      state: { restaurantId: this.restaurantId, from: "hotel-details" }
    });
  }
};
_DineoutHotelDetailsPage.\u0275fac = function DineoutHotelDetailsPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _DineoutHotelDetailsPage)(\u0275\u0275directiveInject(DomSanitizer), \u0275\u0275directiveInject(DineoutService), \u0275\u0275directiveInject(NavController));
};
_DineoutHotelDetailsPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _DineoutHotelDetailsPage, selectors: [["app-dineout-hotel-details"]], decls: 20, vars: 4, consts: [[1, "ion-no-border", "bg-white", "pt-2"], ["slot", "start"], [3, "click"], ["name", "arrow-back-outline", "color", "dark"], [1, "fw-bold", "text-dark"], [1, "bg-light", 3, "fullscreen"], ["title", "Oops! Home page failed to load"], [2, "height", "100px"], [1, "image-viewer-modal", 3, "didDismiss", "isOpen"], [1, "dual-footer"], [1, "footer-inner"], [1, "btn-book", 3, "click"], [1, "btn-pay", 3, "click"], [1, "hero-container"], ["animated", "", 2, "width", "100%", "height", "100%", "margin", "0"], [1, "floating-card-wrapper"], [1, "info-card"], [1, "card-body"], [1, "flex-row"], ["animated", "", 2, "width", "60%", "height", "24px", "border-radius", "4px"], ["animated", "", 2, "width", "40px", "height", "24px", "border-radius", "4px"], ["animated", "", 2, "width", "40%", "height", "16px", "margin-top", "12px", "border-radius", "4px"], ["animated", "", 2, "width", "30%", "height", "16px", "margin-top", "8px", "margin-bottom", "16px", "border-radius", "4px"], [1, "action-row"], ["animated", "", 2, "width", "140px", "height", "40px", "border-radius", "8px"], [1, "icon-actions"], ["animated", "", 2, "width", "36px", "height", "36px", "border-radius", "10px"], [1, "section-content", 2, "margin-top", "20px"], ["animated", "", 2, "width", "120px", "height", "20px", "margin-bottom", "12px", "border-radius", "4px"], [2, "display", "flex", "gap", "16px", "overflow", "hidden"], ["animated", "", 2, "min-width", "280px", "height", "100px", "border-radius", "16px"], ["animated", "", 2, "width", "80px", "height", "20px", "margin-bottom", "12px", "border-radius", "4px"], [2, "display", "flex", "gap", "15px", "overflow", "hidden"], [4, "ngFor", "ngForOf"], [1, "bento-grid"], ["animated", "", 2, "grid-column", "span 2", "grid-row", "span 2", "width", "100%", "height", "100%", "border-radius", "12px"], ["animated", "", 2, "width", "100%", "height", "100%", "border-radius", "12px"], ["animated", "", 2, "width", "100px", "height", "100px", "border-radius", "12px", "margin-bottom", "8px"], ["animated", "", 2, "width", "60px", "height", "12px", "margin", "0 auto", "border-radius", "4px"], ["title", "Oops! Home page failed to load", 3, "reload"], ["alt", "Restaurant Cover", 1, "hero-img", 3, "src"], [1, "badge-strip", "d-flex", "align-items-center"], ["src", "assets/gif/wired-flat-237-star-rating-hover-pinch.gif", "alt", "", 1, "mb-1", 2, "width", "21px"], ["height", "33px", "viewBox", "0 -200.75 596 596", "id", "Layer_1", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M73.4 0h5.3c18.4.4 36.5 7.8 49.5 20.9-4.8 4.9-9.7 9.6-14.4 14.5-7.3-6.6-16.1-11.7-25.7-13.5-14.2-3-29.5-.3-41.4 7.8C33.7 38.2 24.9 52.6 23 68c-2.1 15.2 2.2 31.2 12.1 43 9.5 11.5 24 18.7 39 19.2 14 .8 28.6-3.5 38.8-13.3 8-6.9 11.7-17.4 12.9-27.6-16.6 0-33.2.1-49.8 0V68.7h69.9c3.6 22.1-1.6 47-18.4 62.8-11.2 11.2-26.7 17.8-42.5 19.1-15.3 1.5-31.1-1.4-44.7-8.8C24 133.1 11 118.4 4.6 101.1c-6-15.9-6.1-33.9-.5-49.9C9.2 36.6 19 23.7 31.6 14.7 43.7 5.8 58.4.9 73.4 0z", 1, "st0"], ["d", "M474.4 5.2h21.4V148c-7.1 0-14.3.1-21.4-.1.1-47.5 0-95.1 0-142.7z", 1, "st1"], ["d", "M193.5 54.7c13.2-2.5 27.5.3 38.4 8.2 9.9 7 16.8 18 18.9 30 2.7 13.9-.7 29.1-9.7 40.1-9.7 12.3-25.6 18.9-41.1 17.9-14.2-.8-28-7.9-36.4-19.5-9.5-12.8-11.8-30.4-6.6-45.4 5.2-16.1 19.9-28.4 36.5-31.3m3 19c-5.4 1.4-10.4 4.5-14 8.9-9.7 11.6-9.1 30.5 1.6 41.3 6.1 6.2 15.3 9.1 23.8 7.4 7.9-1.4 14.8-6.7 18.6-13.7 6.6-11.9 4.7-28.3-5.4-37.6-6.5-6-16-8.5-24.6-6.3z", 1, "st2"], ["d", "M299.5 54.7c15.1-2.9 31.6 1.3 42.9 11.9 18.4 16.5 20.4 47.4 4.7 66.4-9.5 12-24.9 18.6-40.1 17.9-14.5-.4-28.8-7.6-37.4-19.5-9.7-13.1-11.8-31.1-6.3-46.4 5.5-15.6 19.9-27.5 36.2-30.3m3 19c-5.4 1.4-10.4 4.5-14 8.8-9.6 11.4-9.2 30 1.1 40.9 6.1 6.5 15.6 9.7 24.4 7.9 7.8-1.5 14.8-6.7 18.6-13.7 6.5-12 4.6-28.4-5.6-37.7-6.5-6-16-8.4-24.5-6.2z", 1, "st3"], ["d", "M389.4 60.5c11.5-7.2 26.8-9.2 39.2-3 3.9 1.7 7.1 4.6 10.2 7.5.1-2.7 0-5.5.1-8.3 6.7.1 13.4 0 20.2.1V145c-.1 13.3-3.5 27.4-13.1 37.1-10.5 10.7-26.6 14-41.1 11.8-15.5-2.3-29-13.6-35-27.9 6-2.9 12.3-5.2 18.5-7.9 3.5 8.2 10.6 15.2 19.5 16.8 8.9 1.6 19.2-.6 25-8 6.2-7.6 6.2-18 5.9-27.3-4.6 4.5-9.9 8.5-16.3 10-13.9 3.9-29.2-.9-39.9-10.3-10.8-9.4-17.2-23.9-16.6-38.3.3-16.3 9.5-32 23.4-40.5m20.7 12.8c-6.1 1-11.8 4.4-15.7 9.1-9.4 11.2-9.4 29.1.1 40.1 5.4 6.5 14.1 10.1 22.5 9.2 7.9-.8 15.2-5.8 19.1-12.7 6.6-11.7 5.5-27.6-3.4-37.8-5.5-6.3-14.3-9.4-22.6-7.9z", 1, "st0"], ["d", "M521.5 65.6c12-11.2 30.5-15 45.9-9.1C582 62 591.3 75.9 596 90.2c-21.7 9-43.3 17.9-65 26.9 3 5.7 7.6 10.9 13.8 13 8.7 3.1 19.1 2 26.4-3.8 2.9-2.2 5.2-5.1 7.4-7.9 5.5 3.7 11 7.3 16.5 11-7.8 11.7-20.9 19.9-35 21.2-15.6 1.9-32.2-4.1-42.3-16.3-16.6-19.2-15-51.4 3.7-68.7m10.7 18.5c-3.4 4.9-4.8 10.9-4.7 16.8 14.5-6 29-12 43.5-18.1-2.4-5.6-8.2-9-14.1-9.9-9.5-1.7-19.4 3.4-24.7 11.2z", 1, "st2"], [1, "rest-name"], [1, "meta-info"], [1, "cuisine"], [1, "status-pill", 3, "click"], [4, "ngIf"], [3, "name"], [1, "action-btn", 3, "click"], ["name", "navigate-outline"], ["name", "call-outline"], ["class", "hours-list", 4, "ngIf"], [1, "section-content"], [1, "mt-3"], [1, "menu-scroll-container"], ["class", "menu-item", 3, "click", 4, "ngFor", "ngForOf"], ["class", "photo-item", 3, "large", "click", 4, "ngFor", "ngForOf"], [1, "amenities-grid"], ["class", "amenity-box", 4, "ngFor", "ngForOf"], [1, "location-card"], [1, "map-frame"], ["width", "100%", "height", "100%", "allowfullscreen", "", "loading", "lazy", 2, "border", "0", 3, "src"], [1, "address-box"], [1, "addr-text"], [1, "map-icon-btn"], [1, "hours-list"], ["class", "day-row", 4, "ngFor", "ngForOf"], [1, "day-row"], [1, "day-name"], [1, "time-slots"], [1, "offers-scroll-container"], [1, "offer-item", 3, "full-width"], [1, "offer-item"], [1, "green-banner", "text-center"], [1, "banner-content"], [1, "menu-item", 3, "click"], [1, "img-wrapper"], ["alt", "Menu", 3, "src"], [1, "photo-item", 3, "click"], ["alt", "Restaurant Photo", 3, "src"], ["class", "more-overlay", 4, "ngIf"], [1, "more-overlay"], [1, "amenity-box"], [1, "viewer-content"], [1, "close-btn", 3, "click"], ["name", "close-outline"], ["zoom", "true", "navigation", "true", "pagination", "true", "style", "height: 100%", 3, "initialSlide", 4, "ngIf"], ["zoom", "true", "navigation", "true", "pagination", "true", 2, "height", "100%", 3, "initialSlide"], [1, "swiper-zoom-container"], [3, "src"]], template: function DineoutHotelDetailsPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar")(2, "ion-buttons", 1)(3, "ion-button", 2);
    \u0275\u0275listener("click", function DineoutHotelDetailsPage_Template_ion_button_click_3_listener() {
      return ctx.goBack();
    });
    \u0275\u0275element(4, "ion-icon", 3);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "ion-title", 4);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(7, "ion-content", 5);
    \u0275\u0275template(8, DineoutHotelDetailsPage_Conditional_8_Template, 31, 2, "div")(9, DineoutHotelDetailsPage_Conditional_9_Template, 1, 0, "app-error", 6)(10, DineoutHotelDetailsPage_Conditional_10_Template, 74, 24, "ng-container");
    \u0275\u0275element(11, "div", 7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "ion-modal", 8);
    \u0275\u0275listener("didDismiss", function DineoutHotelDetailsPage_Template_ion_modal_didDismiss_12_listener() {
      return ctx.closeViewer();
    });
    \u0275\u0275template(13, DineoutHotelDetailsPage_ng_template_13_Template, 4, 1, "ng-template");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "ion-footer", 9)(15, "div", 10)(16, "button", 11);
    \u0275\u0275listener("click", function DineoutHotelDetailsPage_Template_button_click_16_listener() {
      return ctx.bookTable();
    });
    \u0275\u0275text(17, "Book a table");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "button", 12);
    \u0275\u0275listener("click", function DineoutHotelDetailsPage_Template_button_click_18_listener() {
      return ctx.payBillNow();
    });
    \u0275\u0275text(19, "Pay bill now");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate((ctx.restaurant == null ? null : ctx.restaurant.name) || "Restaurant Details");
    \u0275\u0275advance();
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.isLoading ? 8 : ctx.isError ? 9 : 10);
    \u0275\u0275advance(4);
    \u0275\u0275property("isOpen", ctx.isViewerOpen);
  }
}, dependencies: [IonicModule, IonButton, IonButtons, IonContent, IonFooter, IonHeader, IonIcon, IonSkeletonText, IonTitle, IonToolbar, IonModal, CommonModule, NgForOf, NgIf, SlicePipe], styles: ["\n\nion-header[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  z-index: 10;\n}\nion-header[_ngcontent-%COMP%]   ion-toolbar[_ngcontent-%COMP%] {\n  --background: transparent;\n  padding-top: var(--ion-safe-area-top);\n}\nion-header[_ngcontent-%COMP%]   ion-toolbar[_ngcontent-%COMP%]   ion-buttons[_ngcontent-%COMP%]   ion-button[_ngcontent-%COMP%], \nion-header[_ngcontent-%COMP%]   ion-toolbar[_ngcontent-%COMP%]   ion-back-button[_ngcontent-%COMP%] {\n  --color: #fff;\n  background: rgba(0, 0, 0, 0.3);\n  border-radius: 50%;\n  width: 40px;\n  height: 40px;\n  -webkit-backdrop-filter: blur(4px);\n  backdrop-filter: blur(4px);\n  margin: 0 4px;\n}\n.bg-light[_ngcontent-%COMP%] {\n  --background: #f4f5f8;\n}\n.hero-container[_ngcontent-%COMP%] {\n  height: 38vh;\n  position: relative;\n  background: #ddd;\n}\n.hero-container[_ngcontent-%COMP%]   .hero-img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n.hero-container[_ngcontent-%COMP%]   .gallery-pill[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 50px;\n  right: 16px;\n  background: rgba(255, 255, 255, 0.8);\n  -webkit-backdrop-filter: blur(4px);\n  backdrop-filter: blur(4px);\n  padding: 6px 12px;\n  border-radius: 20px;\n  font-size: 12px;\n  font-weight: 700;\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  z-index: 2;\n}\n.floating-card-wrapper[_ngcontent-%COMP%] {\n  padding: 0 16px;\n  margin-top: -40px;\n  position: relative;\n  z-index: 5;\n}\n.floating-card-wrapper[_ngcontent-%COMP%]   .info-card[_ngcontent-%COMP%] {\n  background: #fff;\n  border-radius: 20px;\n  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);\n  overflow: hidden;\n}\n.floating-card-wrapper[_ngcontent-%COMP%]   .info-card[_ngcontent-%COMP%]   .badge-strip[_ngcontent-%COMP%] {\n  background: #e6fcf5;\n  padding: 8px 16px;\n  display: flex;\n  align-items: center;\n  gap: 7px;\n}\n.floating-card-wrapper[_ngcontent-%COMP%]   .info-card[_ngcontent-%COMP%]   .badge-strip[_ngcontent-%COMP%]   .gold-hex[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #d4a04d,\n      #b8860b);\n  color: white;\n  font-weight: 800;\n  font-size: 11px;\n  padding: 4px;\n  clip-path: polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%);\n  width: 28px;\n  height: 26px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.floating-card-wrapper[_ngcontent-%COMP%]   .info-card[_ngcontent-%COMP%]   .badge-strip[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 600;\n  color: #0f5132;\n}\n.floating-card-wrapper[_ngcontent-%COMP%]   .info-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%] {\n  padding: 16px;\n}\n.floating-card-wrapper[_ngcontent-%COMP%]   .info-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .flex-row[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-start;\n}\n.floating-card-wrapper[_ngcontent-%COMP%]   .info-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .flex-row[_ngcontent-%COMP%]   .rest-name[_ngcontent-%COMP%] {\n  font-size: 20px;\n  font-weight: 800;\n  color: #1a1a1a;\n  margin: 0;\n  width: 75%;\n  line-height: 1.2;\n}\n.floating-card-wrapper[_ngcontent-%COMP%]   .info-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .flex-row[_ngcontent-%COMP%]   .rating-box[_ngcontent-%COMP%] {\n  background: #1b8040;\n  color: white;\n  border-radius: 6px;\n  padding: 4px 6px;\n  text-align: center;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n}\n.floating-card-wrapper[_ngcontent-%COMP%]   .info-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .flex-row[_ngcontent-%COMP%]   .rating-box[_ngcontent-%COMP%]   .score[_ngcontent-%COMP%] {\n  font-weight: 700;\n  font-size: 14px;\n  display: flex;\n  align-items: center;\n  gap: 2px;\n}\n.floating-card-wrapper[_ngcontent-%COMP%]   .info-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .flex-row[_ngcontent-%COMP%]   .rating-box[_ngcontent-%COMP%]   .source[_ngcontent-%COMP%] {\n  font-size: 8px;\n  opacity: 0.9;\n}\n.floating-card-wrapper[_ngcontent-%COMP%]   .info-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .flex-row[_ngcontent-%COMP%]   .rating-box[_ngcontent-%COMP%]   .count[_ngcontent-%COMP%] {\n  font-size: 8px;\n  border-top: 1px solid rgba(255, 255, 255, 0.3);\n  margin-top: 2px;\n  padding-top: 2px;\n  width: 100%;\n}\n.floating-card-wrapper[_ngcontent-%COMP%]   .info-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .meta-info[_ngcontent-%COMP%] {\n  font-size: 13px;\n  color: #1a1a1a;\n  margin-top: 8px;\n  display: flex;\n  align-items: center;\n  gap: 4px;\n}\n.floating-card-wrapper[_ngcontent-%COMP%]   .info-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .meta-info[_ngcontent-%COMP%]   .dist[_ngcontent-%COMP%] {\n  font-weight: 600;\n}\n.floating-card-wrapper[_ngcontent-%COMP%]   .info-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .meta-info[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: #ff4500;\n}\n.floating-card-wrapper[_ngcontent-%COMP%]   .info-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .cuisine[_ngcontent-%COMP%] {\n  font-size: 13px;\n  color: #666;\n  margin: 4px 0 16px;\n}\n.floating-card-wrapper[_ngcontent-%COMP%]   .info-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .action-row[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n.floating-card-wrapper[_ngcontent-%COMP%]   .info-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .action-row[_ngcontent-%COMP%]   .status-pill[_ngcontent-%COMP%] {\n  background: #f8f9fa;\n  padding: 8px 12px;\n  border-radius: 8px;\n  font-size: 12px;\n  color: #666;\n  display: flex;\n  align-items: center;\n  gap: 4px;\n}\n.floating-card-wrapper[_ngcontent-%COMP%]   .info-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .action-row[_ngcontent-%COMP%]   .status-pill.closed[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: #dc3545;\n  font-weight: 700;\n}\n.floating-card-wrapper[_ngcontent-%COMP%]   .info-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .action-row[_ngcontent-%COMP%]   .status-pill.open[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: #1b8040;\n  font-weight: 700;\n}\n.floating-card-wrapper[_ngcontent-%COMP%]   .info-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .action-row[_ngcontent-%COMP%]   .icon-actions[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 12px;\n}\n.floating-card-wrapper[_ngcontent-%COMP%]   .info-card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%]   .action-row[_ngcontent-%COMP%]   .icon-actions[_ngcontent-%COMP%]   .action-btn[_ngcontent-%COMP%] {\n  width: 36px;\n  height: 36px;\n  background: #f4f5f8;\n  border-radius: 10px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  color: #1a1a1a;\n  font-size: 18px;\n}\n.hours-list[_ngcontent-%COMP%] {\n  margin-top: 16px;\n  padding-top: 12px;\n  border-top: 1px solid #f0f0f0;\n  animation: _ngcontent-%COMP%_slideDown 0.3s ease-out;\n}\n.hours-list[_ngcontent-%COMP%]   .day-row[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  font-size: 13px;\n  margin-bottom: 8px;\n}\n.hours-list[_ngcontent-%COMP%]   .day-row[_ngcontent-%COMP%]   .day-name[_ngcontent-%COMP%] {\n  font-weight: 600;\n  color: #333;\n  width: 90px;\n}\n.hours-list[_ngcontent-%COMP%]   .day-row[_ngcontent-%COMP%]   .time-slots[_ngcontent-%COMP%] {\n  flex: 1;\n  text-align: right;\n  display: flex;\n  flex-direction: column;\n  color: #666;\n}\n.hours-list[_ngcontent-%COMP%]   .day-row[_ngcontent-%COMP%]   .time-slots[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  margin-bottom: 2px;\n}\n@keyframes _ngcontent-%COMP%_slideDown {\n  from {\n    opacity: 0;\n    transform: translateY(-5px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n.banner-section[_ngcontent-%COMP%] {\n  padding: 20px 16px;\n}\n.green-banner[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      to right,\n      #0e4d2a,\n      #15663a);\n  border-radius: 16px;\n  padding: 20px;\n  color: white;\n  position: relative;\n  overflow: hidden;\n}\n.green-banner[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 22px;\n  font-weight: 800;\n}\n.green-banner[_ngcontent-%COMP%]   .strike[_ngcontent-%COMP%] {\n  text-decoration: line-through;\n  opacity: 0.7;\n  font-weight: 400;\n  font-size: 18px;\n  margin-right: 4px;\n}\n.green-banner[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 4px 0 0;\n  font-size: 14px;\n  opacity: 0.9;\n}\n.offers-scroll-container[_ngcontent-%COMP%] {\n  display: flex;\n  overflow-x: auto;\n  gap: 16px;\n  padding-bottom: 10px;\n  scrollbar-width: none;\n}\n.offers-scroll-container[_ngcontent-%COMP%]::-webkit-scrollbar {\n  display: none;\n}\n.offers-scroll-container[_ngcontent-%COMP%]   .offer-item[_ngcontent-%COMP%] {\n  min-width: 280px;\n  flex-shrink: 0;\n}\n.offers-scroll-container[_ngcontent-%COMP%]   .offer-item.full-width[_ngcontent-%COMP%] {\n  min-width: 100%;\n}\n.offers-scroll-container[_ngcontent-%COMP%]   .offer-item[_ngcontent-%COMP%]   .green-banner[_ngcontent-%COMP%] {\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n}\n.segment-scroll[_ngcontent-%COMP%] {\n  display: flex;\n  overflow-x: auto;\n  padding: 0 16px;\n  gap: 15px;\n  border-bottom: 1px solid #eee;\n  padding-bottom: 12px;\n  margin-bottom: 16px;\n}\n.segment-scroll[_ngcontent-%COMP%]::-webkit-scrollbar {\n  display: none;\n}\n.segment-scroll[_ngcontent-%COMP%]   .segment-btn[_ngcontent-%COMP%] {\n  white-space: nowrap;\n  font-size: 14px;\n  font-weight: 600;\n  color: #666;\n  padding: 6px 12px;\n  border-radius: 20px;\n  transition: all 0.2s;\n}\n.segment-scroll[_ngcontent-%COMP%]   .segment-btn.active[_ngcontent-%COMP%] {\n  background: #1a1a1a;\n  color: white;\n}\n.section-content[_ngcontent-%COMP%] {\n  padding: 0 16px;\n}\n.section-content[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  font-size: 18px;\n  font-weight: 700;\n  margin-bottom: 12px;\n}\n.section-content[_ngcontent-%COMP%]   .dine-cash-strip[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      90deg,\n      #eafff5,\n      #f0fff8);\n  border: 1px solid #cbfbdd;\n  border-radius: 12px;\n  padding: 12px;\n  display: flex;\n  align-items: center;\n  gap: 10px;\n}\n.section-content[_ngcontent-%COMP%]   .dine-cash-strip[_ngcontent-%COMP%]   .gold-hex-small[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #d4a04d,\n      #b8860b);\n  color: white;\n  font-weight: 800;\n  font-size: 9px;\n  clip-path: polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%);\n  width: 24px;\n  height: 22px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.section-content[_ngcontent-%COMP%]   .dine-cash-strip[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 13px;\n  font-weight: 600;\n  color: #0a4d2e;\n  flex: 1;\n}\n.section-content[_ngcontent-%COMP%]   .dine-cash-strip[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  color: #aaa;\n  font-size: 16px;\n}\n.dual-footer[_ngcontent-%COMP%] {\n  background: white;\n  padding: 12px 16px 20px;\n  box-shadow: 0 -4px 12px rgba(0, 0, 0, 0.05);\n}\n.dual-footer[_ngcontent-%COMP%]   .footer-inner[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 12px;\n}\n.dual-footer[_ngcontent-%COMP%]   .footer-inner[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  flex: 1;\n  height: 48px;\n  border-radius: 12px;\n  font-weight: 700;\n  font-size: 15px;\n  border: none;\n}\n.dual-footer[_ngcontent-%COMP%]   .footer-inner[_ngcontent-%COMP%]   .btn-book[_ngcontent-%COMP%] {\n  background: #eac3fa;\n  color: var(--grocery-theme-color);\n}\n.dual-footer[_ngcontent-%COMP%]   .footer-inner[_ngcontent-%COMP%]   .btn-pay[_ngcontent-%COMP%] {\n  background: var(--grocery-theme-color);\n  color: white;\n}\n.menu-scroll-container[_ngcontent-%COMP%] {\n  display: flex;\n  overflow-x: auto;\n  gap: 15px;\n  padding-bottom: 10px;\n  scrollbar-width: none;\n}\n.menu-scroll-container[_ngcontent-%COMP%]::-webkit-scrollbar {\n  display: none;\n}\n.menu-scroll-container[_ngcontent-%COMP%]   .menu-item[_ngcontent-%COMP%] {\n  min-width: 100px;\n  text-align: center;\n}\n.menu-scroll-container[_ngcontent-%COMP%]   .menu-item[_ngcontent-%COMP%]   .img-wrapper[_ngcontent-%COMP%] {\n  width: 100px;\n  height: 100px;\n  border-radius: 12px;\n  overflow: hidden;\n  margin-bottom: 8px;\n  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);\n}\n.menu-scroll-container[_ngcontent-%COMP%]   .menu-item[_ngcontent-%COMP%]   .img-wrapper[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n.menu-scroll-container[_ngcontent-%COMP%]   .menu-item[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-weight: 600;\n  color: #333;\n  margin: 0;\n}\n.bento-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  grid-auto-rows: 100px;\n  gap: 8px;\n}\n.bento-grid[_ngcontent-%COMP%]   .photo-item[_ngcontent-%COMP%] {\n  position: relative;\n  border-radius: 12px;\n  overflow: hidden;\n}\n.bento-grid[_ngcontent-%COMP%]   .photo-item[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n.bento-grid[_ngcontent-%COMP%]   .photo-item.large[_ngcontent-%COMP%] {\n  grid-column: span 2;\n  grid-row: span 2;\n}\n.bento-grid[_ngcontent-%COMP%]   .photo-item[_ngcontent-%COMP%]   .more-overlay[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  background: rgba(0, 0, 0, 0.6);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  color: white;\n  font-weight: 700;\n  font-size: 14px;\n  -webkit-backdrop-filter: blur(2px);\n  backdrop-filter: blur(2px);\n}\n.amenities-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  gap: 12px;\n}\n.amenities-grid[_ngcontent-%COMP%]   .amenity-box[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  padding: 16px;\n  background: #fff;\n  border-radius: 12px;\n  border: 1px solid #f0f0f0;\n  text-align: center;\n  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.02);\n}\n.amenities-grid[_ngcontent-%COMP%]   .amenity-box[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 24px;\n  margin-bottom: 8px;\n  color: #555;\n}\n.amenities-grid[_ngcontent-%COMP%]   .amenity-box[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #4b5563;\n  font-weight: 500;\n}\n.location-card[_ngcontent-%COMP%] {\n  background: #fff;\n  border-radius: 16px;\n  overflow: hidden;\n  border: 1px solid #f0f0f0;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);\n}\n.location-card[_ngcontent-%COMP%]   .map-frame[_ngcontent-%COMP%] {\n  height: 160px;\n  background: #eee;\n}\n.location-card[_ngcontent-%COMP%]   .map-frame[_ngcontent-%COMP%]   iframe[_ngcontent-%COMP%] {\n  display: block;\n}\n.location-card[_ngcontent-%COMP%]   .address-box[_ngcontent-%COMP%] {\n  padding: 16px;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 16px;\n}\n.location-card[_ngcontent-%COMP%]   .address-box[_ngcontent-%COMP%]   .addr-text[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 14px;\n  color: #333;\n  line-height: 1.5;\n}\n.location-card[_ngcontent-%COMP%]   .address-box[_ngcontent-%COMP%]   .map-icon-btn[_ngcontent-%COMP%] {\n  min-width: 44px;\n  height: 44px;\n  background: #e6fcf5;\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  color: #0a4d2e;\n  font-size: 22px;\n}\n.image-viewer-modal[_ngcontent-%COMP%] {\n  --background: #000;\n}\n.image-viewer-modal[_ngcontent-%COMP%]   ion-content[_ngcontent-%COMP%] {\n  --background: #000;\n}\n.viewer-content[_ngcontent-%COMP%] {\n  position: relative;\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n}\n.viewer-content[_ngcontent-%COMP%]   .close-btn[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 20px;\n  right: 20px;\n  z-index: 100;\n  color: white;\n  font-size: 32px;\n  background: rgba(0, 0, 0, 0.3);\n  border-radius: 50%;\n  width: 44px;\n  height: 44px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.viewer-content[_ngcontent-%COMP%]   swiper-container[_ngcontent-%COMP%] {\n  height: 100%;\n  width: 100%;\n  --swiper-navigation-color: #fff;\n  --swiper-pagination-color: #fff;\n}\n.viewer-content[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  max-width: 100%;\n  max-height: 100%;\n  object-fit: contain;\n}\n/*# sourceMappingURL=dineout-hotel-details.page.css.map */"] });
var DineoutHotelDetailsPage = _DineoutHotelDetailsPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(DineoutHotelDetailsPage, { className: "DineoutHotelDetailsPage", filePath: "src/app/pages/dineout-hotel-details/dineout-hotel-details.page.ts", lineNumber: 26 });
})();
export {
  DineoutHotelDetailsPage
};
//# sourceMappingURL=dineout-hotel-details.page-N5H6CZF4.js.map
