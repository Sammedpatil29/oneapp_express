import {
  environment
} from "./chunk-YJYUHAOC.js";
import {
  HttpClient,
  HttpHeaders,
  ɵɵdefineInjectable,
  ɵɵinject
} from "./chunk-Z7XNNJSA.js";

// src/app/services/events.service.ts
var _EventsService = class _EventsService {
  // postDetailsUrl = 'https://oneapp-express-singapore.onrender.com/api/events/booking-details'
  //   {
  //     "id": 14,
  //     "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxOCwicGhvbmUiOiI5NTkxNDIwMDY4IiwidXNlcl9uYW1lIjoiU2FtbWVkIEJpcmFkYXJwYXRpbCIsImlhdCI6MTc0ODQxNzc3Nn0.eKquCtEXSiEf5_LDKnowHiHQ3oQFPQi_rdMhwMIlSAY",
  //     "service_name": "events",
  //     "category": "event",
  //     "service_image": "",
  //     "provider_id": "1",
  //     "provider_name": "sammed",
  //     "scheduled_date": "2025-05-30T15:41:38.132193Z",
  //     "scheduled_time": "2025-05-30T15:41:38.132219Z",
  //     "address": "rjfgrf",
  //     "status": "completed",
  //     "price": "30.00",
  //     "payment": "done",
  //     "created_at": "2025-05-30T15:41:38.132299Z",
  //     "user": 18
  // }
  constructor(http) {
    this.http = http;
    this.postUrl = "https://oneapp-backend.onrender.com/api/orders/";
    this.postGroceryUrl = "https://oneapp-backend.onrender.com/api/orders/grocery-order/";
    this.getEventsUrl = environment.apiUrl;
  }
  getEvents(token) {
    const headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.get(`${this.getEventsUrl}/api/events`, { headers });
  }
  // createOrder(params: any) {
  //   return this.http.post(this.postUrl, params);
  // }
  createGroceryOrder(params) {
    return this.http.post(this.postGroceryUrl, params);
  }
  getEventDetails(params, token) {
    let headers = {
      Authorization: `Bearer ${token}`
    };
    return this.http.post(`${this.getEventsUrl}/api/events/booking-details`, params, { headers });
  }
  checkAvailability(params) {
    return this.http.post(`${this.getEventsUrl}/api/events/check-availability`, params);
  }
  createRazorpayOrder(params, token) {
    let headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.post(`${this.getEventsUrl}/api/payment/create-order`, params, { headers });
  }
  verifyPayment(params) {
    return this.http.post(`${this.getEventsUrl}/api/payment/verify-status`, params);
  }
  fetchOrderDetails(params) {
    return this.http.post(`${this.getEventsUrl}/api/events/order-details`, params);
  }
  cancelOrder(id, token) {
    let headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.post(`${this.getEventsUrl}/api/events/cancel-booking`, { orderId: id }, { headers });
  }
};
_EventsService.\u0275fac = function EventsService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _EventsService)(\u0275\u0275inject(HttpClient));
};
_EventsService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _EventsService, factory: _EventsService.\u0275fac, providedIn: "root" });
var EventsService = _EventsService;

export {
  EventsService
};
//# sourceMappingURL=chunk-GKNTDGNO.js.map
