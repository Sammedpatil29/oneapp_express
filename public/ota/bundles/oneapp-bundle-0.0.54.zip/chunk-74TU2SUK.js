import {
  environment
} from "./chunk-YJYUHAOC.js";
import {
  HttpClient,
  HttpHeaders,
  ɵɵdefineInjectable,
  ɵɵinject
} from "./chunk-Z7XNNJSA.js";

// src/app/services/common.service.ts
var _CommonService = class _CommonService {
  constructor(http) {
    this.http = http;
    this.url = environment.apiUrl;
  }
  // metaData = "https://oneapp-backend.onrender.com/api/metadata/"
  // activeOrders = "https://oneapp-backend.onrender.com/api/orders/active-orders-by-user/"
  getMetaData() {
  }
  getHomeData(token) {
    const headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.get(`${this.url}/api/home`, { headers });
  }
  sendFcmToken(params, token) {
    const headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.patch(`${this.url}/fcm-token`, params, { headers });
  }
  getActiveOrders(token) {
    let headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.get(`${this.url}/api/grocery-order/active`, { headers });
  }
  getActiveBanners(placement, city) {
    const params = [];
    if (placement)
      params.push(`placement=${encodeURIComponent(placement)}`);
    if (city)
      params.push(`city=${encodeURIComponent(city)}`);
    const query = params.length > 0 ? `?${params.join("&")}` : "";
    return this.http.get(`${this.url}/api/banners/active${query}`);
  }
};
_CommonService.\u0275fac = function CommonService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _CommonService)(\u0275\u0275inject(HttpClient));
};
_CommonService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _CommonService, factory: _CommonService.\u0275fac, providedIn: "root" });
var CommonService = _CommonService;

export {
  CommonService
};
//# sourceMappingURL=chunk-74TU2SUK.js.map
