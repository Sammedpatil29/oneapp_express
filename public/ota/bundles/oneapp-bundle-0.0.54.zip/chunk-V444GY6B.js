import {
  f
} from "./chunk-QH3WR2OQ.js";
import {
  registerPlugin
} from "./chunk-FH4NU4VH.js";

// node_modules/@capacitor/geolocation/dist/esm/index.js
var Geolocation = registerPlugin("Geolocation", {
  web: () => import("./web-CPJW6TA4.js").then((m) => new m.GeolocationWeb())
});
f();

export {
  Geolocation
};
//# sourceMappingURL=chunk-V444GY6B.js.map
