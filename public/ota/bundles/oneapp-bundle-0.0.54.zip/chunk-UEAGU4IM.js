import {
  CommonModule,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵlistener,
  ɵɵproperty,
  ɵɵsanitizeUrl,
  ɵɵtext,
  ɵɵtextInterpolate
} from "./chunk-Z7XNNJSA.js";

// src/app/components/property-footer/property-footer.component.ts
var _PropertyFooterComponent = class _PropertyFooterComponent {
  constructor() {
    this.logoUrl = "assets/brahmadev.webp";
    this.companyName = "Brahmadev Constructions";
    this.gstNumber = "GSTIN: 29XXXXX0000X1ZX";
    this.currentYear = (/* @__PURE__ */ new Date()).getFullYear();
  }
  /**
   * Fallback handler if image asset fails to load
   */
  onImageError(event) {
    const target = event.target;
    if (target) {
      target.src = "assets/favicon_io/apple-touch-icon.png";
    }
  }
};
_PropertyFooterComponent.\u0275fac = function PropertyFooterComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _PropertyFooterComponent)();
};
_PropertyFooterComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _PropertyFooterComponent, selectors: [["app-property-footer"]], inputs: { logoUrl: "logoUrl", companyName: "companyName", gstNumber: "gstNumber" }, decls: 15, vars: 3, consts: [[1, "property-brand-footer"], [1, "footer-divider-line"], [1, "footer-content-wrapper"], [1, "powered-by-label"], [1, "partner-card"], [1, "brand-logo-wrap"], [1, "brand-logo-img", 3, "error", "src", "alt"], [1, "brand-text-col"], [1, "brand-name", "text-center"], [1, "brand-gst", "text-nowrap", "text-center"], [1, "brand-gst", "text-center"]], template: function PropertyFooterComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "footer", 0);
    \u0275\u0275element(1, "div", 1);
    \u0275\u0275elementStart(2, "div", 2)(3, "div", 3);
    \u0275\u0275text(4, "Managed By");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 4)(6, "div", 5)(7, "img", 6);
    \u0275\u0275listener("error", function PropertyFooterComponent_Template_img_error_7_listener($event) {
      return ctx.onImageError($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "div", 7)(9, "h4", 8);
    \u0275\u0275text(10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "span", 9);
    \u0275\u0275text(12, "opp. Durgalakshmi theatre, Miraj Road, Athani - 591304.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "span", 10);
    \u0275\u0275text(14, "GSTIN: 29XXXXX0000X1ZX MOB: 8884950068");
    \u0275\u0275elementEnd()()()()();
  }
  if (rf & 2) {
    \u0275\u0275advance(7);
    \u0275\u0275property("src", ctx.logoUrl, \u0275\u0275sanitizeUrl)("alt", ctx.companyName);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx.companyName);
  }
}, dependencies: [CommonModule], styles: ["\n\n.property-brand-footer[_ngcontent-%COMP%] {\n  width: 100%;\n  max-width: 100%;\n  box-sizing: border-box;\n  margin-top: 16px;\n  margin-bottom: 12px;\n  position: relative;\n  overflow: hidden;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n}\n.property-brand-footer[_ngcontent-%COMP%]   .footer-divider-line[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 1px;\n  background:\n    linear-gradient(\n      90deg,\n      transparent 0%,\n      rgba(226, 232, 240, 0.9) 25%,\n      rgba(203, 213, 225, 0.9) 50%,\n      rgba(226, 232, 240, 0.9) 75%,\n      transparent 100%);\n  margin-bottom: 14px;\n}\n.property-brand-footer[_ngcontent-%COMP%]   .footer-content-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  text-align: center;\n  gap: 8px;\n  width: 100%;\n  padding: 0 16px;\n  box-sizing: border-box;\n}\n.property-brand-footer[_ngcontent-%COMP%]   .powered-by-label[_ngcontent-%COMP%] {\n  font-size: 10.5px;\n  font-weight: 700;\n  color: #94a3b8;\n  letter-spacing: 1.2px;\n  text-transform: uppercase;\n}\n.property-brand-footer[_ngcontent-%COMP%]   .partner-card[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  text-align: center;\n  gap: 8px;\n  background: transparent;\n  padding: 0px 0px 10px;\n  max-width: 100%;\n  transition: transform 0.2s ease, box-shadow 0.2s ease;\n}\n.property-brand-footer[_ngcontent-%COMP%]   .partner-card[_ngcontent-%COMP%]   .brand-logo-wrap[_ngcontent-%COMP%] {\n  width: 44px;\n  height: 44px;\n  min-width: 44px;\n  border-radius: 10px;\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  overflow: hidden;\n  flex-shrink: 0;\n  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);\n}\n.property-brand-footer[_ngcontent-%COMP%]   .partner-card[_ngcontent-%COMP%]   .brand-logo-wrap[_ngcontent-%COMP%]   .brand-logo-img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: contain;\n  display: block;\n}\n.property-brand-footer[_ngcontent-%COMP%]   .partner-card[_ngcontent-%COMP%]   .brand-text-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  text-align: center;\n  gap: 3px;\n}\n.property-brand-footer[_ngcontent-%COMP%]   .partner-card[_ngcontent-%COMP%]   .brand-text-col[_ngcontent-%COMP%]   .brand-name[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 12px;\n  font-weight: 800;\n  color: #94a3b8;\n  letter-spacing: -0.2px;\n  line-height: 1.25;\n  text-align: center;\n}\n.property-brand-footer[_ngcontent-%COMP%]   .partner-card[_ngcontent-%COMP%]   .brand-text-col[_ngcontent-%COMP%]   .brand-gst[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 600;\n  color: #94a3b8;\n  letter-spacing: 0.3px;\n  line-height: 1.2;\n  text-align: center;\n}\n/*# sourceMappingURL=property-footer.component.css.map */"] });
var PropertyFooterComponent = _PropertyFooterComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(PropertyFooterComponent, { className: "PropertyFooterComponent", filePath: "src/app/components/property-footer/property-footer.component.ts", lineNumber: 11 });
})();

export {
  PropertyFooterComponent
};
//# sourceMappingURL=chunk-UEAGU4IM.js.map
