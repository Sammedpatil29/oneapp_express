import {
  Geolocation
} from "./chunk-V444GY6B.js";
import {
  environment
} from "./chunk-YJYUHAOC.js";
import {
  BehaviorSubject,
  HttpClient,
  HttpHeaders,
  Observable,
  catchError,
  map,
  ɵɵdefineInjectable,
  ɵɵinject
} from "./chunk-Z7XNNJSA.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/services/location.service.ts
var _LocationService = class _LocationService {
  constructor(http) {
    this.http = http;
    this.citySource = new BehaviorSubject("");
    this.city$ = this.citySource.asObservable();
    this.locationSource = new BehaviorSubject(null);
    this.location$ = this.locationSource.asObservable();
    this.addressSource = new BehaviorSubject("");
    this.address$ = this.addressSource.asObservable();
    this.coordinates = [];
    this.city = "";
    this.address = "";
    this.polygonUrl = environment.apiUrl;
    this.addressUrl = environment.apiUrl;
  }
  /**
   * Check current GPS permission status
   */
  checkLocationPermission() {
    return __async(this, null, function* () {
      try {
        return yield Geolocation.checkPermissions();
      } catch (e) {
        return { location: "prompt", coarseLocation: "prompt" };
      }
    });
  }
  /**
   * Prompt user to grant GPS permission
   */
  requestLocationPermission() {
    return __async(this, null, function* () {
      try {
        return yield Geolocation.requestPermissions();
      } catch (e) {
        return { location: "denied", coarseLocation: "denied" };
      }
    });
  }
  /**
   * Comprehensive location check: returns precise status (ok, permission_denied, gps_disabled)
   */
  getDetailedPosition() {
    return __async(this, null, function* () {
      let perm;
      try {
        perm = yield this.checkLocationPermission();
        if (perm.location === "prompt" || perm.location === "prompt-with-rationale") {
          perm = yield this.requestLocationPermission();
        }
        if (perm.location !== "granted") {
          return { status: "permission_denied" };
        }
      } catch (err) {
        return { status: "permission_denied", error: err };
      }
      try {
        const position = yield Geolocation.getCurrentPosition({
          enableHighAccuracy: true,
          timeout: 9e3,
          maximumAge: 3e3
        });
        if (position == null ? void 0 : position.coords) {
          this.coordinates = position;
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          this.getAddress(lat, lng);
          return {
            status: "ok",
            coords: { latitude: lat, longitude: lng },
            address: this.address,
            city: this.city
          };
        }
        return { status: "gps_disabled" };
      } catch (posErr) {
        console.warn("Geolocation.getCurrentPosition error:", posErr);
        const msg = ((posErr == null ? void 0 : posErr.message) || "").toLowerCase();
        const code = posErr == null ? void 0 : posErr.code;
        if (code === 1 || msg.includes("denied") || msg.includes("permission")) {
          return { status: "permission_denied", error: posErr };
        }
        return { status: "gps_disabled", error: posErr };
      }
    });
  }
  /**
   * Continuous Location Watch
   */
  watchPosition(callback) {
    return __async(this, null, function* () {
      try {
        const watchId = yield Geolocation.watchPosition({ enableHighAccuracy: true, timeout: 1e4 }, (position, err) => {
          if (position == null ? void 0 : position.coords) {
            this.coordinates = position;
            callback(position, null);
          } else if (err) {
            callback(null, err);
          }
        });
        return String(watchId);
      } catch (e) {
        console.warn("watchPosition failed:", e);
        return null;
      }
    });
  }
  clearWatch(watchId) {
    return __async(this, null, function* () {
      try {
        yield Geolocation.clearWatch({ id: watchId });
      } catch (e) {
        console.warn("clearWatch failed:", e);
      }
    });
  }
  getCurrentPosition() {
    return __async(this, null, function* () {
      var _a;
      try {
        const perm = yield this.checkLocationPermission();
        if (perm.location !== "granted") {
          const requested = yield this.requestLocationPermission();
          if (requested.location !== "granted") {
            console.warn("Location permission denied by user.");
            return null;
          }
        }
        this.coordinates = yield Geolocation.getCurrentPosition({
          enableHighAccuracy: true,
          timeout: 1e4
        });
        if ((_a = this.coordinates) == null ? void 0 : _a.coords) {
          this.getAddress(this.coordinates.coords.latitude, this.coordinates.coords.longitude);
          const finalData = {
            coords: this.coordinates,
            address: this.address
          };
          return finalData;
        }
        return null;
      } catch (e) {
        console.warn("Could not fetch GPS coordinates:", e);
        return null;
      }
    });
  }
  getAddress(lat, lng) {
    const apiKey = "7aa0aa489c7246e388e62965c4154f6b";
    const url = `https://api.opencagedata.com/geocode/v1/json?q=${lat}+${lng}&key=${apiKey}`;
    this.http.get(url).subscribe({
      next: (data) => {
        var _a, _b, _c, _d;
        const components = (_b = (_a = data == null ? void 0 : data.results) == null ? void 0 : _a[0]) == null ? void 0 : _b.components;
        if (components) {
          this.city = components.city || components.town || components.village || components.county || "";
          this.address = ((_d = (_c = data == null ? void 0 : data.results) == null ? void 0 : _c[0]) == null ? void 0 : _d.formatted) || "";
          if (this.city)
            this.citySource.next(this.city);
          if (this.address)
            this.addressSource.next(this.address);
        }
      },
      error: (err) => console.warn("Geocoding error:", err)
    });
  }
  /**
   * Fetch all active service areas from backend
   * GET /api/service-areas?active=true
   */
  getServiceAreas(activeOnly = true) {
    const query = activeOnly ? "?active=true" : "";
    return this.http.get(`${this.polygonUrl}/api/service-areas${query}`);
  }
  /**
   * Validate coordinates against backend service areas
   * POST /api/service-areas/check
   */
  checkLocationInServiceArea(lat, lng) {
    return this.http.post(`${this.polygonUrl}/api/service-areas/check`, { lat, lng });
  }
  /**
   * Fetch polygon data strictly from service areas (no legacy metadata fallback)
   */
  getPolygonData() {
    return this.getServiceAreas(true).pipe(map((res) => {
      if ((res == null ? void 0 : res.success) && Array.isArray(res.data) && res.data.length > 0) {
        const primary = res.data[0];
        return {
          success: true,
          data: {
            polygon: primary.polygon || [],
            border_color: primary.strokeColor || "#a000e2",
            inside_color: primary.areaColor || "#a000e2",
            city: primary.cityName || "Athani",
            allAreas: res.data
          }
        };
      }
      return { success: false, data: { polygon: [], allAreas: [] } };
    }), catchError(() => {
      return new Observable((subscriber) => {
        subscriber.next({ success: false, data: { polygon: [], allAreas: [] } });
        subscriber.complete();
      });
    }));
  }
  getData() {
    return this.http.get("https://oneapp-backend.onrender.com/api/services/active/");
  }
  saveAddress(params, token) {
    const headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.post(`${this.addressUrl}/api/addresses`, params, { headers });
  }
  updateAddress(id, params, token) {
    const headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.put(`${this.addressUrl}/api/addresses/${id}`, params, { headers });
  }
  deleteAddress(token, id) {
    const headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.delete(`${this.addressUrl}/api/addresses/${id}`, { headers });
  }
  getAddressesList(token) {
    const headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.get(`${this.addressUrl}/api/addresses`, { headers });
  }
  setAddress(location, token) {
    this.locationSource.next(location);
    localStorage.setItem("location", JSON.stringify(location));
    if ((location == null ? void 0 : location.id) && token) {
      this.setPrimaryAddress(location.id, token).subscribe({
        next: () => console.log(`\u2705 Saved address #${location.id} marked as primary in DB`),
        error: (err) => console.warn("Could not mark address as primary in DB:", err)
      });
    }
  }
  /**
   * Mark an address as primary in the database
   * PUT /api/addresses/:id/set-primary
   */
  setPrimaryAddress(addressId, token) {
    const headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.put(`${this.addressUrl}/api/addresses/${addressId}/set-primary`, {}, { headers });
  }
  /**
   * Get the user's primary address from the database
   * GET /api/addresses/primary
   */
  getPrimaryAddress(token) {
    const headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.get(`${this.addressUrl}/api/addresses/primary`, { headers });
  }
};
_LocationService.\u0275fac = function LocationService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _LocationService)(\u0275\u0275inject(HttpClient));
};
_LocationService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _LocationService, factory: _LocationService.\u0275fac, providedIn: "root" });
var LocationService = _LocationService;

export {
  LocationService
};
//# sourceMappingURL=chunk-4TQR4WSH.js.map
