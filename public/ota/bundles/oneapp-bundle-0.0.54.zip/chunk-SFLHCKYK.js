import {
  BehaviorSubject,
  map,
  ɵɵdefineInjectable
} from "./chunk-Z7XNNJSA.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-6B6DTIB5.js";

// src/app/services/pharmacy-cart.service.ts
var MED_CART_KEY = "pintu_med_cart";
var LAB_CART_KEY = "pintu_lab_cart";
var PRESCRIPTIONS_KEY = "pintu_prescriptions";
var _PharmacyCartService = class _PharmacyCartService {
  constructor() {
    this._medicineCart = new BehaviorSubject(this.loadStoredCart(MED_CART_KEY));
    this.medicineCart$ = this._medicineCart.asObservable();
    this._labCart = new BehaviorSubject(this.loadStoredCart(LAB_CART_KEY));
    this.labCart$ = this._labCart.asObservable();
    this._prescriptions = new BehaviorSubject(this.loadStoredCart(PRESCRIPTIONS_KEY));
    this.prescriptions$ = this._prescriptions.asObservable();
    this.medicineSummary$ = this.medicineCart$.pipe(map((items) => {
      let subtotal = 0;
      let totalMrp = 0;
      let count = 0;
      items.forEach((ci) => {
        subtotal += ci.item.price * ci.quantity;
        totalMrp += ci.item.mrp * ci.quantity;
        count += ci.quantity;
      });
      const savings = Math.max(0, totalMrp - subtotal);
      const deliveryFee = count > 0 && subtotal < 199 ? 25 : 0;
      const platformFee = count > 0 ? 5 : 0;
      const grandTotal = count > 0 ? subtotal + deliveryFee + platformFee : 0;
      return {
        itemCount: count,
        subtotal,
        totalMrp,
        savings,
        fee: deliveryFee + platformFee,
        grandTotal
      };
    }));
    this.labSummary$ = this.labCart$.pipe(map((items) => {
      let subtotal = 0;
      let totalMrp = 0;
      let count = 0;
      items.forEach((ci) => {
        subtotal += ci.test.price * ci.quantity;
        totalMrp += ci.test.mrp * ci.quantity;
        count += ci.quantity;
      });
      const savings = Math.max(0, totalMrp - subtotal);
      const homeCollectionFee = count > 0 && subtotal < 499 ? 50 : 0;
      const grandTotal = count > 0 ? subtotal + homeCollectionFee : 0;
      return {
        itemCount: count,
        subtotal,
        totalMrp,
        savings,
        fee: homeCollectionFee,
        grandTotal
      };
    }));
  }
  // ═══════════════════════════════════════════════════════════════════════════
  // MEDICINE CART METHODS
  // ═══════════════════════════════════════════════════════════════════════════
  addMedicine(item, qty = 1) {
    const current = [...this._medicineCart.value];
    const index = current.findIndex((c) => c.item.id === item.id);
    if (index > -1) {
      current[index] = __spreadProps(__spreadValues({}, current[index]), {
        quantity: current[index].quantity + qty
      });
    } else {
      current.push({ item, quantity: qty });
    }
    this.updateMedicineCart(current);
  }
  updateMedicineQuantity(itemId, qty) {
    let current = [...this._medicineCart.value];
    if (qty <= 0) {
      current = current.filter((c) => c.item.id !== itemId);
    } else {
      const index = current.findIndex((c) => c.item.id === itemId);
      if (index > -1) {
        current[index] = __spreadProps(__spreadValues({}, current[index]), { quantity: qty });
      }
    }
    this.updateMedicineCart(current);
  }
  removeMedicine(itemId) {
    const current = this._medicineCart.value.filter((c) => c.item.id !== itemId);
    this.updateMedicineCart(current);
  }
  getMedicineQuantity(itemId) {
    const found = this._medicineCart.value.find((c) => c.item.id === itemId);
    return found ? found.quantity : 0;
  }
  clearMedicineCart() {
    this.updateMedicineCart([]);
  }
  updateMedicineCart(items) {
    this._medicineCart.next(items);
    this.persist(MED_CART_KEY, items);
  }
  // ═══════════════════════════════════════════════════════════════════════════
  // LAB TEST CART METHODS
  // ═══════════════════════════════════════════════════════════════════════════
  addLabTest(test) {
    const current = [...this._labCart.value];
    const index = current.findIndex((c) => c.test.id === test.id);
    if (index > -1) {
      current[index] = __spreadProps(__spreadValues({}, current[index]), { quantity: current[index].quantity + 1 });
    } else {
      current.push({ test, quantity: 1 });
    }
    this.updateLabCart(current);
  }
  toggleLabTest(test) {
    const isPresent = this.isLabTestInCart(test.id);
    if (isPresent) {
      this.removeLabTest(test.id);
    } else {
      this.addLabTest(test);
    }
  }
  removeLabTest(testId) {
    const current = this._labCart.value.filter((c) => c.test.id !== testId);
    this.updateLabCart(current);
  }
  isLabTestInCart(testId) {
    return this._labCart.value.some((c) => c.test.id === testId);
  }
  clearLabCart() {
    this.updateLabCart([]);
  }
  updateLabCart(items) {
    this._labCart.next(items);
    this.persist(LAB_CART_KEY, items);
  }
  // ═══════════════════════════════════════════════════════════════════════════
  // PRESCRIPTION UPLOAD
  // ═══════════════════════════════════════════════════════════════════════════
  uploadPrescription(data) {
    const newRx = {
      id: `rx-${Date.now()}`,
      fileName: data.fileName,
      fileUrl: data.fileUrl || "assets/icons/prescription_doc.png",
      uploadedAt: /* @__PURE__ */ new Date(),
      notes: data.notes || "",
      type: data.type
    };
    const current = [newRx, ...this._prescriptions.value];
    this._prescriptions.next(current);
    this.persist(PRESCRIPTIONS_KEY, current);
    return newRx;
  }
  // ═══════════════════════════════════════════════════════════════════════════
  // LOCAL STORAGE HELPERS
  // ═══════════════════════════════════════════════════════════════════════════
  loadStoredCart(key) {
    try {
      const raw = localStorage.getItem(key);
      if (raw) {
        const parsed = JSON.parse(raw);
        return Array.isArray(parsed) ? parsed : [];
      }
    } catch (e) {
      console.warn(`Could not load ${key} from storage:`, e);
    }
    return [];
  }
  persist(key, data) {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      console.warn(`Could not persist ${key}:`, e);
    }
  }
};
_PharmacyCartService.\u0275fac = function PharmacyCartService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _PharmacyCartService)();
};
_PharmacyCartService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _PharmacyCartService, factory: _PharmacyCartService.\u0275fac, providedIn: "root" });
var PharmacyCartService = _PharmacyCartService;

export {
  PharmacyCartService
};
//# sourceMappingURL=chunk-SFLHCKYK.js.map
