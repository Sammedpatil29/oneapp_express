import {
  LocationService
} from "./chunk-4TQR4WSH.js";
import "./chunk-V444GY6B.js";
import "./chunk-QH3WR2OQ.js";
import {
  LanguageService,
  TranslatePipe
} from "./chunk-EAEIPGUF.js";
import {
  FooterComponent
} from "./chunk-KQY4CB5X.js";
import {
  ProfileService
} from "./chunk-XB4LQWIP.js";
import {
  addIcons,
  alertCircleOutline,
  arrowBack,
  arrowBackOutline,
  bicycleOutline,
  bulbOutline,
  businessOutline,
  callOutline,
  cartOutline,
  checkmark,
  checkmarkCircle,
  checkmarkDoneCircleOutline,
  chevronForward,
  colorPaletteOutline,
  documentTextOutline,
  fileTrayOutline,
  flashOutline,
  heartOutline,
  helpCircleOutline,
  informationCircleOutline,
  languageOutline,
  locationOutline,
  lockClosedOutline,
  mailOutline,
  moonOutline,
  notificationsOutline,
  peopleOutline,
  phonePortraitOutline,
  readerOutline,
  ribbonOutline,
  searchOutline,
  sendOutline,
  settingsOutline,
  shieldCheckmarkOutline,
  shieldOutline,
  sparklesOutline,
  storefrontOutline,
  sunnyOutline,
  timeOutline,
  trashOutline,
  walletOutline
} from "./chunk-FJYXZAS7.js";
import {
  AppDialogService
} from "./chunk-W37RSO62.js";
import {
  AuthService
} from "./chunk-EB6T6TPT.js";
import "./chunk-YJYUHAOC.js";
import "./chunk-EBMCUG2R.js";
import "./chunk-OE5MTPUR.js";
import {
  IonAlert,
  IonAvatar,
  IonButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonIcon,
  IonInput,
  IonItem,
  IonLabel,
  IonList,
  IonNote,
  IonSkeletonText,
  IonSpinner,
  IonText,
  IonTitle,
  IonToast,
  IonToolbar
} from "./chunk-CJE2NDTY.js";
import {
  CommonModule,
  DatePipe,
  DefaultValueAccessor,
  EventEmitter,
  FormsModule,
  MaxLengthValidator,
  NavController,
  NgClass,
  NgControlStatus,
  NgModel,
  Router,
  UpperCasePipe,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind1,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIdentity,
  ɵɵrepeaterTrackByIndex,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-Z7XNNJSA.js";
import "./chunk-XR3JUECC.js";
import "./chunk-FH4NU4VH.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/components/nodata/nodata.component.ts
function NodataComponent_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 6);
    \u0275\u0275listener("click", function NodataComponent_Conditional_7_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.onAction());
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r1.actionText, " ");
  }
}
var _NodataComponent = class _NodataComponent {
  constructor() {
    this.icon = "file-tray-outline";
    this.title = "No Data Found";
    this.description = "There is nothing to display here yet.";
    this.actionText = "";
    this.action = new EventEmitter();
    addIcons({ fileTrayOutline, searchOutline, alertCircleOutline });
  }
  onAction() {
    this.action.emit();
  }
};
_NodataComponent.\u0275fac = function NodataComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _NodataComponent)();
};
_NodataComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _NodataComponent, selectors: [["app-nodata"]], inputs: { icon: "icon", title: "title", description: "description", actionText: "actionText" }, outputs: { action: "action" }, decls: 8, vars: 4, consts: [[1, "no-data-card"], [1, "icon-wrap"], [3, "name"], [1, "title"], [1, "desc"], [1, "btn-action"], [1, "btn-action", 3, "click"]], template: function NodataComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 0)(1, "div", 1);
    \u0275\u0275element(2, "ion-icon", 2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "h4", 3);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p", 4);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275template(7, NodataComponent_Conditional_7_Template, 2, 1, "button", 5);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance(2);
    \u0275\u0275property("name", ctx.icon);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx.title);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx.description);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.actionText ? 7 : -1);
  }
}, dependencies: [CommonModule, IonIcon], styles: ["\n\n.no-data-card[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  text-align: center;\n  padding: 40px 24px;\n  max-width: 320px;\n  margin: 0 auto;\n}\n.no-data-card[_ngcontent-%COMP%]   .icon-wrap[_ngcontent-%COMP%] {\n  width: 64px;\n  height: 64px;\n  border-radius: 50%;\n  background: #f8eaff;\n  color: var(--app-theme-color, #a000e2);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 32px;\n  margin-bottom: 16px;\n  box-shadow: 0 0 0 8px rgba(160, 0, 226, 0.06);\n}\n.no-data-card[_ngcontent-%COMP%]   .title[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 700;\n  color: #0f172a;\n  margin: 0 0 6px;\n}\n.no-data-card[_ngcontent-%COMP%]   .desc[_ngcontent-%COMP%] {\n  font-size: 13px;\n  color: #64748b;\n  line-height: 1.5;\n  margin: 0 0 20px;\n}\n.no-data-card[_ngcontent-%COMP%]   .btn-action[_ngcontent-%COMP%] {\n  background: var(--app-theme-color, #a000e2);\n  color: #ffffff;\n  border: none;\n  border-radius: 12px;\n  padding: 10px 20px;\n  font-size: 13px;\n  font-weight: 700;\n  cursor: pointer;\n  box-shadow: 0 4px 14px rgba(160, 0, 226, 0.25);\n  transition: transform 0.15s ease;\n}\n.no-data-card[_ngcontent-%COMP%]   .btn-action[_ngcontent-%COMP%]:active {\n  transform: scale(0.97);\n}\n/*# sourceMappingURL=nodata.component.css.map */"] });
var NodataComponent = _NodataComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(NodataComponent, { className: "NodataComponent", filePath: "src/app/components/nodata/nodata.component.ts", lineNumber: 14 });
})();

// src/app/pages/about/about.page.ts
var _c0 = () => [1, 2, 3, 4, 5];
var _forTrack0 = ($index, $item) => $item.code;
var _forTrack1 = ($index, $item) => $item.id;
function AboutPage_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 6)(1, "div", 10)(2, "section", 11);
    \u0275\u0275element(3, "div", 12);
    \u0275\u0275elementStart(4, "div", 13)(5, "div", 14)(6, "span", 15);
    \u0275\u0275text(7, "demoCompany LLP");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "span", 16);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(10, "h1", 17);
    \u0275\u0275text(11, "Pintu");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "p", 18);
    \u0275\u0275text(13, "Minutes App \u2022 Hyperlocal Quick-Commerce & Urban Services");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "div", 19);
    \u0275\u0275element(15, "ion-icon", 20);
    \u0275\u0275elementStart(16, "span");
    \u0275\u0275text(17, "Delivering City Essentials to Your Doorstep in 10\u201315 Minutes");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(18, "div", 21)(19, "div", 22)(20, "div", 23);
    \u0275\u0275element(21, "ion-icon", 24);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(22, "div")(23, "h3", 25);
    \u0275\u0275text(24, "Our Mission & Purpose");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(25, "span", 26);
    \u0275\u0275text(26, "Empowering daily city living through technology");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(27, "p", 27);
    \u0275\u0275text(28, " Pintu is built with a singular vision: to simplify urban life by interconnecting local neighborhood merchants, skilled professionals, and everyday customers into one super-app. From groceries and hot meals to reliable home services, we eliminate wait times and empower local economies. ");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(29, "div", 28);
    \u0275\u0275element(30, "div", 29);
    \u0275\u0275elementStart(31, "h3", 30);
    \u0275\u0275text(32, "What Pintu Delivers");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(33, "div", 31)(34, "div", 32)(35, "div", 33)(36, "div", 34);
    \u0275\u0275element(37, "ion-icon", 35);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(38, "span", 36);
    \u0275\u0275text(39, "10-15 Mins");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(40, "h4", 37);
    \u0275\u0275text(41, "Express Groceries & Daily Staples");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(42, "p", 38);
    \u0275\u0275text(43, "Farm-fresh produce, dairy, fruits, bakery goods, snacks, beverages and household essentials straight from local dark stores.");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(44, "div", 32)(45, "div", 33)(46, "div", 39);
    \u0275\u0275element(47, "ion-icon", 40);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(48, "span", 41);
    \u0275\u0275text(49, "Food & Dine");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(50, "h4", 37);
    \u0275\u0275text(51, "Local Restaurant Food & Dining");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(52, "p", 38);
    \u0275\u0275text(53, "Craving biryani, street food, or caf\xE9 specials? Order hot from curated local kitchens or reserve tables with dineout savings.");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(54, "div", 32)(55, "div", 33)(56, "div", 42);
    \u0275\u0275element(57, "ion-icon", 43);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(58, "span", 44);
    \u0275\u0275text(59, "On-Demand");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(60, "h4", 37);
    \u0275\u0275text(61, "Trusted Home & Repair Services");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(62, "p", 38);
    \u0275\u0275text(63, "Verified electricians, plumbers, appliance technicians, carpenters, and handymen booked on-demand at transparent rates.");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(64, "div", 32)(65, "div", 33)(66, "div", 23);
    \u0275\u0275element(67, "ion-icon", 45);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(68, "span", 46);
    \u0275\u0275text(69, "Hyperlocal");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(70, "h4", 37);
    \u0275\u0275text(71, "Civic Utilities & City Solutions");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(72, "p", 38);
    \u0275\u0275text(73, "Access daily city resources, bill payments, and hyperlocal errands designed specifically for your neighborhood.");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(74, "div", 47);
    \u0275\u0275element(75, "div", 29);
    \u0275\u0275elementStart(76, "h3", 30);
    \u0275\u0275text(77, "Why Choose Pintu?");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(78, "div", 48)(79, "div", 49)(80, "div", 50);
    \u0275\u0275element(81, "ion-icon", 51);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(82, "div", 52)(83, "h4", 53);
    \u0275\u0275text(84, "Unmatched Hyperlocal Speed");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(85, "p", 54);
    \u0275\u0275text(86, "Strategically positioned neighborhood hubs ensure your order is packed and dispatched within 2 minutes of placement.");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(87, "div", 49)(88, "div", 55);
    \u0275\u0275element(89, "ion-icon", 56);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(90, "div", 52)(91, "h4", 53);
    \u0275\u0275text(92, "Quality Assured & Verified Partners");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(93, "p", 54);
    \u0275\u0275text(94, "Every fresh batch is quality checked daily, and every service technician undergoes background verification and credential checks.");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(95, "div", 49)(96, "div", 57);
    \u0275\u0275element(97, "ion-icon", 58);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(98, "div", 52)(99, "h4", 53);
    \u0275\u0275text(100, "100% Safe Payments & Instant Refunds");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(101, "p", 54);
    \u0275\u0275text(102, "Secure end-to-end UPI, Card, and Cashfree/Razorpay payments with instant automated refunds directly back to your source account.");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(103, "div", 49)(104, "div", 59);
    \u0275\u0275element(105, "ion-icon", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(106, "div", 52)(107, "h4", 53);
    \u0275\u0275text(108, "Community & Local First");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(109, "p", 54);
    \u0275\u0275text(110, "We champion local storekeepers and riders by ensuring fair commission structures, fast settlements, and dignified earnings.");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(111, "div", 61)(112, "div", 62);
    \u0275\u0275element(113, "ion-icon", 63);
    \u0275\u0275elementStart(114, "h4", 64);
    \u0275\u0275text(115, "Company & Legal Disclosures");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(116, "div", 65)(117, "div", 66)(118, "span", 67);
    \u0275\u0275text(119, "Legal Entity");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(120, "span", 68);
    \u0275\u0275text(121, "demoCompany LLP");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(122, "div", 66)(123, "span", 67);
    \u0275\u0275text(124, "Registered State");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(125, "span", 68);
    \u0275\u0275text(126, "Karnataka, India");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(127, "div", 66)(128, "span", 67);
    \u0275\u0275text(129, "Customer Support");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(130, "span", 68);
    \u0275\u0275text(131, "support@democompany.in.net");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(132, "div", 66)(133, "span", 67);
    \u0275\u0275text(134, "App Release");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(135, "span", 68);
    \u0275\u0275text(136);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275element(137, "app-footer");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance(9);
    \u0275\u0275textInterpolate1("v", ctx_r0.appVersion || "0.0.22", "");
    \u0275\u0275advance(127);
    \u0275\u0275textInterpolate(ctx_r0.appVersion || "0.0.22 (Production)");
  }
}
function AboutPage_Conditional_9_Conditional_28_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 79)(1, "div", 80)(2, "div", 81);
    \u0275\u0275element(3, "ion-icon", 82);
    \u0275\u0275elementStart(4, "div")(5, "h4", 83);
    \u0275\u0275text(6, "Pintu User Agreement & Terms of Service");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "span", 84);
    \u0275\u0275text(8, "Last Updated: September 2026 \u2022 Effective Immediately");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(9, "p", 85);
    \u0275\u0275text(10, " Welcome to Pintu! By accessing or using the Pintu mobile application or services operated by ");
    \u0275\u0275elementStart(11, "strong");
    \u0275\u0275text(12, "demoCompany LLP");
    \u0275\u0275elementEnd();
    \u0275\u0275text(13, ", you acknowledge that you have read, understood, and agreed to be legally bound by these Terms of Service. ");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(14, "div", 86)(15, "div", 87)(16, "span", 88);
    \u0275\u0275text(17, "01");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "div")(19, "h4", 89);
    \u0275\u0275text(20, "Acceptance & User Eligibility");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(21, "span", 90);
    \u0275\u0275text(22, "Scope of platform service");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(23, "div", 91)(24, "p");
    \u0275\u0275text(25, "To register for an account and use Pintu, you must be at least 18 years of age or possess legal parental/guardian consent. By placing orders, you represent that all information provided is accurate and truthful.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(26, "ul", 92)(27, "li");
    \u0275\u0275text(28, "Pintu acts as a digital marketplace facilitating transactions between you, neighborhood merchants, and delivery partners.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(29, "li");
    \u0275\u0275text(30, "demoCompany LLP reserves the right to modify or update these terms at any time with notification via app updates.");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(31, "div", 86)(32, "div", 87)(33, "span", 88);
    \u0275\u0275text(34, "02");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(35, "div")(36, "h4", 89);
    \u0275\u0275text(37, "Account Security & Registration");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(38, "span", 90);
    \u0275\u0275text(39, "Your personal credentials");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(40, "div", 91)(41, "p");
    \u0275\u0275text(42, "Your account is authenticated via your registered mobile number and One-Time Password (OTP). You are solely responsible for maintaining confidentiality of your device and login sessions.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(43, "ul", 92)(44, "li");
    \u0275\u0275text(45, "Never share your login OTP with anyone, including individuals claiming to represent Pintu.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(46, "li");
    \u0275\u0275text(47, "Notify our support team immediately if you suspect any unauthorized access to your account.");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(48, "div", 86)(49, "div", 87)(50, "span", 88);
    \u0275\u0275text(51, "03");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(52, "div")(53, "h4", 89);
    \u0275\u0275text(54, "Orders, Pricing & Estimated Delivery");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(55, "span", 90);
    \u0275\u0275text(56, "10\u201315 Minute commitment");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(57, "div", 91)(58, "p");
    \u0275\u0275text(59, "All items displayed in the app are subject to store inventory. Prices reflect current merchant listings including applicable statutory taxes.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(60, "ul", 92)(61, "li")(62, "strong");
    \u0275\u0275text(63, "Delivery Timelines:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(64, " Our 10\u201315 minute delivery window is our commitment under normal operating conditions. Delays due to extreme weather, road blockages, or traffic surges will be communicated proactively via live tracking.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(65, "li")(66, "strong");
    \u0275\u0275text(67, "Order Confirmation:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(68, " An order is confirmed once the store accepts it. Once packing has commenced, items cannot be edited.");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(69, "div", 86)(70, "div", 87)(71, "span", 88);
    \u0275\u0275text(72, "04");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(73, "div")(74, "h4", 89);
    \u0275\u0275text(75, "Payments, Cancellations & Refund Policy");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(76, "span", 90);
    \u0275\u0275text(77, "Safe transactions and quick returns");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(78, "div", 91)(79, "p");
    \u0275\u0275text(80, "We provide transparent billing with no hidden fees. Payments are processed securely through licensed payment gateways (Razorpay, Cashfree, UPI).");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(81, "ul", 92)(82, "li")(83, "strong");
    \u0275\u0275text(84, "Order Cancellation:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(85, " You can cancel an order without penalty before the merchant accepts and begins preparing your items.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(86, "li")(87, "strong");
    \u0275\u0275text(88, "Damaged / Incorrect Items:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(89, " If any item is missing, damaged, or spoiled upon delivery, raise a ticket via the Help & Support tab with a photo within 2 hours for an instant replacement or refund.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(90, "li")(91, "strong");
    \u0275\u0275text(92, "Refund Timeline:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(93, " Approved refunds are credited directly back to the original payment source (UPI/Bank/Card) within 2 to 4 business days.");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(94, "div", 86)(95, "div", 87)(96, "span", 88);
    \u0275\u0275text(97, "05");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(98, "div")(99, "h4", 89);
    \u0275\u0275text(100, "Customer Code of Conduct & Fair Use");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(101, "span", 90);
    \u0275\u0275text(102, "Respecting our delivery and merchant partners");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(103, "div", 91)(104, "p");
    \u0275\u0275text(105, "We treat our delivery riders, customer support agents, and partner store workers with dignity and respect, and require our customers to do the same.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(106, "ul", 92)(107, "li");
    \u0275\u0275text(108, "Abuse, harassment, or verbal mistreatment of delivery partners will result in immediate permanent account termination.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(109, "li");
    \u0275\u0275text(110, "Fraudulent activity, including false refund claims, automated scraping, or coupon exploiting, will be reported to appropriate legal authorities.");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(111, "div", 86)(112, "div", 87)(113, "span", 88);
    \u0275\u0275text(114, "06");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(115, "div")(116, "h4", 89);
    \u0275\u0275text(117, "Limitation of Liability & Governing Law");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(118, "span", 90);
    \u0275\u0275text(119, "Legal jurisdiction");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(120, "div", 91)(121, "p");
    \u0275\u0275text(122, "demoCompany LLP operates as a technology facilitator and does not directly manufacture products. These Terms shall be governed by and construed in accordance with the laws of India, with exclusive jurisdiction resting in the competent courts of Karnataka, India.");
    \u0275\u0275elementEnd()()()();
  }
}
function AboutPage_Conditional_9_Conditional_29_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 79)(1, "div", 93)(2, "div", 81);
    \u0275\u0275element(3, "ion-icon", 94);
    \u0275\u0275elementStart(4, "div")(5, "h4", 83);
    \u0275\u0275text(6, "Pintu Privacy & Data Protection Policy");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "span", 84);
    \u0275\u0275text(8, "Compliance with Digital Personal Data Protection (DPDP) Act");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(9, "p", 85);
    \u0275\u0275text(10, " At ");
    \u0275\u0275elementStart(11, "strong");
    \u0275\u0275text(12, "Pintu (demoCompany LLP)");
    \u0275\u0275elementEnd();
    \u0275\u0275text(13, ", protecting your privacy is our highest commitment. We do ");
    \u0275\u0275elementStart(14, "strong");
    \u0275\u0275text(15, "NOT");
    \u0275\u0275elementEnd();
    \u0275\u0275text(16, " sell, rent, or monetize your personal information to third parties. We collect only what is strictly necessary to fulfill your orders. ");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(17, "div", 86)(18, "div", 87)(19, "span", 95);
    \u0275\u0275text(20, "01");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(21, "div")(22, "h4", 89);
    \u0275\u0275text(23, "Location Permissions & GPS Usage");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(24, "span", 90);
    \u0275\u0275text(25, "Delivering accurately to your doorstep");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(26, "div", 91)(27, "p");
    \u0275\u0275text(28, "We request precise GPS location access to provide our signature 10\u201315 minute delivery service.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(29, "ul", 92)(30, "li")(31, "strong");
    \u0275\u0275text(32, "Nearest Store Matching:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(33, " Coordinates identify your active neighborhood dark store and confirm delivery availability.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(34, "li")(35, "strong");
    \u0275\u0275text(36, "Rider Navigation:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(37, " Your confirmed delivery pin guides the delivery fleet directly to your house or apartment gate.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(38, "li")(39, "strong");
    \u0275\u0275text(40, "Live Order Tracking:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(41, " While your order is active, location services provide real-time updates of rider proximity. We do not track your location when the app is closed.");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(42, "div", 86)(43, "div", 87)(44, "span", 95);
    \u0275\u0275text(45, "02");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(46, "div")(47, "h4", 89);
    \u0275\u0275text(48, "Personal Information We Collect");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(49, "span", 90);
    \u0275\u0275text(50, "Transparent data inventory");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(51, "div", 91)(52, "p");
    \u0275\u0275text(53, "We collect only the following essential identifiers provided during your use:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(54, "ul", 92)(55, "li")(56, "strong");
    \u0275\u0275text(57, "Contact Identifiers:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(58, " Mobile phone number (for OTP login and delivery coordination) and full name.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(59, "li")(60, "strong");
    \u0275\u0275text(61, "Saved Addresses:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(62, " House/flat numbers, apartment names, and landmarks to save you time on repeat orders.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(63, "li")(64, "strong");
    \u0275\u0275text(65, "Order History:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(66, " Past items and digital receipts to enable re-ordering and warranty/issue support.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(67, "li")(68, "strong");
    \u0275\u0275text(69, "Device Metadata:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(70, " App version, OS version, and network type to troubleshoot technical glitches and deliver OTA updates.");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(71, "div", 86)(72, "div", 87)(73, "span", 95);
    \u0275\u0275text(74, "03");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(75, "div")(76, "h4", 89);
    \u0275\u0275text(77, "Payment Data Security Guarantee");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(78, "span", 90);
    \u0275\u0275text(79, "RBI and PCI-DSS compliance");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(80, "div", 91)(81, "p");
    \u0275\u0275text(82, "Your financial security is paramount. Pintu ");
    \u0275\u0275elementStart(83, "strong");
    \u0275\u0275text(84, "NEVER stores");
    \u0275\u0275elementEnd();
    \u0275\u0275text(85, " credit/debit card numbers, CVV codes, or UPI PINs on our servers.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(86, "ul", 92)(87, "li");
    \u0275\u0275text(88, "All payment processing occurs directly through RBI-authorized, PCI-DSS Level 1 compliant payment gateways (Razorpay, Cashfree).");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(89, "li");
    \u0275\u0275text(90, "All network communications between the app and servers use industry-grade SSL/TLS 256-bit encryption.");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(91, "div", 86)(92, "div", 87)(93, "span", 95);
    \u0275\u0275text(94, "04");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(95, "div")(96, "h4", 89);
    \u0275\u0275text(97, "Communication & Notifications");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(98, "span", 90);
    \u0275\u0275text(99, "Essential updates vs promotional");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(100, "div", 91)(101, "p");
    \u0275\u0275text(102, "We respect your attention and minimize unnecessary alerts:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(103, "ul", 92)(104, "li")(105, "strong");
    \u0275\u0275text(106, "Transactional Alerts:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(107, " Essential SMS/Push notifications for OTP verification, order accepted, dispatched, and delivered status.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(108, "li")(109, "strong");
    \u0275\u0275text(110, "Promotional Alerts:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(111, " Occasional discounts and coupons. You can mute promotional notifications anytime in device settings.");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(112, "div", 86)(113, "div", 87)(114, "span", 95);
    \u0275\u0275text(115, "05");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(116, "div")(117, "h4", 89);
    \u0275\u0275text(118, "Your Data Rights & Permanent Account Deletion");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(119, "span", 90);
    \u0275\u0275text(120, "Complete control over your data");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(121, "div", 91)(122, "p");
    \u0275\u0275text(123, "Under the Digital Personal Data Protection Act, you have absolute autonomy over your information:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(124, "ul", 92)(125, "li")(126, "strong");
    \u0275\u0275text(127, "Right to Rectification:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(128, " Edit your name, phone number, and delivery addresses anytime in your Profile.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(129, "li")(130, "strong");
    \u0275\u0275text(131, "Right to Erasure (Delete Account):");
    \u0275\u0275elementEnd();
    \u0275\u0275text(132, " You can permanently delete your Pintu account and all associated personal data directly from ");
    \u0275\u0275elementStart(133, "em");
    \u0275\u0275text(134, "Profile > Personal Details > Delete Account");
    \u0275\u0275elementEnd();
    \u0275\u0275text(135, ". Once deleted, your addresses and profile records are erased from our database permanently.");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(136, "div", 86)(137, "div", 87)(138, "span", 95);
    \u0275\u0275text(139, "06");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(140, "div")(141, "h4", 89);
    \u0275\u0275text(142, "Grievance Officer & Contact");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(143, "span", 90);
    \u0275\u0275text(144, "Official statutory channel");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(145, "div", 91)(146, "p");
    \u0275\u0275text(147, "If you have any questions, concerns, or complaints regarding your privacy or data handling, please contact our dedicated Grievance Officer:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(148, "div", 96)(149, "p", 97)(150, "strong");
    \u0275\u0275text(151, "Grievance Officer:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(152, " Legal & Compliance Cell");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(153, "p", 97)(154, "strong");
    \u0275\u0275text(155, "Entity:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(156, " demoCompany LLP");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(157, "p", 97)(158, "strong");
    \u0275\u0275text(159, "Email:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(160, "a", 98);
    \u0275\u0275text(161, "support@democompany.in.net");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(162, "p", 99)(163, "strong");
    \u0275\u0275text(164, "Jurisdiction:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(165, " Karnataka, India (Response within 48 business hours)");
    \u0275\u0275elementEnd()()()()();
  }
}
function AboutPage_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-content", 7)(1, "div", 69)(2, "div", 70)(3, "button", 71);
    \u0275\u0275listener("click", function AboutPage_Conditional_9_Template_button_click_3_listener() {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.setPolicyTab("terms"));
    });
    \u0275\u0275element(4, "ion-icon", 72);
    \u0275\u0275elementStart(5, "span");
    \u0275\u0275text(6, "Terms of Service");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "button", 71);
    \u0275\u0275listener("click", function AboutPage_Conditional_9_Template_button_click_7_listener() {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.setPolicyTab("privacy"));
    });
    \u0275\u0275element(8, "ion-icon", 56);
    \u0275\u0275elementStart(9, "span");
    \u0275\u0275text(10, "Privacy Policy");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(11, "div", 73)(12, "div", 74);
    \u0275\u0275element(13, "ion-icon", 75);
    \u0275\u0275elementStart(14, "span");
    \u0275\u0275text(15, "RBI Compliant");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(16, "div", 74);
    \u0275\u0275element(17, "ion-icon", 76);
    \u0275\u0275elementStart(18, "span");
    \u0275\u0275text(19, "Zero Data Resale");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(20, "div", 74);
    \u0275\u0275element(21, "ion-icon", 77);
    \u0275\u0275elementStart(22, "span");
    \u0275\u0275text(23, "PCI-DSS Encryption");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(24, "div", 74);
    \u0275\u0275element(25, "ion-icon", 78);
    \u0275\u0275elementStart(26, "span");
    \u0275\u0275text(27, "Fast Dispute Resolution");
    \u0275\u0275elementEnd()()();
    \u0275\u0275template(28, AboutPage_Conditional_9_Conditional_28_Template, 123, 0, "div", 79)(29, AboutPage_Conditional_9_Conditional_29_Template, 166, 0, "div", 79);
    \u0275\u0275element(30, "app-footer");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance(3);
    \u0275\u0275classProp("active", ctx_r0.policyTab === "terms");
    \u0275\u0275advance(4);
    \u0275\u0275classProp("active", ctx_r0.policyTab === "privacy");
    \u0275\u0275advance(21);
    \u0275\u0275conditional(ctx_r0.policyTab === "terms" ? 28 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.policyTab === "privacy" ? 29 : -1);
  }
}
function AboutPage_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 8)(1, "section");
    \u0275\u0275element(2, "app-nodata");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275property("fullscreen", true);
  }
}
function AboutPage_Conditional_11_For_14_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 124);
  }
}
function AboutPage_Conditional_11_For_14_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "div", 125);
  }
}
function AboutPage_Conditional_11_For_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 119);
    \u0275\u0275listener("click", function AboutPage_Conditional_11_For_14_Template_div_click_0_listener() {
      const lang_r4 = \u0275\u0275restoreView(_r3).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.setLanguage(lang_r4.code));
    });
    \u0275\u0275elementStart(1, "div", 120)(2, "span", 121);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "span", 122);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "div", 123);
    \u0275\u0275template(7, AboutPage_Conditional_11_For_14_Conditional_7_Template, 1, 0, "ion-icon", 124)(8, AboutPage_Conditional_11_For_14_Conditional_8_Template, 1, 0, "div", 125);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const lang_r4 = ctx.$implicit;
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275classProp("is-selected", ctx_r0.selectedLanguage === lang_r4.code);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(lang_r4.name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(lang_r4.nativeName);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r0.selectedLanguage === lang_r4.code ? 7 : 8);
  }
}
function AboutPage_Conditional_11_For_27_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 124);
  }
}
function AboutPage_Conditional_11_For_27_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "div", 125);
  }
}
function AboutPage_Conditional_11_For_27_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 119);
    \u0275\u0275listener("click", function AboutPage_Conditional_11_For_27_Template_div_click_0_listener() {
      const theme_r6 = \u0275\u0275restoreView(_r5).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.setTheme(theme_r6.id));
    });
    \u0275\u0275elementStart(1, "div", 126)(2, "div", 127);
    \u0275\u0275element(3, "ion-icon", 128);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "div", 120)(5, "span", 121);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(7, "div", 123);
    \u0275\u0275template(8, AboutPage_Conditional_11_For_27_Conditional_8_Template, 1, 0, "ion-icon", 124)(9, AboutPage_Conditional_11_For_27_Conditional_9_Template, 1, 0, "div", 125);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const theme_r6 = ctx.$implicit;
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275classProp("is-selected", ctx_r0.selectedTheme === theme_r6.id);
    \u0275\u0275advance(2);
    \u0275\u0275property("ngClass", "theme-" + theme_r6.id);
    \u0275\u0275advance();
    \u0275\u0275property("name", theme_r6.icon);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(theme_r6.name);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r0.selectedTheme === theme_r6.id ? 8 : 9);
  }
}
function AboutPage_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 9)(1, "div", 100)(2, "div", 101)(3, "div", 102);
    \u0275\u0275element(4, "ion-icon", 103);
    \u0275\u0275elementStart(5, "div", 104)(6, "div", 105);
    \u0275\u0275text(7);
    \u0275\u0275pipe(8, "translate");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "div", 106);
    \u0275\u0275text(10);
    \u0275\u0275pipe(11, "translate");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(12, "div", 107);
    \u0275\u0275repeaterCreate(13, AboutPage_Conditional_11_For_14_Template, 9, 5, "div", 108, _forTrack0);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "div", 109)(16, "div", 102);
    \u0275\u0275element(17, "ion-icon", 110);
    \u0275\u0275elementStart(18, "div", 104)(19, "div", 105);
    \u0275\u0275text(20);
    \u0275\u0275pipe(21, "translate");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(22, "div", 106);
    \u0275\u0275text(23);
    \u0275\u0275pipe(24, "translate");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(25, "div", 107);
    \u0275\u0275repeaterCreate(26, AboutPage_Conditional_11_For_27_Template, 10, 6, "div", 108, _forTrack1);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(28, "div", 111)(29, "div", 112);
    \u0275\u0275element(30, "ion-icon", 113);
    \u0275\u0275elementStart(31, "div", 104)(32, "div", 105);
    \u0275\u0275text(33);
    \u0275\u0275pipe(34, "translate");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(35, "div", 114)(36, "div", 115)(37, "span", 116);
    \u0275\u0275text(38);
    \u0275\u0275pipe(39, "translate");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(40, "span", 117);
    \u0275\u0275text(41);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(42, "div", 118)(43, "span", 116);
    \u0275\u0275text(44);
    \u0275\u0275pipe(45, "translate");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(46, "span", 117);
    \u0275\u0275text(47, "Pintu - Minutes App");
    \u0275\u0275elementEnd()()()()()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(8, 10, "app_language"));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(11, 12, "choose_preferred_language"));
    \u0275\u0275advance(3);
    \u0275\u0275repeater(ctx_r0.languages);
    \u0275\u0275advance(2);
    \u0275\u0275property("hidden", true);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(21, 14, "appearance_theme"));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(24, 16, "select_theme_mode"));
    \u0275\u0275advance(3);
    \u0275\u0275repeater(ctx_r0.themes);
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(34, 18, "about_application"));
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(39, 20, "app_version"));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("v", ctx_r0.appVersion || "0.0.16", "");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(45, 22, "platform"));
  }
}
function AboutPage_Conditional_12_For_14_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 35);
  }
}
function AboutPage_Conditional_12_For_14_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 43);
  }
}
function AboutPage_Conditional_12_For_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 149);
    \u0275\u0275listener("click", function AboutPage_Conditional_12_For_14_Template_button_click_0_listener() {
      const cat_r9 = \u0275\u0275restoreView(_r8).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.selectCategory(cat_r9));
    });
    \u0275\u0275template(1, AboutPage_Conditional_12_For_14_Conditional_1_Template, 1, 0, "ion-icon", 35)(2, AboutPage_Conditional_12_For_14_Conditional_2_Template, 1, 0, "ion-icon", 43);
    \u0275\u0275elementStart(3, "span");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const cat_r9 = ctx.$implicit;
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275classProp("active", ctx_r0.suggestionCategory === cat_r9);
    \u0275\u0275advance();
    \u0275\u0275conditional(cat_r9 === "Product" ? 1 : 2);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(cat_r9);
  }
}
function AboutPage_Conditional_12_Conditional_30_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-spinner", 150);
    \u0275\u0275text(1, " Submitting Idea... ");
  }
}
function AboutPage_Conditional_12_Conditional_31_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 151);
    \u0275\u0275text(1, " Submit Suggestion ");
  }
}
function AboutPage_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-content", 9)(1, "div", 100)(2, "div", 129)(3, "div", 130);
    \u0275\u0275element(4, "ion-icon", 24);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "h2", 131);
    \u0275\u0275text(6, "Help Shape Pintu");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "p", 132);
    \u0275\u0275text(8, " Missing a favorite snack, grocery item, delivery service, or want a new app feature? Tell us below! ");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "div", 133)(10, "label", 134);
    \u0275\u0275text(11, "WHAT WOULD YOU LIKE TO SUGGEST?");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "div", 135);
    \u0275\u0275repeaterCreate(13, AboutPage_Conditional_12_For_14_Template, 5, 4, "button", 136, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "div", 137)(16, "div", 138)(17, "label", 139);
    \u0275\u0275text(18, "Subject / Title");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(19, "div", 140)(20, "input", 141);
    \u0275\u0275twoWayListener("ngModelChange", function AboutPage_Conditional_12_Template_input_ngModelChange_20_listener($event) {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r0.subject, $event) || (ctx_r0.subject = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(21, "div", 142)(22, "div", 143)(23, "label", 144);
    \u0275\u0275text(24, "Suggestion Details");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(25, "span", 145);
    \u0275\u0275text(26);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(27, "div", 146)(28, "textarea", 147);
    \u0275\u0275twoWayListener("ngModelChange", function AboutPage_Conditional_12_Template_textarea_ngModelChange_28_listener($event) {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r0.subjectBody, $event) || (ctx_r0.subjectBody = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(29, "ion-button", 148);
    \u0275\u0275listener("click", function AboutPage_Conditional_12_Template_ion_button_click_29_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.postSuggestion());
    });
    \u0275\u0275template(30, AboutPage_Conditional_12_Conditional_30_Template, 2, 0)(31, AboutPage_Conditional_12_Conditional_31_Template, 2, 0);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance(13);
    \u0275\u0275repeater(ctx_r0.suggestionCategories);
    \u0275\u0275advance(7);
    \u0275\u0275property("placeholder", ctx_r0.suggestionCategory === "Product" ? "e.g. Add Aashirvaad Multigrain Atta (5kg)" : "e.g. Add Fast Bike Courier / Parcel Delivery");
    \u0275\u0275twoWayProperty("ngModel", ctx_r0.subject);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1("", ctx_r0.subjectBody.length, "/500");
    \u0275\u0275advance(2);
    \u0275\u0275property("placeholder", ctx_r0.suggestionCategory === "Product" ? "Describe the product, brand name, pack size, or grocery item you would love to buy on Pintu..." : "Describe the service, delivery route, or city service you would like Pintu to offer...");
    \u0275\u0275twoWayProperty("ngModel", ctx_r0.subjectBody);
    \u0275\u0275advance();
    \u0275\u0275property("disabled", ctx_r0.isLoading || !ctx_r0.subject.trim() || !ctx_r0.subjectBody.trim());
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.isLoading ? 30 : 31);
  }
}
function AboutPage_Conditional_13_Conditional_1_Conditional_0_For_2_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "i", 161);
  }
}
function AboutPage_Conditional_13_Conditional_1_Conditional_0_For_2_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "i", 164);
    \u0275\u0275listener("click", function AboutPage_Conditional_13_Conditional_1_Conditional_0_For_2_Conditional_15_Template_i_click_0_listener() {
      \u0275\u0275restoreView(_r12);
      const item_r13 = \u0275\u0275nextContext().$implicit;
      const ctx_r0 = \u0275\u0275nextContext(4);
      return \u0275\u0275resetView(ctx_r0.setAddressAsDefault(item_r13));
    });
    \u0275\u0275elementEnd();
  }
}
function AboutPage_Conditional_13_Conditional_1_Conditional_0_For_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-list", 154)(1, "ion-item", 156);
    \u0275\u0275element(2, "div", 157);
    \u0275\u0275elementStart(3, "ion-label")(4, "small", 158);
    \u0275\u0275text(5);
    \u0275\u0275pipe(6, "uppercase");
    \u0275\u0275elementEnd();
    \u0275\u0275text(7, "\xA0 ");
    \u0275\u0275elementStart(8, "ion-text");
    \u0275\u0275text(9);
    \u0275\u0275elementEnd();
    \u0275\u0275element(10, "br");
    \u0275\u0275elementStart(11, "ion-note", 159);
    \u0275\u0275text(12);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(13, "div", 160);
    \u0275\u0275template(14, AboutPage_Conditional_13_Conditional_1_Conditional_0_For_2_Conditional_14_Template, 1, 0, "i", 161)(15, AboutPage_Conditional_13_Conditional_1_Conditional_0_For_2_Conditional_15_Template, 1, 0, "i", 162);
    \u0275\u0275elementStart(16, "i", 163);
    \u0275\u0275listener("click", function AboutPage_Conditional_13_Conditional_1_Conditional_0_For_2_Template_i_click_16_listener() {
      const item_r13 = \u0275\u0275restoreView(_r11).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(4);
      return \u0275\u0275resetView(ctx_r0.deleteAddress(item_r13.id));
    });
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const item_r13 = ctx.$implicit;
    const ctx_r0 = \u0275\u0275nextContext(4);
    \u0275\u0275property("ngClass", item_r13.id == ctx_r0.Addressid.id ? "border-color" : "");
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(6, 7, item_r13.label));
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate2("", item_r13["house_no"], "\xA0", item_r13["building_name"], "");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate2("", item_r13["landmark"], "\xA0", item_r13["address"], "");
    \u0275\u0275advance(2);
    \u0275\u0275conditional(item_r13.id == ctx_r0.Addressid.id ? 14 : 15);
  }
}
function AboutPage_Conditional_13_Conditional_1_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section");
    \u0275\u0275repeaterCreate(1, AboutPage_Conditional_13_Conditional_1_Conditional_0_For_2_Template, 17, 9, "ion-list", 154, \u0275\u0275repeaterTrackByIndex);
    \u0275\u0275element(3, "div", 155);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r0.addresses);
  }
}
function AboutPage_Conditional_13_Conditional_1_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "app-nodata");
  }
}
function AboutPage_Conditional_13_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = \u0275\u0275getCurrentView();
    \u0275\u0275template(0, AboutPage_Conditional_13_Conditional_1_Conditional_0_Template, 4, 0, "section")(1, AboutPage_Conditional_13_Conditional_1_Conditional_1_Template, 1, 0, "app-nodata");
    \u0275\u0275elementStart(2, "footer", 152)(3, "ion-button", 153);
    \u0275\u0275listener("click", function AboutPage_Conditional_13_Conditional_1_Template_ion_button_click_3_listener() {
      \u0275\u0275restoreView(_r10);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.openLocation());
    });
    \u0275\u0275text(4, "add New Address");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275conditional(ctx_r0.addresses ? 0 : 1);
  }
}
function AboutPage_Conditional_13_Conditional_2_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-list", 165)(1, "ion-item", 156)(2, "ion-label")(3, "div", 166);
    \u0275\u0275element(4, "ion-skeleton-text", 167)(5, "ion-skeleton-text", 168);
    \u0275\u0275elementEnd();
    \u0275\u0275element(6, "ion-skeleton-text", 169)(7, "ion-skeleton-text", 170);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "div", 171);
    \u0275\u0275element(9, "ion-skeleton-text", 172)(10, "ion-skeleton-text", 173);
    \u0275\u0275elementEnd()()();
  }
}
function AboutPage_Conditional_13_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section");
    \u0275\u0275repeaterCreate(1, AboutPage_Conditional_13_Conditional_2_For_2_Template, 11, 0, "ion-list", 165, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance();
    \u0275\u0275repeater(\u0275\u0275pureFunction0(0, _c0));
  }
}
function AboutPage_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 8);
    \u0275\u0275template(1, AboutPage_Conditional_13_Conditional_1_Template, 5, 1)(2, AboutPage_Conditional_13_Conditional_2_Template, 3, 1, "section");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance();
    \u0275\u0275conditional(!ctx_r0.isSpinnerLoading ? 1 : 2);
  }
}
function AboutPage_Conditional_14_Conditional_1_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-avatar", 176)(1, "ion-title", 189);
    \u0275\u0275text(2);
    \u0275\u0275pipe(3, "uppercase");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(3, 1, ctx_r0.nameShorthand()));
  }
}
function AboutPage_Conditional_14_Conditional_1_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-avatar", 176);
    \u0275\u0275element(1, "img", 190);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275property("src", ctx_r0.profileData.profile_image, \u0275\u0275sanitizeUrl);
  }
}
function AboutPage_Conditional_14_Conditional_1_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "i", 191);
    \u0275\u0275listener("click", function AboutPage_Conditional_14_Conditional_1_Conditional_14_Template_i_click_0_listener() {
      \u0275\u0275restoreView(_r15);
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.updateAddress("name"));
    });
    \u0275\u0275elementEnd();
  }
}
function AboutPage_Conditional_14_Conditional_1_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r16 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "i", 192);
    \u0275\u0275listener("click", function AboutPage_Conditional_14_Conditional_1_Conditional_15_Template_i_click_0_listener() {
      \u0275\u0275restoreView(_r16);
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.isNameEditable = true);
    });
    \u0275\u0275elementEnd();
  }
}
function AboutPage_Conditional_14_Conditional_1_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "i", 191);
    \u0275\u0275listener("click", function AboutPage_Conditional_14_Conditional_1_Conditional_18_Template_i_click_0_listener() {
      \u0275\u0275restoreView(_r17);
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.update("phone"));
    });
    \u0275\u0275elementEnd();
  }
}
function AboutPage_Conditional_14_Conditional_1_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 184)(1, "i", 192);
    \u0275\u0275listener("click", function AboutPage_Conditional_14_Conditional_1_Conditional_19_Template_i_click_1_listener() {
      \u0275\u0275restoreView(_r18);
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.isPhoneEditable = true);
    });
    \u0275\u0275elementEnd()();
  }
}
function AboutPage_Conditional_14_Conditional_1_Conditional_22_Template(rf, ctx) {
  if (rf & 1) {
    const _r19 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "i", 191);
    \u0275\u0275listener("click", function AboutPage_Conditional_14_Conditional_1_Conditional_22_Template_i_click_0_listener() {
      \u0275\u0275restoreView(_r19);
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.updateAddress("email"));
    });
    \u0275\u0275elementEnd();
  }
}
function AboutPage_Conditional_14_Conditional_1_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "i", 192);
    \u0275\u0275listener("click", function AboutPage_Conditional_14_Conditional_1_Conditional_23_Template_i_click_0_listener() {
      \u0275\u0275restoreView(_r20);
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.isEmailEditable = true);
    });
    \u0275\u0275elementEnd();
  }
}
function AboutPage_Conditional_14_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 175);
    \u0275\u0275template(1, AboutPage_Conditional_14_Conditional_1_Conditional_1_Template, 4, 3, "ion-avatar", 176)(2, AboutPage_Conditional_14_Conditional_1_Conditional_2_Template, 2, 1, "ion-avatar", 176);
    \u0275\u0275elementStart(3, "ion-label", 177);
    \u0275\u0275text(4);
    \u0275\u0275pipe(5, "uppercase");
    \u0275\u0275pipe(6, "uppercase");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "ion-label");
    \u0275\u0275text(8);
    \u0275\u0275pipe(9, "date");
    \u0275\u0275elementEnd()();
    \u0275\u0275element(10, "hr");
    \u0275\u0275elementStart(11, "div", 178)(12, "ion-item", 179)(13, "ion-input", 180);
    \u0275\u0275twoWayListener("ngModelChange", function AboutPage_Conditional_14_Conditional_1_Template_ion_input_ngModelChange_13_listener($event) {
      \u0275\u0275restoreView(_r14);
      const ctx_r0 = \u0275\u0275nextContext(2);
      \u0275\u0275twoWayBindingSet(ctx_r0.name, $event) || (ctx_r0.name = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275template(14, AboutPage_Conditional_14_Conditional_1_Conditional_14_Template, 1, 0, "i", 181)(15, AboutPage_Conditional_14_Conditional_1_Conditional_15_Template, 1, 0, "i", 182);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "ion-item", 179)(17, "ion-input", 183);
    \u0275\u0275twoWayListener("ngModelChange", function AboutPage_Conditional_14_Conditional_1_Template_ion_input_ngModelChange_17_listener($event) {
      \u0275\u0275restoreView(_r14);
      const ctx_r0 = \u0275\u0275nextContext(2);
      \u0275\u0275twoWayBindingSet(ctx_r0.phone, $event) || (ctx_r0.phone = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275template(18, AboutPage_Conditional_14_Conditional_1_Conditional_18_Template, 1, 0, "i", 181)(19, AboutPage_Conditional_14_Conditional_1_Conditional_19_Template, 2, 0, "div", 184);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "ion-item", 179)(21, "ion-input", 185);
    \u0275\u0275twoWayListener("ngModelChange", function AboutPage_Conditional_14_Conditional_1_Template_ion_input_ngModelChange_21_listener($event) {
      \u0275\u0275restoreView(_r14);
      const ctx_r0 = \u0275\u0275nextContext(2);
      \u0275\u0275twoWayBindingSet(ctx_r0.email, $event) || (ctx_r0.email = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275template(22, AboutPage_Conditional_14_Conditional_1_Conditional_22_Template, 1, 0, "i", 181)(23, AboutPage_Conditional_14_Conditional_1_Conditional_23_Template, 1, 0, "i", 182);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(24, "div", 186)(25, "ion-button", 187);
    \u0275\u0275text(26, "\nDELETE ACCOUNT PERMANENTLY ");
    \u0275\u0275elementEnd()();
    \u0275\u0275element(27, "ion-alert", 188);
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.profileData.profile_image == "" || ctx_r0.profileData.profile_image == null ? 1 : 2);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate2("", \u0275\u0275pipeBind1(5, 18, ctx_r0.profileData.first_name), "\xA0", \u0275\u0275pipeBind1(6, 20, ctx_r0.profileData.last_name), "");
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate2("", ctx_r0.profileData.phone, " \u2022 Since ", \u0275\u0275pipeBind2(9, 22, ctx_r0.profileData.date_joined, "dd-MMM-YYYY"), "");
    \u0275\u0275advance(5);
    \u0275\u0275property("disabled", !ctx_r0.isNameEditable);
    \u0275\u0275twoWayProperty("ngModel", ctx_r0.name);
    \u0275\u0275property("value", ctx_r0.name);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.isNameEditable ? 14 : 15);
    \u0275\u0275advance(3);
    \u0275\u0275property("disabled", !ctx_r0.isPhoneEditable);
    \u0275\u0275twoWayProperty("ngModel", ctx_r0.phone);
    \u0275\u0275property("value", ctx_r0.profileData.phone);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.isPhoneEditable ? 18 : 19);
    \u0275\u0275advance(3);
    \u0275\u0275property("disabled", !ctx_r0.isEmailEditable);
    \u0275\u0275twoWayProperty("ngModel", ctx_r0.email);
    \u0275\u0275property("value", ctx_r0.profileData.email);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.isEmailEditable ? 22 : 23);
    \u0275\u0275advance(5);
    \u0275\u0275property("buttons", ctx_r0.alertButtons);
  }
}
function AboutPage_Conditional_14_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 174);
    \u0275\u0275element(1, "ion-spinner", 193);
    \u0275\u0275elementEnd();
  }
}
function AboutPage_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 8);
    \u0275\u0275template(1, AboutPage_Conditional_14_Conditional_1_Template, 28, 25)(2, AboutPage_Conditional_14_Conditional_2_Template, 2, 0, "div", 174);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance();
    \u0275\u0275conditional(!ctx_r0.isLoading ? 1 : 2);
  }
}
var _AboutPage = class _AboutPage {
  constructor(router, navCtrl, authService, locationService, profileService, dialogService, languageService) {
    this.router = router;
    this.navCtrl = navCtrl;
    this.authService = authService;
    this.locationService = locationService;
    this.profileService = profileService;
    this.dialogService = dialogService;
    this.languageService = languageService;
    this.subject = "";
    this.subjectBody = "";
    this.suggestionCategory = "Product";
    this.suggestionCategories = [
      "Product",
      "Service"
    ];
    this.selectedLanguage = "en";
    this.selectedTheme = "system";
    this.languages = [
      { code: "en", name: "English", nativeName: "EN", subtitle: "Standard language" },
      { code: "jw", name: "Jawari Kannada", nativeName: "Jawari", subtitle: "Regional language" }
    ];
    this.themes = [
      { id: "light", name: "Light Mode", subtitle: "Crisp and bright display", icon: "sunny-outline" },
      { id: "dark", name: "Dark Mode", subtitle: "Gentle & power efficient", icon: "moon-outline" },
      { id: "system", name: "System Default", subtitle: "Matches device appearance", icon: "phone-portrait-outline" }
    ];
    this.addresses = [
      {
        "lat": "",
        "lng": "",
        "address": "",
        "landmark": "",
        "label": "",
        "house_no": "",
        "building_name": "",
        "receiver_name": "",
        "receiver_contact": "",
        "user": 18
      }
    ];
    this.name = "";
    this.phone = "";
    this.email = "";
    this.isLoading = false;
    this.isSpinnerLoading = false;
    this.isToastOpen = false;
    this.toastMessage = "";
    this.isNameEditable = false;
    this.isEmailEditable = false;
    this.isPhoneEditable = false;
    this.alertButtons = [
      {
        text: "CONFIRM DELETE",
        cssClass: "confirm-button",
        handler: () => {
          console.log("OK clicked");
          this.deleteProfilePermanently();
        }
      }
    ];
    this.profileData = {
      first_name: "",
      profile_image: "",
      email: "",
      phone: ""
    };
    this.policyTab = "terms";
    addIcons({
      arrowBack,
      arrowBackOutline,
      chevronForward,
      checkmarkCircle,
      checkmark,
      sunnyOutline,
      moonOutline,
      phonePortraitOutline,
      bulbOutline,
      cartOutline,
      bicycleOutline,
      sparklesOutline,
      heartOutline,
      informationCircleOutline,
      settingsOutline,
      languageOutline,
      colorPaletteOutline,
      sendOutline,
      shieldCheckmarkOutline,
      shieldOutline,
      documentTextOutline,
      lockClosedOutline,
      walletOutline,
      locationOutline,
      notificationsOutline,
      mailOutline,
      helpCircleOutline,
      checkmarkDoneCircleOutline,
      flashOutline,
      storefrontOutline,
      peopleOutline,
      timeOutline,
      ribbonOutline,
      callOutline,
      trashOutline,
      readerOutline,
      businessOutline
    });
  }
  ngOnInit() {
    return __async(this, null, function* () {
      var _a, _b, _c;
      this.data = ((_b = (_a = this.router.getCurrentNavigation()) == null ? void 0 : _a.extras.state) == null ? void 0 : _b["data"]) || ((_c = history.state) == null ? void 0 : _c.data);
      console.log("Passed Data:", this.data);
      if (this.data === "settings" || this.data === "language" || this.data === "Languages" || this.data === "Preferences") {
        this.data = "App Settings";
      }
      if (this.data === "privacy" || this.data === "Privacy Policy") {
        this.policyTab = "privacy";
      } else {
        this.policyTab = "terms";
      }
      this.initSettings();
      this.Addressid = this.locationService.location$.subscribe((res) => {
        this.Addressid = res;
        console.log("address set as", this.Addressid);
      });
      this.getYear();
      this.token = yield this.authService.getToken();
      if (this.data == "Personal Details") {
        this.getProfileData();
      }
      if (this.data == "About Pintu" || this.data == "App Settings" || this.isPolicyPage()) {
        const version = yield this.profileService.getAppVersion();
        this.appVersion = version;
      }
      if (this.data == "Saved Addresses") {
        this.getAddressList();
      }
    });
  }
  ionViewWillEnter() {
    const locationData = this.locationService.location$.subscribe((res) => {
      this.Addressid = res;
    });
    if (this.Addressid) {
      const location = this.Addressid;
      this.selectedAddress = location.address;
    }
    if (this.data == "Saved Addresses") {
      this.getAddressList();
    }
  }
  setAddressAsDefault(item) {
    let data = {
      lat: item.lat,
      lng: item.lng,
      id: item.id,
      label: item.label,
      address: item.address
    };
    this.locationService.setAddress(data);
    localStorage.setItem("location", JSON.stringify(data));
    console.log(this.Addressid);
  }
  getYear() {
    const TodayDate = /* @__PURE__ */ new Date();
    this.year = TodayDate.getUTCFullYear();
  }
  goBack() {
    this.navCtrl.back();
  }
  deleteProfilePermanently() {
    console.log(this.token);
    const id = this.profileData.id;
    let params = {
      "token": this.token
    };
    this.profileService.deleteProfilePermanently(params, id).subscribe((res) => {
      console.log(res);
      this.authService.logout();
    });
  }
  updateAddress(type) {
    if (type == "name") {
      let params = {
        "first_name": this.name
      };
      this.params = params;
    } else if (type == "email") {
      let params = {
        "email": this.email
      };
      this.params = params;
    }
    this.profileService.updateUser(this.params, this.token).subscribe((res) => {
      this.getProfileData();
      if (type == "name") {
        this.isNameEditable = false;
      } else if (type == "email") {
        this.isEmailEditable = false;
      }
    });
  }
  getAddressList() {
    console.log(this.token);
    this.isSpinnerLoading = true;
    this.locationService.getAddressesList(this.token).subscribe((res) => {
      let address = res.data;
      this.isSpinnerLoading = false;
      this.addresses = address;
      this.addresses = [...this.addresses];
      console.log(this.addresses);
    }, (error) => {
      this.addresses = [];
      this.isSpinnerLoading = false;
    });
  }
  deleteAddress(id) {
    return __async(this, null, function* () {
      const confirmed = yield this.dialogService.showDangerConfirm({
        title: "Delete Address?",
        message: "Are you sure you want to delete this address?\nThis action cannot be undone.",
        confirmText: "Yes, Delete",
        cancelText: "Cancel"
      });
      if (!confirmed)
        return;
      this.isSpinnerLoading = true;
      this.locationService.deleteAddress(this.token, id).subscribe({
        next: () => {
          this.isSpinnerLoading = false;
          this.getAddressList();
          this.dialogService.showToast("Address deleted successfully", "success");
        },
        error: () => {
          this.isSpinnerLoading = false;
          this.dialogService.showToast("Failed to delete address", "danger");
        }
      });
    });
  }
  setPolicyTab(tab) {
    this.policyTab = tab;
  }
  isPolicyPage() {
    return this.data === "Terms & Privacy" || this.data === "terms" || this.data === "Terms & Conditions" || this.data === "privacy" || this.data === "Privacy Policy";
  }
  getPageTitle() {
    if (this.data === "suggestion")
      return "Suggest a Product or Service";
    if (this.data === "App Settings")
      return "App Settings";
    if (this.isPolicyPage()) {
      return this.policyTab === "terms" ? "Terms of Service" : "Privacy Policy";
    }
    if (this.data === "About Pintu")
      return "About Pintu";
    return this.data || "About Pintu";
  }
  selectCategory(category) {
    this.suggestionCategory = category;
  }
  initSettings() {
    this.selectedLanguage = this.languageService.getCurrentLanguage();
    this.languages = this.languageService.getLanguages();
    this.selectedTheme = localStorage.getItem("pintu_theme") || "system";
  }
  setLanguage(code) {
    this.selectedLanguage = code;
    this.languageService.setLanguage(code);
    const lang = this.languages.find((l) => l.code === code);
    const msg = code === "jw" ? "Bhashe badalaayislagide: Jawari Kannada" : `Language set to ${(lang == null ? void 0 : lang.name) || code}`;
    this.dialogService.showToast(msg, "success");
  }
  setTheme(themeId) {
    this.selectedTheme = themeId;
    localStorage.setItem("pintu_theme", themeId);
    this.applyTheme(themeId);
    const themeObj = this.themes.find((t) => t.id === themeId);
    this.dialogService.showToast(`Theme updated: ${themeObj == null ? void 0 : themeObj.name}`, "success");
  }
  applyTheme(themeId) {
    const prefersDark = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
    if (themeId === "dark" || themeId === "system" && prefersDark) {
      document.body.classList.add("dark");
    } else {
      document.body.classList.remove("dark");
    }
  }
  postSuggestion() {
    return __async(this, null, function* () {
      if (!this.subject.trim()) {
        this.dialogService.showToast("Please enter a short subject / title", "warning");
        return;
      }
      if (!this.subjectBody.trim()) {
        this.dialogService.showToast("Please describe your suggestion", "warning");
        return;
      }
      this.isLoading = true;
      const params = {
        token: this.token,
        type: this.suggestionCategory,
        category: this.suggestionCategory,
        title: this.subject.trim(),
        subject: this.subject.trim(),
        details: this.subjectBody.trim(),
        suggestion: this.subjectBody.trim(),
        orderService: `Suggestion: ${this.suggestionCategory}`
      };
      this.profileService.postSuggestion(params, this.token).subscribe({
        next: (res) => __async(this, null, function* () {
          this.isLoading = false;
          this.subject = "";
          this.subjectBody = "";
          yield this.dialogService.showAlert("Suggestion Submitted! \u{1F389}", "Thank you for your valuable feedback! Our team reviews every idea to bring the best experience to Pintu.", "success", "Done");
          this.goBack();
        }),
        error: (error) => {
          var _a;
          this.isLoading = false;
          console.error("Post suggestion error:", error);
          this.dialogService.showToast(((_a = error == null ? void 0 : error.error) == null ? void 0 : _a.message) || "Error while submitting suggestion", "danger");
        }
      });
    });
  }
  openLocation() {
    this.navCtrl.navigateForward("/layout/map", {
      state: { data: "addAddress" }
    });
  }
  nameShorthand() {
    return this.nameShort = this.profileData.first_name.slice(0, 2);
  }
  update(event) {
    if (event == "name") {
      this.isNameEditable = false;
    } else if (event == "phone") {
      this.isPhoneEditable = false;
    } else {
      this.isEmailEditable = false;
    }
  }
  getProfileData() {
    console.log("triggered");
    this.isLoading = true;
    this.profileService.getProfileData(this.token).subscribe({
      next: (res) => {
        this.profileData = res.user;
        this.isLoading = false;
        this.name = this.profileData.first_name;
        this.phone = this.profileData.phone;
        this.email = this.profileData.email;
        console.log(this.profileData);
      },
      error: (error) => {
        this.isLoading = false;
        alert("Error while fetching data");
        console.error(error);
      }
    });
  }
};
_AboutPage.\u0275fac = function AboutPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _AboutPage)(\u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(AuthService), \u0275\u0275directiveInject(LocationService), \u0275\u0275directiveInject(ProfileService), \u0275\u0275directiveInject(AppDialogService), \u0275\u0275directiveInject(LanguageService));
};
_AboutPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _AboutPage, selectors: [["app-about"]], decls: 15, vars: 5, consts: [[1, "ion-no-border", "bg-white", "pt-2"], ["slot", "start"], [3, "click"], ["name", "arrow-back-outline", "color", "dark"], [1, "fw-bold", "text-dark"], [3, "isOpen", "message", "duration"], [1, "about-page-content", 3, "fullscreen"], [1, "policy-page-content", 3, "fullscreen"], [3, "fullscreen"], [1, "page-content-wrapper", 3, "fullscreen"], [1, "about-page-container"], [1, "brand-hero-card"], [1, "hero-glow-circle"], [1, "hero-content"], [1, "brand-badge-row"], [1, "brand-pill"], [1, "version-pill"], [1, "brand-title"], [1, "brand-tagline"], [1, "brand-promise-banner"], ["name", "flash-outline", 1, "promise-icon"], [1, "clean-card", "mission-card"], [1, "card-header-with-icon"], [1, "icon-circle", "icon-purple"], ["name", "bulb-outline"], [1, "card-title"], [1, "card-subtitle"], [1, "card-desc-text"], [1, "section-heading-bar"], [1, "heading-accent"], [1, "section-heading"], [1, "offerings-grid"], [1, "service-offering-card"], [1, "offering-header"], [1, "icon-circle", "icon-emerald"], ["name", "cart-outline"], [1, "card-chip", "chip-emerald"], [1, "offering-title"], [1, "offering-desc"], [1, "icon-circle", "icon-amber"], ["name", "storefront-outline"], [1, "card-chip", "chip-amber"], [1, "icon-circle", "icon-blue"], ["name", "bicycle-outline"], [1, "card-chip", "chip-blue"], ["name", "business-outline"], [1, "card-chip", "chip-purple"], [1, "section-heading-bar", "mt-4"], [1, "trust-pillars-stack"], [1, "trust-pillar-card"], [1, "pillar-icon-box", "icon-purple"], ["name", "flash-outline"], [1, "pillar-content"], [1, "pillar-title"], [1, "pillar-desc"], [1, "pillar-icon-box", "icon-emerald"], ["name", "shield-checkmark-outline"], [1, "pillar-icon-box", "icon-blue"], ["name", "wallet-outline"], [1, "pillar-icon-box", "icon-amber"], ["name", "people-outline"], [1, "clean-card", "corporate-card", "mt-4"], [1, "corp-header"], ["name", "information-circle-outline", 1, "corp-icon"], [1, "corp-title"], [1, "corp-grid"], [1, "corp-item"], [1, "corp-label"], [1, "corp-value"], [1, "policy-page-container"], [1, "policy-segmented-bar"], ["type", "button", 1, "segment-pill", 3, "click"], ["name", "document-text-outline"], [1, "policy-trust-badges-strip"], [1, "trust-badge-item"], ["name", "checkmark-done-circle-outline", 1, "badge-icon", "green"], ["name", "lock-closed-outline", 1, "badge-icon", "purple"], ["name", "shield-outline", 1, "badge-icon", "blue"], ["name", "time-outline", 1, "badge-icon", "amber"], [1, "policy-tab-body", "animate__animated", "animate__fadeIn"], [1, "policy-notice-card", "terms-notice"], [1, "notice-header"], ["name", "reader-outline", 1, "notice-icon"], [1, "notice-title"], [1, "notice-date"], [1, "notice-text"], [1, "policy-card"], [1, "policy-card-header"], [1, "policy-num-badge"], [1, "policy-section-title"], [1, "policy-section-sub"], [1, "policy-card-body"], [1, "policy-bullet-list"], [1, "policy-notice-card", "privacy-notice"], ["name", "shield-checkmark-outline", 1, "notice-icon", "text-emerald"], [1, "policy-num-badge", "badge-emerald"], [1, "grievance-box"], [1, "mb-1"], ["href", "mailto:support@democompany.in.net"], [1, "mb-0"], [1, "inner-container"], [1, "settings-card", "mb-3"], [1, "settings-card-header"], ["name", "language-outline", 1, "settings-header-icon"], [1, "settings-header-text"], [1, "settings-card-title"], [1, "settings-card-subtitle"], [1, "settings-card-body"], ["role", "button", "tabindex", "0", 1, "selection-row", 3, "is-selected"], [1, "settings-card", "mb-3", 3, "hidden"], ["name", "color-palette-outline", 1, "settings-header-icon"], [1, "settings-card", "mb-4"], [1, "settings-card-header", "border-0", "pb-0"], ["name", "information-circle-outline", 1, "settings-header-icon"], [1, "settings-card-body", "pt-2"], [1, "d-flex", "justify-content-between", "align-items-center", "py-2", "border-bottom"], [1, "info-label"], [1, "info-value"], [1, "d-flex", "justify-content-between", "align-items-center", "py-2"], ["role", "button", "tabindex", "0", 1, "selection-row", 3, "click"], [1, "selection-info"], [1, "primary-text"], [1, "native-badge"], [1, "selection-radio-indicator"], ["name", "checkmark-circle", 1, "check-icon-active"], [1, "radio-unselected-circle"], [1, "d-flex", "align-items-center", "gap-3"], [1, "theme-icon-box", 3, "ngClass"], [3, "name"], [1, "suggest-hero-card", "mb-3"], [1, "suggest-hero-icon-circle"], [1, "suggest-hero-title"], [1, "suggest-hero-desc"], [1, "form-section-card", "mb-3"], [1, "section-label"], [1, "category-chips-grid", "two-options"], ["type", "button", 1, "cat-chip-pill", 3, "active"], [1, "form-section-card", "mb-4"], [1, "form-field-group", "mb-3"], [1, "form-field-label"], [1, "form-input-box"], ["type", "text", "maxlength", "80", 1, "styled-input", 3, "ngModelChange", "placeholder", "ngModel"], [1, "form-field-group"], [1, "d-flex", "justify-content-between", "align-items-center", "mb-1"], [1, "form-field-label", "m-0"], [1, "char-count-tag"], [1, "form-textarea-box"], ["rows", "4", "maxlength", "500", 1, "styled-textarea", 3, "ngModelChange", "placeholder", "ngModel"], ["expand", "block", 1, "submit-suggestion-btn", 3, "click", "disabled"], ["type", "button", 1, "cat-chip-pill", 3, "click"], ["name", "crescent", 1, "me-2"], ["name", "send-outline", "slot", "start"], [1, "position-fixed", "bottom-0", "w-100", "p-3"], [1, "book-btn", "w-100", 3, "click"], [1, "border", "mt-2", "mx-3", 2, "border-radius", "20px", 3, "ngClass"], [2, "height", "200px"], ["lines", "none"], ["slot", "start", 1, "unread-indicator-wrapper"], [1, "border", "py-1", "px-2", 2, "border-radius", "10px"], ["color", "medium", 1, "ion-text-wrap", "text-truncate"], ["slot", "end", 1, "metadata-end-wrapper", "me-2"], ["color", "dark", 1, "bi", "bi-check-circle-fill", "me-4", "text-success"], ["color", "dark", 1, "bi", "bi-circle", "me-4", "text-success"], ["color", "dark", 1, "bi", "bi-trash", "text-danger", 3, "click"], ["color", "dark", 1, "bi", "bi-circle", "me-4", "text-success", 3, "click"], [1, "border", "mt-2", "mx-3", 2, "border-radius", "20px"], [1, "d-flex", "align-items-center", "mb-2", "mt-1"], ["animated", "", 2, "width", "60px", "height", "22px", "border-radius", "10px", "margin-right", "10px"], ["animated", "", 2, "width", "100px", "height", "16px", "border-radius", "4px"], ["animated", "", 2, "width", "90%", "height", "14px", "border-radius", "4px", "margin-bottom", "6px"], ["animated", "", 2, "width", "60%", "height", "14px", "border-radius", "4px"], ["slot", "end", 1, "metadata-end-wrapper", "me-2", "d-flex", "align-items-center", "gap-3"], ["animated", "", 2, "width", "18px", "height", "18px", "border-radius", "50%", "margin", "0"], ["animated", "", 2, "width", "18px", "height", "18px", "border-radius", "4px", "margin", "0"], [1, "d-flex", "justify-content-center", "align-items-center", "h-100"], [1, "profile-container"], [1, "profile-avatar"], [1, "profile-name"], [1, "mx-3", "mt-4"], ["lines", "none", 1, "addressField", "mt-2"], ["placeholder", "Full Name", 3, "ngModelChange", "disabled", "ngModel", "value"], [1, "bi", "bi-arrow-up-circle-fill", "text-primary"], ["color", "dark", 1, "bi", "bi-pencil"], ["placeholder", "Mobile Number", 3, "ngModelChange", "disabled", "ngModel", "value"], ["hidden", ""], ["placeholder", "Email Id", 3, "ngModelChange", "disabled", "ngModel", "value"], [1, "position-fixed", "w-100", "bottom-0", "px-2", "mb-4"], ["id", "present-alert", "color", "danger", "fill", "outline", 1, "w-100", "book-btn", "text-nowrap"], ["trigger", "present-alert", "cssClass", "custom-alert", "subHeader", "Once account is DELETED, all your data will be deleted permanently!!.", "header", "Sure you want to delete account?", "message", "", 1, "", 3, "buttons"], [1, "avatar"], ["alt", "Avatar", 3, "src"], [1, "bi", "bi-arrow-up-circle-fill", "text-primary", 3, "click"], ["color", "dark", 1, "bi", "bi-pencil", 3, "click"], ["name", "crescent"]], template: function AboutPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar")(2, "ion-buttons", 1)(3, "ion-button", 2);
    \u0275\u0275listener("click", function AboutPage_Template_ion_button_click_3_listener() {
      return ctx.goBack();
    });
    \u0275\u0275element(4, "ion-icon", 3);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "ion-title", 4);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()()();
    \u0275\u0275element(7, "ion-toast", 5);
    \u0275\u0275template(8, AboutPage_Conditional_8_Template, 138, 3, "ion-content", 6)(9, AboutPage_Conditional_9_Template, 31, 7, "ion-content", 7)(10, AboutPage_Conditional_10_Template, 3, 1, "ion-content", 8)(11, AboutPage_Conditional_11_Template, 48, 24, "ion-content", 9)(12, AboutPage_Conditional_12_Template, 32, 8, "ion-content", 9)(13, AboutPage_Conditional_13_Template, 3, 2, "ion-content", 8)(14, AboutPage_Conditional_14_Template, 3, 2, "ion-content", 8);
  }
  if (rf & 2) {
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(ctx.getPageTitle());
    \u0275\u0275advance();
    \u0275\u0275property("isOpen", ctx.isToastOpen)("message", ctx.toastMessage)("duration", 3e3);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.data == "About Pintu" ? 8 : ctx.isPolicyPage() ? 9 : ctx.data == "Favourites" ? 10 : ctx.data == "App Settings" || ctx.data == "Preferences" || ctx.data == "Languages" ? 11 : ctx.data == "suggestion" ? 12 : ctx.data == "Saved Addresses" ? 13 : ctx.data == "Personal Details" ? 14 : -1);
  }
}, dependencies: [IonAlert, IonAvatar, IonButton, IonToast, IonSkeletonText, IonSpinner, IonNote, IonLabel, IonInput, IonList, IonItem, IonText, IonIcon, IonButtons, IonContent, IonHeader, IonTitle, IonToolbar, CommonModule, NgClass, UpperCasePipe, DatePipe, FormsModule, DefaultValueAccessor, NgControlStatus, MaxLengthValidator, NgModel, NodataComponent, TranslatePipe, FooterComponent], styles: ['@charset "UTF-8";\n\n\n\n.about-page-content[_ngcontent-%COMP%], \n.policy-page-content[_ngcontent-%COMP%] {\n  --background: #f8fafc;\n}\n.about-page-container[_ngcontent-%COMP%], \n.policy-page-container[_ngcontent-%COMP%] {\n  padding: 14px 16px 28px;\n  max-width: 600px;\n  margin: 0 auto;\n  box-sizing: border-box;\n}\n.brand-hero-card[_ngcontent-%COMP%] {\n  position: relative;\n  background:\n    linear-gradient(\n      135deg,\n      #2e0854 0%,\n      #1e1b4b 60%,\n      #3b0764 100%);\n  border-radius: 22px;\n  padding: 22px 18px;\n  color: #ffffff;\n  overflow: hidden;\n  box-shadow: 0 10px 28px rgba(46, 8, 84, 0.28);\n  margin-bottom: 16px;\n}\n.brand-hero-card[_ngcontent-%COMP%]   .hero-glow-circle[_ngcontent-%COMP%] {\n  position: absolute;\n  right: -25px;\n  top: -25px;\n  width: 130px;\n  height: 130px;\n  border-radius: 50%;\n  background:\n    radial-gradient(\n      circle,\n      rgba(160, 0, 226, 0.45) 0%,\n      transparent 70%);\n  filter: blur(16px);\n  pointer-events: none;\n}\n.brand-hero-card[_ngcontent-%COMP%]   .hero-content[_ngcontent-%COMP%] {\n  position: relative;\n  z-index: 2;\n}\n.brand-hero-card[_ngcontent-%COMP%]   .hero-content[_ngcontent-%COMP%]   .brand-badge-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  margin-bottom: 8px;\n}\n.brand-hero-card[_ngcontent-%COMP%]   .hero-content[_ngcontent-%COMP%]   .brand-badge-row[_ngcontent-%COMP%]   .brand-pill[_ngcontent-%COMP%] {\n  background: rgba(255, 255, 255, 0.16);\n  -webkit-backdrop-filter: blur(6px);\n  backdrop-filter: blur(6px);\n  color: #ffffff;\n  font-size: 10.5px;\n  font-weight: 800;\n  padding: 3px 9px;\n  border-radius: 99px;\n  letter-spacing: 0.4px;\n  text-transform: uppercase;\n}\n.brand-hero-card[_ngcontent-%COMP%]   .hero-content[_ngcontent-%COMP%]   .brand-badge-row[_ngcontent-%COMP%]   .version-pill[_ngcontent-%COMP%] {\n  background: rgba(160, 0, 226, 0.35);\n  color: #e9d5ff;\n  font-size: 10px;\n  font-weight: 750;\n  padding: 2px 7px;\n  border-radius: 6px;\n  border: 1px solid rgba(233, 213, 255, 0.2);\n}\n.brand-hero-card[_ngcontent-%COMP%]   .hero-content[_ngcontent-%COMP%]   .brand-title[_ngcontent-%COMP%] {\n  font-size: 28px;\n  font-weight: 900;\n  color: #ffffff;\n  margin: 0 0 4px;\n  letter-spacing: -0.5px;\n}\n.brand-hero-card[_ngcontent-%COMP%]   .hero-content[_ngcontent-%COMP%]   .brand-tagline[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 600;\n  color: rgba(255, 255, 255, 0.85);\n  margin: 0 0 14px;\n  line-height: 1.35;\n}\n.brand-hero-card[_ngcontent-%COMP%]   .hero-content[_ngcontent-%COMP%]   .brand-promise-banner[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n  background: rgba(255, 255, 255, 0.12);\n  -webkit-backdrop-filter: blur(8px);\n  backdrop-filter: blur(8px);\n  padding: 6px 11px;\n  border-radius: 12px;\n  border: 1px solid rgba(255, 255, 255, 0.18);\n  font-size: 11px;\n  font-weight: 750;\n  color: #fef08a;\n}\n.brand-hero-card[_ngcontent-%COMP%]   .hero-content[_ngcontent-%COMP%]   .brand-promise-banner[_ngcontent-%COMP%]   .promise-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: #facc15;\n}\n.clean-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 18px;\n  border: 1.5px solid #e2e8f0;\n  padding: 16px;\n  box-shadow: 0 2px 10px rgba(15, 23, 42, 0.04);\n  margin-bottom: 14px;\n}\n.clean-card.mission-card[_ngcontent-%COMP%] {\n  border-left: 4px solid #a000e2;\n}\n.clean-card.mission-card[_ngcontent-%COMP%]   .card-header-with-icon[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  margin-bottom: 10px;\n}\n.clean-card.mission-card[_ngcontent-%COMP%]   .card-header-with-icon[_ngcontent-%COMP%]   .card-title[_ngcontent-%COMP%] {\n  font-size: 15px;\n  font-weight: 850;\n  color: #0f172a;\n  margin: 0;\n}\n.clean-card.mission-card[_ngcontent-%COMP%]   .card-header-with-icon[_ngcontent-%COMP%]   .card-subtitle[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  color: #64748b;\n  font-weight: 500;\n}\n.clean-card.mission-card[_ngcontent-%COMP%]   .card-desc-text[_ngcontent-%COMP%] {\n  font-size: 12.5px;\n  color: #334155;\n  line-height: 1.55;\n  margin: 0;\n}\n.section-heading-bar[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  margin: 18px 0 12px;\n}\n.section-heading-bar[_ngcontent-%COMP%]   .heading-accent[_ngcontent-%COMP%] {\n  width: 4px;\n  height: 16px;\n  border-radius: 99px;\n  background: #a000e2;\n}\n.section-heading-bar[_ngcontent-%COMP%]   .section-heading[_ngcontent-%COMP%] {\n  font-size: 15px;\n  font-weight: 850;\n  color: #0f172a;\n  margin: 0;\n  letter-spacing: -0.2px;\n}\n.offerings-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 12px;\n  margin-bottom: 16px;\n}\n@media (max-width: 320px) {\n  .offerings-grid[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n  }\n}\n.offerings-grid[_ngcontent-%COMP%]   .service-offering-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 18px;\n  border: 1.5px solid #e2e8f0;\n  padding: 14px 12px;\n  display: flex;\n  flex-direction: column;\n  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.04);\n  transition: transform 0.16s ease, border-color 0.16s ease;\n}\n.offerings-grid[_ngcontent-%COMP%]   .service-offering-card[_ngcontent-%COMP%]:active {\n  transform: scale(0.98);\n  border-color: #cbd5e1;\n}\n.offerings-grid[_ngcontent-%COMP%]   .service-offering-card[_ngcontent-%COMP%]   .offering-header[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin-bottom: 10px;\n}\n.offerings-grid[_ngcontent-%COMP%]   .service-offering-card[_ngcontent-%COMP%]   .offering-title[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-weight: 800;\n  color: #0f172a;\n  margin: 0 0 5px;\n  line-height: 1.3;\n}\n.offerings-grid[_ngcontent-%COMP%]   .service-offering-card[_ngcontent-%COMP%]   .offering-desc[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #64748b;\n  margin: 0;\n  line-height: 1.45;\n  flex: 1;\n}\n.trust-pillars-stack[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n  margin-bottom: 16px;\n}\n.trust-pillars-stack[_ngcontent-%COMP%]   .trust-pillar-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 16px;\n  border: 1.5px solid #e2e8f0;\n  padding: 14px;\n  display: flex;\n  align-items: flex-start;\n  gap: 12px;\n  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.04);\n}\n.trust-pillars-stack[_ngcontent-%COMP%]   .trust-pillar-card[_ngcontent-%COMP%]   .pillar-content[_ngcontent-%COMP%] {\n  flex: 1;\n}\n.trust-pillars-stack[_ngcontent-%COMP%]   .trust-pillar-card[_ngcontent-%COMP%]   .pillar-content[_ngcontent-%COMP%]   .pillar-title[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  font-weight: 800;\n  color: #0f172a;\n  margin: 0 0 3px;\n}\n.trust-pillars-stack[_ngcontent-%COMP%]   .trust-pillar-card[_ngcontent-%COMP%]   .pillar-content[_ngcontent-%COMP%]   .pillar-desc[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  color: #64748b;\n  margin: 0;\n  line-height: 1.45;\n}\n.corporate-card[_ngcontent-%COMP%] {\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n}\n.corporate-card[_ngcontent-%COMP%]   .corp-header[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 7px;\n  margin-bottom: 12px;\n  padding-bottom: 8px;\n  border-bottom: 1px solid #e2e8f0;\n}\n.corporate-card[_ngcontent-%COMP%]   .corp-header[_ngcontent-%COMP%]   .corp-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n  color: #a000e2;\n}\n.corporate-card[_ngcontent-%COMP%]   .corp-header[_ngcontent-%COMP%]   .corp-title[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  font-weight: 800;\n  color: #0f172a;\n  margin: 0;\n}\n.corporate-card[_ngcontent-%COMP%]   .corp-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 10px;\n}\n.corporate-card[_ngcontent-%COMP%]   .corp-grid[_ngcontent-%COMP%]   .corp-item[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n}\n.corporate-card[_ngcontent-%COMP%]   .corp-grid[_ngcontent-%COMP%]   .corp-item[_ngcontent-%COMP%]   .corp-label[_ngcontent-%COMP%] {\n  font-size: 10.5px;\n  font-weight: 700;\n  text-transform: uppercase;\n  color: #94a3b8;\n  letter-spacing: 0.3px;\n}\n.corporate-card[_ngcontent-%COMP%]   .corp-grid[_ngcontent-%COMP%]   .corp-item[_ngcontent-%COMP%]   .corp-value[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 700;\n  color: #1e293b;\n}\n.about-page-footer[_ngcontent-%COMP%], \n.policy-page-footer[_ngcontent-%COMP%] {\n  text-align: center;\n  padding: 16px 8px 8px;\n}\n.about-page-footer[_ngcontent-%COMP%]   .footer-heart-text[_ngcontent-%COMP%], \n.policy-page-footer[_ngcontent-%COMP%]   .footer-heart-text[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 700;\n  color: #475569;\n  margin: 0 0 4px;\n}\n.about-page-footer[_ngcontent-%COMP%]   .footer-copy-text[_ngcontent-%COMP%], \n.policy-page-footer[_ngcontent-%COMP%]   .footer-copy-text[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #94a3b8;\n  margin: 0;\n}\n.icon-circle[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 38px;\n  min-width: 38px;\n  border-radius: 11px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 19px;\n}\n.icon-circle.icon-purple[_ngcontent-%COMP%] {\n  background: #f5f3ff;\n  color: #7c3aed;\n}\n.icon-circle.icon-emerald[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  color: #059669;\n}\n.icon-circle.icon-amber[_ngcontent-%COMP%] {\n  background: #fff7ed;\n  color: #ea580c;\n}\n.icon-circle.icon-blue[_ngcontent-%COMP%] {\n  background: #eff6ff;\n  color: #2563eb;\n}\n.pillar-icon-box[_ngcontent-%COMP%] {\n  width: 36px;\n  height: 36px;\n  min-width: 36px;\n  border-radius: 10px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 18px;\n}\n.pillar-icon-box.icon-purple[_ngcontent-%COMP%] {\n  background: #f5f3ff;\n  color: #7c3aed;\n}\n.pillar-icon-box.icon-emerald[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  color: #059669;\n}\n.pillar-icon-box.icon-amber[_ngcontent-%COMP%] {\n  background: #fff7ed;\n  color: #ea580c;\n}\n.pillar-icon-box.icon-blue[_ngcontent-%COMP%] {\n  background: #eff6ff;\n  color: #2563eb;\n}\n.card-chip[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 800;\n  padding: 2px 7px;\n  border-radius: 99px;\n  letter-spacing: 0.3px;\n}\n.card-chip.chip-emerald[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  color: #059669;\n}\n.card-chip.chip-amber[_ngcontent-%COMP%] {\n  background: #fff7ed;\n  color: #ea580c;\n}\n.card-chip.chip-blue[_ngcontent-%COMP%] {\n  background: #eff6ff;\n  color: #2563eb;\n}\n.card-chip.chip-purple[_ngcontent-%COMP%] {\n  background: #f5f3ff;\n  color: #7c3aed;\n}\n.policy-segmented-bar[_ngcontent-%COMP%] {\n  display: flex;\n  background: #e2e8f0;\n  border-radius: 14px;\n  padding: 4px;\n  gap: 4px;\n  margin-bottom: 12px;\n}\n.policy-segmented-bar[_ngcontent-%COMP%]   .segment-pill[_ngcontent-%COMP%] {\n  flex: 1;\n  border: none;\n  background: transparent;\n  padding: 9px 8px;\n  border-radius: 10px;\n  font-size: 12.5px;\n  font-weight: 750;\n  color: #64748b;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 6px;\n  cursor: pointer;\n  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);\n}\n.policy-segmented-bar[_ngcontent-%COMP%]   .segment-pill[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 15px;\n}\n.policy-segmented-bar[_ngcontent-%COMP%]   .segment-pill.active[_ngcontent-%COMP%] {\n  background: #ffffff;\n  color: #a000e2;\n  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);\n}\n.policy-trust-badges-strip[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  overflow-x: auto;\n  padding: 4px 2px 12px;\n  scrollbar-width: none;\n  -webkit-overflow-scrolling: touch;\n}\n.policy-trust-badges-strip[_ngcontent-%COMP%]::-webkit-scrollbar {\n  display: none;\n}\n.policy-trust-badges-strip[_ngcontent-%COMP%]   .trust-badge-item[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  background: #ffffff;\n  border: 1.5px solid #e2e8f0;\n  border-radius: 99px;\n  padding: 5px 10px;\n  font-size: 11px;\n  font-weight: 750;\n  color: #334155;\n  white-space: nowrap;\n  flex-shrink: 0;\n}\n.policy-trust-badges-strip[_ngcontent-%COMP%]   .trust-badge-item[_ngcontent-%COMP%]   .badge-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n}\n.policy-trust-badges-strip[_ngcontent-%COMP%]   .trust-badge-item[_ngcontent-%COMP%]   .badge-icon.green[_ngcontent-%COMP%] {\n  color: #10b981;\n}\n.policy-trust-badges-strip[_ngcontent-%COMP%]   .trust-badge-item[_ngcontent-%COMP%]   .badge-icon.purple[_ngcontent-%COMP%] {\n  color: #8b5cf6;\n}\n.policy-trust-badges-strip[_ngcontent-%COMP%]   .trust-badge-item[_ngcontent-%COMP%]   .badge-icon.blue[_ngcontent-%COMP%] {\n  color: #3b82f6;\n}\n.policy-trust-badges-strip[_ngcontent-%COMP%]   .trust-badge-item[_ngcontent-%COMP%]   .badge-icon.amber[_ngcontent-%COMP%] {\n  color: #f59e0b;\n}\n.policy-notice-card[_ngcontent-%COMP%] {\n  border-radius: 18px;\n  padding: 16px;\n  margin-bottom: 14px;\n}\n.policy-notice-card.terms-notice[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #f5f3ff 0%,\n      #ede9fe 100%);\n  border: 1.5px solid rgba(160, 0, 226, 0.25);\n}\n.policy-notice-card.privacy-notice[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #ecfdf5 0%,\n      #d1fae5 100%);\n  border: 1.5px solid rgba(5, 150, 105, 0.25);\n}\n.policy-notice-card[_ngcontent-%COMP%]   .notice-header[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  margin-bottom: 8px;\n}\n.policy-notice-card[_ngcontent-%COMP%]   .notice-header[_ngcontent-%COMP%]   .notice-icon[_ngcontent-%COMP%] {\n  font-size: 24px;\n  color: #7c3aed;\n}\n.policy-notice-card[_ngcontent-%COMP%]   .notice-header[_ngcontent-%COMP%]   .notice-icon.text-emerald[_ngcontent-%COMP%] {\n  color: #059669;\n}\n.policy-notice-card[_ngcontent-%COMP%]   .notice-header[_ngcontent-%COMP%]   .notice-title[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 850;\n  color: #0f172a;\n  margin: 0;\n  line-height: 1.25;\n}\n.policy-notice-card[_ngcontent-%COMP%]   .notice-header[_ngcontent-%COMP%]   .notice-date[_ngcontent-%COMP%] {\n  font-size: 10.5px;\n  color: #64748b;\n  font-weight: 600;\n}\n.policy-notice-card[_ngcontent-%COMP%]   .notice-text[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #334155;\n  line-height: 1.55;\n  margin: 0;\n}\n.policy-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 18px;\n  border: 1.5px solid #e2e8f0;\n  padding: 16px;\n  margin-bottom: 12px;\n  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.03);\n}\n.policy-card[_ngcontent-%COMP%]   .policy-card-header[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  margin-bottom: 10px;\n  padding-bottom: 8px;\n  border-bottom: 1px solid #f1f5f9;\n}\n.policy-card[_ngcontent-%COMP%]   .policy-card-header[_ngcontent-%COMP%]   .policy-num-badge[_ngcontent-%COMP%] {\n  width: 28px;\n  height: 28px;\n  min-width: 28px;\n  border-radius: 8px;\n  background: #f5f3ff;\n  color: #7c3aed;\n  font-size: 12px;\n  font-weight: 850;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.policy-card[_ngcontent-%COMP%]   .policy-card-header[_ngcontent-%COMP%]   .policy-num-badge.badge-emerald[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  color: #059669;\n}\n.policy-card[_ngcontent-%COMP%]   .policy-card-header[_ngcontent-%COMP%]   .policy-section-title[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  font-weight: 850;\n  color: #0f172a;\n  margin: 0;\n  line-height: 1.25;\n}\n.policy-card[_ngcontent-%COMP%]   .policy-card-header[_ngcontent-%COMP%]   .policy-section-sub[_ngcontent-%COMP%] {\n  font-size: 10.5px;\n  color: #64748b;\n  font-weight: 600;\n}\n.policy-card[_ngcontent-%COMP%]   .policy-card-body[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #334155;\n  line-height: 1.55;\n  margin: 0 0 8px;\n}\n.policy-card[_ngcontent-%COMP%]   .policy-card-body[_ngcontent-%COMP%]   .policy-bullet-list[_ngcontent-%COMP%] {\n  margin: 0;\n  padding-left: 18px;\n}\n.policy-card[_ngcontent-%COMP%]   .policy-card-body[_ngcontent-%COMP%]   .policy-bullet-list[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #475569;\n  line-height: 1.5;\n  margin-bottom: 6px;\n}\n.policy-card[_ngcontent-%COMP%]   .policy-card-body[_ngcontent-%COMP%]   .policy-bullet-list[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: #0f172a;\n}\n.policy-card[_ngcontent-%COMP%]   .policy-card-body[_ngcontent-%COMP%]   .policy-bullet-list[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]:last-child {\n  margin-bottom: 0;\n}\n.policy-card[_ngcontent-%COMP%]   .policy-card-body[_ngcontent-%COMP%]   .grievance-box[_ngcontent-%COMP%] {\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n  border-radius: 12px;\n  padding: 10px 12px;\n  margin-top: 8px;\n  font-size: 11.5px;\n  color: #334155;\n}\n.policy-card[_ngcontent-%COMP%]   .policy-card-body[_ngcontent-%COMP%]   .grievance-box[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  color: #a000e2;\n  text-decoration: none;\n  font-weight: 700;\n}\n.text-area[_ngcontent-%COMP%] {\n  border-radius: 10px;\n  border: 1px solid black;\n  border-radius: 20px;\n}\n  .suggestion .sc-ion-textarea-md {\n  font-size: 20px !important;\n}\n  .suggestion .sc-ion-input-md {\n  font-size: 20px !important;\n}\n.language[_ngcontent-%COMP%] {\n  border: 1px solid var(--ion-color-medium);\n  border-radius: 20px;\n}\n.addressField[_ngcontent-%COMP%] {\n  border-radius: 20px;\n  border: 1px solid gray;\n}\n.profile-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  margin-top: 2rem;\n}\n.profile-avatar[_ngcontent-%COMP%] {\n  width: 80px;\n  height: 80px;\n  margin-bottom: 10px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n.profile-name[_ngcontent-%COMP%] {\n  font-size: 1.5rem;\n  font-weight: 600;\n  color: var(--ion-text-color, #000);\n}\n.bi-icon[_ngcontent-%COMP%] {\n  color: var(--ion-text-color, #000);\n}\n.avatar[_ngcontent-%COMP%] {\n  width: 80px;\n  height: 80px;\n  border-radius: 50%;\n  background-color: pink;\n  font-size: x-large;\n  padding-left: 24px;\n}\n.box[_ngcontent-%COMP%] {\n  border: 1px solid gray;\n  border-radius: 20px;\n  z-index: 999;\n}\n  .confirm-button {\n  color: white !important;\n  border: 1px solid red !important;\n  padding: 10px !important;\n  padding-left: 10px !important;\n  padding-right: 10px !important;\n  background-color: red !important;\n  width: 100% !important;\n  text-align: center !important;\n  border-radius: 10px !important;\n}\n  .custom-alert .alert-wrapper {\n  width: 90%;\n  max-width: 400px;\n  display: flex !important;\n  justify-content: center !important;\n  box-shadow: 0px 0px 10px red !important;\n  border-radius: 20px !important;\n  padding: 10px !important;\n}\n  .alert-button-inner.sc-ion-alert-md {\n  -ms-flex-pack: end;\n  justify-content: center;\n}\n  .alert-head.sc-ion-alert-md {\n  text-align: center !important;\n}\n  .custom-alert ion-backdrop.sc-ion-alert-md.md {\n  background-color: red !important;\n}\n.border-color[_ngcontent-%COMP%] {\n  border: 1px solid green;\n  box-shadow: 0px 0px 8px green;\n}\n.page-content-wrapper[_ngcontent-%COMP%] {\n  --background: #f8f9fd;\n}\n.inner-container[_ngcontent-%COMP%] {\n  padding: 16px;\n  max-width: 560px;\n  margin: 0 auto 24px;\n}\n.suggest-hero-card[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #ffffff 0%,\n      #faf5ff 100%);\n  border: 1px solid #f0e6fc;\n  border-radius: 18px;\n  padding: 20px 16px;\n  text-align: center;\n  box-shadow: 0 2px 10px rgba(160, 0, 226, 0.04);\n}\n.suggest-hero-icon-circle[_ngcontent-%COMP%] {\n  width: 52px;\n  height: 52px;\n  border-radius: 50%;\n  background: #f3e5fa;\n  color: #a000e2;\n  font-size: 26px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin: 0 auto 10px;\n}\n.suggest-hero-title[_ngcontent-%COMP%] {\n  font-size: 18px;\n  font-weight: 700;\n  color: #1e1b2e;\n  margin: 0 0 6px;\n}\n.suggest-hero-desc[_ngcontent-%COMP%] {\n  font-size: 13px;\n  color: #64748b;\n  margin: 0;\n  line-height: 1.45;\n}\n.form-section-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border: 1px solid #edf0f7;\n  border-radius: 16px;\n  padding: 16px;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.02);\n}\n.section-label[_ngcontent-%COMP%] {\n  display: block;\n  font-size: 11px;\n  font-weight: 800;\n  letter-spacing: 0.7px;\n  color: #8b92a2;\n  margin-bottom: 12px;\n  text-transform: uppercase;\n}\n.category-chips-grid[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px;\n}\n.category-chips-grid.two-options[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: 1fr 1fr;\n  gap: 12px;\n}\n.category-chips-grid.two-options[_ngcontent-%COMP%]   .cat-chip-pill[_ngcontent-%COMP%] {\n  justify-content: center;\n  padding: 12px 16px;\n  font-size: 14px;\n  border-radius: 14px;\n}\n.cat-chip-pill[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  background: #f8fafc;\n  border: 1.5px solid #e2e8f0;\n  color: #475569;\n  font-size: 13px;\n  font-weight: 600;\n  padding: 8px 14px;\n  border-radius: 20px;\n  cursor: pointer;\n  transition: all 0.2s ease;\n}\n.cat-chip-pill[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 16px;\n}\n.cat-chip-pill.active[_ngcontent-%COMP%] {\n  background: #a000e2;\n  border-color: #a000e2;\n  color: #ffffff;\n  box-shadow: 0 4px 12px rgba(160, 0, 226, 0.25);\n}\n.cat-chip-pill[_ngcontent-%COMP%]:active {\n  transform: scale(0.96);\n}\n.form-field-group[_ngcontent-%COMP%] {\n  position: relative;\n}\n.form-field-label[_ngcontent-%COMP%] {\n  display: block;\n  font-size: 12px;\n  font-weight: 600;\n  color: #475569;\n  margin-bottom: 6px;\n}\n.char-count-tag[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #94a3b8;\n}\n.form-input-box[_ngcontent-%COMP%] {\n  background: #f9fafc;\n  border: 1.5px solid #e2e8f0;\n  border-radius: 12px;\n  padding: 0 14px;\n  height: 48px;\n  display: flex;\n  align-items: center;\n  transition: all 0.2s ease;\n}\n.form-input-box[_ngcontent-%COMP%]:focus-within {\n  background: #ffffff;\n  border-color: #a000e2;\n  box-shadow: 0 0 0 3px rgba(160, 0, 226, 0.08);\n}\n.form-input-box[_ngcontent-%COMP%]   .styled-input[_ngcontent-%COMP%] {\n  width: 100%;\n  border: none;\n  outline: none;\n  background: transparent;\n  font-size: 14.5px;\n  font-weight: 500;\n  color: #1e293b;\n}\n.form-input-box[_ngcontent-%COMP%]   .styled-input[_ngcontent-%COMP%]::placeholder {\n  color: #94a3b8;\n}\n.form-textarea-box[_ngcontent-%COMP%] {\n  background: #f9fafc;\n  border: 1.5px solid #e2e8f0;\n  border-radius: 12px;\n  padding: 10px 14px;\n  transition: all 0.2s ease;\n}\n.form-textarea-box[_ngcontent-%COMP%]:focus-within {\n  background: #ffffff;\n  border-color: #a000e2;\n  box-shadow: 0 0 0 3px rgba(160, 0, 226, 0.08);\n}\n.form-textarea-box[_ngcontent-%COMP%]   .styled-textarea[_ngcontent-%COMP%] {\n  width: 100%;\n  border: none;\n  outline: none;\n  background: transparent;\n  font-size: 14.5px;\n  font-weight: 500;\n  color: #1e293b;\n  resize: vertical;\n  min-height: 85px;\n}\n.form-textarea-box[_ngcontent-%COMP%]   .styled-textarea[_ngcontent-%COMP%]::placeholder {\n  color: #94a3b8;\n}\n.submit-suggestion-btn[_ngcontent-%COMP%] {\n  --background: #a000e2;\n  --background-hover: #8e00c7;\n  --border-radius: 14px;\n  font-weight: 700;\n  font-size: 15px;\n  height: 48px;\n}\n.settings-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border: 1px solid #edf0f7;\n  border-radius: 18px;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.025);\n  overflow: hidden;\n}\n.settings-card-header[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  padding: 14px 18px 12px;\n  border-bottom: 1px solid #f6f7fb;\n}\n.settings-card-header[_ngcontent-%COMP%]   .settings-header-icon[_ngcontent-%COMP%] {\n  font-size: 22px;\n  color: #a000e2;\n}\n.settings-card-header[_ngcontent-%COMP%]   .settings-card-title[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 700;\n  color: #1e293b;\n}\n.settings-card-header[_ngcontent-%COMP%]   .settings-card-subtitle[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #64748b;\n}\n.settings-card-body[_ngcontent-%COMP%] {\n  padding: 8px 12px;\n}\n.selection-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 12px 10px;\n  border-radius: 12px;\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n.selection-row[_ngcontent-%COMP%]:hover {\n  background: #f8f9fe;\n}\n.selection-row.is-selected[_ngcontent-%COMP%] {\n  background: #faf5ff;\n}\n.selection-row[_ngcontent-%COMP%]:active {\n  transform: scale(0.99);\n}\n.selection-row[_ngcontent-%COMP%]   .selection-info[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.selection-row[_ngcontent-%COMP%]   .selection-info[_ngcontent-%COMP%]   .primary-text[_ngcontent-%COMP%] {\n  font-size: 14.5px;\n  font-weight: 600;\n  color: #1e293b;\n}\n.selection-row[_ngcontent-%COMP%]   .selection-info[_ngcontent-%COMP%]   .native-badge[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 600;\n  color: #a000e2;\n  background: #f5e8fc;\n  padding: 2px 8px;\n  border-radius: 8px;\n}\n.selection-row[_ngcontent-%COMP%]   .selection-info[_ngcontent-%COMP%]   .secondary-text[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #64748b;\n}\n.selection-row[_ngcontent-%COMP%]   .theme-icon-box[_ngcontent-%COMP%] {\n  width: 36px;\n  height: 36px;\n  border-radius: 10px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 18px;\n}\n.selection-row[_ngcontent-%COMP%]   .theme-icon-box.theme-light[_ngcontent-%COMP%] {\n  background: #fef3c7;\n  color: #d97706;\n}\n.selection-row[_ngcontent-%COMP%]   .theme-icon-box.theme-dark[_ngcontent-%COMP%] {\n  background: #1e293b;\n  color: #f8fafc;\n}\n.selection-row[_ngcontent-%COMP%]   .theme-icon-box.theme-system[_ngcontent-%COMP%] {\n  background: #e2e8f0;\n  color: #475569;\n}\n.selection-row[_ngcontent-%COMP%]   .selection-radio-indicator[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n}\n.selection-row[_ngcontent-%COMP%]   .selection-radio-indicator[_ngcontent-%COMP%]   .check-icon-active[_ngcontent-%COMP%] {\n  font-size: 22px;\n  color: #a000e2;\n}\n.selection-row[_ngcontent-%COMP%]   .selection-radio-indicator[_ngcontent-%COMP%]   .radio-unselected-circle[_ngcontent-%COMP%] {\n  width: 18px;\n  height: 18px;\n  border-radius: 50%;\n  border: 2px solid #cbd5e1;\n}\n.info-label[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  color: #64748b;\n  font-weight: 500;\n}\n.info-value[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  color: #1e293b;\n  font-weight: 700;\n}\n/*# sourceMappingURL=about.page.css.map */'] });
var AboutPage = _AboutPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(AboutPage, { className: "AboutPage", filePath: "src/app/pages/about/about.page.ts", lineNumber: 63 });
})();
export {
  AboutPage
};
//# sourceMappingURL=about.page-RNE2TZTJ.js.map
