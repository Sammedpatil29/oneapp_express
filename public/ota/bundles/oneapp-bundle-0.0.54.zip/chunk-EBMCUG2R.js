import {
  registerPlugin
} from "./chunk-FH4NU4VH.js";

// node_modules/@capacitor/app/dist/esm/index.js
var App = registerPlugin("App", {
  web: () => import("./web-VJV2EHY5.js").then((m) => new m.AppWeb())
});

export {
  App
};
//# sourceMappingURL=chunk-EBMCUG2R.js.map
