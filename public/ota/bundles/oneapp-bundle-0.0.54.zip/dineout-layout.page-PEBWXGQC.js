import {
  IonApp,
  IonRouterOutlet
} from "./chunk-CJE2NDTY.js";
import {
  CommonModule,
  FormsModule,
  ɵsetClassDebugInfo,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart
} from "./chunk-Z7XNNJSA.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import "./chunk-6B6DTIB5.js";

// src/app/pages/dineout-layout/dineout-layout.page.ts
var _DineoutLayoutPage = class _DineoutLayoutPage {
  constructor() {
  }
  ngOnInit() {
  }
};
_DineoutLayoutPage.\u0275fac = function DineoutLayoutPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _DineoutLayoutPage)();
};
_DineoutLayoutPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _DineoutLayoutPage, selectors: [["app-dineout-layout"]], decls: 2, vars: 0, template: function DineoutLayoutPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-app");
    \u0275\u0275element(1, "ion-router-outlet");
    \u0275\u0275elementEnd();
  }
}, dependencies: [IonRouterOutlet, IonApp, CommonModule, FormsModule], encapsulation: 2 });
var DineoutLayoutPage = _DineoutLayoutPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(DineoutLayoutPage, { className: "DineoutLayoutPage", filePath: "src/app/pages/dineout-layout/dineout-layout.page.ts", lineNumber: 14 });
})();
export {
  DineoutLayoutPage
};
//# sourceMappingURL=dineout-layout.page-PEBWXGQC.js.map
