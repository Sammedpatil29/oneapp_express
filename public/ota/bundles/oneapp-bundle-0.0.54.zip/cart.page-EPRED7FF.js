import {
  ProductCardComponent
} from "./chunk-RDXQZO3F.js";
import {
  GroceryService
} from "./chunk-UOJDERHI.js";
import {
  LocationService
} from "./chunk-4TQR4WSH.js";
import "./chunk-V444GY6B.js";
import "./chunk-QH3WR2OQ.js";
import {
  addIcons,
  arrowBack,
  arrowBackOutline,
  arrowForward,
  business,
  checkmarkCircle,
  home,
  location,
  locationOutline,
  pricetagOutline,
  timeOutline
} from "./chunk-FJYXZAS7.js";
import {
  AuthService
} from "./chunk-EB6T6TPT.js";
import "./chunk-YJYUHAOC.js";
import {
  IonButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonIcon,
  IonSkeletonText,
  IonTitle,
  IonToolbar,
  IonicModule,
  ToastController
} from "./chunk-OE5MTPUR.js";
import {
  ChangeDetectorRef,
  CommonModule,
  DecimalPipe,
  DefaultValueAccessor,
  FormsModule,
  NavController,
  NgControlStatus,
  NgForOf,
  NgModel,
  Platform,
  TitleCasePipe,
  UpperCasePipe,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind1,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIdentity,
  ɵɵrepeaterTrackByIndex,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeHtml,
  ɵɵsanitizeUrl,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-Z7XNNJSA.js";
import "./chunk-XR3JUECC.js";
import "./chunk-FH4NU4VH.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/pages/cart/cart.page.ts
var _c0 = () => [1, 2];
var _c1 = () => [1, 2, 3, 4];
function CartPage_Conditional_0_Conditional_8_For_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 12)(1, "div", 25);
    \u0275\u0275element(2, "ion-skeleton-text", 26);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 27);
    \u0275\u0275element(4, "ion-skeleton-text", 28)(5, "ion-skeleton-text", 29)(6, "ion-skeleton-text", 30);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "div", 31);
    \u0275\u0275element(8, "ion-skeleton-text", 32);
    \u0275\u0275elementEnd()();
  }
}
function CartPage_Conditional_0_Conditional_8_For_18_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 19);
    \u0275\u0275element(1, "ion-skeleton-text", 33)(2, "ion-skeleton-text", 34);
    \u0275\u0275elementEnd();
  }
}
function CartPage_Conditional_0_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 8)(1, "div", 9);
    \u0275\u0275element(2, "ion-skeleton-text", 10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 11);
    \u0275\u0275repeaterCreate(4, CartPage_Conditional_0_Conditional_8_For_5_Template, 9, 0, "div", 12, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "div", 13)(7, "div", 9);
    \u0275\u0275element(8, "ion-skeleton-text", 10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "div", 14)(10, "div", 15);
    \u0275\u0275element(11, "ion-skeleton-text", 16)(12, "ion-skeleton-text", 17);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(13, "div", 13)(14, "div", 9);
    \u0275\u0275element(15, "ion-skeleton-text", 18);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "div", 14);
    \u0275\u0275repeaterCreate(17, CartPage_Conditional_0_Conditional_8_For_18_Template, 3, 0, "div", 19, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementStart(19, "div", 20);
    \u0275\u0275element(20, "ion-skeleton-text", 18)(21, "ion-skeleton-text", 21);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(22, "div", 22)(23, "div", 9);
    \u0275\u0275element(24, "ion-skeleton-text", 10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(25, "div", 14);
    \u0275\u0275element(26, "ion-skeleton-text", 23)(27, "ion-skeleton-text", 24);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(4);
    \u0275\u0275repeater(\u0275\u0275pureFunction0(0, _c0));
    \u0275\u0275advance(13);
    \u0275\u0275repeater(\u0275\u0275pureFunction0(1, _c1));
  }
}
function CartPage_Conditional_0_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "app-error", 35);
    \u0275\u0275listener("retry", function CartPage_Conditional_0_Conditional_9_Template_app_error_retry_0_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.fetchCartData(true));
    });
    \u0275\u0275elementEnd();
  }
}
function CartPage_Conditional_0_Conditional_10_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 36);
    \u0275\u0275element(1, "span", 42);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275property("innerHTML", ctx_r1.billDetails.deliveryMessage, \u0275\u0275sanitizeHtml);
  }
}
function CartPage_Conditional_0_Conditional_10_Conditional_5_For_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 43)(1, "div", 25);
    \u0275\u0275element(2, "img", 44);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 45)(4, "h6");
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span", 46);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "span", 47);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "span", 48);
    \u0275\u0275text(11);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(12, "div", 49)(13, "div", 50);
    \u0275\u0275listener("click", function CartPage_Conditional_0_Conditional_10_Conditional_5_For_1_Template_div_click_13_listener() {
      const item_r5 = \u0275\u0275restoreView(_r4).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(4);
      return \u0275\u0275resetView(ctx_r1.decrease(item_r5.productId));
    });
    \u0275\u0275text(14, "\u2212");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "span");
    \u0275\u0275text(16);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "div", 50);
    \u0275\u0275listener("click", function CartPage_Conditional_0_Conditional_10_Conditional_5_For_1_Template_div_click_17_listener() {
      const item_r5 = \u0275\u0275restoreView(_r4).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(4);
      return \u0275\u0275resetView(ctx_r1.increase(item_r5.productId));
    });
    \u0275\u0275text(18, "+");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const item_r5 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275property("src", item_r5.image, \u0275\u0275sanitizeUrl);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(item_r5.name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(item_r5.weight);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("\u20B9", item_r5.sellingPrice, " ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("\u20B9", item_r5.mrp, "");
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(item_r5.quantity);
  }
}
function CartPage_Conditional_0_Conditional_10_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275repeaterCreate(0, CartPage_Conditional_0_Conditional_10_Conditional_5_For_1_Template, 19, 6, "div", 43, \u0275\u0275repeaterTrackByIndex);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275repeater(ctx_r1.items);
  }
}
function CartPage_Conditional_0_Conditional_10_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 37)(1, "h6", 51);
    \u0275\u0275text(2, "Cart is empty");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "ion-button", 52);
    \u0275\u0275listener("click", function CartPage_Conditional_0_Conditional_10_Conditional_6_Template_ion_button_click_3_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.goBack());
    });
    \u0275\u0275text(4, "Add Items");
    \u0275\u0275elementEnd()();
  }
}
function CartPage_Conditional_0_Conditional_10_Conditional_7_app_product_card_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "app-product-card", 56);
    \u0275\u0275listener("increase", function CartPage_Conditional_0_Conditional_10_Conditional_7_app_product_card_5_Template_app_product_card_increase_0_listener($event) {
      \u0275\u0275restoreView(_r7);
      const ctx_r1 = \u0275\u0275nextContext(4);
      return \u0275\u0275resetView(ctx_r1.increase($event));
    })("decrease", function CartPage_Conditional_0_Conditional_10_Conditional_7_app_product_card_5_Template_app_product_card_decrease_0_listener($event) {
      \u0275\u0275restoreView(_r7);
      const ctx_r1 = \u0275\u0275nextContext(4);
      return \u0275\u0275resetView(ctx_r1.decrease($event));
    });
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const p_r8 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(4);
    \u0275\u0275property("product", p_r8)("qty", ctx_r1.getQty(p_r8.id));
  }
}
function CartPage_Conditional_0_Conditional_10_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 38)(1, "div", 9);
    \u0275\u0275text(2, " You might need ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 53)(4, "div", 54);
    \u0275\u0275template(5, CartPage_Conditional_0_Conditional_10_Conditional_7_app_product_card_5_Template, 1, 2, "app-product-card", 55);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(5);
    \u0275\u0275property("ngForOf", ctx_r1.suggestions);
  }
}
function CartPage_Conditional_0_Conditional_10_Conditional_14_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "small", 59);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(4);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.couponMessage);
  }
}
function CartPage_Conditional_0_Conditional_10_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 15)(1, "input", 57);
    \u0275\u0275twoWayListener("ngModelChange", function CartPage_Conditional_0_Conditional_10_Conditional_14_Template_input_ngModelChange_1_listener($event) {
      \u0275\u0275restoreView(_r9);
      const ctx_r1 = \u0275\u0275nextContext(3);
      \u0275\u0275twoWayBindingSet(ctx_r1.couponCode, $event) || (ctx_r1.couponCode = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "button", 58);
    \u0275\u0275listener("click", function CartPage_Conditional_0_Conditional_10_Conditional_14_Template_button_click_2_listener() {
      \u0275\u0275restoreView(_r9);
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.applyCoupon());
    });
    \u0275\u0275text(3, "APPLY");
    \u0275\u0275elementEnd()();
    \u0275\u0275template(4, CartPage_Conditional_0_Conditional_10_Conditional_14_Conditional_4_Template, 2, 1, "small", 59);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.couponCode);
    \u0275\u0275advance();
    \u0275\u0275property("disabled", !ctx_r1.couponCode);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(!ctx_r1.isCouponApplied && ctx_r1.couponMessage ? 4 : -1);
  }
}
function CartPage_Conditional_0_Conditional_10_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 41)(1, "div", 60);
    \u0275\u0275element(2, "ion-icon", 61);
    \u0275\u0275elementStart(3, "div")(4, "b", 62);
    \u0275\u0275text(5);
    \u0275\u0275pipe(6, "uppercase");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "div", 63);
    \u0275\u0275text(8);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(9, "small", 64);
    \u0275\u0275listener("click", function CartPage_Conditional_0_Conditional_10_Conditional_15_Template_small_click_9_listener() {
      \u0275\u0275restoreView(_r10);
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.removeCoupon());
    });
    \u0275\u0275text(10, "REMOVE");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate1("", \u0275\u0275pipeBind1(6, 2, ctx_r1.couponCode), " Applied");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("You saved ", ctx_r1.billDetails.couponDiscount, "");
  }
}
function CartPage_Conditional_0_Conditional_10_Conditional_16_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 65)(1, "span");
    \u0275\u0275text(2, "Late Night Charge");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 66);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(4);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r1.billDetails.lateNightCharge, "");
  }
}
function CartPage_Conditional_0_Conditional_10_Conditional_16_Conditional_26_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 65)(1, "span", 62);
    \u0275\u0275text(2, "Coupon Discount");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 67);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(4);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("- \u20B9", ctx_r1.billDetails.couponDiscount, "");
  }
}
function CartPage_Conditional_0_Conditional_10_Conditional_16_Conditional_43_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "small", 72);
    \u0275\u0275text(1, "Not available for orders > \u20B91500");
    \u0275\u0275elementEnd();
  }
}
function CartPage_Conditional_0_Conditional_10_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 13)(1, "div", 9);
    \u0275\u0275text(2, "Bill Details");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 14)(4, "div", 65)(5, "span");
    \u0275\u0275text(6, "Item Total (MRP)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "span", 66);
    \u0275\u0275text(8);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "div", 65)(10, "span");
    \u0275\u0275text(11, "Product Discount");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "span", 67);
    \u0275\u0275text(13);
    \u0275\u0275pipe(14, "number");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "div", 65)(16, "span");
    \u0275\u0275text(17, "Handling Charge");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "span", 66);
    \u0275\u0275text(19);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(20, "div", 65)(21, "span");
    \u0275\u0275text(22, "Delivery Fee");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(23, "span", 66);
    \u0275\u0275text(24);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(25, CartPage_Conditional_0_Conditional_10_Conditional_16_Conditional_25_Template, 5, 1, "div", 65)(26, CartPage_Conditional_0_Conditional_10_Conditional_16_Conditional_26_Template, 5, 1, "div", 65);
    \u0275\u0275elementStart(27, "div", 68)(28, "span");
    \u0275\u0275text(29, "To Pay");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(30, "span");
    \u0275\u0275text(31);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(32, "div", 69);
    \u0275\u0275text(33);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(34, "div", 22)(35, "div", 9);
    \u0275\u0275text(36, "Payment Method");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(37, "div", 14)(38, "div", 70);
    \u0275\u0275listener("click", function CartPage_Conditional_0_Conditional_10_Conditional_16_Template_div_click_38_listener() {
      \u0275\u0275restoreView(_r11);
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.selectedPayment = "cod");
    });
    \u0275\u0275elementStart(39, "div", 60);
    \u0275\u0275element(40, "div", 71);
    \u0275\u0275elementStart(41, "span");
    \u0275\u0275text(42, "Cash on Delivery");
    \u0275\u0275elementEnd()();
    \u0275\u0275template(43, CartPage_Conditional_0_Conditional_10_Conditional_16_Conditional_43_Template, 2, 0, "small", 72);
    \u0275\u0275elementEnd()()();
    \u0275\u0275element(44, "div", 73);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(8);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r1.billDetails.mrpTotal, "");
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate1("- \u20B9", \u0275\u0275pipeBind2(14, 11, ctx_r1.billDetails.mrpTotal - ctx_r1.billDetails.itemTotal, "1.2-2"), "");
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r1.billDetails.handlingCharge, "");
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r1.billDetails.deliveryFee, "");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.billDetails.lateNightCharge > 0 ? 25 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.isCouponApplied ? 26 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r1.billDetails.toPay, "");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" You are saving \u20B9", ctx_r1.billDetails.totalSavings, " on this order ");
    \u0275\u0275advance(5);
    \u0275\u0275classProp("selected", ctx_r1.selectedPayment === "cod");
    \u0275\u0275advance(5);
    \u0275\u0275conditional(ctx_r1.billDetails.toPay > 1500 ? 43 : -1);
  }
}
function CartPage_Conditional_0_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275template(0, CartPage_Conditional_0_Conditional_10_Conditional_0_Template, 2, 1, "div", 36);
    \u0275\u0275elementStart(1, "div", 8)(2, "div", 9);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "div", 11);
    \u0275\u0275template(5, CartPage_Conditional_0_Conditional_10_Conditional_5_Template, 2, 0)(6, CartPage_Conditional_0_Conditional_10_Conditional_6_Template, 5, 0, "div", 37);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(7, CartPage_Conditional_0_Conditional_10_Conditional_7_Template, 6, 1, "div", 38);
    \u0275\u0275elementStart(8, "div", 13)(9, "div", 39)(10, "span");
    \u0275\u0275text(11, "Coupon Code");
    \u0275\u0275elementEnd();
    \u0275\u0275element(12, "ion-icon", 40);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "div", 14);
    \u0275\u0275template(14, CartPage_Conditional_0_Conditional_10_Conditional_14_Template, 5, 3)(15, CartPage_Conditional_0_Conditional_10_Conditional_15_Template, 11, 4, "div", 41);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(16, CartPage_Conditional_0_Conditional_10_Conditional_16_Template, 45, 14);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275conditional(ctx_r1.items.length > 0 ? 0 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" Item Details (", ctx_r1.items.length, ") ");
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.items.length > 0 ? 5 : 6);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.suggestions.length > 0 ? 7 : -1);
    \u0275\u0275advance(7);
    \u0275\u0275conditional(!ctx_r1.isCouponApplied ? 14 : 15);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.items.length > 0 ? 16 : -1);
  }
}
function CartPage_Conditional_0_Conditional_11_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 75);
  }
}
function CartPage_Conditional_0_Conditional_11_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 76);
  }
}
function CartPage_Conditional_0_Conditional_11_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 77);
  }
}
function CartPage_Conditional_0_Conditional_11_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 86);
    \u0275\u0275text(1);
    \u0275\u0275pipe(2, "titlecase");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 87);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("Delivering to ", \u0275\u0275pipeBind1(2, 2, ctx_r1.address.label), "");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx_r1.address == null ? null : ctx_r1.address.address);
  }
}
function CartPage_Conditional_0_Conditional_11_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 86);
    \u0275\u0275text(1, "Delivery Address");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "div", 87);
    \u0275\u0275text(3, "Select your delivery location");
    \u0275\u0275elementEnd();
  }
}
function CartPage_Conditional_0_Conditional_11_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 80);
    \u0275\u0275text(1, "Please select a delivery address to proceed.");
    \u0275\u0275elementEnd();
  }
}
function CartPage_Conditional_0_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 7)(1, "div", 74);
    \u0275\u0275template(2, CartPage_Conditional_0_Conditional_11_Conditional_2_Template, 1, 0, "ion-icon", 75)(3, CartPage_Conditional_0_Conditional_11_Conditional_3_Template, 1, 0, "ion-icon", 76)(4, CartPage_Conditional_0_Conditional_11_Conditional_4_Template, 1, 0, "ion-icon", 77);
    \u0275\u0275elementStart(5, "div", 78);
    \u0275\u0275template(6, CartPage_Conditional_0_Conditional_11_Conditional_6_Template, 5, 4)(7, CartPage_Conditional_0_Conditional_11_Conditional_7_Template, 4, 0);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "div", 79);
    \u0275\u0275listener("click", function CartPage_Conditional_0_Conditional_11_Template_div_click_8_listener() {
      \u0275\u0275restoreView(_r12);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.openLocation());
    });
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(10, CartPage_Conditional_0_Conditional_11_Conditional_10_Template, 2, 0, "div", 80);
    \u0275\u0275elementStart(11, "button", 81);
    \u0275\u0275listener("click", function CartPage_Conditional_0_Conditional_11_Template_button_click_11_listener() {
      \u0275\u0275restoreView(_r12);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.checkBeforePayment());
    });
    \u0275\u0275elementStart(12, "div", 82)(13, "span", 83);
    \u0275\u0275text(14);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "span", 84);
    \u0275\u0275text(16, "TOTAL");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(17, "div", 74);
    \u0275\u0275text(18);
    \u0275\u0275element(19, "ion-icon", 85);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(2);
    \u0275\u0275conditional((ctx_r1.address == null ? null : ctx_r1.address.label == null ? null : ctx_r1.address.label.toLowerCase()) === "home" ? 2 : (ctx_r1.address == null ? null : ctx_r1.address.label == null ? null : ctx_r1.address.label.toLowerCase()) === "work" ? 3 : 4);
    \u0275\u0275advance(4);
    \u0275\u0275conditional((ctx_r1.address == null ? null : ctx_r1.address.label) ? 6 : 7);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" ", (ctx_r1.address == null ? null : ctx_r1.address.label) ? "Change" : "Add", " ");
    \u0275\u0275advance();
    \u0275\u0275conditional(!(ctx_r1.address == null ? null : ctx_r1.address.label) || ctx_r1.address.label === "" ? 10 : -1);
    \u0275\u0275advance();
    \u0275\u0275property("disabled", ctx_r1.selectedPayment === "cod" && ctx_r1.billDetails.toPay > 1500 || !(ctx_r1.address == null ? null : ctx_r1.address.label) || ctx_r1.address.label === "");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r1.billDetails.toPay, "");
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1(" ", ctx_r1.selectedPayment === "cod" ? "Place Order" : "Proceed to Pay", " ");
  }
}
function CartPage_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar")(2, "ion-buttons", 1)(3, "ion-button", 2);
    \u0275\u0275listener("click", function CartPage_Conditional_0_Template_ion_button_click_3_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.goBack());
    });
    \u0275\u0275element(4, "ion-icon", 3);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "ion-title", 4);
    \u0275\u0275text(6, "My Cart");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(7, "ion-content", 5);
    \u0275\u0275template(8, CartPage_Conditional_0_Conditional_8_Template, 28, 2)(9, CartPage_Conditional_0_Conditional_9_Template, 1, 0, "app-error", 6)(10, CartPage_Conditional_0_Conditional_10_Template, 17, 6);
    \u0275\u0275elementEnd();
    \u0275\u0275template(11, CartPage_Conditional_0_Conditional_11_Template, 20, 7, "div", 7);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(7);
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.isLoading ? 8 : ctx_r1.isError ? 9 : 10);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(!ctx_r1.isLoading && ctx_r1.items.length > 0 ? 11 : -1);
  }
}
function CartPage_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-content")(1, "div", 88);
    \u0275\u0275element(2, "ion-icon", 89);
    \u0275\u0275elementStart(3, "h4", 90);
    \u0275\u0275text(4, "Order Placed!");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p", 51);
    \u0275\u0275text(6, "Your order has been received.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "ion-button", 91);
    \u0275\u0275listener("click", function CartPage_Conditional_1_Template_ion_button_click_7_listener() {
      \u0275\u0275restoreView(_r13);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.trackOrder());
    });
    \u0275\u0275text(8, "Track Order");
    \u0275\u0275elementEnd()()();
  }
}
var _CartPage = class _CartPage {
  constructor(navCtrl, toastCtrl, groceryService, authService, cdr, platform, locationService) {
    this.navCtrl = navCtrl;
    this.toastCtrl = toastCtrl;
    this.groceryService = groceryService;
    this.authService = authService;
    this.cdr = cdr;
    this.platform = platform;
    this.locationService = locationService;
    this.isLoading = true;
    this.isError = false;
    this.applyingCoupon = false;
    this.checking = false;
    this.isOrderPlaced = false;
    this.insideServiceArea = false;
    this.couponMessage = "";
    this.pendingOrderId = null;
    this.pollingInterval = null;
    this.isPaymentDetected = false;
    this.cartData = null;
    this.items = [];
    this.suggestions = [];
    this.billDetails = {};
    this.selectedPayment = "cod";
    this.couponCode = "";
    this.isCouponApplied = false;
    this.cartItems = [];
    addIcons({ arrowBack, arrowBackOutline, locationOutline, timeOutline, checkmarkCircle, arrowForward, pricetagOutline, location, home, business });
  }
  ngOnInit() {
    return __async(this, null, function* () {
      this.token = yield this.authService.getToken();
      this.locationService.location$.subscribe((res) => {
        if (res) {
          this.address = res;
          this.checkServiceAvailability();
        }
      });
      this.checkPendingOrder();
      this.isLoading = true;
      this.groceryService.cart$.subscribe((cartItems) => {
        console.log("Cart Items Updated:", cartItems);
        this.cartItems = cartItems;
        this.fetchCartData(false);
        this.cdr.markForCheck();
      });
    });
  }
  checkServiceAvailability() {
    if (!this.address || !this.address.lat || !this.address.lng) {
      this.insideServiceArea = false;
      return;
    }
    this.locationService.getPolygonData().subscribe((res) => {
      if (res && res.data && res.data.polygon) {
        const polygonCoords = res.data.polygon.map((point) => ({ lat: point.lat, lng: point.lng }));
        const userLocation = { lat: this.address.lat, lng: this.address.lng };
        this.insideServiceArea = this.isPointInPolygon(userLocation, polygonCoords);
      } else {
        this.insideServiceArea = false;
      }
    }, (error) => {
      console.error("Error fetching polygon data:", error);
      this.insideServiceArea = false;
    });
  }
  isPointInPolygon(point, polygon) {
    let isInside = false;
    const x = point.lat, y = point.lng;
    for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
      if (polygon[i].lng > y !== polygon[j].lng > y && x < (polygon[j].lat - polygon[i].lat) * (y - polygon[i].lng) / (polygon[j].lng - polygon[i].lng) + polygon[i].lat) {
        isInside = !isInside;
      }
    }
    return isInside;
  }
  fetchCartData(reload) {
    if (reload) {
      this.isLoading = true;
    }
    this.isError = false;
    this.groceryService.getCartdata(this.token, this.couponCode).subscribe((apiResponse) => {
      console.log("\u{1F4E6} Cart API Response:", apiResponse);
      this.cartData = apiResponse.data;
      this.items = apiResponse.data.items;
      this.billDetails = apiResponse.data.billDetails;
      this.couponMessage = this.billDetails.couponMessage;
      this.suggestions = apiResponse.data.suggestions;
      if (this.billDetails.couponStatus === "applied") {
        this.isCouponApplied = true;
      } else {
        this.isCouponApplied = false;
      }
      this.isLoading = false;
    }, (error) => {
      console.error("Error fetching cart data:", error);
      this.isLoading = false;
      this.isError = true;
    });
  }
  checkBeforePayment() {
    this.checking = true;
    this.isError = false;
    this.groceryService.getCartdata(this.token, this.couponCode).subscribe((res) => {
      console.log("\u{1F4E6} Cart API Response:", res);
      let isChanged = false;
      let msg = "Cart details have changed. Please review.";
      console.log(msg);
      if (this.billDetails.toPay !== res.data.billDetails.toPay) {
        isChanged = true;
        msg = "Bill amount updated. Please review.";
        console.log(msg);
      } else if (this.items && res.data.items) {
        for (const item of this.items) {
          const newItem = res.data.items.find((i) => i.productId === item.productId);
          if (newItem && item.isOutOfStock === false && newItem.isOutOfStock === true) {
            isChanged = true;
            msg = "Some items are now out of stock.";
            console.log(msg);
            break;
          }
        }
      }
      if (!isChanged) {
        console.log("opening pay");
        this.checking = false;
        this.pay();
      } else {
        console.log("presenting toast");
        this.presentToast(msg);
        this.cartData = res.data;
        this.items = res.data.items;
        this.billDetails = res.data.billDetails;
        this.suggestions = res.data.suggestions;
        this.isCouponApplied = this.billDetails.couponStatus === "applied";
        this.checking = false;
      }
    }, (error) => {
      console.error("Error fetching cart data:", error);
      this.checking = false;
      this.isError = true;
    });
  }
  increase(productId) {
    this.groceryService.increaseQty(productId, this.token).subscribe({
      next: () => console.log("Increase Success"),
      error: (err) => console.error("API Failed", err)
    });
  }
  decrease(productId) {
    var _a;
    (_a = this.groceryService.decreaseQty(productId, this.token)) == null ? void 0 : _a.subscribe({
      next: () => console.log("Decrease Success"),
      error: (err) => console.error("API Failed", err)
    });
  }
  // --- HELPERS ---
  getQty(productId) {
    if (!this.cartItems || this.cartItems.length === 0)
      return 0;
    const item = this.cartItems.find((i) => String(i.productId) === String(productId));
    return item ? item.quantity : 0;
  }
  addSuggestion(productId) {
    console.log(`Add Suggestion ID: ${productId}`);
    this.presentToast("Item added to cart");
  }
  applyCoupon() {
    if (!this.couponCode) {
      this.couponMessage = "Please enter a coupon code";
      return;
    }
    this.applyingCoupon = true;
    this.fetchCartData(false);
    if (this.billDetails.couponStatus === "applied") {
      this.applyingCoupon = false;
      this.isCouponApplied = true;
      this.couponMessage = this.billDetails.couponMessage;
    } else {
      this.applyingCoupon = false;
      this.isCouponApplied = false;
      this.couponMessage = this.billDetails.couponMessage;
    }
  }
  removeCoupon() {
    this.isCouponApplied = false;
    this.couponCode = "";
    this.fetchCartData(false);
  }
  pay() {
    if (this.selectedPayment === "cod" && parseFloat(this.billDetails.toPay) > 1500) {
      this.presentToast("COD not available for orders above \u20B91500");
      return;
    }
    if (this.selectedPayment === "cod") {
      let params = {
        cartItems: this.cartData.items,
        billDetails: this.cartData.billDetails,
        address: this.address,
        status: "CONFIRMED",
        paymentDetails: {
          mode: "cod"
        }
      };
      this.groceryService.placeGroceryOrder(this.token, params).subscribe((res) => {
        this.isOrderPlaced = true;
        this.groceryService.clearCart();
        this.isLoading = false;
        this.navCtrl.navigateRoot(`/layout/grocery-layout/grocery-order-details/${res.data.id}`);
      });
    } else {
      const params = {
        cartItems: this.cartData.items,
        billDetails: this.cartData.billDetails,
        address: this.address,
        status: "PENDING",
        paymentDetails: { mode: "online" }
      };
      this.groceryService.placeGroceryOrder(this.token, params).subscribe({
        next: (res) => __async(this, null, function* () {
          if (res.success && res.razorpay_order_id) {
            this.pendingOrderId = res.internal_order_id;
            localStorage.setItem("pending_grocery_order_id", res.internal_order_id);
            this.initiateRazorpay(res.razorpay_order_id);
          } else {
            this.handleSuccess(res, this.pendingOrderId);
          }
        }),
        error: (err) => {
          console.error("Order Creation Failed", err);
          this.isLoading = false;
          this.presentToast("Order creation failed");
        }
      });
    }
  }
  // --- Payment Polling & Refund Logic ---
  checkPendingOrder() {
    return __async(this, null, function* () {
      const value = localStorage.getItem("pending_grocery_order_id");
      if (value) {
        this.pendingOrderId = value;
        this.startPolling(this.pendingOrderId);
      }
    });
  }
  initiateRazorpay(rzpOrderId) {
    const options = {
      key: "rzp_test_S5RLYqr6y2I6xs",
      amount: (this.billDetails.toPay * 100).toString(),
      currency: "INR",
      name: "Pintu Grocery",
      description: "Grocery Order",
      image: "https://your-logo-url.com/logo.png",
      order_id: rzpOrderId,
      theme: { color: "#121212" }
    };
    this.platform.ready().then(() => {
      if (typeof window.RazorpayCheckout !== "undefined") {
        window.RazorpayCheckout.open(options);
        this.startPolling(this.pendingOrderId);
      } else {
        this.isLoading = false;
        this.presentToast("Razorpay Plugin not installed");
      }
    });
  }
  startPolling(internalOrderId) {
    console.log("Started polling for:", internalOrderId);
    this.stopPolling();
    this.pollingInterval = setInterval(() => {
      this.checkStatusFromBackend(internalOrderId);
    }, 3e3);
    setTimeout(() => {
      if (!this.isPaymentDetected) {
        this.stopPolling();
        this.isLoading = false;
      }
    }, 12e4);
  }
  stopPolling() {
    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
      this.pollingInterval = null;
    }
  }
  checkStatusFromBackend(internalOrderId) {
    this.groceryService.verifyPayment({ orderId: internalOrderId }).subscribe({
      next: (res) => {
        if (res.success && res.status === "paid") {
          this.handleSuccess(res, internalOrderId);
        } else if (res.status === "failed") {
          this.stopPolling();
          this.isLoading = false;
          this.presentToast("Payment Failed.");
        }
      },
      error: (err) => console.log("Poll error", err)
    });
  }
  handleSuccess(res, internalOrderId) {
    return __async(this, null, function* () {
      this.isPaymentDetected = true;
      this.stopPolling();
      localStorage.removeItem("pending_grocery_order_id");
      this.groceryService.clearCart();
      this.navCtrl.navigateRoot(`/layout/grocery-layout/grocery-order-details/${internalOrderId}`, {
        animated: true,
        animationDirection: "forward"
      });
      this.isLoading = false;
      this.presentToast("Order Placed Successfully! \u{1F680}");
    });
  }
  ngOnDestroy() {
    this.stopPolling();
  }
  goBack() {
    this.navCtrl.back();
  }
  openLocation() {
    this.navCtrl.navigateForward("/layout/address-list", {
      state: { data: "cart" }
    });
  }
  trackOrder() {
    console.log("Track Order");
  }
  presentToast(msg) {
    return __async(this, null, function* () {
      const toast = yield this.toastCtrl.create({
        message: msg,
        duration: 1500,
        position: "bottom"
      });
      toast.present();
    });
  }
};
_CartPage.\u0275fac = function CartPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _CartPage)(\u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(ToastController), \u0275\u0275directiveInject(GroceryService), \u0275\u0275directiveInject(AuthService), \u0275\u0275directiveInject(ChangeDetectorRef), \u0275\u0275directiveInject(Platform), \u0275\u0275directiveInject(LocationService));
};
_CartPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _CartPage, selectors: [["app-cart"]], decls: 2, vars: 1, consts: [[1, "ion-no-border", "bg-white", "pt-2"], ["slot", "start"], [3, "click"], ["name", "arrow-back-outline", "color", "dark"], [1, "fw-bold", "text-dark"], [1, "bg-light", 3, "fullscreen"], ["title", "Failed to Load Cart", "subtitle", "Please check your internet connection and try again.", "buttonText", "Retry"], [1, "payment-footer"], [1, "section-card", "mt-3"], [1, "header"], ["animated", "", 2, "width", "40%", "height", "20px", "border-radius", "4px", "margin", "0"], [1, "body", "pb-2"], [1, "cart-item-wrapper", "d-flex", "align-items-center", "mb-3"], [1, "section-card"], [1, "body", "py-3"], [1, "d-flex", "gap-2"], ["animated", "", 2, "width", "70%", "height", "40px", "border-radius", "8px", "margin", "0"], ["animated", "", 2, "width", "30%", "height", "40px", "border-radius", "8px", "margin", "0"], ["animated", "", 2, "width", "30%", "height", "20px", "border-radius", "4px", "margin", "0"], [1, "d-flex", "justify-content-between", "mb-3"], [1, "d-flex", "justify-content-between", "mt-3", "pt-2", 2, "border-top", "1px dashed #eee"], ["animated", "", 2, "width", "25%", "height", "20px", "border-radius", "4px", "margin", "0"], [1, "section-card", "mb-5"], ["animated", "", 2, "width", "100%", "height", "60px", "border-radius", "12px", "margin-bottom", "10px"], ["animated", "", 2, "width", "100%", "height", "60px", "border-radius", "12px", "margin", "0"], [1, "item-img-box"], ["animated", "", 2, "width", "60px", "height", "60px", "border-radius", "10px", "margin", "0"], [1, "item-details-box", "flex-grow-1", "ms-3"], ["animated", "", 2, "width", "70%", "height", "16px", "border-radius", "4px", "margin-bottom", "8px"], ["animated", "", 2, "width", "40%", "height", "12px", "border-radius", "4px", "margin-bottom", "8px"], ["animated", "", 2, "width", "30%", "height", "16px", "border-radius", "4px", "margin", "0"], [1, "qty-btn-group", 2, "width", "80px", "height", "32px", "border-radius", "6px", "overflow", "hidden", "border", "none", "background", "transparent"], ["animated", "", 2, "width", "100%", "height", "100%", "margin", "0"], ["animated", "", 2, "width", "50%", "height", "16px", "border-radius", "4px", "margin", "0"], ["animated", "", 2, "width", "20%", "height", "16px", "border-radius", "4px", "margin", "0"], ["title", "Failed to Load Cart", "subtitle", "Please check your internet connection and try again.", "buttonText", "Retry", 3, "retry"], [1, "delivery-bar", "mx-3", "mt-2", "p-2", "text-center", "rounded-3"], [1, "text-center", "py-5"], [1, "section-card", "swiper-section"], [1, "header", "d-flex", "justify-content-between", "align-items-center"], ["name", "pricetag-outline", "color", "primary"], [1, "applied-coupon", "d-flex", "justify-content-between", "align-items-center"], [3, "innerHTML"], [1, "cart-item-wrapper", "d-flex", "align-items-center"], ["alt", "", 2, "border-radius", "10px", 3, "src"], [1, "item-details-box", "flex-grow-1"], [1, "sub-text"], [1, "price-text"], [1, "price-text", "text-decoration-line-through", 2, "font-weight", "200"], [1, "qty-btn-group"], [1, "action-btn", 3, "click"], [1, "text-secondary"], ["size", "small", "fill", "outline", "color", "dark", 3, "click"], [1, "body"], [1, "product-scroll"], [3, "product", "qty", "increase", "decrease", 4, "ngFor", "ngForOf"], [3, "increase", "decrease", "product", "qty"], ["type", "text", "placeholder", "Enter Code (e.g. WELCOME50)", 1, "coupon-input", "flex-grow-1", 3, "ngModelChange", "ngModel"], [1, "apply-btn", 3, "click", "disabled"], [1, "text-danger", "px-1", 2, "font-size", "13px"], [1, "d-flex", "align-items-center", "gap-2"], ["name", "checkmark-circle", "color", "success"], [1, "text-success"], [2, "font-size", "10px", "color", "#666"], [1, "text-danger", "fw-bold", 3, "click"], [1, "bill-row"], [1, "value"], [1, "discount"], [1, "bill-row", "total"], [1, "mt-2", "p-2", "rounded", "text-center", 2, "background", "#e8f5e9", "color", "#2e7d32", "font-size", "12px", "font-weight", "600"], [1, "payment-option", 3, "click"], [1, "radio-circle"], [1, "text-danger", "d-block", "mt-1", "ms-4", 2, "font-size", "10px"], [2, "height", "120px"], [1, "d-flex", "align-items-center"], ["name", "home", 1, "flex-shrink-0", 2, "color", "var(--grocery-theme-color)", "font-size", "30px"], ["name", "business", 1, "flex-shrink-0", 2, "color", "var(--grocery-theme-color)", "font-size", "30px"], ["name", "location", 1, "flex-shrink-0", 2, "color", "var(--grocery-theme-color)", "font-size", "30px"], [1, "ms-2", "flex-grow-1", 2, "min-width", "0"], [1, "text-uppercase", "fw-bold", "ms-2", "flex-shrink-0", 2, "font-size", "11px", "color", "var(--grocery-theme-color)", 3, "click"], [1, "text-truncate", "text-danger", "p-2", "mt-2", "text-center", 2, "font-size", "12px", "background", "rgba(255, 0, 0, 0.1)", "border", "1px solid rgba(255,0,0,0.3)", "border-radius", "5px"], [1, "pay-btn", "mt-2", 3, "click", "disabled"], [1, "d-flex", "flex-column", "align-items-start"], [2, "font-size", "14px", "font-weight", "500"], [2, "font-size", "10px", "opacity", "0.7"], ["name", "arrow-forward", 1, "ms-2"], [1, "fw-bold", "text-truncate", 2, "font-size", "13px"], [1, "text-truncate", "text-secondary", 2, "font-size", "11px"], [1, "h-100", "d-flex", "flex-column", "justify-content-center", "align-items-center"], ["name", "checkmark-circle", 2, "font-size", "80px", "color", "#28a745"], [1, "mt-3"], ["fill", "outline", "color", "dark", 1, "mt-4", 3, "click"]], template: function CartPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275template(0, CartPage_Conditional_0_Template, 12, 3)(1, CartPage_Conditional_1_Template, 9, 0, "ion-content");
  }
  if (rf & 2) {
    \u0275\u0275conditional(!ctx.isOrderPlaced ? 0 : 1);
  }
}, dependencies: [IonicModule, IonButton, IonButtons, IonContent, IonHeader, IonIcon, IonSkeletonText, IonTitle, IonToolbar, CommonModule, NgForOf, UpperCasePipe, DecimalPipe, TitleCasePipe, FormsModule, DefaultValueAccessor, NgControlStatus, NgModel, ProductCardComponent], styles: ['\n\n.bg-light[_ngcontent-%COMP%] {\n  --background: #f5f7fd;\n}\n.delivery-bar[_ngcontent-%COMP%] {\n  background: #e1f5fe;\n  color: #0277bd;\n  font-size: 12px;\n  font-weight: 500;\n  border: 1px solid #b3e5fc;\n}\n.section-card[_ngcontent-%COMP%] {\n  background: white;\n  border-radius: 16px;\n  margin: 10px 15px;\n  overflow: hidden;\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.03);\n}\n.section-card[_ngcontent-%COMP%]   .header[_ngcontent-%COMP%] {\n  padding: 12px 16px;\n  border-bottom: 1px solid #f4f4f4;\n  font-size: 15px;\n  font-weight: 700;\n  color: #222;\n}\n.section-card[_ngcontent-%COMP%]   .body[_ngcontent-%COMP%] {\n  padding: 0 16px;\n}\n.section-card.swiper-section[_ngcontent-%COMP%]   .body[_ngcontent-%COMP%] {\n  padding: 16px 0 16px 12px;\n}\n.cart-item-wrapper[_ngcontent-%COMP%] {\n  background: white;\n  padding: 15px 0;\n  border-bottom: 1px solid #f0f0f0;\n}\n.cart-item-wrapper[_ngcontent-%COMP%]:last-child {\n  border-bottom: none;\n}\n.item-img-box[_ngcontent-%COMP%] {\n  width: 60px;\n  height: 60px;\n  background: #f9f9f9;\n  border-radius: 10px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.item-img-box[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: contain;\n}\n.item-details-box[_ngcontent-%COMP%] {\n  padding-left: 12px;\n}\n.item-details-box[_ngcontent-%COMP%]   h6[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 600;\n  color: #212121;\n  margin: 0 0 2px 0;\n}\n.item-details-box[_ngcontent-%COMP%]   .sub-text[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #888;\n  display: block;\n  margin-bottom: 4px;\n}\n.item-details-box[_ngcontent-%COMP%]   .price-text[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 700;\n  color: #212121;\n}\n.qty-btn-group[_ngcontent-%COMP%] {\n  background-color: #a000e2;\n  border-radius: 6px;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 4px 8px;\n  width: 85px;\n  height: 34px;\n  box-shadow: 0 3px 6px rgba(255, 50, 105, 0.2);\n}\n.qty-btn-group[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: white;\n  font-weight: 700;\n  font-size: 14px;\n}\n.qty-btn-group[_ngcontent-%COMP%]   .action-btn[_ngcontent-%COMP%] {\n  cursor: pointer;\n  font-size: 18px;\n  line-height: 1;\n  color: white;\n  padding: 0 5px;\n}\n.suggestion-card[_ngcontent-%COMP%] {\n  background: white;\n  border: 1px solid #ebedf0;\n  border-radius: 12px;\n  padding: 10px;\n  position: relative;\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n}\n.suggestion-card[_ngcontent-%COMP%]   .discount-tag[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  background: #5d6bc0;\n  color: white;\n  font-size: 9px;\n  font-weight: 700;\n  padding: 2px 6px;\n  border-radius: 12px 0 6px 0;\n  z-index: 10;\n}\n.suggestion-card[_ngcontent-%COMP%]   .sug-img-wrapper[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 80px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin-bottom: 8px;\n}\n.suggestion-card[_ngcontent-%COMP%]   .sug-img-wrapper[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  max-width: 100%;\n  max-height: 100%;\n  object-fit: contain;\n}\n.suggestion-card[_ngcontent-%COMP%]   .time-badge[_ngcontent-%COMP%] {\n  background: #f8f9fa;\n  border: 1px solid #eee;\n  color: #666;\n  font-size: 9px;\n  padding: 2px 6px;\n  border-radius: 4px;\n  display: flex;\n  align-items: center;\n  width: fit-content;\n  margin-bottom: 5px;\n}\n.suggestion-card[_ngcontent-%COMP%]   .time-badge[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 10px;\n  margin-right: 2px;\n}\n.suggestion-card[_ngcontent-%COMP%]   h6[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-weight: 600;\n  color: #333;\n  margin: 0 0 2px 0;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.suggestion-card[_ngcontent-%COMP%]   .weight-text[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #999;\n  margin-bottom: 8px;\n  display: block;\n}\n.suggestion-card[_ngcontent-%COMP%]   .bottom-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin-top: auto;\n}\n.suggestion-card[_ngcontent-%COMP%]   .bottom-row[_ngcontent-%COMP%]   .price-box[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n.suggestion-card[_ngcontent-%COMP%]   .bottom-row[_ngcontent-%COMP%]   .price-box[_ngcontent-%COMP%]   .current-price[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 700;\n  color: #212121;\n}\n.suggestion-card[_ngcontent-%COMP%]   .bottom-row[_ngcontent-%COMP%]   .price-box[_ngcontent-%COMP%]   .original-price[_ngcontent-%COMP%] {\n  font-size: 10px;\n  text-decoration: line-through;\n  color: #999;\n}\n.suggestion-card[_ngcontent-%COMP%]   .bottom-row[_ngcontent-%COMP%]   .add-btn[_ngcontent-%COMP%] {\n  background: #fff;\n  border: 1px solid #a000e2;\n  color: #a000e2;\n  font-weight: 800;\n  font-size: 11px;\n  padding: 5px 14px;\n  border-radius: 6px;\n  text-transform: uppercase;\n}\n.coupon-input[_ngcontent-%COMP%] {\n  border: 1px solid #ddd;\n  padding: 10px;\n  border-radius: 8px;\n  outline: none;\n  font-size: 13px;\n  text-transform: uppercase;\n  background: #f9f9f9;\n}\n.apply-btn[_ngcontent-%COMP%] {\n  background: white;\n  color: #a000e2;\n  font-weight: 700;\n  border: none;\n  font-size: 13px;\n  padding: 0 10px;\n}\n.applied-coupon[_ngcontent-%COMP%] {\n  background: #e8f5e9;\n  border: 1px dashed #2e7d32;\n  padding: 10px;\n  border-radius: 8px;\n}\n.payment-option[_ngcontent-%COMP%] {\n  border: 1px solid var(--grocery-theme-color);\n  padding: 12px;\n  border-radius: 10px;\n  cursor: pointer;\n  transition: all 0.2s;\n}\n.payment-option[_ngcontent-%COMP%]   .radio-circle[_ngcontent-%COMP%] {\n  width: 18px;\n  height: 18px;\n  border: 2px solid var(--grocery-theme-color-light);\n  border-radius: 50%;\n  position: relative;\n}\n.payment-option.selected[_ngcontent-%COMP%] {\n  border-color: var(--grocery-theme-color);\n  background: var(--grocery-theme-color-light);\n}\n.payment-option.selected[_ngcontent-%COMP%]   .radio-circle[_ngcontent-%COMP%] {\n  border-color: var(--grocery-theme-color);\n}\n.payment-option.selected[_ngcontent-%COMP%]   .radio-circle[_ngcontent-%COMP%]::after {\n  content: "";\n  position: absolute;\n  top: 3px;\n  left: 3px;\n  width: 8px;\n  height: 8px;\n  background: var(--grocery-theme-color);\n  border-radius: 50%;\n}\n.bill-row[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  margin-bottom: 8px;\n  font-size: 13px;\n  color: #555;\n}\n.bill-row.total[_ngcontent-%COMP%] {\n  font-weight: 800;\n  color: #212121;\n  font-size: 15px;\n  margin-top: 10px;\n  padding-top: 10px;\n  border-top: 1px dashed #ddd;\n}\n.bill-row[_ngcontent-%COMP%]   .value[_ngcontent-%COMP%] {\n  color: #212121;\n}\n.bill-row[_ngcontent-%COMP%]   .discount[_ngcontent-%COMP%] {\n  color: #28a745;\n}\n.payment-footer[_ngcontent-%COMP%] {\n  position: fixed;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  background: white;\n  padding: 15px;\n  box-shadow: 0 -4px 12px rgba(0, 0, 0, 0.05);\n  z-index: 1000;\n  border-top-left-radius: 20px;\n  border-top-right-radius: 20px;\n}\n.payment-footer[_ngcontent-%COMP%]   .pay-btn[_ngcontent-%COMP%] {\n  background: var(--grocery-theme-color);\n  color: white;\n  border: none;\n  width: 100%;\n  padding: 14px;\n  border-radius: 12px;\n  font-size: 16px;\n  font-weight: 700;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n.payment-footer[_ngcontent-%COMP%]   .pay-btn[_ngcontent-%COMP%]:disabled {\n  opacity: 0.6;\n}\n.skeleton-box[_ngcontent-%COMP%] {\n  background: #e0e0e0;\n  animation: _ngcontent-%COMP%_pulse 1.5s infinite;\n}\n@keyframes _ngcontent-%COMP%_pulse {\n  0% {\n    opacity: 0.6;\n  }\n  50% {\n    opacity: 1;\n  }\n  100% {\n    opacity: 0.6;\n  }\n}\n.product-scroll[_ngcontent-%COMP%] {\n  display: flex;\n  overflow-x: auto;\n  padding: 0 15px;\n  gap: 12px;\n  scroll-behavior: smooth;\n}\n.product-scroll[_ngcontent-%COMP%]::-webkit-scrollbar {\n  display: none;\n}\n.product-scroll[_ngcontent-%COMP%]   app-product-card[_ngcontent-%COMP%] {\n  flex: 0 0 145px;\n  width: 145px;\n}\n/*# sourceMappingURL=cart.page.css.map */'] });
var CartPage = _CartPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(CartPage, { className: "CartPage", filePath: "src/app/pages/cart/cart.page.ts", lineNumber: 23 });
})();
export {
  CartPage
};
//# sourceMappingURL=cart.page-EPRED7FF.js.map
