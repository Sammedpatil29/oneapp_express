import {
  GESTURE_CONTROLLER,
  createGesture
} from "./chunk-6FFMTLXI.js";
import "./chunk-6B6DTIB5.js";
export {
  GESTURE_CONTROLLER,
  createGesture
};
//# sourceMappingURL=index3-C7WJFX7W.js.map
