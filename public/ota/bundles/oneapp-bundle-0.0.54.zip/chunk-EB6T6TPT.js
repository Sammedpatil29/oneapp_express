import {
  environment
} from "./chunk-YJYUHAOC.js";
import {
  HttpClient,
  HttpHeaders,
  NavController,
  Router,
  ɵɵdefineInjectable,
  ɵɵinject
} from "./chunk-Z7XNNJSA.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/services/auth.service.ts
var _AuthService = class _AuthService {
  constructor(http, router, navCtrl) {
    this.http = http;
    this.router = router;
    this.navCtrl = navCtrl;
    this.url = environment.apiUrl;
    this.token = null;
  }
  getUsers() {
    return this.http.get(this.url);
  }
  /**
   * Send Email OTP to customer
   */
  sendEmailOtp(email) {
    return this.http.post(`${this.url}/send-otp`, { email });
  }
  /**
   * Verify Customer Email OTP
   */
  verifyEmailOtp(email, otp) {
    return this.http.post(`${this.url}/verify-otp`, { email, otp });
  }
  /**
   * Legacy phone send OTP (fallback for SMS)
   */
  sendOtp(testMobileNumber, otp) {
    return this.http.post(`${this.url}/send-otp`, {
      mobileNumber: testMobileNumber,
      otp
    });
  }
  register(params) {
    return this.http.post(`${this.url}/register`, params);
  }
  checkUser(params) {
    return this.http.post(`${this.url}/login`, params);
  }
  verifyToken(token) {
    const headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.get(`${this.url}/verify-token`, { headers });
  }
  hasToken() {
    const token = localStorage.getItem("auth-token");
    return !!token && token.trim().length > 0;
  }
  getCurrentUser() {
    try {
      const u = localStorage.getItem("userDetails");
      return u ? JSON.parse(u) : null;
    } catch {
      return null;
    }
  }
  saveSession(token, user) {
    if (token) {
      localStorage.setItem("auth-token", token);
    }
    if (user) {
      const details = {
        id: user.id,
        name: `${user.first_name || ""} ${user.last_name || ""}`.trim() || user.username,
        first_name: user.first_name,
        last_name: user.last_name,
        phone: user.phone,
        email: user.email,
        profile_image: user.profile_image
      };
      localStorage.setItem("userDetails", JSON.stringify(details));
      if (user.id) {
        localStorage.setItem("user_id", String(user.id));
      }
    }
  }
  logout() {
    return __async(this, null, function* () {
      localStorage.removeItem("location");
      localStorage.removeItem("auth-token");
      localStorage.removeItem("user_id");
      localStorage.removeItem("userDetails");
      this.navCtrl.navigateRoot(["/login"]);
    });
  }
  getToken() {
    return __async(this, null, function* () {
      const token = localStorage.getItem("auth-token");
      return token;
    });
  }
};
_AuthService.\u0275fac = function AuthService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _AuthService)(\u0275\u0275inject(HttpClient), \u0275\u0275inject(Router), \u0275\u0275inject(NavController));
};
_AuthService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _AuthService, factory: _AuthService.\u0275fac, providedIn: "root" });
var AuthService = _AuthService;

export {
  AuthService
};
//# sourceMappingURL=chunk-EB6T6TPT.js.map
