import {
  environment
} from "./chunk-YJYUHAOC.js";
import {
  HttpClient,
  HttpHeaders,
  ɵɵdefineInjectable,
  ɵɵinject
} from "./chunk-Z7XNNJSA.js";

// src/app/services/referral.service.ts
var _ReferralService = class _ReferralService {
  constructor(http) {
    this.http = http;
    this.apiUrl = environment.apiUrl;
  }
  /**
   * Validate a referral code (public, called during registration)
   */
  validateReferralCode(code) {
    return this.http.post(`${this.apiUrl}/api/referral/validate`, {
      referral_code: code.trim()
    });
  }
  /**
   * Get referral dashboard details & stats for the authenticated user
   */
  getReferralDetails() {
    const token = localStorage.getItem("auth-token");
    const headers = new HttpHeaders({
      "Authorization": `Bearer ${token}`
    });
    return this.http.get(`${this.apiUrl}/api/referral/details`, { headers });
  }
};
_ReferralService.\u0275fac = function ReferralService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _ReferralService)(\u0275\u0275inject(HttpClient));
};
_ReferralService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _ReferralService, factory: _ReferralService.\u0275fac, providedIn: "root" });
var ReferralService = _ReferralService;

export {
  ReferralService
};
//# sourceMappingURL=chunk-A4U5EYAN.js.map
