import {
  LocationService
} from "./chunk-4TQR4WSH.js";
import "./chunk-V444GY6B.js";
import "./chunk-QH3WR2OQ.js";
import {
  FooterComponent
} from "./chunk-KQY4CB5X.js";
import {
  ProfileService
} from "./chunk-XB4LQWIP.js";
import {
  register
} from "./chunk-TXY46XHU.js";
import {
  addIcons,
  alertCircle,
  alertCircleOutline,
  arrowDownOutline,
  arrowForward,
  arrowForwardOutline,
  bagHandleOutline,
  carOutline,
  chatbubbleEllipsesOutline,
  chevronDown,
  chevronForward,
  closeOutline,
  cloudOfflineOutline,
  flashOutline,
  headsetOutline,
  locate,
  locateOutline,
  location,
  locationOutline,
  mapOutline,
  moonOutline,
  navigateCircleOutline,
  playCircle,
  receiptOutline,
  refresh,
  refreshOutline,
  restaurantOutline,
  shieldCheckmarkOutline,
  sparklesOutline,
  timeOutline,
  volumeHighOutline,
  volumeMuteOutline
} from "./chunk-FJYXZAS7.js";
import {
  CommonService
} from "./chunk-74TU2SUK.js";
import {
  AuthService
} from "./chunk-EB6T6TPT.js";
import {
  environment
} from "./chunk-YJYUHAOC.js";
import {
  App
} from "./chunk-EBMCUG2R.js";
import "./chunk-OE5MTPUR.js";
import {
  IonContent,
  IonHeader,
  IonIcon,
  IonModal,
  IonRefresher,
  IonRefresherContent,
  IonSkeletonText,
  IonToolbar,
  ToastController
} from "./chunk-CJE2NDTY.js";
import {
  CommonModule,
  FormsModule,
  NavController,
  NgClass,
  Router,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵstyleProp,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1
} from "./chunk-Z7XNNJSA.js";
import "./chunk-XR3JUECC.js";
import "./chunk-FH4NU4VH.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/pages/home/home.page.ts
var _c0 = () => [0, 0.55, 0.85];
var _forTrack0 = ($index, $item) => $item.id || $index;
var _forTrack1 = ($index, $item) => $item.id || $item.title || $index;
var _forTrack2 = ($index, $item) => ($item == null ? null : $item.orderId) || ($item == null ? null : $item.id) || $index;
function HomePage_Conditional_0_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 28);
    \u0275\u0275element(1, "div", 29)(2, "div", 30);
    \u0275\u0275elementStart(3, "div", 31);
    \u0275\u0275element(4, "ion-icon", 5);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "h3", 32);
    \u0275\u0275text(6, "Loading Your Address...");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "p", 33);
    \u0275\u0275text(8, " Retrieving your saved delivery address for instant access... ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "div", 34);
    \u0275\u0275element(10, "div", 35);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "span", 36);
    \u0275\u0275element(12, "ion-icon", 37);
    \u0275\u0275elementStart(13, "span");
    \u0275\u0275text(14, "Pintu Delivery Coverage System");
    \u0275\u0275elementEnd()();
  }
}
function HomePage_Conditional_0_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 28);
    \u0275\u0275element(1, "div", 29)(2, "div", 30);
    \u0275\u0275elementStart(3, "div", 31);
    \u0275\u0275element(4, "ion-icon", 5);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "h3", 32);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "p", 33);
    \u0275\u0275text(8);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "div", 34);
    \u0275\u0275element(10, "div", 35);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "span", 36);
    \u0275\u0275element(12, "ion-icon", 37);
    \u0275\u0275elementStart(13, "span");
    \u0275\u0275text(14, "Pintu Delivery Coverage System");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1(" ", ctx_r0.locationCheckPhase === "detecting" ? "Detecting Location..." : "Checking Service Area...", " ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" ", ctx_r0.locationCheckPhase === "detecting" ? "Locating your current GPS coordinates to verify fast delivery coverage..." : "Verifying active stores and service boundaries for your area...", " ");
  }
}
function HomePage_Conditional_0_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 38)(1, "div", 39);
    \u0275\u0275element(2, "ion-icon", 40);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(3, "h3", 32);
    \u0275\u0275text(4, "Location Permission Required");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p", 33);
    \u0275\u0275text(6, " Pintu needs your location permission to verify deliverability, find open stores, and calculate accurate arrival times in Athani. ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "button", 41);
    \u0275\u0275listener("click", function HomePage_Conditional_0_Conditional_4_Template_button_click_7_listener() {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.requestLocationPermissionAndPosition());
    });
    \u0275\u0275element(8, "ion-icon", 5);
    \u0275\u0275elementStart(9, "span");
    \u0275\u0275text(10, "ALLOW LOCATION ACCESS");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(11, "div", 42);
    \u0275\u0275element(12, "span", 43);
    \u0275\u0275elementStart(13, "span");
    \u0275\u0275text(14, "Waiting for permission... auto-detects once allowed");
    \u0275\u0275elementEnd()();
  }
}
function HomePage_Conditional_0_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 38)(1, "div", 44);
    \u0275\u0275element(2, "ion-icon", 45);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(3, "h3", 32);
    \u0275\u0275text(4, "Device GPS is Turned Off");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p", 33);
    \u0275\u0275text(6, " Please turn ON your device location (GPS) from the notification shade or quick settings to detect your delivery area. ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "button", 41);
    \u0275\u0275listener("click", function HomePage_Conditional_0_Conditional_5_Template_button_click_7_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.requestLocationPermissionAndPosition());
    });
    \u0275\u0275element(8, "ion-icon", 46);
    \u0275\u0275elementStart(9, "span");
    \u0275\u0275text(10, "I'VE TURNED ON GPS / RETRY");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(11, "div", 42);
    \u0275\u0275element(12, "span", 47);
    \u0275\u0275elementStart(13, "span");
    \u0275\u0275text(14, "Continuously monitoring... will detect automatically");
    \u0275\u0275elementEnd()();
  }
}
function HomePage_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 0)(1, "div", 27);
    \u0275\u0275template(2, HomePage_Conditional_0_Conditional_2_Template, 15, 0)(3, HomePage_Conditional_0_Conditional_3_Template, 15, 2)(4, HomePage_Conditional_0_Conditional_4_Template, 15, 0)(5, HomePage_Conditional_0_Conditional_5_Template, 15, 0);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r0.locationCheckPhase === "loading_address" ? 2 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.locationCheckPhase === "detecting" || ctx_r0.locationCheckPhase === "validating" ? 3 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.locationCheckPhase === "permission_needed" ? 4 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.locationCheckPhase === "gps_disabled" ? 5 : -1);
  }
}
function HomePage_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "span", 9);
  }
}
function HomePage_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "span", 10);
  }
}
function HomePage_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "span", 11);
  }
}
function HomePage_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 13)(1, "span", 48);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r0.displayFullAddress);
  }
}
function HomePage_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "img", 49);
    \u0275\u0275listener("error", function HomePage_Conditional_18_Template_img_error_0_listener() {
      \u0275\u0275restoreView(_r4);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.profileAvatar = "");
    });
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275property("src", ctx_r0.profileAvatar, \u0275\u0275sanitizeUrl);
  }
}
function HomePage_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 17);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r0.userInitials);
  }
}
function HomePage_Conditional_23_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 50)(1, "div", 52);
    \u0275\u0275element(2, "ion-skeleton-text", 53);
    \u0275\u0275elementEnd()();
  }
}
function HomePage_Conditional_23_Conditional_1_For_3_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "swiper-slide")(1, "div", 55);
    \u0275\u0275listener("click", function HomePage_Conditional_23_Conditional_1_For_3_Conditional_0_Template_div_click_1_listener() {
      \u0275\u0275restoreView(_r5);
      const banner_r6 = \u0275\u0275nextContext().$implicit;
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.navigateToBanner(banner_r6));
    });
    \u0275\u0275elementStart(2, "img", 56);
    \u0275\u0275listener("error", function HomePage_Conditional_23_Conditional_1_For_3_Conditional_0_Template_img_error_2_listener() {
      \u0275\u0275restoreView(_r5);
      const banner_r6 = \u0275\u0275nextContext().$implicit;
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.onBannerImgError(banner_r6));
    });
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const banner_r6 = \u0275\u0275nextContext().$implicit;
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(2);
    \u0275\u0275property("src", ctx_r0.getBannerImgUrl(banner_r6), \u0275\u0275sanitizeUrl)("alt", banner_r6.title || "Promotional Banner");
  }
}
function HomePage_Conditional_23_Conditional_1_For_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275template(0, HomePage_Conditional_23_Conditional_1_For_3_Conditional_0_Template, 3, 2, "swiper-slide");
  }
  if (rf & 2) {
    const banner_r6 = ctx.$implicit;
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275conditional(ctx_r0.isBannerImageValid(banner_r6) ? 0 : -1);
  }
}
function HomePage_Conditional_23_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 51)(1, "swiper-container", 54);
    \u0275\u0275repeaterCreate(2, HomePage_Conditional_23_Conditional_1_For_3_Template, 1, 1, null, null, _forTrack0);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(2);
    \u0275\u0275repeater(ctx_r0.banners);
  }
}
function HomePage_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275template(0, HomePage_Conditional_23_Conditional_0_Template, 3, 0, "section", 50)(1, HomePage_Conditional_23_Conditional_1_Template, 4, 0, "section", 51);
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275conditional(ctx_r0.isLoadingHeroBanners ? 0 : ctx_r0.banners && ctx_r0.banners.length > 0 ? 1 : -1);
  }
}
function HomePage_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "section", 22)(1, "div", 57);
    \u0275\u0275element(2, "ion-icon", 58);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 59)(4, "div", 60);
    \u0275\u0275element(5, "span", 61);
    \u0275\u0275elementStart(6, "span");
    \u0275\u0275text(7, "LOCATION PERMISSION REQUIRED");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "h4", 62);
    \u0275\u0275text(9, "GPS Access Disabled");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "p", 63);
    \u0275\u0275text(11, "Please enable location permissions to verify deliverability and explore active stores in Athani.");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(12, "button", 64);
    \u0275\u0275listener("click", function HomePage_Conditional_25_Template_button_click_12_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.requestLocationPermissionAndPosition());
    });
    \u0275\u0275elementStart(13, "span");
    \u0275\u0275text(14, "ENABLE");
    \u0275\u0275elementEnd();
    \u0275\u0275element(15, "ion-icon", 65);
    \u0275\u0275elementEnd()();
  }
}
function HomePage_Conditional_26_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "section", 66)(1, "div", 68);
    \u0275\u0275element(2, "div", 69);
    \u0275\u0275elementStart(3, "div", 70);
    \u0275\u0275element(4, "ion-icon", 71);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "div", 72);
    \u0275\u0275element(6, "span", 73);
    \u0275\u0275elementStart(7, "span");
    \u0275\u0275text(8, "SERVICES TEMPORARILY CLOSED");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "h3", 74);
    \u0275\u0275text(10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "p", 75);
    \u0275\u0275text(12);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "div", 76)(14, "button", 77);
    \u0275\u0275listener("click", function HomePage_Conditional_26_Conditional_1_Template_button_click_14_listener() {
      \u0275\u0275restoreView(_r8);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.openLocation());
    });
    \u0275\u0275element(15, "ion-icon", 78);
    \u0275\u0275elementStart(16, "span");
    \u0275\u0275text(17, "Change Location");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(18, "button", 79);
    \u0275\u0275listener("click", function HomePage_Conditional_26_Conditional_1_Template_button_click_18_listener() {
      \u0275\u0275restoreView(_r8);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.recheckLocationAndServiceArea());
    });
    \u0275\u0275element(19, "ion-icon", 80);
    \u0275\u0275elementStart(20, "span");
    \u0275\u0275text(21, "Check Again");
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(10);
    \u0275\u0275textInterpolate1(" Operations Paused in ", ctx_r0.closedAreaCity || ctx_r0.displayLocationName || "this city", " ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" ", ctx_r0.areaClosureMessage || "Our delivery partners and stores in this city are temporarily offline. We will resume operations soon.", " ");
  }
}
function HomePage_Conditional_26_Conditional_2_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 84)(1, "div", 87);
    \u0275\u0275element(2, "ion-icon", 88);
    \u0275\u0275elementStart(3, "span");
    \u0275\u0275text(4, "Nearest City Zone: ");
    \u0275\u0275elementStart(5, "strong");
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(7, "div", 89);
    \u0275\u0275text(8, " Approx. ");
    \u0275\u0275elementStart(9, "strong");
    \u0275\u0275text(10);
    \u0275\u0275elementEnd();
    \u0275\u0275text(11, " away ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "p", 90);
    \u0275\u0275text(13, " Please travel inside ");
    \u0275\u0275elementStart(14, "strong");
    \u0275\u0275text(15);
    \u0275\u0275elementEnd();
    \u0275\u0275text(16, " or change delivery location to place orders. ");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(ctx_r0.nearestServiceArea.cityName);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("", ctx_r0.nearestServiceArea.distanceKm, " km");
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r0.nearestServiceArea.cityName);
  }
}
function HomePage_Conditional_26_Conditional_2_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 85);
    \u0275\u0275element(1, "ion-icon", 88);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3, "Please move inside our active service area to explore and place orders.");
    \u0275\u0275elementEnd()();
  }
}
function HomePage_Conditional_26_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "section", 67)(1, "div", 81);
    \u0275\u0275element(2, "div", 69);
    \u0275\u0275elementStart(3, "div", 70);
    \u0275\u0275element(4, "ion-icon", 82);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "div", 83);
    \u0275\u0275element(6, "span", 73);
    \u0275\u0275elementStart(7, "span");
    \u0275\u0275text(8, "OUT OF SERVICE AREA");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "h3", 74);
    \u0275\u0275text(10, "Outside Serviceable Zone");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "p", 75);
    \u0275\u0275text(12, " Your selected location is currently outside our operating delivery service boundaries. ");
    \u0275\u0275elementEnd();
    \u0275\u0275template(13, HomePage_Conditional_26_Conditional_2_Conditional_13_Template, 17, 3, "div", 84)(14, HomePage_Conditional_26_Conditional_2_Conditional_14_Template, 4, 0, "div", 85);
    \u0275\u0275elementStart(15, "div", 76)(16, "button", 77);
    \u0275\u0275listener("click", function HomePage_Conditional_26_Conditional_2_Template_button_click_16_listener() {
      \u0275\u0275restoreView(_r9);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.openLocation());
    });
    \u0275\u0275element(17, "ion-icon", 78);
    \u0275\u0275elementStart(18, "span");
    \u0275\u0275text(19, "Change Location");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(20, "button", 86);
    \u0275\u0275listener("click", function HomePage_Conditional_26_Conditional_2_Template_button_click_20_listener() {
      \u0275\u0275restoreView(_r9);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.recheckLocationAndServiceArea());
    });
    \u0275\u0275element(21, "ion-icon", 80);
    \u0275\u0275elementStart(22, "span");
    \u0275\u0275text(23, "Check Again");
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(13);
    \u0275\u0275conditional(ctx_r0.nearestServiceArea ? 13 : 14);
  }
}
function HomePage_Conditional_26_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 23);
    \u0275\u0275template(1, HomePage_Conditional_26_Conditional_1_Template, 22, 2, "section", 66)(2, HomePage_Conditional_26_Conditional_2_Template, 24, 1, "section", 67);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.isAreaClosed ? 1 : ctx_r0.isOutOfServiceArea ? 2 : -1);
  }
}
function HomePage_Conditional_27_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 96)(1, "div", 101);
    \u0275\u0275element(2, "div", 102)(3, "ion-skeleton-text", 103)(4, "ion-skeleton-text", 104)(5, "ion-skeleton-text", 105);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "div", 106);
    \u0275\u0275element(7, "div", 102)(8, "ion-skeleton-text", 107)(9, "ion-skeleton-text", 108)(10, "ion-skeleton-text", 109);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "div", 106);
    \u0275\u0275element(12, "div", 102)(13, "ion-skeleton-text", 107)(14, "ion-skeleton-text", 108)(15, "ion-skeleton-text", 109);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "div", 110);
    \u0275\u0275element(17, "div", 102)(18, "ion-skeleton-text", 111)(19, "ion-skeleton-text", 112)(20, "ion-skeleton-text", 113);
    \u0275\u0275elementEnd()();
  }
}
function HomePage_Conditional_27_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 97)(1, "div", 114);
    \u0275\u0275element(2, "ion-icon", 115);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "h4", 116);
    \u0275\u0275text(4, "Unable to Load Services");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p", 117);
    \u0275\u0275text(6, "We couldn't connect to Pintu servers. Please check your connection.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "button", 118);
    \u0275\u0275listener("click", function HomePage_Conditional_27_Conditional_8_Template_button_click_7_listener() {
      \u0275\u0275restoreView(_r10);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.retryHomeData());
    });
    \u0275\u0275element(8, "ion-icon", 80);
    \u0275\u0275elementStart(9, "span");
    \u0275\u0275text(10, "Tap to Retry");
    \u0275\u0275elementEnd()()();
  }
}
function HomePage_Conditional_27_Conditional_9_For_2_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 121)(1, "span");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const service_r12 = \u0275\u0275nextContext().$implicit;
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275property("ngClass", ctx_r0.getOfferTagClass(service_r12));
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(service_r12.offers);
  }
}
function HomePage_Conditional_27_Conditional_9_For_2_Conditional_2_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "img", 134);
    \u0275\u0275listener("error", function HomePage_Conditional_27_Conditional_9_For_2_Conditional_2_Conditional_7_Template_img_error_0_listener() {
      \u0275\u0275restoreView(_r13);
      const service_r12 = \u0275\u0275nextContext(2).$implicit;
      return \u0275\u0275resetView(service_r12.hasImgError = true);
    });
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const service_r12 = \u0275\u0275nextContext(2).$implicit;
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275property("src", ctx_r0.getServiceImgUrl(service_r12), \u0275\u0275sanitizeUrl)("alt", service_r12.title);
  }
}
function HomePage_Conditional_27_Conditional_9_For_2_Conditional_2_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 135)(1, "span", 136);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const service_r12 = \u0275\u0275nextContext(2).$implicit;
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275styleProp("background", ctx_r0.getServiceBg(service_r12));
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r0.getServiceIcon(service_r12));
  }
}
function HomePage_Conditional_27_Conditional_9_For_2_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 123)(1, "div", 124)(2, "h3", 125);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "p", 126);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "div", 127);
    \u0275\u0275template(7, HomePage_Conditional_27_Conditional_9_For_2_Conditional_2_Conditional_7_Template, 1, 2, "img", 128)(8, HomePage_Conditional_27_Conditional_9_For_2_Conditional_2_Conditional_8_Template, 3, 3, "div", 129);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "div", 130)(10, "span", 131);
    \u0275\u0275text(11, "Explore");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "div", 132);
    \u0275\u0275element(13, "ion-icon", 133);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const service_r12 = \u0275\u0275nextContext().$implicit;
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275classProp("has-corner-tag", ctx_r0.hasOffer(service_r12));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(service_r12.title);
    \u0275\u0275advance();
    \u0275\u0275classProp("status-active", ctx_r0.isStatusActive(service_r12));
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", service_r12.subtitle || (ctx_r0.isStatusActive(service_r12) ? "Active" : "Instant & reliable service"), " ");
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r0.isImageValid(service_r12) && !service_r12.hasImgError ? 7 : 8);
  }
}
function HomePage_Conditional_27_Conditional_9_For_2_Conditional_3_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "img", 145);
    \u0275\u0275listener("error", function HomePage_Conditional_27_Conditional_9_For_2_Conditional_3_Conditional_11_Template_img_error_0_listener() {
      \u0275\u0275restoreView(_r14);
      const service_r12 = \u0275\u0275nextContext(2).$implicit;
      return \u0275\u0275resetView(service_r12.hasImgError = true);
    });
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const service_r12 = \u0275\u0275nextContext(2).$implicit;
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275property("src", ctx_r0.getServiceImgUrl(service_r12), \u0275\u0275sanitizeUrl)("alt", service_r12.title);
  }
}
function HomePage_Conditional_27_Conditional_9_For_2_Conditional_3_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 146)(1, "span", 136);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const service_r12 = \u0275\u0275nextContext(2).$implicit;
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275styleProp("background", ctx_r0.getServiceBg(service_r12));
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r0.getServiceIcon(service_r12));
  }
}
function HomePage_Conditional_27_Conditional_9_For_2_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 137)(1, "div", 138)(2, "h4", 139);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "p", 140);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "div", 141)(7, "span");
    \u0275\u0275text(8, "Explore");
    \u0275\u0275elementEnd();
    \u0275\u0275element(9, "ion-icon", 133);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(10, "div", 142);
    \u0275\u0275template(11, HomePage_Conditional_27_Conditional_9_For_2_Conditional_3_Conditional_11_Template, 1, 2, "img", 143)(12, HomePage_Conditional_27_Conditional_9_For_2_Conditional_3_Conditional_12_Template, 3, 3, "div", 144);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const service_r12 = \u0275\u0275nextContext().$implicit;
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275classProp("has-corner-tag", ctx_r0.hasOffer(service_r12));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(service_r12.title);
    \u0275\u0275advance();
    \u0275\u0275classProp("status-active", ctx_r0.isStatusActive(service_r12));
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", service_r12.subtitle || (ctx_r0.isStatusActive(service_r12) ? "Active" : "Available now"), " ");
    \u0275\u0275advance(6);
    \u0275\u0275conditional(ctx_r0.isImageValid(service_r12) && !service_r12.hasImgError ? 11 : 12);
  }
}
function HomePage_Conditional_27_Conditional_9_For_2_Conditional_4_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "img", 155);
    \u0275\u0275listener("error", function HomePage_Conditional_27_Conditional_9_For_2_Conditional_4_Conditional_9_Template_img_error_0_listener() {
      \u0275\u0275restoreView(_r15);
      const service_r12 = \u0275\u0275nextContext(2).$implicit;
      return \u0275\u0275resetView(service_r12.hasImgError = true);
    });
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const service_r12 = \u0275\u0275nextContext(2).$implicit;
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275property("src", ctx_r0.getServiceImgUrl(service_r12), \u0275\u0275sanitizeUrl)("alt", service_r12.title);
  }
}
function HomePage_Conditional_27_Conditional_9_For_2_Conditional_4_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 156)(1, "span", 157);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const service_r12 = \u0275\u0275nextContext(2).$implicit;
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275styleProp("background", ctx_r0.getServiceBg(service_r12));
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r0.getServiceIcon(service_r12));
  }
}
function HomePage_Conditional_27_Conditional_9_For_2_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 147)(1, "div", 148)(2, "h4", 149);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "p", 150);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "div", 151);
    \u0275\u0275element(7, "ion-icon", 133);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "div", 152);
    \u0275\u0275template(9, HomePage_Conditional_27_Conditional_9_For_2_Conditional_4_Conditional_9_Template, 1, 2, "img", 153)(10, HomePage_Conditional_27_Conditional_9_For_2_Conditional_4_Conditional_10_Template, 3, 3, "div", 154);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const service_r12 = \u0275\u0275nextContext().$implicit;
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275classProp("has-corner-tag", ctx_r0.hasOffer(service_r12));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(service_r12.title);
    \u0275\u0275advance();
    \u0275\u0275classProp("status-active", ctx_r0.isStatusActive(service_r12));
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", service_r12.subtitle || (ctx_r0.isStatusActive(service_r12) ? "Active" : "Book now"), " ");
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx_r0.isImageValid(service_r12) && !service_r12.hasImgError ? 9 : 10);
  }
}
function HomePage_Conditional_27_Conditional_9_For_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 120);
    \u0275\u0275listener("click", function HomePage_Conditional_27_Conditional_9_For_2_Template_div_click_0_listener() {
      const service_r12 = \u0275\u0275restoreView(_r11).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.navigateToService(service_r12));
    });
    \u0275\u0275template(1, HomePage_Conditional_27_Conditional_9_For_2_Conditional_1_Template, 3, 2, "div", 121)(2, HomePage_Conditional_27_Conditional_9_For_2_Conditional_2_Template, 14, 7, "div", 122)(3, HomePage_Conditional_27_Conditional_9_For_2_Conditional_3_Template, 13, 7)(4, HomePage_Conditional_27_Conditional_9_For_2_Conditional_4_Template, 11, 7);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const service_r12 = ctx.$implicit;
    const $index_r16 = ctx.$index;
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275styleProp("background", ctx_r0.getServiceCardGradient(service_r12));
    \u0275\u0275property("ngClass", ctx_r0.getMosaicTileType($index_r16, ctx_r0.allServices.length));
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.hasOffer(service_r12) ? 1 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.getMosaicTileType($index_r16, ctx_r0.allServices.length) === "mosaic-tile-tall" ? 2 : ctx_r0.getMosaicTileType($index_r16, ctx_r0.allServices.length) === "mosaic-tile-wide" ? 3 : 4);
  }
}
function HomePage_Conditional_27_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 98);
    \u0275\u0275repeaterCreate(1, HomePage_Conditional_27_Conditional_9_For_2_Template, 5, 5, "div", 119, _forTrack1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275property("ngClass", "count-" + ctx_r0.allServices.length + (ctx_r0.allServices.length > 2 ? " bento-grid" : ""));
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r0.allServices);
  }
}
function HomePage_Conditional_27_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 99)(1, "div", 158);
    \u0275\u0275element(2, "ion-skeleton-text", 159);
    \u0275\u0275elementEnd()();
  }
}
function HomePage_Conditional_27_Conditional_11_For_2_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 161);
    \u0275\u0275listener("click", function HomePage_Conditional_27_Conditional_11_For_2_Conditional_0_Template_div_click_0_listener() {
      \u0275\u0275restoreView(_r17);
      const banner_r18 = \u0275\u0275nextContext().$implicit;
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.navigateToBanner(banner_r18));
    });
    \u0275\u0275elementStart(1, "img", 162);
    \u0275\u0275listener("error", function HomePage_Conditional_27_Conditional_11_For_2_Conditional_0_Template_img_error_1_listener() {
      \u0275\u0275restoreView(_r17);
      const banner_r18 = \u0275\u0275nextContext().$implicit;
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.onBannerImgError(banner_r18));
    });
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const banner_r18 = \u0275\u0275nextContext().$implicit;
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275property("src", ctx_r0.getBannerImgUrl(banner_r18), \u0275\u0275sanitizeUrl)("alt", banner_r18.title || "Promotional Banner");
  }
}
function HomePage_Conditional_27_Conditional_11_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275template(0, HomePage_Conditional_27_Conditional_11_For_2_Conditional_0_Template, 2, 2, "div", 160);
  }
  if (rf & 2) {
    const banner_r18 = ctx.$implicit;
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275conditional(ctx_r0.isBannerImageValid(banner_r18) ? 0 : -1);
  }
}
function HomePage_Conditional_27_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 100);
    \u0275\u0275repeaterCreate(1, HomePage_Conditional_27_Conditional_11_For_2_Template, 1, 1, null, null, _forTrack0);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r0.bottomBanners);
  }
}
function HomePage_Conditional_27_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 91)(1, "div", 92)(2, "div", 93)(3, "span", 94);
    \u0275\u0275text(4, "\u2728");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "h3", 95);
    \u0275\u0275text(6, "Services");
    \u0275\u0275elementEnd()()();
    \u0275\u0275template(7, HomePage_Conditional_27_Conditional_7_Template, 21, 0, "div", 96)(8, HomePage_Conditional_27_Conditional_8_Template, 11, 0, "div", 97)(9, HomePage_Conditional_27_Conditional_9_Template, 3, 1, "div", 98);
    \u0275\u0275elementEnd();
    \u0275\u0275template(10, HomePage_Conditional_27_Conditional_10_Template, 3, 0, "section", 99)(11, HomePage_Conditional_27_Conditional_11_Template, 3, 0, "section", 100);
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(7);
    \u0275\u0275conditional(ctx_r0.isLoadingServices && ctx_r0.allServices.length === 0 ? 7 : ctx_r0.hasHomeDataError && ctx_r0.allServices.length === 0 ? 8 : 9);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx_r0.isLoadingBottomBanners ? 10 : ctx_r0.bottomBanners && ctx_r0.bottomBanners.length > 0 ? 11 : -1);
  }
}
function HomePage_Conditional_28_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "app-footer");
  }
}
function HomePage_Conditional_30_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 170);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("#", (ctx_r0.orders[0] == null ? null : ctx_r0.orders[0].orderId) || (ctx_r0.orders[0] == null ? null : ctx_r0.orders[0].id), "");
  }
}
function HomePage_Conditional_30_Template(rf, ctx) {
  if (rf & 1) {
    const _r19 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "aside", 163);
    \u0275\u0275listener("click", function HomePage_Conditional_30_Template_aside_click_0_listener() {
      \u0275\u0275restoreView(_r19);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.handleActiveOrderBannerClick());
    });
    \u0275\u0275elementStart(1, "div", 164)(2, "div", 165);
    \u0275\u0275element(3, "div", 166);
    \u0275\u0275elementStart(4, "div", 167)(5, "div", 168)(6, "span", 169);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275template(8, HomePage_Conditional_30_Conditional_8_Template, 2, 1, "span", 170);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "span", 171);
    \u0275\u0275text(10);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(11, "button", 172)(12, "span");
    \u0275\u0275text(13);
    \u0275\u0275elementEnd();
    \u0275\u0275element(14, "ion-icon", 133);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate1(" ", ctx_r0.orders.length > 1 ? ctx_r0.orders.length + " ACTIVE ORDERS" : "ACTIVE ORDER", " ");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.orders.length === 1 && ((ctx_r0.orders[0] == null ? null : ctx_r0.orders[0].orderId) || (ctx_r0.orders[0] == null ? null : ctx_r0.orders[0].id)) ? 8 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" ", ctx_r0.orders.length > 1 ? "Multiple deliveries in progress" : ctx_r0.getActiveOrderHeadline(ctx_r0.orders[0]), " ");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx_r0.orders.length > 1 ? "View All" : "Track");
  }
}
function HomePage_ng_template_32_For_13_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 194);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const order_r22 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("\u20B9", order_r22.totalAmount || order_r22.grandTotal || order_r22.total, "");
  }
}
function HomePage_ng_template_32_For_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r21 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 184);
    \u0275\u0275listener("click", function HomePage_ng_template_32_For_13_Template_div_click_0_listener() {
      const order_r22 = \u0275\u0275restoreView(_r21).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.selectActiveOrder(order_r22));
    });
    \u0275\u0275elementStart(1, "div", 185)(2, "div", 186);
    \u0275\u0275element(3, "ion-icon", 187);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "div", 188)(5, "div", 189)(6, "span", 190);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "span", 191);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(10, "div", 192);
    \u0275\u0275element(11, "span", 193);
    \u0275\u0275elementStart(12, "span");
    \u0275\u0275text(13);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(14, HomePage_ng_template_32_For_13_Conditional_14_Template, 2, 1, "span", 194);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "div", 195)(16, "button", 196)(17, "span");
    \u0275\u0275text(18, "Track");
    \u0275\u0275elementEnd();
    \u0275\u0275element(19, "ion-icon", 65);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const order_r22 = ctx.$implicit;
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(3);
    \u0275\u0275property("name", ctx_r0.getOrderIcon(order_r22));
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("Order #", order_r22.orderId || order_r22.id, "");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r0.formatOrderTime(order_r22));
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r0.getActiveOrderHeadline(order_r22));
    \u0275\u0275advance();
    \u0275\u0275conditional(order_r22.totalAmount || order_r22.grandTotal || order_r22.total ? 14 : -1);
  }
}
function HomePage_ng_template_32_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 173)(1, "div", 174);
    \u0275\u0275element(2, "div", 175);
    \u0275\u0275elementStart(3, "div", 176)(4, "div", 177)(5, "h3", 178);
    \u0275\u0275text(6, "Active Orders");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "p", 179);
    \u0275\u0275text(8, "Select an ongoing order to track live status");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "button", 180);
    \u0275\u0275listener("click", function HomePage_ng_template_32_Template_button_click_9_listener() {
      \u0275\u0275restoreView(_r20);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.closeMultiOrderModal());
    });
    \u0275\u0275element(10, "ion-icon", 181);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(11, "div", 182);
    \u0275\u0275repeaterCreate(12, HomePage_ng_template_32_For_13_Template, 20, 5, "div", 183, _forTrack2);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(12);
    \u0275\u0275repeater(ctx_r0.orders);
  }
}
register();
var _HomePage = class _HomePage {
  get isOfflineOrOutOfServiceArea() {
    return Boolean(this.isAreaClosed || this.isOutOfServiceArea);
  }
  constructor(router, navCtrl, authService, locationService, profileService, commonService, toastCtrl) {
    this.router = router;
    this.navCtrl = navCtrl;
    this.authService = authService;
    this.locationService = locationService;
    this.profileService = profileService;
    this.commonService = commonService;
    this.toastCtrl = toastCtrl;
    this.headerBg = "rgba(255, 255, 255, 0)";
    this.headerOpacity = 0;
    this.isPastBanner = false;
    this.isScrolled = false;
    this.cachedBannerHeight = 0;
    this.locationLabel = "UNSAVED";
    this.isSavedAddress = false;
    this.displayLocationName = "Select Location";
    this.displayFullAddress = "";
    this.profileAvatar = "";
    this.userInitials = "P";
    this.orders = [];
    this.isMultiOrderModalOpen = false;
    this.token = "";
    this.isLoadingServices = true;
    this.isCheckingLocation = true;
    this.locationCheckPhase = "detecting";
    this.isGpsDisabled = false;
    this.locationWatchId = null;
    this.locationMonitorTimer = null;
    this.appStateListener = null;
    this.isLocationPermissionDenied = false;
    this.isOutOfServiceArea = false;
    this.nearestServiceArea = null;
    this.isAreaClosed = false;
    this.closedAreaCity = "";
    this.areaClosureMessage = "";
    this.currentCoords = null;
    this.banners = [];
    this.bottomBanners = [];
    this.isLoadingHeroBanners = true;
    this.isLoadingBottomBanners = true;
    this.hasHomeDataError = false;
    this.currentCity = "";
    this.allServices = [];
    addIcons({ location, shieldCheckmarkOutline, alertCircle, locate, refresh, chevronDown, alertCircleOutline, chevronForward, moonOutline, mapOutline, refreshOutline, locationOutline, navigateCircleOutline, cloudOfflineOutline, arrowForward, closeOutline, locateOutline, arrowForwardOutline, flashOutline, sparklesOutline, chatbubbleEllipsesOutline, arrowDownOutline, headsetOutline, playCircle, volumeMuteOutline, volumeHighOutline, bagHandleOutline, carOutline, restaurantOutline, timeOutline, receiptOutline });
  }
  goToSupport() {
    this.router.navigate(["/layout/support"]);
  }
  ngOnInit() {
    return __async(this, null, function* () {
      this.token = (yield this.authService.getToken()) || "";
      const savedLoc = localStorage.getItem("location");
      if (savedLoc) {
        try {
          const parsed = JSON.parse(savedLoc);
          this.applyLocationDetails(parsed);
        } catch (e) {
        }
      }
      this.locationService.location$.subscribe((loc) => {
        if (loc) {
          this.applyLocationDetails(loc);
        }
      });
      this.locationService.address$.subscribe((addr) => {
        if (addr && addr.trim() && (!this.displayFullAddress || this.displayFullAddress === "Select Location")) {
          this.displayFullAddress = addr.trim();
          if (this.displayLocationName === "Select Location" || !this.displayLocationName) {
            this.displayLocationName = addr.split(",")[0].trim();
          }
        }
      });
      this.locationService.city$.subscribe((city) => {
        if (city && city.trim()) {
          const trimmedCity = city.trim();
          const cityChanged = this.currentCity !== trimmedCity;
          this.currentCity = trimmedCity;
          if (this.displayLocationName === "Select Location" || !this.displayLocationName) {
            this.displayLocationName = trimmedCity;
          }
          if (cityChanged) {
            this.loadBanners();
          }
        }
      });
      this.startLocationVerificationFlow(true);
      if (this.token) {
        this.loadUserProfile();
        this.loadHomeData();
        this.loadActiveOrders();
      } else {
        this.loadHomeData();
      }
    });
  }
  ngOnDestroy() {
    this.stopContinuousLocationMonitoring();
  }
  /**
   * Fires every time the home page becomes active (including back navigation).
   * Re-reads localStorage to pick up address changes made on the map/address-list pages.
   */
  ionViewWillEnter() {
    const savedLoc = localStorage.getItem("location");
    if (savedLoc) {
      try {
        const parsed = JSON.parse(savedLoc);
        this.applyLocationDetails(parsed);
      } catch (e) {
      }
    }
  }
  /**
   * Helper to display informative toast messages
   */
  presentToast(message, color = "dark") {
    return __async(this, null, function* () {
      try {
        const toast = yield this.toastCtrl.create({
          message,
          duration: 2e3,
          position: "bottom",
          color
        });
        yield toast.present();
      } catch (e) {
        console.log("Toast:", message);
      }
    });
  }
  /**
   * Primary location verification flow on startup & refresh.
   * Priority: 1) localStorage cached address → 2) DB primary address → 3) GPS fallback
   */
  startLocationVerificationFlow(showModal = true) {
    return __async(this, null, function* () {
      var _a;
      if (showModal) {
        this.isCheckingLocation = true;
        this.locationCheckPhase = "loading_address";
      }
      const savedLoc = localStorage.getItem("location");
      if (savedLoc) {
        try {
          const parsed = JSON.parse(savedLoc);
          if ((parsed == null ? void 0 : parsed.lat) && (parsed == null ? void 0 : parsed.lng)) {
            console.log("\u{1F4CD} Using cached primary address from localStorage");
            this.applyLocationDetails(parsed);
            this.locationCheckPhase = "validating";
            yield this.evaluateServiceArea(Number(parsed.lat), Number(parsed.lng));
            this.startContinuousLocationMonitoring();
            return;
          }
        } catch (e) {
          console.warn("Failed to parse cached location:", e);
        }
      }
      if (this.token) {
        try {
          const primaryAddr = yield this.fetchPrimaryAddressFromApi();
          if ((primaryAddr == null ? void 0 : primaryAddr.lat) && (primaryAddr == null ? void 0 : primaryAddr.lng)) {
            console.log("\u{1F4CD} Using DB primary address:", primaryAddr.address);
            const locData = {
              lat: primaryAddr.lat,
              lng: primaryAddr.lng,
              id: primaryAddr.id,
              label: primaryAddr.label || "Home",
              house_no: primaryAddr.house_no,
              building_name: primaryAddr.building_name,
              landmark: primaryAddr.landmark,
              address: primaryAddr.address,
              area: ((_a = primaryAddr.address) == null ? void 0 : _a.split(",")[0]) || "Athani"
            };
            this.locationService.setAddress(locData);
            this.applyLocationDetails(locData);
            this.locationCheckPhase = "validating";
            yield this.evaluateServiceArea(Number(primaryAddr.lat), Number(primaryAddr.lng));
            this.startContinuousLocationMonitoring();
            return;
          }
        } catch (e) {
          console.warn("Could not fetch primary address from API:", e);
        }
      }
      console.log("\u{1F4CD} No primary address found, falling back to GPS detection");
      this.locationCheckPhase = "detecting";
      yield this.runLocationCheck();
      this.startContinuousLocationMonitoring();
    });
  }
  /**
   * Apply address details to header UI:
   * Sets locationLabel ('HOME', 'WORK', 'OTHER', or 'UNSAVED'),
   * displayLocationName (main area name),
   * and displayFullAddress (detailed street / full address).
   */
  applyLocationDetails(addr) {
    if (!addr)
      return;
    const rawLabel = (addr.label || "").trim();
    if (addr.id || rawLabel && rawLabel.toLowerCase() !== "unsaved") {
      this.locationLabel = rawLabel ? rawLabel : "Home";
      this.isSavedAddress = true;
    } else {
      this.locationLabel = "Unsaved";
      this.isSavedAddress = false;
    }
    if (addr.area && addr.area.trim()) {
      this.displayLocationName = addr.area.trim();
    } else if (addr.address && addr.address.trim()) {
      this.displayLocationName = addr.address.split(",")[0].trim() || "Athani";
    } else {
      this.displayLocationName = "Select Location";
    }
    const detailedParts = [
      addr.house_no,
      addr.building_name,
      addr.landmark ? "Near " + addr.landmark : "",
      addr.address
    ].filter(Boolean);
    if (detailedParts.length > 1) {
      this.displayFullAddress = detailedParts.join(", ");
    } else if (addr.address && addr.address.trim()) {
      this.displayFullAddress = addr.address.trim();
    } else {
      this.displayFullAddress = this.displayLocationName;
    }
    if (addr.city && addr.city.trim()) {
      const cityChanged = this.currentCity !== addr.city.trim();
      this.currentCity = addr.city.trim();
      if (cityChanged) {
        this.loadBanners();
      }
    }
    if (addr.lat && addr.lng) {
      this.currentCoords = { lat: Number(addr.lat), lng: Number(addr.lng) };
    }
  }
  /**
   * Fetch primary address from backend API (returns null if none)
   */
  fetchPrimaryAddressFromApi() {
    return new Promise((resolve) => {
      this.locationService.getPrimaryAddress(this.token).subscribe({
        next: (res) => {
          resolve((res == null ? void 0 : res.success) && (res == null ? void 0 : res.data) ? res.data : null);
        },
        error: () => resolve(null)
      });
    });
  }
  /**
   * GPS-based location check (only used when no primary address exists)
   */
  runLocationCheck() {
    return __async(this, null, function* () {
      const locResult = yield this.locationService.getDetailedPosition();
      if (locResult.status === "permission_denied") {
        this.isLocationPermissionDenied = true;
        this.isGpsDisabled = false;
        this.locationCheckPhase = "permission_needed";
        this.isCheckingLocation = true;
        return;
      }
      if (locResult.status === "gps_disabled") {
        this.isLocationPermissionDenied = false;
        this.isGpsDisabled = true;
        this.locationCheckPhase = "gps_disabled";
        this.isCheckingLocation = true;
        return;
      }
      if (locResult.status === "ok" && locResult.coords) {
        this.isLocationPermissionDenied = false;
        this.isGpsDisabled = false;
        this.locationCheckPhase = "validating";
        const { latitude, longitude } = locResult.coords;
        this.currentCoords = { lat: latitude, lng: longitude };
        const area = locResult.city || (locResult.address ? locResult.address.split(",")[0] : "Athani");
        const address = locResult.address || locResult.city || "Athani";
        this.applyLocationDetails({
          lat: latitude,
          lng: longitude,
          label: "",
          // Empty label signals 'Unsaved'
          area,
          address
        });
        yield this.evaluateServiceArea(latitude, longitude);
      }
    });
  }
  /**
   * Validate coordinates against backend service areas
   */
  evaluateServiceArea(lat, lng) {
    return new Promise((resolve) => {
      this.locationService.checkLocationInServiceArea(lat, lng).subscribe({
        next: (res) => {
          var _a;
          this.isCheckingLocation = false;
          this.locationCheckPhase = "done";
          if (res == null ? void 0 : res.success) {
            if (res.inServiceArea) {
              this.isOutOfServiceArea = false;
              this.nearestServiceArea = null;
              if ((_a = res.area) == null ? void 0 : _a.isOffline) {
                this.isAreaClosed = true;
                this.closedAreaCity = res.area.cityName || this.displayLocationName || "Athani";
                this.areaClosureMessage = res.area.offlineMessage || "Operations in this city are temporarily offline. We will resume shortly.";
              } else {
                this.isAreaClosed = false;
              }
            } else {
              this.isOutOfServiceArea = true;
              this.isAreaClosed = false;
              this.nearestServiceArea = res.nearestArea || null;
            }
          }
          resolve();
        },
        error: (err) => {
          console.warn("Could not check service area:", err);
          this.isCheckingLocation = false;
          this.locationCheckPhase = "done";
          resolve();
        }
      });
    });
  }
  /**
   * Action button in popup: request permission and immediately re-evaluate
   */
  requestLocationPermissionAndPosition() {
    return __async(this, null, function* () {
      this.locationCheckPhase = "detecting";
      try {
        const perm = yield this.locationService.requestLocationPermission();
        if (perm.location === "granted") {
          this.isLocationPermissionDenied = false;
          yield this.runLocationCheck();
        } else {
          this.isLocationPermissionDenied = true;
          this.locationCheckPhase = "permission_needed";
        }
      } catch (e) {
        yield this.runLocationCheck();
      }
    });
  }
  recheckLocationAndServiceArea() {
    return __async(this, null, function* () {
      yield this.startLocationVerificationFlow(true);
    });
  }
  /**
   * Continuous background monitoring: appStateChange, active interval, & watchPosition
   */
  startContinuousLocationMonitoring() {
    if (!this.appStateListener) {
      try {
        this.appStateListener = App.addListener("appStateChange", (state) => __async(this, null, function* () {
          if (state.isActive) {
            console.log("\u{1F4F1} App resumed, re-evaluating location status...");
            if (this.isLocationPermissionDenied || this.isGpsDisabled || this.isCheckingLocation) {
              yield this.runLocationCheck();
            }
          }
        }));
      } catch (e) {
        console.warn("AppState listener unavailable:", e);
      }
    }
    if (!this.locationMonitorTimer) {
      this.locationMonitorTimer = setInterval(() => __async(this, null, function* () {
        if (this.isLocationPermissionDenied || this.isGpsDisabled || this.isCheckingLocation) {
          const perm = yield this.locationService.checkLocationPermission();
          if (perm.location === "granted") {
            yield this.runLocationCheck();
          }
        }
      }), 2500);
    }
    if (!this.locationWatchId) {
      this.locationService.watchPosition((position, err) => {
        if (position == null ? void 0 : position.coords) {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          if (this.isLocationPermissionDenied || this.isGpsDisabled) {
            this.isLocationPermissionDenied = false;
            this.isGpsDisabled = false;
          }
          if (this.isOutOfServiceArea || !this.currentCoords) {
            this.currentCoords = { lat, lng };
            this.evaluateServiceArea(lat, lng);
          }
        }
      }).then((id) => {
        if (id)
          this.locationWatchId = id;
      });
    }
  }
  stopContinuousLocationMonitoring() {
    var _a, _b;
    if (this.locationMonitorTimer) {
      clearInterval(this.locationMonitorTimer);
      this.locationMonitorTimer = null;
    }
    if (this.locationWatchId) {
      this.locationService.clearWatch(this.locationWatchId);
      this.locationWatchId = null;
    }
    if (this.appStateListener) {
      (_b = (_a = this.appStateListener).remove) == null ? void 0 : _b.call(_a);
      this.appStateListener = null;
    }
  }
  onScroll(event) {
    var _a;
    const scrollTop = ((_a = event == null ? void 0 : event.detail) == null ? void 0 : _a.scrollTop) || 0;
    if (!this.cachedBannerHeight) {
      const heroEl = document.querySelector(".home-top-hero-slider");
      if (heroEl && heroEl.offsetHeight > 0) {
        this.cachedBannerHeight = heroEl.offsetHeight;
      }
    }
    const hasBanners = Boolean(this.banners && this.banners.length > 0);
    const bannerHeight = hasBanners ? this.cachedBannerHeight || 240 : 0;
    const headerHeight = 64;
    const endFade = bannerHeight > 0 ? Math.max(100, bannerHeight - headerHeight) : 20;
    const startFade = bannerHeight > 0 ? Math.max(20, Math.round(endFade * 0.25)) : 0;
    let newOpacity = 0;
    let pastBanner = false;
    if (scrollTop <= startFade) {
      newOpacity = 0;
      pastBanner = false;
    } else if (scrollTop >= endFade) {
      newOpacity = 1;
      pastBanner = true;
    } else {
      const raw = (scrollTop - startFade) / (endFade - startFade);
      newOpacity = Math.round(raw * 20) / 20;
      pastBanner = false;
    }
    if (this.headerOpacity !== newOpacity || this.isPastBanner !== pastBanner) {
      this.headerOpacity = newOpacity;
      this.isPastBanner = pastBanner;
      this.isScrolled = pastBanner;
      this.headerBg = pastBanner ? "#ffffff" : `rgba(255, 255, 255, ${newOpacity})`;
    }
  }
  handleRefresh(event) {
    this.cachedBannerHeight = 0;
    this.startLocationVerificationFlow(false);
    if (this.token) {
      this.loadUserProfile();
      this.loadHomeData();
      this.loadActiveOrders();
    } else {
      this.loadHomeData();
    }
    setTimeout(() => {
      event.target.complete();
    }, 800);
  }
  loadUserProfile() {
    this.profileService.getProfileData(this.token).subscribe({
      next: (res) => {
        const user = (res == null ? void 0 : res.user) || (res == null ? void 0 : res.data) || res || {};
        const name = user.first_name || user.name || "";
        this.userInitials = name.charAt(0).toUpperCase() || "P";
        this.profileAvatar = user.profile_image || "";
      },
      error: () => {
      }
    });
  }
  /**
   * Loads customer promotional banners based on placement tag and user city.
   * 'hometop' -> top sliding banners
   * 'homedown' -> below the services banners
   */
  loadBanners() {
    var _a;
    const city = this.currentCity || ((_a = this.nearestServiceArea) == null ? void 0 : _a.cityName) || "";
    this.isLoadingHeroBanners = true;
    this.isLoadingBottomBanners = true;
    this.commonService.getActiveBanners("hometop", city).subscribe({
      next: (res) => {
        const items = (res == null ? void 0 : res.data) || res || [];
        this.banners = Array.isArray(items) ? items : [];
        this.isLoadingHeroBanners = false;
      },
      error: (err) => {
        console.warn("Could not load hometop banners:", (err == null ? void 0 : err.message) || err);
        this.banners = [];
        this.isLoadingHeroBanners = false;
      }
    });
    this.commonService.getActiveBanners("homedown", city).subscribe({
      next: (res) => {
        const items = (res == null ? void 0 : res.data) || res || [];
        this.bottomBanners = Array.isArray(items) ? items : [];
        this.isLoadingBottomBanners = false;
      },
      error: (err) => {
        console.warn("Could not load homedown banners:", (err == null ? void 0 : err.message) || err);
        this.bottomBanners = [];
        this.isLoadingBottomBanners = false;
      }
    });
  }
  loadHomeData() {
    this.isLoadingServices = true;
    this.hasHomeDataError = false;
    this.loadBanners();
    this.commonService.getHomeData(this.token).subscribe({
      next: (res) => {
        const data = (res == null ? void 0 : res.data) || res || {};
        const services = (data == null ? void 0 : data.services) || (Array.isArray(data) ? data : []);
        if (Array.isArray(services) && services.length > 0) {
          const active = services.filter((s) => s.status === "active" || !s.status);
          if (active.length > 0) {
            this.allServices = active;
            this.hasHomeDataError = false;
          }
        }
        this.isLoadingServices = false;
      },
      error: () => {
        this.locationService.getData().subscribe({
          next: (fallbackRes) => {
            const fallbackData = (fallbackRes == null ? void 0 : fallbackRes.data) || fallbackRes || [];
            if (Array.isArray(fallbackData) && fallbackData.length > 0) {
              const active = fallbackData.filter((s) => s.status === "active" || !s.status);
              if (active.length > 0) {
                this.allServices = active;
                this.hasHomeDataError = false;
              }
            }
            this.isLoadingServices = false;
            if (this.allServices.length === 0) {
              this.hasHomeDataError = true;
            }
          },
          error: () => {
            this.isLoadingServices = false;
            if (this.allServices.length === 0) {
              this.allServices = [
                {
                  id: 1,
                  title: "Pintu Grocery",
                  subtitle: "10-15 Min Instant Delivery",
                  offers: "\u26A1 10-15 MINS",
                  img: "",
                  category: "grocery",
                  route: "/layout/grocery-layout"
                },
                {
                  id: 2,
                  title: "Daily Commute",
                  subtitle: "Bike, Auto & Cabs",
                  offers: "ZERO SURGE",
                  img: "",
                  category: "rides",
                  route: "/layout/rides"
                },
                {
                  id: 3,
                  title: "Medicines & Lab Tests",
                  subtitle: "Genuine Meds & Blood Tests",
                  offers: "FLAT 15% OFF",
                  img: "",
                  category: "pharmacy",
                  route: "/layout/pharmacy"
                }
              ];
              this.hasHomeDataError = true;
            }
          }
        });
      }
    });
  }
  retryHomeData() {
    this.hasHomeDataError = false;
    this.loadHomeData();
  }
  loadActiveOrders() {
    this.commonService.getActiveOrders(this.token).subscribe({
      next: (res) => {
        this.orders = (res == null ? void 0 : res.data) || (Array.isArray(res) ? res : []);
      },
      error: () => {
        this.orders = [];
      }
    });
  }
  /**
   * User-defined count-based Bento layout rules:
   * - 1 service  -> 100% width (wide)
   * - 2 services -> 50% width 2 in inline (normal)
   * - > 2 services -> dynamic bento mosaic
   */
  getMosaicTileType(index, total) {
    if (total === 1) {
      return "mosaic-tile-wide";
    }
    if (total === 2) {
      return "mosaic-tile-normal";
    }
    if (total === 3) {
      return index === 0 ? "mosaic-tile-tall" : "mosaic-tile-normal";
    }
    if (total === 4) {
      if (index === 0)
        return "mosaic-tile-tall";
      if (index === 1 || index === 2)
        return "mosaic-tile-normal";
      return "mosaic-tile-wide";
    }
    if (total === 5) {
      return index === 0 ? "mosaic-tile-tall" : "mosaic-tile-normal";
    }
    if (total === 6) {
      if (index === 0)
        return "mosaic-tile-tall";
      if (index === 5)
        return "mosaic-tile-wide";
      return "mosaic-tile-normal";
    }
    const mod = index % 7;
    if (mod === 0)
      return "mosaic-tile-tall";
    if (mod === 3 || mod === 6)
      return "mosaic-tile-wide";
    return "mosaic-tile-normal";
  }
  isImageValid(service) {
    if (!(service == null ? void 0 : service.img))
      return false;
    const img = String(service.img).trim();
    if (!img || img.includes("example.com") || img === "img.jpg" || img === "null" || img === "undefined") {
      return false;
    }
    return true;
  }
  getServiceImgUrl(service) {
    if (!(service == null ? void 0 : service.img))
      return "";
    const img = String(service.img).trim();
    if (img.startsWith("http://") || img.startsWith("https://") || img.startsWith("assets/")) {
      return img;
    }
    if (img.startsWith("/")) {
      return `${environment.apiUrl}${img}`;
    }
    return `${environment.apiUrl}/${img}`;
  }
  hasOffer(service) {
    if (!(service == null ? void 0 : service.offers))
      return false;
    const o = String(service.offers).trim().toLowerCase();
    return o !== "" && o !== "nothing" && o !== "null" && o !== "undefined";
  }
  isStatusActive(service) {
    const sub = ((service == null ? void 0 : service.subtitle) || "").toLowerCase();
    const st = ((service == null ? void 0 : service.status) || "").toLowerCase();
    return sub.includes("active") || st === "active" && !(service == null ? void 0 : service.subtitle);
  }
  getOfferTagClass(service) {
    const offer = ((service == null ? void 0 : service.offers) || "").toLowerCase();
    if (offer.includes("%") || offer.includes("off") || offer.includes("save") || offer.includes("cash")) {
      return "tag-discount";
    }
    if (offer.includes("commission") || offer.includes("zero") || offer.includes("surge") || offer.includes("free")) {
      return "tag-highlight";
    }
    return "tag-brand";
  }
  getServiceIcon(service) {
    const title = ((service == null ? void 0 : service.title) || "").toLowerCase();
    const cat = ((service == null ? void 0 : service.category) || "").toLowerCase();
    if (title.includes("property") || title.includes("properties") || cat.includes("property") || cat.includes("real estate")) {
      return "\u{1F3E1}";
    }
    if (title.includes("vehicle") || cat.includes("vehicle")) {
      return "\u{1F697}";
    }
    if (title.includes("grocery") || title.includes("vegitables") || title.includes("vegetable") || title.includes("milk") || cat.includes("daily")) {
      return "\u{1F966}";
    }
    if (title.includes("ride") || title.includes("cab") || title.includes("auto") || title.includes("commute")) {
      return "\u{1F6F5}";
    }
    if (title.includes("food") || title.includes("dineout") || title.includes("restaurant") || title.includes("dining")) {
      return "\u{1F354}";
    }
    if (title.includes("doctor") || title.includes("medicine") || title.includes("lab") || cat.includes("health")) {
      return "\u{1F48A}";
    }
    if (title.includes("laundry")) {
      return "\u{1F9FA}";
    }
    if (title.includes("parcel") || title.includes("goods")) {
      return "\u{1F4E6}";
    }
    if (title.includes("history") || title.includes("order") || title.includes("track")) {
      return "\u{1F4E6}";
    }
    return "\u2728";
  }
  getServiceBg(service) {
    const title = ((service == null ? void 0 : service.title) || "").toLowerCase();
    if (title.includes("property") || title.includes("properties"))
      return "rgba(16, 185, 129, 0.12)";
    if (title.includes("grocery") || title.includes("vegitables"))
      return "rgba(16, 185, 129, 0.12)";
    if (title.includes("ride") || title.includes("cab") || title.includes("auto"))
      return "rgba(59, 130, 246, 0.12)";
    if (title.includes("food") || title.includes("dineout") || title.includes("dining"))
      return "rgba(249, 115, 22, 0.12)";
    if (title.includes("doctor") || title.includes("medicine"))
      return "rgba(168, 85, 247, 0.12)";
    if (title.includes("history") || title.includes("track"))
      return "rgba(160, 0, 226, 0.12)";
    return "rgba(160, 0, 226, 0.1)";
  }
  getServiceCardGradient(service) {
    const title = ((service == null ? void 0 : service.title) || "").toLowerCase();
    if (title.includes("property") || title.includes("properties")) {
      return "linear-gradient(155deg, #ffffff 0%, #f0fdf4 100%)";
    }
    if (title.includes("grocery") || title.includes("vegitables")) {
      return "linear-gradient(155deg, #ffffff 0%, #f0fdf4 100%)";
    }
    if (title.includes("ride") || title.includes("cab") || title.includes("auto")) {
      return "linear-gradient(155deg, #ffffff 0%, #eff6ff 100%)";
    }
    if (title.includes("food") || title.includes("dineout") || title.includes("dining")) {
      return "linear-gradient(155deg, #ffffff 0%, #fff7ed 100%)";
    }
    if (title.includes("doctor") || title.includes("medicine")) {
      return "linear-gradient(155deg, #ffffff 0%, #fdf4ff 100%)";
    }
    if (title.includes("history") || title.includes("track")) {
      return "linear-gradient(155deg, #ffffff 0%, #faf5ff 100%)";
    }
    return "#ffffff";
  }
  navigateToService(service) {
    if (!service)
      return;
    const route = (service.route || "").trim();
    if (route.startsWith("http://") || route.startsWith("https://")) {
      window.open(route, "_system");
      return;
    }
    if (route === "grocery" || route === "/layout/grocery" || route === "/layout/grocery-layout" || route === "/grocery") {
      this.router.navigate(["/layout/grocery-layout"]);
      return;
    }
    if (route === "rides" || route === "ride" || route === "cab" || route === "/layout/rides" || route === "/layout/ride") {
      this.router.navigate(["/layout/rides"]);
      return;
    }
    if (route === "food" || route === "dineout" || route === "/layout/dineout-layout") {
      this.router.navigate(["/layout/dineout-layout"]);
      return;
    }
    if (route === "history" || route === "/layout/history") {
      this.router.navigate(["/layout/history"]);
      return;
    }
    if (route === "pharmacy" || route === "medicine" || route === "medicines" || route === "lab" || route === "/layout/pharmacy" || route === "/pharmacy") {
      this.router.navigate(["/layout/pharmacy"]);
      return;
    }
    if (route.startsWith("/")) {
      this.router.navigate([route]);
    } else if (route) {
      this.router.navigate([`/layout/${route}`]);
    } else {
      const title = (service.title || "").toLowerCase();
      if (title.includes("grocery") || title.includes("vegitables") || title.includes("milk")) {
        this.router.navigate(["/layout/grocery-layout"]);
      } else if (title.includes("ride") || title.includes("cab") || title.includes("auto") || title.includes("commute")) {
        this.router.navigate(["/layout/rides"]);
      } else if (title.includes("dineout") || title.includes("food") || title.includes("dining")) {
        this.router.navigate(["/layout/dineout-layout"]);
      } else if (title.includes("history") || title.includes("order") || title.includes("track")) {
        this.router.navigate(["/layout/history"]);
      } else if (title.includes("property") || title.includes("properties") || title.includes("vehicle")) {
        this.router.navigate(["/layout/property"]);
      } else if (title.includes("medicine") || title.includes("pharmacy") || title.includes("lab") || title.includes("test") || title.includes("health") || title.includes("doctor")) {
        this.router.navigate(["/layout/pharmacy"]);
      }
    }
  }
  navigateToBanner(banner) {
    if (!banner)
      return;
    const route = (banner.route || "").trim();
    if (!route)
      return;
    if (route.startsWith("http://") || route.startsWith("https://")) {
      window.open(route, "_system");
      return;
    }
    if (route === "pharmacy" || route === "medicine" || route === "medicines" || route === "lab" || route === "/layout/pharmacy" || route === "/pharmacy") {
      this.router.navigate(["/layout/pharmacy"]);
      return;
    }
    if (route === "grocery" || route === "/layout/grocery" || route === "/layout/grocery-layout" || route === "/grocery") {
      this.router.navigate(["/layout/grocery-layout"]);
      return;
    }
    if (route === "rides" || route === "ride" || route === "cab" || route === "/layout/rides" || route === "/layout/ride") {
      this.router.navigate(["/layout/rides"]);
      return;
    }
    if (route === "food" || route === "dineout" || route === "/layout/dineout-layout") {
      this.router.navigate(["/layout/dineout-layout"]);
      return;
    }
    if (route.startsWith("/")) {
      this.router.navigate([route]);
    } else {
      this.router.navigate([`/layout/${route}`]);
    }
  }
  getBannerImgUrl(banner) {
    if (!(banner == null ? void 0 : banner.img))
      return "";
    const img = String(banner.img).trim();
    if (img.startsWith("http://") || img.startsWith("https://") || img.startsWith("assets/")) {
      return img;
    }
    if (img.startsWith("/")) {
      return `${environment.apiUrl}${img}`;
    }
    return `${environment.apiUrl}/${img}`;
  }
  isBannerImageValid(banner) {
    if (!(banner == null ? void 0 : banner.img) || banner.hasImgError)
      return false;
    const img = String(banner.img).trim();
    if (!img || img.includes("example.com") || img === "null" || img === "undefined") {
      return false;
    }
    return true;
  }
  onBannerImgError(banner) {
    if (banner) {
      banner.hasImgError = true;
    }
  }
  openLocation() {
    this.router.navigate(["/layout/address-list"], {
      state: { data: "home" }
    });
  }
  goToProfile() {
    this.router.navigate(["/layout/profile"]);
  }
  handleActiveOrderBannerClick() {
    if (!this.orders || this.orders.length === 0)
      return;
    if (this.orders.length === 1) {
      this.goToOrderDetails(this.orders[0]);
    } else {
      this.isMultiOrderModalOpen = true;
    }
  }
  closeMultiOrderModal() {
    this.isMultiOrderModalOpen = false;
  }
  selectActiveOrder(order) {
    this.closeMultiOrderModal();
    this.goToOrderDetails(order);
  }
  getActiveOrderHeadline(order) {
    if (!order)
      return "Your order is active";
    const status = String(order.status || order.orderStatus || "").toLowerCase();
    if (status.includes("deliver") && (status.includes("out") || status.includes("way"))) {
      return "Out for delivery \u2022 Arriving soon";
    }
    if (status.includes("prep") || status.includes("pack")) {
      return "Order is being packed";
    }
    if (status.includes("accept") || status.includes("confirm")) {
      return "Order confirmed \u2022 In progress";
    }
    if (status.includes("pickup") || status.includes("picked")) {
      return "Picked up \u2022 On the way";
    }
    return "Your delivery is arriving soon";
  }
  getOrderIcon(order) {
    const serviceType = String((order == null ? void 0 : order.serviceType) || (order == null ? void 0 : order.service) || (order == null ? void 0 : order.category) || "").toLowerCase();
    if (serviceType.includes("ride") || serviceType.includes("cab"))
      return "car-outline";
    if (serviceType.includes("food") || serviceType.includes("dine"))
      return "restaurant-outline";
    return "bag-handle-outline";
  }
  formatOrderTime(order) {
    const dt = (order == null ? void 0 : order.createdAt) || (order == null ? void 0 : order.orderDate) || (order == null ? void 0 : order.date);
    if (!dt)
      return "Just now";
    try {
      const date = new Date(dt);
      return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    } catch {
      return "Today";
    }
  }
  goToOrderDetails(orderOrId) {
    if (!orderOrId) {
      this.router.navigate(["/layout/history"]);
      return;
    }
    const order = typeof orderOrId === "object" ? orderOrId : { id: orderOrId, orderId: orderOrId };
    const id = order.id || order.orderId;
    const serviceType = String(order.serviceType || order.service || order.category || "").toLowerCase();
    if (serviceType.includes("ride") || serviceType.includes("cab")) {
      this.router.navigate(["/layout/rides/tracking"], { queryParams: { orderId: id } });
    } else if (serviceType.includes("food") || serviceType.includes("dine")) {
      this.router.navigate([`/layout/dineout-layout/dineout-track/${id}`]);
    } else if (id) {
      this.router.navigate([`/layout/grocery-layout/grocery-order-details/${id}`]);
    } else {
      this.router.navigate(["/layout/history"]);
    }
  }
};
_HomePage.\u0275fac = function HomePage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _HomePage)(\u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(AuthService), \u0275\u0275directiveInject(LocationService), \u0275\u0275directiveInject(ProfileService), \u0275\u0275directiveInject(CommonService), \u0275\u0275directiveInject(ToastController));
};
_HomePage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _HomePage, selectors: [["app-home"]], decls: 33, vars: 18, consts: [[1, "location-checking-backdrop", "animate__animated", "animate__fadeIn"], [1, "customer-header", "ion-no-border"], [1, "header-inner"], ["role", "button", "tabindex", "0", 1, "location-pill-btn", 3, "click"], [1, "location-icon-box"], ["name", "location"], [1, "location-text-col"], [1, "location-title-row"], [1, "location-name"], ["title", "Location Not Serviceable", 1, "location-status-dot", "red"], ["title", "Saved Address", 1, "location-status-dot", "green"], ["title", "Unsaved Location", 1, "location-status-dot", "orange"], ["name", "chevron-down", 1, "chevron-icon"], [1, "location-sub-row"], [1, "header-actions"], ["role", "button", "tabindex", "0", "title", "My Profile", 1, "customer-avatar-btn", 3, "click"], ["alt", "Profile", 3, "src"], [1, "avatar-initial"], [1, "home-page-content", 3, "fullscreen"], ["mode", "md", "slot", "fixed", 1, "custom-refresher", 3, "ionRefresh"], ["mode", "md", "pullingIcon", "arrow-down-outline", "refreshingSpinner", "crescent"], [1, "home-body-container"], [1, "service-alert-banner", "permission-banner", "animate__animated", "animate__fadeIn"], [1, "home-centered-status-wrapper", "animate__animated", "animate__fadeIn"], [1, "bottom-nav-spacer"], ["slot", "fixed", "role", "button", "tabindex", "0", 1, "docked-active-orders-banner"], [1, "active-orders-sheet-modal", 3, "didDismiss", "isOpen", "initialBreakpoint", "breakpoints"], [1, "location-checking-card", "animate__animated", "animate__zoomIn"], [1, "loc-badge-wrap", "pulse-anim"], [1, "radar-ring", "r1"], [1, "radar-ring", "r2"], [1, "loc-badge-circle"], [1, "loc-modal-title"], [1, "loc-modal-desc"], [1, "loc-progress-bar"], [1, "loc-progress-indicator"], [1, "loc-modal-footnote"], ["name", "shield-checkmark-outline"], [1, "loc-badge-wrap", "warning-badge"], [1, "loc-badge-circle", "warning"], ["name", "alert-circle"], ["type", "button", 1, "btn-loc-resolve", 3, "click"], [1, "loc-monitoring-pill"], [1, "pulse-dot-amber"], [1, "loc-badge-circle", "rose"], ["name", "locate"], ["name", "refresh"], [1, "pulse-dot-rose"], [1, "location-full-address", "text-truncate"], ["alt", "Profile", 3, "error", "src"], [1, "home-top-hero-slider", "hero-skeleton-section"], [1, "home-top-hero-slider"], [1, "hero-banner-skeleton-card"], ["animated", "", 1, "hero-banner-skeleton-img"], ["slides-per-view", "1", "pagination", "true", "autoplay-delay", "3800", "autoplay-disable-on-interaction", "false", "loop", "true", 1, "hero-swiper"], ["role", "button", "tabindex", "0", 1, "hero-banner-card", 3, "click"], [1, "hero-banner-img", 3, "error", "src", "alt"], [1, "alert-icon-box", "warning"], ["name", "alert-circle-outline"], [1, "alert-text-col"], [1, "alert-badge", "warning"], [1, "status-pulse-dot", "amber"], [1, "alert-title"], [1, "alert-desc"], ["type", "button", 1, "btn-alert-action", "enable-btn", 3, "click"], ["name", "chevron-forward"], [1, "centered-status-card", "closed-card"], [1, "centered-status-card", "out-of-area-card"], [1, "status-graphic-wrapper", "closed"], [1, "graphic-glow-ring"], [1, "graphic-icon-box"], ["name", "moon-outline"], [1, "status-badge", "closed"], [1, "status-pulse-dot", "red"], [1, "status-title"], [1, "status-desc"], [1, "status-actions-group"], ["type", "button", 1, "btn-primary-action", 3, "click"], ["name", "map-outline"], ["type", "button", "title", "Re-check status", 1, "btn-secondary-action", 3, "click"], ["name", "refresh-outline"], [1, "status-graphic-wrapper", "out"], ["name", "location-outline"], [1, "status-badge", "out"], [1, "nearest-area-box"], [1, "nearest-tip-box"], ["type", "button", "title", "Recheck Location", 1, "btn-secondary-action", 3, "click"], [1, "nearest-title"], ["name", "navigate-circle-outline"], [1, "nearest-distance-badge"], [1, "nearest-instruction"], [1, "services-mosaic-section"], [1, "section-title-row"], [1, "d-flex", "align-items-center", "gap-2"], [1, "sparkle-icon"], [1, "section-heading"], [1, "services-mosaic-grid", "bento-grid"], [1, "services-error-card"], [1, "services-mosaic-grid", 3, "ngClass"], [1, "home-bottom-banners-section", "bottom-skeleton-section"], [1, "home-bottom-banners-section"], [1, "mosaic-tile", "mosaic-tile-tall", "skeleton-card"], [1, "skeleton-corner-tag"], ["animated", "", 2, "width", "110px", "height", "20px", "border-radius", "6px", "margin", "26px 0 6px 0"], ["animated", "", 2, "width", "130px", "height", "14px", "border-radius", "4px"], ["animated", "", 1, "skeleton-corner-circle", "tall"], [1, "mosaic-tile", "mosaic-tile-normal", "skeleton-card"], ["animated", "", 2, "width", "80px", "height", "16px", "border-radius", "6px", "margin", "24px 0 4px 0"], ["animated", "", 2, "width", "55px", "height", "12px", "border-radius", "4px"], ["animated", "", 1, "skeleton-corner-circle", "normal"], [1, "mosaic-tile", "mosaic-tile-wide", "skeleton-card"], ["animated", "", 2, "width", "130px", "height", "18px", "border-radius", "6px", "margin", "24px 0 6px 0"], ["animated", "", 2, "width", "100px", "height", "13px", "border-radius", "4px"], ["animated", "", 1, "skeleton-corner-circle", "wide"], [1, "error-icon-box"], ["name", "cloud-offline-outline"], [1, "error-title"], [1, "error-desc"], ["type", "button", 1, "btn-retry-services", 3, "click"], ["role", "button", "tabindex", "0", 1, "mosaic-tile", 3, "ngClass", "background"], ["role", "button", "tabindex", "0", 1, "mosaic-tile", 3, "click", "ngClass"], [1, "service-corner-tag", 3, "ngClass"], [1, "tall-tile-inner", 3, "has-corner-tag"], [1, "tall-tile-inner"], [1, "tile-header-area"], [1, "tile-title-tall"], [1, "tile-subtitle-tall"], [1, "tile-center-art-tall"], [1, "service-art-img-tall-center", 3, "src", "alt"], [1, "service-art-fallback", "tall-fallback", 3, "background"], [1, "tile-action-row"], [1, "action-btn-text"], [1, "arrow-circle-btn"], ["name", "arrow-forward"], [1, "service-art-img-tall-center", 3, "error", "src", "alt"], [1, "service-art-fallback", "tall-fallback"], [1, "fallback-emoji"], [1, "wide-tile-inner"], [1, "wide-left-content"], [1, "tile-title-wide"], [1, "tile-subtitle-wide"], [1, "wide-cta-chip"], [1, "tile-corner-art", "wide-corner-art"], [1, "service-art-img-wide", 3, "src", "alt"], [1, "service-art-fallback", "wide-fallback", 3, "background"], [1, "service-art-img-wide", 3, "error", "src", "alt"], [1, "service-art-fallback", "wide-fallback"], [1, "normal-tile-inner"], [1, "normal-left-info"], [1, "tile-title-normal"], [1, "tile-subtitle-normal"], [1, "arrow-circle-mini"], [1, "tile-corner-art", "normal-corner-art"], [1, "service-art-img-normal", 3, "src", "alt"], [1, "service-art-fallback", "normal-fallback", 3, "background"], [1, "service-art-img-normal", 3, "error", "src", "alt"], [1, "service-art-fallback", "normal-fallback"], [1, "fallback-emoji-small"], [1, "bottom-banner-skeleton-card"], ["animated", "", 1, "bottom-banner-skeleton-img"], ["role", "button", "tabindex", "0", 1, "bottom-promo-card"], ["role", "button", "tabindex", "0", 1, "bottom-promo-card", 3, "click"], [1, "banner-full-img", 3, "error", "src", "alt"], ["slot", "fixed", "role", "button", "tabindex", "0", 1, "docked-active-orders-banner", 3, "click"], [1, "banner-inner-card"], [1, "banner-left"], [1, "live-pulse-dot"], [1, "order-text-col"], [1, "order-badge-row"], [1, "badge-text"], [1, "order-id-chip"], [1, "order-title-line"], ["type", "button", "aria-label", "Track Active Orders", 1, "btn-docked-track"], [1, "sheet-container"], [1, "sheet-header"], [1, "sheet-handle-bar"], [1, "sheet-title-row"], [1, "sheet-title-col"], [1, "sheet-title"], [1, "sheet-sub"], ["type", "button", "aria-label", "Close", 1, "sheet-close-btn", 3, "click"], ["name", "close-outline"], [1, "orders-list-content"], ["role", "button", "tabindex", "0", 1, "active-order-item-card"], ["role", "button", "tabindex", "0", 1, "active-order-item-card", 3, "click"], [1, "item-card-left"], [1, "order-icon-box"], [3, "name"], [1, "order-details-col"], [1, "order-meta-line"], [1, "order-number"], [1, "order-time"], [1, "order-status-badge"], [1, "mini-pulse-dot"], [1, "order-amount"], [1, "item-card-right"], ["type", "button", 1, "btn-track-item"]], template: function HomePage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275template(0, HomePage_Conditional_0_Template, 6, 4, "div", 0);
    \u0275\u0275elementStart(1, "ion-header", 1)(2, "ion-toolbar")(3, "div", 2)(4, "div", 3);
    \u0275\u0275listener("click", function HomePage_Template_div_click_4_listener() {
      return ctx.openLocation();
    });
    \u0275\u0275elementStart(5, "div", 4);
    \u0275\u0275element(6, "ion-icon", 5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "div", 6)(8, "div", 7)(9, "span", 8);
    \u0275\u0275text(10);
    \u0275\u0275elementEnd();
    \u0275\u0275template(11, HomePage_Conditional_11_Template, 1, 0, "span", 9)(12, HomePage_Conditional_12_Template, 1, 0, "span", 10)(13, HomePage_Conditional_13_Template, 1, 0, "span", 11);
    \u0275\u0275element(14, "ion-icon", 12);
    \u0275\u0275elementEnd();
    \u0275\u0275template(15, HomePage_Conditional_15_Template, 3, 1, "div", 13);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(16, "div", 14)(17, "div", 15);
    \u0275\u0275listener("click", function HomePage_Template_div_click_17_listener() {
      return ctx.goToProfile();
    });
    \u0275\u0275template(18, HomePage_Conditional_18_Template, 1, 1, "img", 16)(19, HomePage_Conditional_19_Template, 2, 1, "div", 17);
    \u0275\u0275elementEnd()()()()();
    \u0275\u0275elementStart(20, "ion-content", 18)(21, "ion-refresher", 19);
    \u0275\u0275listener("ionRefresh", function HomePage_Template_ion_refresher_ionRefresh_21_listener($event) {
      return ctx.handleRefresh($event);
    });
    \u0275\u0275element(22, "ion-refresher-content", 20);
    \u0275\u0275elementEnd();
    \u0275\u0275template(23, HomePage_Conditional_23_Template, 2, 1);
    \u0275\u0275elementStart(24, "main", 21);
    \u0275\u0275template(25, HomePage_Conditional_25_Template, 16, 0, "section", 22)(26, HomePage_Conditional_26_Template, 3, 1, "div", 23)(27, HomePage_Conditional_27_Template, 12, 2)(28, HomePage_Conditional_28_Template, 1, 0, "app-footer");
    \u0275\u0275element(29, "div", 24);
    \u0275\u0275elementEnd();
    \u0275\u0275template(30, HomePage_Conditional_30_Template, 15, 4, "aside", 25);
    \u0275\u0275elementStart(31, "ion-modal", 26);
    \u0275\u0275listener("didDismiss", function HomePage_Template_ion_modal_didDismiss_31_listener() {
      return ctx.closeMultiOrderModal();
    });
    \u0275\u0275template(32, HomePage_ng_template_32_Template, 14, 0, "ng-template");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275conditional(ctx.isCheckingLocation ? 0 : -1);
    \u0275\u0275advance(10);
    \u0275\u0275textInterpolate(ctx.displayLocationName);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.isOutOfServiceArea ? 11 : ctx.isSavedAddress ? 12 : 13);
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx.displayFullAddress ? 15 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx.profileAvatar ? 18 : 19);
    \u0275\u0275advance(2);
    \u0275\u0275property("fullscreen", false);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(!ctx.isOfflineOrOutOfServiceArea ? 23 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx.isLocationPermissionDenied ? 25 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(!ctx.isLocationPermissionDenied && ctx.isOfflineOrOutOfServiceArea ? 26 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(!ctx.isOfflineOrOutOfServiceArea ? 27 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(!ctx.isOfflineOrOutOfServiceArea ? 28 : -1);
    \u0275\u0275advance();
    \u0275\u0275classProp("has-active-orders", ctx.orders && ctx.orders.length > 0);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.orders && ctx.orders.length > 0 ? 30 : -1);
    \u0275\u0275advance();
    \u0275\u0275property("isOpen", ctx.isMultiOrderModalOpen)("initialBreakpoint", 0.55)("breakpoints", \u0275\u0275pureFunction0(17, _c0));
  }
}, dependencies: [
  CommonModule,
  NgClass,
  FormsModule,
  IonHeader,
  IonToolbar,
  IonContent,
  IonRefresher,
  IonRefresherContent,
  IonSkeletonText,
  IonIcon,
  IonModal,
  FooterComponent
], styles: ['@charset "UTF-8";\n\n\n\n[_nghost-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  width: 100%;\n  height: 100%;\n}\n.home-page-content[_ngcontent-%COMP%] {\n  --background: #f8fafc;\n  --overflow: hidden auto;\n  overflow-x: hidden;\n  width: 100%;\n  position: relative;\n}\n.home-page-content[_ngcontent-%COMP%]::part(scroll) {\n  transform: none !important;\n}\n.custom-refresher[_ngcontent-%COMP%] {\n  z-index: 150;\n}\n.custom-refresher[_ngcontent-%COMP%]   ion-refresher-content[_ngcontent-%COMP%] {\n  --color: var(--app-theme-color, #a000e2);\n}\n.custom-refresher[_ngcontent-%COMP%]   .refresher-pulling-icon[_ngcontent-%COMP%], \n.custom-refresher[_ngcontent-%COMP%]   .refresher-refreshing-icon[_ngcontent-%COMP%] {\n  border-radius: 50% !important;\n  background: #ffffff !important;\n  box-shadow: 0 4px 14px rgba(0, 0, 0, 0.15) !important;\n  border: 1px solid rgba(160, 0, 226, 0.15) !important;\n}\n.customer-header[_ngcontent-%COMP%] {\n  --background: #ffffff;\n  background: #ffffff;\n  border-bottom: 1px solid #f1f5f9;\n  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.04);\n  z-index: 100;\n  padding: 0 !important;\n  margin: 0 !important;\n  --ion-safe-area-top: 0px;\n}\n.customer-header[_ngcontent-%COMP%]   ion-toolbar[_ngcontent-%COMP%] {\n  --background: #ffffff;\n  background: #ffffff;\n  --padding-start: 16px;\n  --padding-end: 16px;\n  --padding-top: env(safe-area-inset-top, 0px);\n  --padding-bottom: 4px;\n  --min-height: 48px;\n  --border-width: 0;\n}\n.header-inner[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  width: 100%;\n}\n.location-pill-btn[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  cursor: pointer;\n  max-width: 80%;\n  transition: transform 0.15s ease;\n}\n.location-pill-btn[_ngcontent-%COMP%]:active {\n  transform: scale(0.97);\n}\n.location-pill-btn[_ngcontent-%COMP%]   .location-icon-box[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 38px;\n  border-radius: 12px;\n  background:\n    linear-gradient(\n      135deg,\n      rgba(160, 0, 226, 0.12) 0%,\n      rgba(160, 0, 226, 0.03) 100%),\n    #ffffff;\n  border: 1px solid rgba(160, 0, 226, 0.2);\n  color: #a000e2;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 20px;\n  flex-shrink: 0;\n  box-shadow: 0 2px 8px rgba(160, 0, 226, 0.08);\n}\n.location-pill-btn[_ngcontent-%COMP%]   .location-text-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  overflow: hidden;\n  gap: 1px;\n}\n.location-pill-btn[_ngcontent-%COMP%]   .location-text-col[_ngcontent-%COMP%]   .location-title-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  min-width: 0;\n}\n.location-pill-btn[_ngcontent-%COMP%]   .location-text-col[_ngcontent-%COMP%]   .location-title-row[_ngcontent-%COMP%]   .location-status-dot[_ngcontent-%COMP%] {\n  width: 8px;\n  height: 8px;\n  border-radius: 50%;\n  flex-shrink: 0;\n  display: inline-block;\n}\n.location-pill-btn[_ngcontent-%COMP%]   .location-text-col[_ngcontent-%COMP%]   .location-title-row[_ngcontent-%COMP%]   .location-status-dot.green[_ngcontent-%COMP%] {\n  background-color: #10b981;\n  box-shadow: 0 0 0 2.5px rgba(16, 185, 129, 0.25);\n}\n.location-pill-btn[_ngcontent-%COMP%]   .location-text-col[_ngcontent-%COMP%]   .location-title-row[_ngcontent-%COMP%]   .location-status-dot.orange[_ngcontent-%COMP%] {\n  background-color: #f59e0b;\n  box-shadow: 0 0 0 2.5px rgba(245, 158, 11, 0.25);\n}\n.location-pill-btn[_ngcontent-%COMP%]   .location-text-col[_ngcontent-%COMP%]   .location-title-row[_ngcontent-%COMP%]   .location-status-dot.red[_ngcontent-%COMP%] {\n  background-color: #ef4444;\n  box-shadow: 0 0 0 2.5px rgba(239, 68, 68, 0.25);\n}\n.location-pill-btn[_ngcontent-%COMP%]   .location-text-col[_ngcontent-%COMP%]   .location-title-row[_ngcontent-%COMP%]   .location-label-tag[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  font-weight: 800;\n  letter-spacing: 0.5px;\n  text-transform: uppercase;\n  padding: 2px 6px;\n  border-radius: 5px;\n  background: #f1f5f9;\n  color: #475569;\n  flex-shrink: 0;\n  line-height: 1.2;\n}\n.location-pill-btn[_ngcontent-%COMP%]   .location-text-col[_ngcontent-%COMP%]   .location-title-row[_ngcontent-%COMP%]   .location-label-tag[data-label=home][_ngcontent-%COMP%] {\n  background: rgba(16, 185, 129, 0.12);\n  color: #059669;\n}\n.location-pill-btn[_ngcontent-%COMP%]   .location-text-col[_ngcontent-%COMP%]   .location-title-row[_ngcontent-%COMP%]   .location-label-tag[data-label=work][_ngcontent-%COMP%] {\n  background: rgba(59, 130, 246, 0.12);\n  color: #2563eb;\n}\n.location-pill-btn[_ngcontent-%COMP%]   .location-text-col[_ngcontent-%COMP%]   .location-title-row[_ngcontent-%COMP%]   .location-label-tag[data-label=other][_ngcontent-%COMP%] {\n  background: rgba(160, 0, 226, 0.1);\n  color: #a000e2;\n}\n.location-pill-btn[_ngcontent-%COMP%]   .location-text-col[_ngcontent-%COMP%]   .location-title-row[_ngcontent-%COMP%]   .location-label-tag[data-label=unsaved][_ngcontent-%COMP%] {\n  background: rgba(245, 158, 11, 0.14);\n  color: #d97706;\n}\n.location-pill-btn[_ngcontent-%COMP%]   .location-text-col[_ngcontent-%COMP%]   .location-title-row[_ngcontent-%COMP%]   .location-name[_ngcontent-%COMP%] {\n  font-size: 14.5px;\n  font-weight: 750;\n  color: #0f172a;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  max-width: 170px;\n  line-height: 1.2;\n}\n.location-pill-btn[_ngcontent-%COMP%]   .location-text-col[_ngcontent-%COMP%]   .location-title-row[_ngcontent-%COMP%]   .chevron-icon[_ngcontent-%COMP%] {\n  font-size: 13px;\n  color: #64748b;\n  flex-shrink: 0;\n}\n.location-pill-btn[_ngcontent-%COMP%]   .location-text-col[_ngcontent-%COMP%]   .location-sub-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  min-width: 0;\n}\n.location-pill-btn[_ngcontent-%COMP%]   .location-text-col[_ngcontent-%COMP%]   .location-sub-row[_ngcontent-%COMP%]   .location-full-address[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 500;\n  color: #64748b;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  max-width: 230px;\n  line-height: 1.25;\n}\n.header-actions[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n}\n.header-actions[_ngcontent-%COMP%]   .customer-avatar-btn[_ngcontent-%COMP%] {\n  position: relative;\n  width: 38px;\n  height: 38px;\n  border-radius: 50%;\n  overflow: hidden;\n  border: 2px solid var(--app-theme-color, #a000e2);\n  cursor: pointer;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  box-shadow: 0 2px 8px rgba(160, 0, 226, 0.2);\n}\n.header-actions[_ngcontent-%COMP%]   .customer-avatar-btn[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n.header-actions[_ngcontent-%COMP%]   .customer-avatar-btn[_ngcontent-%COMP%]   .avatar-initial[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  background: var(--app-theme-color, #a000e2);\n  color: #ffffff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-weight: 800;\n  font-size: 15px;\n  text-transform: uppercase;\n}\n.home-body-container[_ngcontent-%COMP%] {\n  padding: 10px 16px 24px;\n  display: flex;\n  flex-direction: column;\n  gap: 16px;\n  width: 100%;\n  max-width: 100%;\n  box-sizing: border-box;\n  overflow-x: hidden;\n}\n.docked-active-orders-banner[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  width: 100%;\n  padding: 8px 14px 10px;\n  background:\n    linear-gradient(\n      to top,\n      rgb(248, 250, 252) 70%,\n      rgba(248, 250, 252, 0) 100%);\n  z-index: 99;\n  pointer-events: auto;\n  box-sizing: border-box;\n}\n.docked-active-orders-banner[_ngcontent-%COMP%]   .banner-inner-card[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #1e1b4b 0%,\n      #311042 100%);\n  border: 1px solid rgba(168, 85, 247, 0.35);\n  border-radius: 16px;\n  padding: 10px 14px;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 12px;\n  box-shadow: 0 6px 20px rgba(30, 27, 75, 0.3);\n  cursor: pointer;\n  transition: transform 0.15s ease, box-shadow 0.15s ease;\n}\n.docked-active-orders-banner[_ngcontent-%COMP%]   .banner-inner-card[_ngcontent-%COMP%]:active {\n  transform: scale(0.98);\n  box-shadow: 0 3px 12px rgba(30, 27, 75, 0.2);\n}\n.docked-active-orders-banner[_ngcontent-%COMP%]   .banner-inner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  min-width: 0;\n  flex: 1;\n}\n.docked-active-orders-banner[_ngcontent-%COMP%]   .banner-inner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .live-pulse-dot[_ngcontent-%COMP%] {\n  width: 11px;\n  height: 11px;\n  border-radius: 50%;\n  background: #10b981;\n  box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7);\n  animation: _ngcontent-%COMP%_pulseGlow 1.8s infinite;\n  flex-shrink: 0;\n}\n.docked-active-orders-banner[_ngcontent-%COMP%]   .banner-inner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .order-text-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  min-width: 0;\n  gap: 2px;\n}\n.docked-active-orders-banner[_ngcontent-%COMP%]   .banner-inner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .order-text-col[_ngcontent-%COMP%]   .order-badge-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n}\n.docked-active-orders-banner[_ngcontent-%COMP%]   .banner-inner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .order-text-col[_ngcontent-%COMP%]   .order-badge-row[_ngcontent-%COMP%]   .badge-text[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 850;\n  color: #34d399;\n  letter-spacing: 0.5px;\n  text-transform: uppercase;\n}\n.docked-active-orders-banner[_ngcontent-%COMP%]   .banner-inner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .order-text-col[_ngcontent-%COMP%]   .order-badge-row[_ngcontent-%COMP%]   .order-id-chip[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  font-weight: 700;\n  color: #c084fc;\n  background: rgba(192, 132, 252, 0.15);\n  padding: 1px 6px;\n  border-radius: 6px;\n}\n.docked-active-orders-banner[_ngcontent-%COMP%]   .banner-inner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .order-text-col[_ngcontent-%COMP%]   .order-title-line[_ngcontent-%COMP%] {\n  font-size: 12.5px;\n  font-weight: 700;\n  color: #ffffff;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.docked-active-orders-banner[_ngcontent-%COMP%]   .banner-inner-card[_ngcontent-%COMP%]   .btn-docked-track[_ngcontent-%COMP%] {\n  background: #ffffff;\n  color: #0f172a;\n  border: none;\n  border-radius: 99px;\n  padding: 6px 14px;\n  font-size: 12px;\n  font-weight: 800;\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  flex-shrink: 0;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);\n  cursor: pointer;\n}\n.docked-active-orders-banner[_ngcontent-%COMP%]   .banner-inner-card[_ngcontent-%COMP%]   .btn-docked-track[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 13px;\n  color: #7c3aed;\n}\n@keyframes _ngcontent-%COMP%_pulseGlow {\n  0% {\n    box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7);\n  }\n  70% {\n    box-shadow: 0 0 0 8px rgba(16, 185, 129, 0);\n  }\n  100% {\n    box-shadow: 0 0 0 0 rgba(16, 185, 129, 0);\n  }\n}\n.home-top-hero-slider[_ngcontent-%COMP%] {\n  width: 100%;\n  max-width: 100%;\n  box-sizing: border-box;\n  margin: 0;\n  padding: 0;\n  border-radius: 0;\n  overflow: hidden;\n  position: relative;\n}\n.home-top-hero-slider[_ngcontent-%COMP%]   .hero-swiper[_ngcontent-%COMP%] {\n  width: 100%;\n  overflow: hidden;\n  margin: 0;\n  padding: 0;\n  border-radius: 0;\n  display: block;\n}\n.home-top-hero-slider[_ngcontent-%COMP%]   .hero-swiper[_ngcontent-%COMP%]   swiper-slide[_ngcontent-%COMP%] {\n  width: 100%;\n  margin: 0;\n  padding: 0;\n  border-radius: 0;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  box-sizing: border-box;\n}\n.home-top-hero-slider[_ngcontent-%COMP%]   .hero-swiper[_ngcontent-%COMP%]::part(pagination) {\n  bottom: 12px;\n}\n.home-top-hero-slider[_ngcontent-%COMP%]   .hero-swiper[_ngcontent-%COMP%]::part(bullet) {\n  width: 6px;\n  height: 6px;\n  background: rgba(255, 255, 255, 0.45);\n  opacity: 1;\n  border-radius: 99px;\n  transition: all 0.25s ease;\n}\n.home-top-hero-slider[_ngcontent-%COMP%]   .hero-swiper[_ngcontent-%COMP%]::part(bullet-active) {\n  width: 18px;\n  background: #ffffff;\n  border-radius: 99px;\n}\n.home-top-hero-slider[_ngcontent-%COMP%]   .hero-banner-card[_ngcontent-%COMP%] {\n  width: 100%;\n  min-height: 215px;\n  max-height: 255px;\n  margin: 0;\n  padding: 18px 18px 22px 18px;\n  border-radius: 0;\n  position: relative;\n  overflow: hidden;\n  cursor: pointer;\n  box-shadow: 0 4px 16px rgba(15, 23, 42, 0.08);\n  display: flex;\n  align-items: flex-end;\n  box-sizing: border-box;\n  transition: transform 0.15s ease;\n}\n.home-top-hero-slider[_ngcontent-%COMP%]   .hero-banner-card[_ngcontent-%COMP%]:active {\n  transform: scale(0.985);\n}\n.home-top-hero-slider[_ngcontent-%COMP%]   .hero-banner-card[_ngcontent-%COMP%]   .hero-banner-img[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n  border-radius: 0;\n  display: block;\n}\n.home-top-hero-slider[_ngcontent-%COMP%]   .hero-banner-card[_ngcontent-%COMP%]   .hero-banner-content-box[_ngcontent-%COMP%] {\n  position: relative;\n  z-index: 2;\n  max-width: 82%;\n  display: flex;\n  flex-direction: column;\n  gap: 3px;\n}\n.home-top-hero-slider[_ngcontent-%COMP%]   .hero-banner-card[_ngcontent-%COMP%]   .hero-banner-content-box[_ngcontent-%COMP%]   .banner-badge-pill[_ngcontent-%COMP%] {\n  display: inline-block;\n  font-size: 9.5px;\n  font-weight: 850;\n  letter-spacing: 0.6px;\n  padding: 3px 9px;\n  border-radius: 99px;\n  width: fit-content;\n  margin-bottom: 4px;\n  -webkit-backdrop-filter: blur(8px);\n  backdrop-filter: blur(8px);\n}\n.home-top-hero-slider[_ngcontent-%COMP%]   .hero-banner-card[_ngcontent-%COMP%]   .hero-banner-content-box[_ngcontent-%COMP%]   .banner-title[_ngcontent-%COMP%] {\n  font-size: 19px;\n  font-weight: 850;\n  color: #ffffff;\n  margin: 0 0 2px 0;\n  line-height: 1.25;\n  text-shadow: 0 2px 8px rgba(0, 0, 0, 0.4);\n}\n.home-top-hero-slider[_ngcontent-%COMP%]   .hero-banner-card[_ngcontent-%COMP%]   .hero-banner-content-box[_ngcontent-%COMP%]   .banner-subtitle[_ngcontent-%COMP%] {\n  font-size: 12.5px;\n  color: rgba(255, 255, 255, 0.9);\n  margin: 0 0 10px 0;\n  line-height: 1.4;\n  text-shadow: 0 1px 4px rgba(0, 0, 0, 0.3);\n}\n.home-top-hero-slider[_ngcontent-%COMP%]   .hero-banner-card[_ngcontent-%COMP%]   .hero-banner-content-box[_ngcontent-%COMP%]   .banner-cta-row[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n  width: fit-content;\n  background: rgba(255, 255, 255, 0.94);\n  padding: 5px 12px;\n  border-radius: 99px;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);\n}\n.home-top-hero-slider[_ngcontent-%COMP%]   .hero-banner-card[_ngcontent-%COMP%]   .hero-banner-content-box[_ngcontent-%COMP%]   .banner-cta-row[_ngcontent-%COMP%]   .banner-cta-text[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 800;\n  color: #0f172a;\n}\n.home-top-hero-slider[_ngcontent-%COMP%]   .hero-banner-card[_ngcontent-%COMP%]   .hero-banner-content-box[_ngcontent-%COMP%]   .banner-cta-row[_ngcontent-%COMP%]   .banner-cta-arrow[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #a000e2;\n  display: flex;\n  align-items: center;\n}\n.home-top-hero-slider.hero-skeleton-section[_ngcontent-%COMP%]   .hero-banner-skeleton-card[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 230px;\n  position: relative;\n  background: #f1f5f9;\n}\n.home-top-hero-slider.hero-skeleton-section[_ngcontent-%COMP%]   .hero-banner-skeleton-card[_ngcontent-%COMP%]   .hero-banner-skeleton-img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  margin: 0;\n  --border-radius: 0;\n}\n.service-alert-banner[_ngcontent-%COMP%] {\n  border-radius: 18px;\n  padding: 14px 16px;\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n  box-shadow: 0 4px 16px rgba(15, 23, 42, 0.05);\n  box-sizing: border-box;\n}\n.service-alert-banner[_ngcontent-%COMP%]   .alert-icon-box[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 38px;\n  border-radius: 12px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 20px;\n  flex-shrink: 0;\n}\n.service-alert-banner[_ngcontent-%COMP%]   .alert-icon-box.warning[_ngcontent-%COMP%] {\n  background: #fef3c7;\n  color: #d97706;\n}\n.service-alert-banner[_ngcontent-%COMP%]   .alert-icon-box.closed[_ngcontent-%COMP%] {\n  background: #fce7f3;\n  color: #db2777;\n}\n.service-alert-banner[_ngcontent-%COMP%]   .alert-icon-box.out[_ngcontent-%COMP%] {\n  background: #ffedd5;\n  color: #ea580c;\n}\n.service-alert-banner[_ngcontent-%COMP%]   .alert-text-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n}\n.service-alert-banner[_ngcontent-%COMP%]   .alert-text-col[_ngcontent-%COMP%]   .alert-badge[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n  padding: 3px 8px;\n  border-radius: 99px;\n  font-size: 9.5px;\n  font-weight: 850;\n  letter-spacing: 0.6px;\n  width: fit-content;\n}\n.service-alert-banner[_ngcontent-%COMP%]   .alert-text-col[_ngcontent-%COMP%]   .alert-badge.warning[_ngcontent-%COMP%] {\n  background: #fef3c7;\n  color: #92400e;\n}\n.service-alert-banner[_ngcontent-%COMP%]   .alert-text-col[_ngcontent-%COMP%]   .alert-badge.closed[_ngcontent-%COMP%] {\n  background: #fce7f3;\n  color: #9d174d;\n}\n.service-alert-banner[_ngcontent-%COMP%]   .alert-text-col[_ngcontent-%COMP%]   .alert-badge.out[_ngcontent-%COMP%] {\n  background: #fee2e2;\n  color: #991b1b;\n}\n.service-alert-banner[_ngcontent-%COMP%]   .alert-text-col[_ngcontent-%COMP%]   .alert-title[_ngcontent-%COMP%] {\n  font-size: 15px;\n  font-weight: 800;\n  color: #0f172a;\n  margin: 0;\n  letter-spacing: -0.2px;\n}\n.service-alert-banner[_ngcontent-%COMP%]   .alert-text-col[_ngcontent-%COMP%]   .alert-desc[_ngcontent-%COMP%] {\n  font-size: 12.5px;\n  color: #64748b;\n  margin: 0;\n  line-height: 1.45;\n}\n.service-alert-banner[_ngcontent-%COMP%]   .status-pulse-dot[_ngcontent-%COMP%] {\n  width: 6px;\n  height: 6px;\n  border-radius: 50%;\n  display: inline-block;\n}\n.service-alert-banner[_ngcontent-%COMP%]   .status-pulse-dot.amber[_ngcontent-%COMP%] {\n  background: #f59e0b;\n  box-shadow: 0 0 0 2px rgba(245, 158, 11, 0.3);\n}\n.service-alert-banner[_ngcontent-%COMP%]   .status-pulse-dot.red[_ngcontent-%COMP%] {\n  background: #ef4444;\n  box-shadow: 0 0 0 2px rgba(239, 68, 68, 0.3);\n  animation: _ngcontent-%COMP%_alertPulse 1.6s infinite;\n}\n.service-alert-banner.permission-banner[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      180deg,\n      #fffbeb 0%,\n      #fefce8 100%);\n  border: 1.5px solid #fde68a;\n}\n.service-alert-banner.permission-banner[_ngcontent-%COMP%]   .btn-alert-action.enable-btn[_ngcontent-%COMP%] {\n  align-self: flex-start;\n  background: #d97706;\n  color: #ffffff;\n  border: none;\n  border-radius: 10px;\n  padding: 8px 16px;\n  font-size: 12px;\n  font-weight: 800;\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n  cursor: pointer;\n  box-shadow: 0 2px 8px rgba(217, 119, 6, 0.25);\n  transition: transform 0.15s ease;\n}\n.service-alert-banner.permission-banner[_ngcontent-%COMP%]   .btn-alert-action.enable-btn[_ngcontent-%COMP%]:active {\n  transform: scale(0.96);\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  min-height: calc(100dvh - 170px);\n  min-height: calc(100vh - 170px);\n  padding: 24px 12px;\n  margin: auto 0;\n  width: 100%;\n  box-sizing: border-box;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%] {\n  width: 100%;\n  max-width: 390px;\n  background: #ffffff;\n  border-radius: 24px;\n  padding: 32px 22px 26px;\n  box-sizing: border-box;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  text-align: center;\n  position: relative;\n  overflow: hidden;\n  box-shadow: 0 16px 40px rgba(15, 23, 42, 0.08), 0 2px 10px rgba(15, 23, 42, 0.04);\n  transition: transform 0.2s ease;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card.closed-card[_ngcontent-%COMP%] {\n  border: 1.5px solid #fbcfe8;\n  background:\n    linear-gradient(\n      180deg,\n      #fffdfd 0%,\n      #ffffff 100%);\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card.out-of-area-card[_ngcontent-%COMP%] {\n  border: 1.5px solid #fed7aa;\n  background:\n    linear-gradient(\n      180deg,\n      #fffdfa 0%,\n      #ffffff 100%);\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .status-graphic-wrapper[_ngcontent-%COMP%] {\n  position: relative;\n  width: 84px;\n  height: 84px;\n  margin-bottom: 18px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .status-graphic-wrapper[_ngcontent-%COMP%]   .graphic-glow-ring[_ngcontent-%COMP%] {\n  position: absolute;\n  top: -6px;\n  right: -6px;\n  bottom: -6px;\n  left: -6px;\n  border-radius: 50%;\n  opacity: 0.5;\n  animation: _ngcontent-%COMP%_statusGlowPulse 2.4s infinite ease-in-out;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .status-graphic-wrapper[_ngcontent-%COMP%]   .graphic-icon-box[_ngcontent-%COMP%] {\n  position: relative;\n  width: 100%;\n  height: 100%;\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 38px;\n  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.06);\n  z-index: 2;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .status-graphic-wrapper.closed[_ngcontent-%COMP%]   .graphic-glow-ring[_ngcontent-%COMP%] {\n  background:\n    radial-gradient(\n      circle,\n      rgba(244, 114, 182, 0.4) 0%,\n      rgba(244, 114, 182, 0) 70%);\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .status-graphic-wrapper.closed[_ngcontent-%COMP%]   .graphic-icon-box[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #fce7f3 0%,\n      #fdf2f8 100%);\n  border: 2px solid #f472b6;\n  color: #db2777;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .status-graphic-wrapper.out[_ngcontent-%COMP%]   .graphic-glow-ring[_ngcontent-%COMP%] {\n  background:\n    radial-gradient(\n      circle,\n      rgba(251, 146, 60, 0.4) 0%,\n      rgba(251, 146, 60, 0) 70%);\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .status-graphic-wrapper.out[_ngcontent-%COMP%]   .graphic-icon-box[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #ffedd5 0%,\n      #fff7ed 100%);\n  border: 2px solid #fb923c;\n  color: #ea580c;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .status-badge[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n  padding: 4px 12px;\n  border-radius: 99px;\n  font-size: 10.5px;\n  font-weight: 850;\n  letter-spacing: 0.7px;\n  margin-bottom: 12px;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .status-badge.closed[_ngcontent-%COMP%] {\n  background: #fce7f3;\n  color: #9d174d;\n  border: 1px solid #fbcfe8;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .status-badge.out[_ngcontent-%COMP%] {\n  background: #fee2e2;\n  color: #991b1b;\n  border: 1px solid #fecaca;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .status-title[_ngcontent-%COMP%] {\n  font-size: 19px;\n  font-weight: 800;\n  color: #0f172a;\n  margin: 0 0 8px 0;\n  line-height: 1.3;\n  letter-spacing: -0.3px;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .status-desc[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  color: #64748b;\n  margin: 0 0 18px 0;\n  line-height: 1.5;\n  max-width: 320px;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .nearest-area-box[_ngcontent-%COMP%] {\n  width: 100%;\n  background: #f8fafc;\n  border: 1.5px dashed #cbd5e1;\n  border-radius: 16px;\n  padding: 14px 14px;\n  margin-bottom: 20px;\n  box-sizing: border-box;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .nearest-area-box[_ngcontent-%COMP%]   .nearest-title[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 6px;\n  font-size: 13px;\n  font-weight: 600;\n  color: #334155;\n  margin-bottom: 6px;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .nearest-area-box[_ngcontent-%COMP%]   .nearest-title[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 17px;\n  color: #ea580c;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .nearest-area-box[_ngcontent-%COMP%]   .nearest-title[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: #0f172a;\n  font-weight: 800;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .nearest-area-box[_ngcontent-%COMP%]   .nearest-distance-badge[_ngcontent-%COMP%] {\n  display: inline-block;\n  background: #ffedd5;\n  border: 1px solid #fed7aa;\n  color: #9a3412;\n  font-size: 12px;\n  font-weight: 800;\n  padding: 3px 12px;\n  border-radius: 99px;\n  margin-bottom: 8px;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .nearest-area-box[_ngcontent-%COMP%]   .nearest-distance-badge[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: #c2410c;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .nearest-area-box[_ngcontent-%COMP%]   .nearest-instruction[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #64748b;\n  line-height: 1.45;\n  margin: 0;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .nearest-area-box[_ngcontent-%COMP%]   .nearest-instruction[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: #334155;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .nearest-tip-box[_ngcontent-%COMP%] {\n  width: 100%;\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n  border-radius: 14px;\n  padding: 12px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 8px;\n  font-size: 12.5px;\n  color: #64748b;\n  margin-bottom: 20px;\n  box-sizing: border-box;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .nearest-tip-box[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n  color: #ea580c;\n  flex-shrink: 0;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .status-actions-group[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n  width: 100%;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .status-actions-group[_ngcontent-%COMP%]   .btn-primary-action[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 48px;\n  background:\n    linear-gradient(\n      135deg,\n      #a000e2 0%,\n      #7900b2 100%);\n  color: #ffffff;\n  border: none;\n  border-radius: 14px;\n  font-size: 14px;\n  font-weight: 800;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 8px;\n  cursor: pointer;\n  box-shadow: 0 4px 16px rgba(160, 0, 226, 0.28);\n  transition: transform 0.15s ease, box-shadow 0.15s ease;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .status-actions-group[_ngcontent-%COMP%]   .btn-primary-action[_ngcontent-%COMP%]:active {\n  transform: scale(0.98);\n  box-shadow: 0 2px 8px rgba(160, 0, 226, 0.2);\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .status-actions-group[_ngcontent-%COMP%]   .btn-primary-action[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .status-actions-group[_ngcontent-%COMP%]   .btn-secondary-action[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 44px;\n  background: #f8fafc;\n  border: 1.5px solid #e2e8f0;\n  color: #475569;\n  border-radius: 14px;\n  font-size: 13.5px;\n  font-weight: 750;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 6px;\n  cursor: pointer;\n  transition: transform 0.15s ease, background 0.15s ease;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .status-actions-group[_ngcontent-%COMP%]   .btn-secondary-action[_ngcontent-%COMP%]:active {\n  transform: scale(0.98);\n  background: #f1f5f9;\n}\n.home-centered-status-wrapper[_ngcontent-%COMP%]   .centered-status-card[_ngcontent-%COMP%]   .status-actions-group[_ngcontent-%COMP%]   .btn-secondary-action[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 17px;\n}\n@keyframes _ngcontent-%COMP%_statusGlowPulse {\n  0% {\n    transform: scale(0.92);\n    opacity: 0.35;\n  }\n  50% {\n    transform: scale(1.18);\n    opacity: 0.75;\n  }\n  100% {\n    transform: scale(0.92);\n    opacity: 0.35;\n  }\n}\n@keyframes _ngcontent-%COMP%_alertPulse {\n  0% {\n    transform: scale(0.95);\n    opacity: 0.8;\n  }\n  50% {\n    transform: scale(1.2);\n    opacity: 1;\n  }\n  100% {\n    transform: scale(0.95);\n    opacity: 0.8;\n  }\n}\n.services-mosaic-section[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n}\n.services-mosaic-section[_ngcontent-%COMP%]   .section-title-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n.services-mosaic-section[_ngcontent-%COMP%]   .section-title-row[_ngcontent-%COMP%]   .sparkle-icon[_ngcontent-%COMP%] {\n  font-size: 16px;\n}\n.services-mosaic-section[_ngcontent-%COMP%]   .section-title-row[_ngcontent-%COMP%]   .section-heading[_ngcontent-%COMP%] {\n  font-size: 16.5px;\n  font-weight: 850;\n  color: #0f172a;\n  letter-spacing: -0.2px;\n  margin: 0;\n}\n.services-mosaic-section[_ngcontent-%COMP%]   .section-title-row[_ngcontent-%COMP%]   .services-count-pill[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 800;\n  color: #a000e2;\n  background: #f3e8ff;\n  padding: 3px 9px;\n  border-radius: 99px;\n  letter-spacing: 0.4px;\n}\n.services-mosaic-grid[_ngcontent-%COMP%] {\n  display: grid;\n  gap: 12px;\n  width: 100%;\n}\n.services-mosaic-grid.count-1[_ngcontent-%COMP%] {\n  grid-template-columns: 1fr;\n  grid-auto-rows: 124px;\n}\n.services-mosaic-grid.count-1[_ngcontent-%COMP%]   .mosaic-tile[_ngcontent-%COMP%] {\n  width: 100%;\n}\n.services-mosaic-grid.count-2[_ngcontent-%COMP%] {\n  grid-template-columns: repeat(2, minmax(0, 1fr));\n  grid-auto-rows: 130px;\n}\n.services-mosaic-grid.count-2[_ngcontent-%COMP%]   .mosaic-tile[_ngcontent-%COMP%] {\n  width: 100%;\n}\n.services-mosaic-grid.bento-grid[_ngcontent-%COMP%] {\n  grid-template-columns: repeat(2, minmax(0, 1fr));\n  grid-auto-rows: 122px;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile[_ngcontent-%COMP%] {\n  min-width: 0;\n  box-sizing: border-box;\n  border-radius: 18px;\n  border: 1.5px solid #e2e8f0;\n  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.04);\n  background: #ffffff;\n  cursor: pointer;\n  overflow: hidden;\n  position: relative;\n  transition:\n    transform 0.16s ease,\n    border-color 0.16s ease,\n    box-shadow 0.16s ease;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile[_ngcontent-%COMP%]:active {\n  transform: scale(0.975);\n  border-color: rgba(160, 0, 226, 0.4);\n  box-shadow: 0 4px 14px rgba(160, 0, 226, 0.12);\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile[_ngcontent-%COMP%]   .service-corner-tag[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  z-index: 3;\n  display: inline-flex;\n  align-items: center;\n  gap: 3px;\n  padding: 3px 8.5px 3.5px 8px;\n  font-size: 8.5px;\n  font-weight: 850;\n  letter-spacing: 0.35px;\n  text-transform: uppercase;\n  line-height: 1.2;\n  border-radius: 16.5px 0 10px 0;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile[_ngcontent-%COMP%]   .service-corner-tag.tag-brand[_ngcontent-%COMP%] {\n  background: #f5f3ff;\n  color: #7c3aed;\n  border-right: 1px solid rgba(124, 58, 237, 0.2);\n  border-bottom: 1px solid rgba(124, 58, 237, 0.2);\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile[_ngcontent-%COMP%]   .service-corner-tag.tag-discount[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  color: #059669;\n  border-right: 1px solid rgba(5, 150, 105, 0.2);\n  border-bottom: 1px solid rgba(5, 150, 105, 0.2);\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile[_ngcontent-%COMP%]   .service-corner-tag.tag-highlight[_ngcontent-%COMP%] {\n  background: #fff7ed;\n  color: #ea580c;\n  border-right: 1px solid rgba(234, 88, 12, 0.22);\n  border-bottom: 1px solid rgba(234, 88, 12, 0.22);\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile[_ngcontent-%COMP%]   .status-active[_ngcontent-%COMP%] {\n  color: #059669 !important;\n  font-weight: 700 !important;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile[_ngcontent-%COMP%]   .tile-corner-art[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 0;\n  bottom: 0;\n  display: flex;\n  align-items: flex-end;\n  justify-content: flex-end;\n  pointer-events: none;\n  z-index: 1;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile[_ngcontent-%COMP%]   .tile-corner-art[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  display: block;\n  object-fit: contain;\n  filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.08));\n  transition: transform 0.2s ease;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-tall[_ngcontent-%COMP%] {\n  grid-column: span 1;\n  grid-row: span 2;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-tall[_ngcontent-%COMP%]   .tall-tile-inner[_ngcontent-%COMP%] {\n  height: 100%;\n  width: 100%;\n  padding: 14px 14px 12px 14px;\n  box-sizing: border-box;\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n  position: relative;\n  z-index: 2;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-tall[_ngcontent-%COMP%]   .tall-tile-inner.has-corner-tag[_ngcontent-%COMP%] {\n  padding-top: 26px;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-tall[_ngcontent-%COMP%]   .tall-tile-inner[_ngcontent-%COMP%]   .tile-header-area[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n  max-width: 100%;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-tall[_ngcontent-%COMP%]   .tall-tile-inner[_ngcontent-%COMP%]   .tile-header-area[_ngcontent-%COMP%]   .tile-title-tall[_ngcontent-%COMP%] {\n  font-size: 18px;\n  font-weight: 850;\n  color: #0f172a;\n  margin: 0;\n  letter-spacing: -0.3px;\n  line-height: 1.25;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-tall[_ngcontent-%COMP%]   .tall-tile-inner[_ngcontent-%COMP%]   .tile-header-area[_ngcontent-%COMP%]   .tile-subtitle-tall[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #64748b;\n  margin: 0;\n  line-height: 1.35;\n  font-weight: 600;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-tall[_ngcontent-%COMP%]   .tall-tile-inner[_ngcontent-%COMP%]   .tile-center-art-tall[_ngcontent-%COMP%] {\n  flex: 1;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin: 6px 0;\n  width: 100%;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-tall[_ngcontent-%COMP%]   .tall-tile-inner[_ngcontent-%COMP%]   .tile-center-art-tall[_ngcontent-%COMP%]   .service-art-img-tall-center[_ngcontent-%COMP%] {\n  width: 86px;\n  height: 86px;\n  object-fit: contain;\n  filter: drop-shadow(0 4px 12px rgba(0, 0, 0, 0.1));\n  transition: transform 0.2s ease;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-tall[_ngcontent-%COMP%]   .tall-tile-inner[_ngcontent-%COMP%]   .tile-center-art-tall[_ngcontent-%COMP%]   .service-art-fallback.tall-fallback[_ngcontent-%COMP%] {\n  width: 76px;\n  height: 76px;\n  border-radius: 20px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-tall[_ngcontent-%COMP%]   .tall-tile-inner[_ngcontent-%COMP%]   .tile-center-art-tall[_ngcontent-%COMP%]   .service-art-fallback.tall-fallback[_ngcontent-%COMP%]   .fallback-emoji[_ngcontent-%COMP%] {\n  font-size: 40px;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-tall[_ngcontent-%COMP%]   .tall-tile-inner[_ngcontent-%COMP%]   .tile-action-row[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding-top: 8px;\n  border-top: 1px solid rgba(0, 0, 0, 0.05);\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-tall[_ngcontent-%COMP%]   .tall-tile-inner[_ngcontent-%COMP%]   .tile-action-row[_ngcontent-%COMP%]   .action-btn-text[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 800;\n  color: #a000e2;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-tall[_ngcontent-%COMP%]   .tall-tile-inner[_ngcontent-%COMP%]   .tile-action-row[_ngcontent-%COMP%]   .arrow-circle-btn[_ngcontent-%COMP%] {\n  width: 26px;\n  height: 26px;\n  border-radius: 50%;\n  background: #a000e2;\n  color: #ffffff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 13px;\n  box-shadow: 0 2px 6px rgba(160, 0, 226, 0.3);\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-normal[_ngcontent-%COMP%] {\n  grid-column: span 1;\n  grid-row: span 1;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-normal[_ngcontent-%COMP%]   .normal-tile-inner[_ngcontent-%COMP%] {\n  height: 100%;\n  width: 100%;\n  padding: 13px 12px 12px 14px;\n  box-sizing: border-box;\n  display: flex;\n  flex-direction: column;\n  justify-content: flex-start;\n  position: relative;\n  z-index: 2;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-normal[_ngcontent-%COMP%]   .normal-tile-inner.has-corner-tag[_ngcontent-%COMP%] {\n  padding-top: 24px;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-normal[_ngcontent-%COMP%]   .normal-tile-inner[_ngcontent-%COMP%]   .normal-left-info[_ngcontent-%COMP%] {\n  max-width: 75%;\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-normal[_ngcontent-%COMP%]   .normal-tile-inner[_ngcontent-%COMP%]   .normal-left-info[_ngcontent-%COMP%]   .tile-title-normal[_ngcontent-%COMP%] {\n  font-size: 14.5px;\n  font-weight: 800;\n  color: #0f172a;\n  margin: 0;\n  line-height: 1.25;\n  letter-spacing: -0.2px;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-normal[_ngcontent-%COMP%]   .normal-tile-inner[_ngcontent-%COMP%]   .normal-left-info[_ngcontent-%COMP%]   .tile-subtitle-normal[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  color: #64748b;\n  margin: 0;\n  font-weight: 600;\n  line-height: 1.2;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-normal[_ngcontent-%COMP%]   .normal-tile-inner[_ngcontent-%COMP%]   .arrow-circle-mini[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 10px;\n  right: 10px;\n  width: 22px;\n  height: 22px;\n  border-radius: 50%;\n  background: rgba(0, 0, 0, 0.04);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 11px;\n  color: #64748b;\n  z-index: 2;\n  transition: all 0.15s ease;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-normal[_ngcontent-%COMP%]   .normal-tile-inner[_ngcontent-%COMP%]   .arrow-circle-mini[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 12px;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-normal[_ngcontent-%COMP%]:active   .arrow-circle-mini[_ngcontent-%COMP%] {\n  background: #a000e2;\n  color: #ffffff;\n  transform: scale(1.08);\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-normal[_ngcontent-%COMP%]   .normal-corner-art[_ngcontent-%COMP%] {\n  position: absolute;\n  right: -12px;\n  bottom: -12px;\n  z-index: 1;\n  pointer-events: none;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-normal[_ngcontent-%COMP%]   .normal-corner-art[_ngcontent-%COMP%]   .service-art-img-normal[_ngcontent-%COMP%] {\n  width: 80px;\n  height: 80px;\n  object-fit: contain;\n  filter: drop-shadow(0 4px 10px rgba(0, 0, 0, 0.1));\n  display: block;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-normal[_ngcontent-%COMP%]   .normal-corner-art[_ngcontent-%COMP%]   .service-art-fallback.normal-fallback[_ngcontent-%COMP%] {\n  width: 52px;\n  height: 52px;\n  border-radius: 14px;\n  margin: 0 4px 4px 0;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-normal[_ngcontent-%COMP%]   .normal-corner-art[_ngcontent-%COMP%]   .service-art-fallback.normal-fallback[_ngcontent-%COMP%]   .fallback-emoji-small[_ngcontent-%COMP%] {\n  font-size: 26px;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-wide[_ngcontent-%COMP%] {\n  grid-column: span 2;\n  grid-row: span 1;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-wide[_ngcontent-%COMP%]   .wide-tile-inner[_ngcontent-%COMP%] {\n  height: 100%;\n  width: 100%;\n  padding: 14px 16px;\n  box-sizing: border-box;\n  display: flex;\n  align-items: center;\n  position: relative;\n  z-index: 2;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-wide[_ngcontent-%COMP%]   .wide-tile-inner.has-corner-tag[_ngcontent-%COMP%] {\n  padding-top: 22px;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-wide[_ngcontent-%COMP%]   .wide-tile-inner[_ngcontent-%COMP%]   .wide-left-content[_ngcontent-%COMP%] {\n  max-width: 65%;\n  display: flex;\n  flex-direction: column;\n  gap: 3px;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-wide[_ngcontent-%COMP%]   .wide-tile-inner[_ngcontent-%COMP%]   .wide-left-content[_ngcontent-%COMP%]   .tile-title-wide[_ngcontent-%COMP%] {\n  font-size: 16.5px;\n  font-weight: 800;\n  color: #0f172a;\n  margin: 0;\n  letter-spacing: -0.2px;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-wide[_ngcontent-%COMP%]   .wide-tile-inner[_ngcontent-%COMP%]   .wide-left-content[_ngcontent-%COMP%]   .tile-subtitle-wide[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #64748b;\n  margin: 0;\n  font-weight: 600;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-wide[_ngcontent-%COMP%]   .wide-tile-inner[_ngcontent-%COMP%]   .wide-left-content[_ngcontent-%COMP%]   .wide-cta-chip[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  font-size: 11px;\n  font-weight: 800;\n  color: #a000e2;\n  margin-top: 4px;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-wide[_ngcontent-%COMP%]   .wide-tile-inner[_ngcontent-%COMP%]   .wide-left-content[_ngcontent-%COMP%]   .wide-cta-chip[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 12px;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-wide[_ngcontent-%COMP%]   .wide-corner-art[_ngcontent-%COMP%] {\n  position: absolute;\n  right: -14px;\n  bottom: -12px;\n  z-index: 1;\n  pointer-events: none;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-wide[_ngcontent-%COMP%]   .wide-corner-art[_ngcontent-%COMP%]   .service-art-img-wide[_ngcontent-%COMP%] {\n  width: 92px;\n  height: 92px;\n  object-fit: contain;\n  filter: drop-shadow(0 4px 10px rgba(0, 0, 0, 0.1));\n  display: block;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-wide[_ngcontent-%COMP%]   .wide-corner-art[_ngcontent-%COMP%]   .service-art-fallback.wide-fallback[_ngcontent-%COMP%] {\n  width: 64px;\n  height: 64px;\n  border-radius: 16px;\n  margin: 0 6px 6px 0;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.mosaic-tile-wide[_ngcontent-%COMP%]   .wide-corner-art[_ngcontent-%COMP%]   .service-art-fallback.wide-fallback[_ngcontent-%COMP%]   .fallback-emoji[_ngcontent-%COMP%] {\n  font-size: 32px;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.skeleton-card[_ngcontent-%COMP%] {\n  pointer-events: none;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.skeleton-card[_ngcontent-%COMP%]   .skeleton-corner-tag[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 54px;\n  height: 18px;\n  background: #f1f5f9;\n  border-top-left-radius: 16.5px;\n  border-bottom-right-radius: 10px;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.skeleton-card[_ngcontent-%COMP%]   .skeleton-corner-circle[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 0;\n  bottom: 0;\n  border-bottom-right-radius: 16.5px;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.skeleton-card[_ngcontent-%COMP%]   .skeleton-corner-circle.normal[_ngcontent-%COMP%] {\n  width: 58px;\n  height: 58px;\n  border-radius: 18px 0 16.5px 0;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.skeleton-card[_ngcontent-%COMP%]   .skeleton-corner-circle.wide[_ngcontent-%COMP%] {\n  width: 70px;\n  height: 70px;\n  border-radius: 20px 0 16.5px 0;\n}\n.services-mosaic-grid[_ngcontent-%COMP%]   .mosaic-tile.skeleton-card[_ngcontent-%COMP%]   .skeleton-corner-circle.tall[_ngcontent-%COMP%] {\n  width: 82px;\n  height: 82px;\n  border-radius: 24px 0 16.5px 0;\n}\n.home-bottom-banners-section[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n  width: 100%;\n  max-width: 100%;\n  box-sizing: border-box;\n}\n.home-bottom-banners-section[_ngcontent-%COMP%]   .bottom-promo-card[_ngcontent-%COMP%] {\n  width: 100%;\n  min-height: 122px;\n  border-radius: 20px;\n  position: relative;\n  overflow: hidden;\n  cursor: pointer;\n  box-shadow: 0 6px 20px rgba(15, 23, 42, 0.08);\n  border: 1px solid rgba(0, 0, 0, 0.04);\n  display: flex;\n  align-items: center;\n  box-sizing: border-box;\n  transition: transform 0.15s ease, box-shadow 0.15s ease;\n}\n.home-bottom-banners-section[_ngcontent-%COMP%]   .bottom-promo-card[_ngcontent-%COMP%]:active {\n  transform: scale(0.985);\n  box-shadow: 0 2px 8px rgba(160, 0, 226, 0.12);\n}\n.home-bottom-banners-section[_ngcontent-%COMP%]   .bottom-promo-card[_ngcontent-%COMP%]   .banner-full-img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  min-height: 122px;\n  max-height: 140px;\n  object-fit: cover;\n  display: block;\n}\n.home-bottom-banners-section[_ngcontent-%COMP%]   .bottom-promo-card[_ngcontent-%COMP%]   .bottom-promo-content[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  min-height: 122px;\n  padding: 14px 16px;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  position: relative;\n  z-index: 2;\n}\n.home-bottom-banners-section[_ngcontent-%COMP%]   .bottom-promo-card[_ngcontent-%COMP%]   .bottom-promo-content[_ngcontent-%COMP%]   .promo-text-col[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 0;\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n  z-index: 2;\n}\n.home-bottom-banners-section[_ngcontent-%COMP%]   .bottom-promo-card[_ngcontent-%COMP%]   .bottom-promo-content[_ngcontent-%COMP%]   .promo-text-col[_ngcontent-%COMP%]   .promo-badge-pill[_ngcontent-%COMP%] {\n  font-size: 9px;\n  font-weight: 850;\n  letter-spacing: 0.5px;\n  padding: 2px 8px;\n  border-radius: 99px;\n  width: fit-content;\n  display: inline-block;\n  margin-bottom: 2px;\n}\n.home-bottom-banners-section[_ngcontent-%COMP%]   .bottom-promo-card[_ngcontent-%COMP%]   .bottom-promo-content[_ngcontent-%COMP%]   .promo-text-col[_ngcontent-%COMP%]   .promo-title[_ngcontent-%COMP%] {\n  font-size: 15.5px;\n  font-weight: 850;\n  color: #ffffff;\n  margin: 0;\n  letter-spacing: -0.2px;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.home-bottom-banners-section[_ngcontent-%COMP%]   .bottom-promo-card[_ngcontent-%COMP%]   .bottom-promo-content[_ngcontent-%COMP%]   .promo-text-col[_ngcontent-%COMP%]   .promo-subtitle[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 500;\n  color: rgba(255, 255, 255, 0.82);\n  margin: 0;\n  line-height: 1.3;\n  display: -webkit-box;\n  -webkit-line-clamp: 2;\n  -webkit-box-orient: vertical;\n  overflow: hidden;\n  max-width: 220px;\n}\n.home-bottom-banners-section[_ngcontent-%COMP%]   .bottom-promo-card[_ngcontent-%COMP%]   .bottom-promo-content[_ngcontent-%COMP%]   .promo-text-col[_ngcontent-%COMP%]   .promo-cta-row[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  margin-top: 5px;\n}\n.home-bottom-banners-section[_ngcontent-%COMP%]   .bottom-promo-card[_ngcontent-%COMP%]   .bottom-promo-content[_ngcontent-%COMP%]   .promo-text-col[_ngcontent-%COMP%]   .promo-cta-row[_ngcontent-%COMP%]   .promo-cta-text[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 800;\n  color: #ffffff;\n}\n.home-bottom-banners-section[_ngcontent-%COMP%]   .bottom-promo-card[_ngcontent-%COMP%]   .bottom-promo-content[_ngcontent-%COMP%]   .promo-text-col[_ngcontent-%COMP%]   .promo-cta-row[_ngcontent-%COMP%]   .promo-cta-arrow[_ngcontent-%COMP%] {\n  width: 18px;\n  height: 18px;\n  border-radius: 50%;\n  background: rgba(255, 255, 255, 0.2);\n  -webkit-backdrop-filter: blur(4px);\n  backdrop-filter: blur(4px);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  color: #ffffff;\n  font-size: 10px;\n}\n.home-bottom-banners-section[_ngcontent-%COMP%]   .bottom-promo-card[_ngcontent-%COMP%]   .bottom-promo-content[_ngcontent-%COMP%]   .promo-art-col[_ngcontent-%COMP%] {\n  width: 70px;\n  height: 70px;\n  position: relative;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  flex-shrink: 0;\n}\n.home-bottom-banners-section[_ngcontent-%COMP%]   .bottom-promo-card[_ngcontent-%COMP%]   .bottom-promo-content[_ngcontent-%COMP%]   .promo-art-col[_ngcontent-%COMP%]   .promo-orb-glow[_ngcontent-%COMP%] {\n  position: absolute;\n  width: 60px;\n  height: 60px;\n  border-radius: 50%;\n  background:\n    radial-gradient(\n      circle,\n      rgba(255, 255, 255, 0.22) 0%,\n      rgba(255, 255, 255, 0) 70%);\n  filter: blur(8px);\n}\n.home-bottom-banners-section[_ngcontent-%COMP%]   .bottom-promo-card[_ngcontent-%COMP%]   .bottom-promo-content[_ngcontent-%COMP%]   .promo-art-col[_ngcontent-%COMP%]   .promo-art-emoji[_ngcontent-%COMP%] {\n  font-size: 38px;\n  position: relative;\n  z-index: 2;\n  filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.2));\n}\n.home-bottom-banners-section.bottom-skeleton-section[_ngcontent-%COMP%]   .bottom-banner-skeleton-card[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 140px;\n  border-radius: 18px;\n  overflow: hidden;\n  margin: 8px 0;\n}\n.home-bottom-banners-section.bottom-skeleton-section[_ngcontent-%COMP%]   .bottom-banner-skeleton-card[_ngcontent-%COMP%]   .bottom-banner-skeleton-img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  margin: 0;\n  --border-radius: 18px;\n}\n.services-error-card[_ngcontent-%COMP%] {\n  width: 100%;\n  background: #ffffff;\n  border-radius: 20px;\n  padding: 30px 20px;\n  border: 1.5px dashed #cbd5e1;\n  text-align: center;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  margin: 12px 0 20px;\n}\n.services-error-card[_ngcontent-%COMP%]   .error-icon-box[_ngcontent-%COMP%] {\n  width: 48px;\n  height: 48px;\n  border-radius: 50%;\n  background: #fef2f2;\n  color: #ef4444;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 24px;\n  margin-bottom: 10px;\n}\n.services-error-card[_ngcontent-%COMP%]   .error-title[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 15.5px;\n  font-weight: 800;\n  color: #0f172a;\n}\n.services-error-card[_ngcontent-%COMP%]   .error-desc[_ngcontent-%COMP%] {\n  margin: 4px 0 16px;\n  font-size: 12px;\n  color: #64748b;\n  max-width: 280px;\n}\n.services-error-card[_ngcontent-%COMP%]   .btn-retry-services[_ngcontent-%COMP%] {\n  background: #7c3aed;\n  color: #ffffff;\n  border: none;\n  border-radius: 99px;\n  padding: 8px 18px;\n  font-size: 12.5px;\n  font-weight: 800;\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n  cursor: pointer;\n  box-shadow: 0 4px 12px rgba(124, 58, 237, 0.25);\n  transition: transform 0.15s ease;\n}\n.services-error-card[_ngcontent-%COMP%]   .btn-retry-services[_ngcontent-%COMP%]:active {\n  transform: scale(0.96);\n}\n.bottom-nav-spacer[_ngcontent-%COMP%] {\n  min-height: calc(80px + env(safe-area-inset-bottom, 0px));\n  height: calc(80px + env(safe-area-inset-bottom, 0px));\n  width: 100%;\n}\n.location-checking-backdrop[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  background: rgba(15, 23, 42, 0.72);\n  backdrop-filter: blur(10px);\n  -webkit-backdrop-filter: blur(10px);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  padding: 24px 20px;\n  z-index: 10000;\n}\n.location-checking-card[_ngcontent-%COMP%] {\n  position: relative;\n  background: #ffffff;\n  border-radius: 28px;\n  padding: 34px 24px 26px;\n  width: 100%;\n  max-width: 335px;\n  text-align: center;\n  box-shadow: 0 24px 50px rgba(15, 23, 42, 0.25);\n  border: 1px solid rgba(226, 232, 240, 0.8);\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n}\n.loc-badge-wrap[_ngcontent-%COMP%] {\n  position: relative;\n  width: 72px;\n  height: 72px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin-bottom: 20px;\n}\n.loc-badge-wrap[_ngcontent-%COMP%]   .radar-ring[_ngcontent-%COMP%] {\n  position: absolute;\n  border-radius: 50%;\n  border: 2px solid rgba(160, 0, 226, 0.35);\n  animation: _ngcontent-%COMP%_radarPulse 2s cubic-bezier(0.25, 1, 0.5, 1) infinite;\n}\n.loc-badge-wrap[_ngcontent-%COMP%]   .radar-ring.r1[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n}\n.loc-badge-wrap[_ngcontent-%COMP%]   .radar-ring.r2[_ngcontent-%COMP%] {\n  width: 130%;\n  height: 130%;\n  animation-delay: 0.6s;\n}\n.loc-badge-wrap[_ngcontent-%COMP%]   .loc-badge-circle[_ngcontent-%COMP%] {\n  width: 64px;\n  height: 64px;\n  border-radius: 50%;\n  background:\n    linear-gradient(\n      135deg,\n      #a000e2 0%,\n      #7c3aed 100%);\n  color: #ffffff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 28px;\n  box-shadow: 0 8px 22px rgba(160, 0, 226, 0.3);\n  position: relative;\n  z-index: 2;\n}\n.loc-badge-wrap[_ngcontent-%COMP%]   .loc-badge-circle.warning[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #ea580c 0%,\n      #f59e0b 100%);\n  box-shadow: 0 8px 22px rgba(234, 88, 12, 0.3);\n}\n.loc-badge-wrap[_ngcontent-%COMP%]   .loc-badge-circle.rose[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #e11d48 0%,\n      #f43f5e 100%);\n  box-shadow: 0 8px 22px rgba(225, 29, 72, 0.3);\n}\n@keyframes _ngcontent-%COMP%_radarPulse {\n  0% {\n    transform: scale(0.8);\n    opacity: 0.8;\n  }\n  100% {\n    transform: scale(1.6);\n    opacity: 0;\n  }\n}\n.loc-modal-title[_ngcontent-%COMP%] {\n  font-size: 18px;\n  font-weight: 850;\n  color: #0f172a;\n  margin: 0 0 8px 0;\n  letter-spacing: -0.2px;\n}\n.loc-modal-desc[_ngcontent-%COMP%] {\n  font-size: 13px;\n  line-height: 1.5;\n  color: #64748b;\n  margin: 0 0 20px 0;\n  padding: 0 4px;\n}\n.loc-progress-bar[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 4px;\n  background: #f1f5f9;\n  border-radius: 99px;\n  overflow: hidden;\n  position: relative;\n  margin-bottom: 16px;\n}\n.loc-progress-bar[_ngcontent-%COMP%]   .loc-progress-indicator[_ngcontent-%COMP%] {\n  position: absolute;\n  height: 100%;\n  width: 40%;\n  background:\n    linear-gradient(\n      90deg,\n      #a000e2,\n      #c084fc);\n  border-radius: 99px;\n  animation: _ngcontent-%COMP%_indeterminateSlide 1.5s infinite ease-in-out;\n}\n@keyframes _ngcontent-%COMP%_indeterminateSlide {\n  0% {\n    left: -40%;\n  }\n  100% {\n    left: 100%;\n  }\n}\n.loc-modal-footnote[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  font-size: 11px;\n  font-weight: 650;\n  color: #94a3b8;\n}\n.loc-modal-footnote[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: #10b981;\n}\n.btn-loc-resolve[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 48px;\n  border-radius: 14px;\n  border: none;\n  background:\n    linear-gradient(\n      135deg,\n      #a000e2 0%,\n      #7c3aed 100%);\n  color: #ffffff;\n  font-size: 13.5px;\n  font-weight: 800;\n  letter-spacing: 0.3px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 8px;\n  cursor: pointer;\n  box-shadow: 0 6px 18px rgba(160, 0, 226, 0.28);\n  transition: all 0.2s ease;\n  margin-bottom: 14px;\n}\n.btn-loc-resolve[_ngcontent-%COMP%]:active {\n  transform: scale(0.97);\n}\n.btn-loc-resolve[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n}\n.loc-monitoring-pill[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 7px;\n  font-size: 11.5px;\n  font-weight: 600;\n  color: #64748b;\n  background: #f8fafc;\n  padding: 6px 12px;\n  border-radius: 99px;\n  border: 1px solid #f1f5f9;\n}\n.loc-monitoring-pill[_ngcontent-%COMP%]   .pulse-dot-amber[_ngcontent-%COMP%] {\n  width: 8px;\n  height: 8px;\n  border-radius: 50%;\n  background: #f59e0b;\n  box-shadow: 0 0 0 3px rgba(245, 158, 11, 0.2);\n  animation: _ngcontent-%COMP%_dotPulseAmber 1.4s infinite;\n}\n.loc-monitoring-pill[_ngcontent-%COMP%]   .pulse-dot-rose[_ngcontent-%COMP%] {\n  width: 8px;\n  height: 8px;\n  border-radius: 50%;\n  background: #f43f5e;\n  box-shadow: 0 0 0 3px rgba(244, 63, 94, 0.2);\n  animation: _ngcontent-%COMP%_dotPulseRose 1.4s infinite;\n}\n@keyframes _ngcontent-%COMP%_dotPulseAmber {\n  0% {\n    box-shadow: 0 0 0 0 rgba(245, 158, 11, 0.6);\n  }\n  70% {\n    box-shadow: 0 0 0 6px rgba(245, 158, 11, 0);\n  }\n  100% {\n    box-shadow: 0 0 0 0 rgba(245, 158, 11, 0);\n  }\n}\n@keyframes _ngcontent-%COMP%_dotPulseRose {\n  0% {\n    box-shadow: 0 0 0 0 rgba(244, 63, 94, 0.6);\n  }\n  70% {\n    box-shadow: 0 0 0 6px rgba(244, 63, 94, 0);\n  }\n  100% {\n    box-shadow: 0 0 0 0 rgba(244, 63, 94, 0);\n  }\n}\n.bottom-nav-spacer[_ngcontent-%COMP%] {\n  height: 24px;\n  width: 100%;\n  transition: height 0.2s ease;\n}\n.bottom-nav-spacer.has-active-orders[_ngcontent-%COMP%] {\n  height: 76px;\n}\n.active-orders-sheet-modal[_ngcontent-%COMP%] {\n  --border-radius: 24px 24px 0 0;\n  --background: #ffffff;\n}\n.active-orders-sheet-modal[_ngcontent-%COMP%]::part(content) {\n  border-radius: 24px 24px 0 0;\n  background: #ffffff;\n}\n.active-orders-sheet-modal[_ngcontent-%COMP%]   .sheet-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  height: 100%;\n  background: #ffffff;\n  padding-bottom: max(env(safe-area-inset-bottom, 0px), 16px);\n}\n.active-orders-sheet-modal[_ngcontent-%COMP%]   .sheet-container[_ngcontent-%COMP%]   .sheet-header[_ngcontent-%COMP%] {\n  padding: 12px 18px 14px;\n  border-bottom: 1px solid #f1f5f9;\n}\n.active-orders-sheet-modal[_ngcontent-%COMP%]   .sheet-container[_ngcontent-%COMP%]   .sheet-header[_ngcontent-%COMP%]   .sheet-handle-bar[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 4px;\n  background: #cbd5e1;\n  border-radius: 99px;\n  margin: 0 auto 12px;\n}\n.active-orders-sheet-modal[_ngcontent-%COMP%]   .sheet-container[_ngcontent-%COMP%]   .sheet-header[_ngcontent-%COMP%]   .sheet-title-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n.active-orders-sheet-modal[_ngcontent-%COMP%]   .sheet-container[_ngcontent-%COMP%]   .sheet-header[_ngcontent-%COMP%]   .sheet-title-row[_ngcontent-%COMP%]   .sheet-title-col[_ngcontent-%COMP%]   .sheet-title[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 17px;\n  font-weight: 800;\n  color: #0f172a;\n}\n.active-orders-sheet-modal[_ngcontent-%COMP%]   .sheet-container[_ngcontent-%COMP%]   .sheet-header[_ngcontent-%COMP%]   .sheet-title-row[_ngcontent-%COMP%]   .sheet-title-col[_ngcontent-%COMP%]   .sheet-sub[_ngcontent-%COMP%] {\n  margin: 2px 0 0;\n  font-size: 12px;\n  color: #64748b;\n}\n.active-orders-sheet-modal[_ngcontent-%COMP%]   .sheet-container[_ngcontent-%COMP%]   .sheet-header[_ngcontent-%COMP%]   .sheet-title-row[_ngcontent-%COMP%]   .sheet-close-btn[_ngcontent-%COMP%] {\n  width: 32px;\n  height: 32px;\n  border-radius: 50%;\n  background: #f1f5f9;\n  border: none;\n  color: #475569;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 18px;\n  cursor: pointer;\n}\n.active-orders-sheet-modal[_ngcontent-%COMP%]   .sheet-container[_ngcontent-%COMP%]   .orders-list-content[_ngcontent-%COMP%] {\n  padding: 14px 16px;\n  overflow-y: auto;\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n}\n.active-orders-sheet-modal[_ngcontent-%COMP%]   .sheet-container[_ngcontent-%COMP%]   .orders-list-content[_ngcontent-%COMP%]   .active-order-item-card[_ngcontent-%COMP%] {\n  background: #f8fafc;\n  border: 1.5px solid #e2e8f0;\n  border-radius: 16px;\n  padding: 14px;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 12px;\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n.active-orders-sheet-modal[_ngcontent-%COMP%]   .sheet-container[_ngcontent-%COMP%]   .orders-list-content[_ngcontent-%COMP%]   .active-order-item-card[_ngcontent-%COMP%]:active {\n  transform: scale(0.98);\n  background: #f1f5f9;\n  border-color: #cbd5e1;\n}\n.active-orders-sheet-modal[_ngcontent-%COMP%]   .sheet-container[_ngcontent-%COMP%]   .orders-list-content[_ngcontent-%COMP%]   .active-order-item-card[_ngcontent-%COMP%]   .item-card-left[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  min-width: 0;\n  flex: 1;\n}\n.active-orders-sheet-modal[_ngcontent-%COMP%]   .sheet-container[_ngcontent-%COMP%]   .orders-list-content[_ngcontent-%COMP%]   .active-order-item-card[_ngcontent-%COMP%]   .item-card-left[_ngcontent-%COMP%]   .order-icon-box[_ngcontent-%COMP%] {\n  width: 42px;\n  height: 42px;\n  border-radius: 12px;\n  background: #f3e8ff;\n  color: #a000e2;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 20px;\n  flex-shrink: 0;\n}\n.active-orders-sheet-modal[_ngcontent-%COMP%]   .sheet-container[_ngcontent-%COMP%]   .orders-list-content[_ngcontent-%COMP%]   .active-order-item-card[_ngcontent-%COMP%]   .item-card-left[_ngcontent-%COMP%]   .order-details-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n  min-width: 0;\n}\n.active-orders-sheet-modal[_ngcontent-%COMP%]   .sheet-container[_ngcontent-%COMP%]   .orders-list-content[_ngcontent-%COMP%]   .active-order-item-card[_ngcontent-%COMP%]   .item-card-left[_ngcontent-%COMP%]   .order-details-col[_ngcontent-%COMP%]   .order-meta-line[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.active-orders-sheet-modal[_ngcontent-%COMP%]   .sheet-container[_ngcontent-%COMP%]   .orders-list-content[_ngcontent-%COMP%]   .active-order-item-card[_ngcontent-%COMP%]   .item-card-left[_ngcontent-%COMP%]   .order-details-col[_ngcontent-%COMP%]   .order-meta-line[_ngcontent-%COMP%]   .order-number[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  font-weight: 800;\n  color: #0f172a;\n}\n.active-orders-sheet-modal[_ngcontent-%COMP%]   .sheet-container[_ngcontent-%COMP%]   .orders-list-content[_ngcontent-%COMP%]   .active-order-item-card[_ngcontent-%COMP%]   .item-card-left[_ngcontent-%COMP%]   .order-details-col[_ngcontent-%COMP%]   .order-meta-line[_ngcontent-%COMP%]   .order-time[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #94a3b8;\n  font-weight: 500;\n}\n.active-orders-sheet-modal[_ngcontent-%COMP%]   .sheet-container[_ngcontent-%COMP%]   .orders-list-content[_ngcontent-%COMP%]   .active-order-item-card[_ngcontent-%COMP%]   .item-card-left[_ngcontent-%COMP%]   .order-details-col[_ngcontent-%COMP%]   .order-status-badge[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  font-size: 12px;\n  color: #059669;\n  font-weight: 650;\n}\n.active-orders-sheet-modal[_ngcontent-%COMP%]   .sheet-container[_ngcontent-%COMP%]   .orders-list-content[_ngcontent-%COMP%]   .active-order-item-card[_ngcontent-%COMP%]   .item-card-left[_ngcontent-%COMP%]   .order-details-col[_ngcontent-%COMP%]   .order-status-badge[_ngcontent-%COMP%]   .mini-pulse-dot[_ngcontent-%COMP%] {\n  width: 7px;\n  height: 7px;\n  border-radius: 50%;\n  background: #10b981;\n  flex-shrink: 0;\n}\n.active-orders-sheet-modal[_ngcontent-%COMP%]   .sheet-container[_ngcontent-%COMP%]   .orders-list-content[_ngcontent-%COMP%]   .active-order-item-card[_ngcontent-%COMP%]   .item-card-left[_ngcontent-%COMP%]   .order-details-col[_ngcontent-%COMP%]   .order-amount[_ngcontent-%COMP%] {\n  font-size: 12.5px;\n  font-weight: 750;\n  color: #334155;\n}\n.active-orders-sheet-modal[_ngcontent-%COMP%]   .sheet-container[_ngcontent-%COMP%]   .orders-list-content[_ngcontent-%COMP%]   .active-order-item-card[_ngcontent-%COMP%]   .item-card-right[_ngcontent-%COMP%]   .btn-track-item[_ngcontent-%COMP%] {\n  background: #a000e2;\n  color: #ffffff;\n  border: none;\n  border-radius: 99px;\n  padding: 6px 14px;\n  font-size: 12px;\n  font-weight: 750;\n  display: inline-flex;\n  align-items: center;\n  gap: 3px;\n  cursor: pointer;\n}\n.active-orders-sheet-modal[_ngcontent-%COMP%]   .sheet-container[_ngcontent-%COMP%]   .orders-list-content[_ngcontent-%COMP%]   .active-order-item-card[_ngcontent-%COMP%]   .item-card-right[_ngcontent-%COMP%]   .btn-track-item[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 13px;\n}\n/*# sourceMappingURL=home.page.css.map */'] });
var HomePage = _HomePage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(HomePage, { className: "HomePage", filePath: "src/app/pages/home/home.page.ts", lineNumber: 109 });
})();
export {
  HomePage
};
//# sourceMappingURL=home.page-XIIAU3X5.js.map
