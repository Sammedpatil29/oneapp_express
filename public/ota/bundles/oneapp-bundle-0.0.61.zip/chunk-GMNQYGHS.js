import{a}from"./chunk-7KGURMOZ.js";import"./chunk-CVT7ZQ5I.js";export{a as startFocusVisible};
