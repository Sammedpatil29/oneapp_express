import {
  ErrorComponent
} from "./chunk-DH3PQJ2C.js";
import {
  ProductCardComponent
} from "./chunk-LSG5LT6I.js";
import {
  GroceryService
} from "./chunk-UOJDERHI.js";
import {
  add,
  addIcons,
  arrowBackOutline,
  cartOutline,
  remove,
  searchOutline
} from "./chunk-I7AJKZVE.js";
import {
  AuthService
} from "./chunk-EB6T6TPT.js";
import "./chunk-OE5MTPUR.js";
import "./chunk-YJYUHAOC.js";
import "./chunk-XR3JUECC.js";
import {
  IonButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonIcon,
  IonSkeletonText,
  IonTitle,
  IonToolbar
} from "./chunk-CJE2NDTY.js";
import {
  ChangeDetectorRef,
  CommonModule,
  FormsModule,
  NavController,
  NgForOf,
  NgIf,
  Router,
  TitleCasePipe,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind1,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1
} from "./chunk-Z7XNNJSA.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/grocery-by-category/grocery-by-category.page.ts
var _c0 = () => [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
var _c1 = () => [1, 2, 3, 4, 5, 6];
function GroceryByCategoryPage_Conditional_11_div_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 18)(1, "div", 19);
    \u0275\u0275element(2, "ion-skeleton-text", 20);
    \u0275\u0275elementEnd();
    \u0275\u0275element(3, "ion-skeleton-text", 21);
    \u0275\u0275elementEnd();
  }
}
function GroceryByCategoryPage_Conditional_11_div_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 22);
    \u0275\u0275element(1, "ion-skeleton-text", 23)(2, "ion-skeleton-text", 24)(3, "ion-skeleton-text", 25);
    \u0275\u0275elementStart(4, "div", 26);
    \u0275\u0275element(5, "ion-skeleton-text", 27)(6, "ion-skeleton-text", 28);
    \u0275\u0275elementEnd()();
  }
}
function GroceryByCategoryPage_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 8)(1, "div", 10);
    \u0275\u0275template(2, GroceryByCategoryPage_Conditional_11_div_2_Template, 4, 0, "div", 11);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 12)(4, "div", 13);
    \u0275\u0275element(5, "ion-skeleton-text", 14)(6, "ion-skeleton-text", 15);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "div", 16);
    \u0275\u0275template(8, GroceryByCategoryPage_Conditional_11_div_8_Template, 7, 0, "div", 17);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    \u0275\u0275advance(2);
    \u0275\u0275property("ngForOf", \u0275\u0275pureFunction0(2, _c0));
    \u0275\u0275advance(6);
    \u0275\u0275property("ngForOf", \u0275\u0275pureFunction0(3, _c1));
  }
}
function GroceryByCategoryPage_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "app-error", 29);
    \u0275\u0275listener("retry", function GroceryByCategoryPage_Conditional_12_Template_app_error_retry_0_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.getCategories());
    });
    \u0275\u0275elementEnd();
  }
}
function GroceryByCategoryPage_Conditional_13_div_2_div_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "div", 38);
  }
}
function GroceryByCategoryPage_Conditional_13_div_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 34);
    \u0275\u0275listener("click", function GroceryByCategoryPage_Conditional_13_div_2_Template_div_click_0_listener() {
      const cat_r4 = \u0275\u0275restoreView(_r3).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.selectCategory(cat_r4.name));
    });
    \u0275\u0275elementStart(1, "div", 35);
    \u0275\u0275element(2, "img", 36);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275template(5, GroceryByCategoryPage_Conditional_13_div_2_div_5_Template, 1, 0, "div", 37);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const cat_r4 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275classProp("active", ctx_r1.selectedCategory === cat_r4.name);
    \u0275\u0275advance(2);
    \u0275\u0275property("src", cat_r4.img, \u0275\u0275sanitizeUrl);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(cat_r4.name);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", ctx_r1.selectedCategory === cat_r4.name);
  }
}
function GroceryByCategoryPage_Conditional_13_app_product_card_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "app-product-card", 39);
    \u0275\u0275listener("increase", function GroceryByCategoryPage_Conditional_13_app_product_card_12_Template_app_product_card_increase_0_listener($event) {
      \u0275\u0275restoreView(_r5);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.increase($event));
    })("decrease", function GroceryByCategoryPage_Conditional_13_app_product_card_12_Template_app_product_card_decrease_0_listener($event) {
      \u0275\u0275restoreView(_r5);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.decrease($event));
    })("itemClicked", function GroceryByCategoryPage_Conditional_13_app_product_card_12_Template_app_product_card_itemClicked_0_listener($event) {
      \u0275\u0275restoreView(_r5);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.goToDetails($event));
    });
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const p_r6 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275property("product", p_r6)("qty", ctx_r1.getQty(p_r6.id));
  }
}
function GroceryByCategoryPage_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 8)(1, "div", 10);
    \u0275\u0275template(2, GroceryByCategoryPage_Conditional_13_div_2_Template, 6, 5, "div", 30);
    \u0275\u0275element(3, "div", 31);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "div", 12)(5, "div", 13)(6, "h4");
    \u0275\u0275text(7);
    \u0275\u0275pipe(8, "titlecase");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "small");
    \u0275\u0275text(10);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(11, "div", 16);
    \u0275\u0275template(12, GroceryByCategoryPage_Conditional_13_app_product_card_12_Template, 1, 2, "app-product-card", 32);
    \u0275\u0275elementEnd();
    \u0275\u0275element(13, "div", 33);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(2);
    \u0275\u0275property("ngForOf", ctx_r1.categories);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(8, 4, ctx_r1.selectedCategory));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("", ctx_r1.products.length, " items");
    \u0275\u0275advance(2);
    \u0275\u0275property("ngForOf", ctx_r1.products);
  }
}
var _GroceryByCategoryPage = class _GroceryByCategoryPage {
  // [
  //   { id: 1, stock: '', name: 'Fresh Tomato', weight: '500g', price: 24, oldPrice: 30, discount: 20, img: 'https://cdn-icons-png.flaticon.com/512/1202/1202125.png' },
  //   { id: 2, stock: '', name: 'Red Onion', weight: '1kg', price: 45, oldPrice: 60, discount: 25, img: 'https://cdn-icons-png.flaticon.com/512/765/765580.png' },
  //   { id: 3, stock: '', name: 'Potato', weight: '1kg', price: 35, oldPrice: 40, discount: 0, img: 'https://cdn-icons-png.flaticon.com/512/765/765544.png' },
  //   { id: 4, stock: '', name: 'Carrot', weight: '500g', price: 30, oldPrice: 40, discount: 10, img: 'https://cdn-icons-png.flaticon.com/512/2329/2329954.png' },
  //   { id: 5, stock: '', name: 'Broccoli', weight: '1pc', price: 60, oldPrice: 80, discount: 15, img: 'https://cdn-icons-png.flaticon.com/512/2329/2329905.png' },
  //   { id: 6, stock: '', name: 'Spinach', weight: '1 bunch', price: 15, oldPrice: 20, discount: 0, img: 'https://cdn-icons-png.flaticon.com/512/2329/2329937.png' },
  // ];
  constructor(router, groceryService, authService, cdr, navCtrl) {
    var _a, _b;
    this.router = router;
    this.groceryService = groceryService;
    this.authService = authService;
    this.cdr = cdr;
    this.navCtrl = navCtrl;
    this.selectedCategory = "Veggies";
    this.categories = [];
    this.cartItems = [];
    this.isLoading = false;
    this.isError = false;
    this.products = [];
    addIcons({ arrowBackOutline, searchOutline, cartOutline, add, remove });
    const navigation = this.router.getCurrentNavigation();
    if ((_b = (_a = navigation == null ? void 0 : navigation.extras) == null ? void 0 : _a.state) == null ? void 0 : _b["category"]) {
      const catName = navigation.extras.state["category"];
      this.selectedCategory = catName;
      console.log(this.selectedCategory);
    }
  }
  ngOnInit() {
    return __async(this, null, function* () {
      this.token = yield this.authService.getToken();
      this.groceryService.cart$.subscribe((items) => {
        this.cartItems = items;
        console.log("\u{1F6D2} UI Cart Updated:", this.cartItems);
        this.cdr.detectChanges();
      });
      this.getCategories();
    });
  }
  selectCategory(id) {
    this.selectedCategory = id;
    this.getProductsByCat();
  }
  // Helper to get display name
  getCategoryName() {
    var _a;
    return (_a = this.categories.find((c) => c.id === this.selectedCategory)) == null ? void 0 : _a.name;
  }
  getCategories() {
    let params = {
      selectedCategory: this.selectedCategory
    };
    this.isLoading = true;
    this.isError = false;
    this.groceryService.getCategories(params).subscribe((res) => {
      console.log("Categories:", res);
      this.categories = res.data.categories;
      this.products = res.data.products;
      this.selectCategory(this.selectedCategory);
      this.isLoading = false;
    }, (error) => {
      this.isLoading = false;
      this.isError = true;
    });
  }
  getProductsByCat() {
    let params = {
      selectedCategory: this.selectedCategory
    };
    this.groceryService.getProductsByCategory(params).subscribe((res) => {
      console.log("Products by Category:", res);
      this.products = res.data.products;
    });
  }
  goToDetails(product) {
    this.router.navigate([`/layout/grocery-layout/grocery-item-details/${product == null ? void 0 : product.id}`], {
      state: { productId: product == null ? void 0 : product.id }
    });
  }
  increase(productId) {
    this.groceryService.increaseQty(productId, this.token).subscribe({
      next: () => console.log("Increase Success"),
      error: (err) => console.error("API Failed", err)
    });
  }
  decrease(productId) {
    var _a;
    (_a = this.groceryService.decreaseQty(productId, this.token)) == null ? void 0 : _a.subscribe({
      next: () => console.log("Decrease Success"),
      error: (err) => console.error("API Failed", err)
    });
  }
  // --- HELPERS ---
  getQty(productId) {
    if (!this.cartItems || this.cartItems.length === 0)
      return 0;
    const item = this.cartItems.find((i) => String(i.productId) === String(productId));
    return item ? item.quantity : 0;
  }
  gotoSearch() {
    this.router.navigate(["/layout/grocery-layout/grocery-search"]);
  }
  back() {
    this.navCtrl.back();
  }
};
_GroceryByCategoryPage.\u0275fac = function GroceryByCategoryPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _GroceryByCategoryPage)(\u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(GroceryService), \u0275\u0275directiveInject(AuthService), \u0275\u0275directiveInject(ChangeDetectorRef), \u0275\u0275directiveInject(NavController));
};
_GroceryByCategoryPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _GroceryByCategoryPage, selectors: [["app-grocery-by-category"]], decls: 14, vars: 2, consts: [[1, "ion-no-border", "bg-white", "pt-2"], ["slot", "start"], [3, "click"], ["name", "arrow-back-outline", "color", "dark"], [1, "fw-bold", "text-dark"], ["slot", "end"], ["name", "search-outline", "color", "dark"], [1, "bg-light", 3, "fullscreen"], [1, "split-layout"], ["title", "Failed to Load Categories", "subtitle", "Please check your internet connection and try again.", "buttonText", "Retry"], [1, "sidebar"], ["class", "cat-tab", 4, "ngFor", "ngForOf"], [1, "main-content"], [1, "content-header"], ["animated", "", 2, "width", "150px", "height", "24px", "border-radius", "4px"], ["animated", "", 2, "width", "80px", "height", "14px", "margin-top", "4px", "border-radius", "4px"], [1, "product-grid"], ["style", "margin-bottom: 16px;", 4, "ngFor", "ngForOf"], [1, "cat-tab"], [1, "img-circle", 2, "background", "transparent"], ["animated", "", 2, "width", "100%", "height", "100%", "border-radius", "50%"], ["animated", "", 2, "width", "40px", "height", "10px", "margin-top", "8px", "border-radius", "4px"], [2, "margin-bottom", "16px"], ["animated", "", 2, "width", "100%", "height", "140px", "border-radius", "12px"], ["animated", "", 2, "width", "90%", "height", "14px", "margin-top", "8px", "border-radius", "4px"], ["animated", "", 2, "width", "60%", "height", "14px", "margin-top", "4px", "border-radius", "4px"], [2, "display", "flex", "justify-content", "space-between", "align-items", "center", "margin-top", "8px"], ["animated", "", 2, "width", "40%", "height", "18px", "border-radius", "4px"], ["animated", "", 2, "width", "60px", "height", "30px", "border-radius", "6px"], ["title", "Failed to Load Categories", "subtitle", "Please check your internet connection and try again.", "buttonText", "Retry", 3, "retry"], ["class", "cat-tab", 3, "active", "click", 4, "ngFor", "ngForOf"], [2, "height", "200px"], [3, "product", "qty", "increase", "decrease", "itemClicked", 4, "ngFor", "ngForOf"], [2, "height", "80px"], [1, "cat-tab", 3, "click"], [1, "img-circle"], [3, "src"], ["class", "active-strip", 4, "ngIf"], [1, "active-strip"], [3, "increase", "decrease", "itemClicked", "product", "qty"]], template: function GroceryByCategoryPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar")(2, "ion-buttons", 1)(3, "ion-button", 2);
    \u0275\u0275listener("click", function GroceryByCategoryPage_Template_ion_button_click_3_listener() {
      return ctx.back();
    });
    \u0275\u0275element(4, "ion-icon", 3);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "ion-title", 4);
    \u0275\u0275text(6, "All Categories");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "ion-buttons", 5)(8, "ion-button", 2);
    \u0275\u0275listener("click", function GroceryByCategoryPage_Template_ion_button_click_8_listener() {
      return ctx.gotoSearch();
    });
    \u0275\u0275element(9, "ion-icon", 6);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(10, "ion-content", 7);
    \u0275\u0275template(11, GroceryByCategoryPage_Conditional_11_Template, 9, 4, "div", 8)(12, GroceryByCategoryPage_Conditional_12_Template, 1, 0, "app-error", 9)(13, GroceryByCategoryPage_Conditional_13_Template, 14, 6, "div", 8);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance(10);
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.isLoading ? 11 : ctx.isError ? 12 : 13);
  }
}, dependencies: [IonSkeletonText, IonButtons, IonButton, IonIcon, IonTitle, IonContent, IonHeader, IonToolbar, CommonModule, NgForOf, NgIf, TitleCasePipe, FormsModule, ProductCardComponent, ErrorComponent], styles: ["\n\n[_nghost-%COMP%] {\n  display: block;\n  width: 100%;\n  height: 100%;\n}\nion-toolbar[_ngcontent-%COMP%] {\n  --background: #fff;\n  border-bottom: 1px solid #f0f0f0;\n}\n.header-container[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 0 16px;\n}\n.header-container[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  font-weight: 800;\n  font-size: 20px;\n  margin: 0;\n  color: #333;\n}\n.header-container[_ngcontent-%COMP%]   .header-icons[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 24px;\n  color: #333;\n}\n.split-layout[_ngcontent-%COMP%] {\n  display: flex;\n  height: 100%;\n  overflow: hidden;\n}\n.sidebar[_ngcontent-%COMP%] {\n  width: 20%;\n  background: #f3f4f8;\n  height: 100%;\n  overflow-y: auto;\n  border-right: 1px solid #e5e5e5;\n}\n.sidebar[_ngcontent-%COMP%]::-webkit-scrollbar {\n  display: none;\n}\n.sidebar[_ngcontent-%COMP%]   .cat-tab[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  padding: 15px 5px;\n  position: relative;\n  text-align: center;\n  transition: background 0.2s;\n  cursor: pointer;\n}\n.sidebar[_ngcontent-%COMP%]   .cat-tab[_ngcontent-%COMP%]   .img-circle[_ngcontent-%COMP%] {\n  width: 45px;\n  height: 45px;\n  background: #fff;\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin-bottom: 6px;\n  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);\n}\n.sidebar[_ngcontent-%COMP%]   .cat-tab[_ngcontent-%COMP%]   .img-circle[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 28px;\n  height: 28px;\n  object-fit: contain;\n}\n.sidebar[_ngcontent-%COMP%]   .cat-tab[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-size: 10px;\n  color: #666;\n  font-weight: 500;\n  line-height: 1.2;\n}\n.sidebar[_ngcontent-%COMP%]   .cat-tab.active[_ngcontent-%COMP%] {\n  background: #fff;\n}\n.sidebar[_ngcontent-%COMP%]   .cat-tab.active[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: #3d0374;\n  font-weight: 700;\n}\n.sidebar[_ngcontent-%COMP%]   .cat-tab.active[_ngcontent-%COMP%]   .img-circle[_ngcontent-%COMP%] {\n  background: #e9dff5;\n}\n.sidebar[_ngcontent-%COMP%]   .cat-tab.active[_ngcontent-%COMP%]   .img-circle[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  transform: scale(1.1);\n}\n.sidebar[_ngcontent-%COMP%]   .cat-tab.active[_ngcontent-%COMP%]   .active-strip[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 0;\n  top: 20%;\n  bottom: 20%;\n  width: 4px;\n  background: #3d0374;\n  border-radius: 4px 0 0 4px;\n}\n.main-content[_ngcontent-%COMP%] {\n  width: 80%;\n  background: #ffffff;\n  height: 100%;\n  overflow-y: auto;\n  padding: 10px 10px 80px 10px;\n}\n.main-content[_ngcontent-%COMP%]::-webkit-scrollbar {\n  display: none;\n}\n.main-content[_ngcontent-%COMP%]   .content-header[_ngcontent-%COMP%] {\n  margin-bottom: 15px;\n  padding-left: 5px;\n}\n.main-content[_ngcontent-%COMP%]   .content-header[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  margin: 0;\n  font-weight: 800;\n  font-size: 18px;\n  color: #222;\n}\n.main-content[_ngcontent-%COMP%]   .content-header[_ngcontent-%COMP%]   small[_ngcontent-%COMP%] {\n  color: #888;\n  font-size: 12px;\n}\n.main-content[_ngcontent-%COMP%]   .product-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(2, minmax(0, 1fr));\n  gap: 12px;\n  padding-bottom: 20px;\n}\n@media (min-width: 768px) {\n  .main-content[_ngcontent-%COMP%]   .product-grid[_ngcontent-%COMP%] {\n    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));\n  }\n}\n/*# sourceMappingURL=grocery-by-category.page.css.map */"] });
var GroceryByCategoryPage = _GroceryByCategoryPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(GroceryByCategoryPage, { className: "GroceryByCategoryPage", filePath: "src/app/grocery-by-category/grocery-by-category.page.ts", lineNumber: 21 });
})();
export {
  GroceryByCategoryPage
};
//# sourceMappingURL=grocery-by-category.page-37CTBFTY.js.map
