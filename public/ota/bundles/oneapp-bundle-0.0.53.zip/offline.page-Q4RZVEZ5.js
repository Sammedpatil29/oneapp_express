import {
  Network
} from "./chunk-TKIKIY3A.js";
import {
  IonButton,
  IonContent,
  IonIcon
} from "./chunk-CJE2NDTY.js";
import {
  ɵsetClassDebugInfo,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵlistener,
  ɵɵtext
} from "./chunk-Z7XNNJSA.js";
import "./chunk-FH4NU4VH.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/offline/offline.page.ts
var _OfflinePage = class _OfflinePage {
  constructor() {
    this.remoteUrl = "https://pintu-teal.vercel.app/";
  }
  retry() {
    return __async(this, null, function* () {
      const status = yield Network.getStatus();
      if (status.connected) {
      }
    });
  }
};
_OfflinePage.\u0275fac = function OfflinePage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _OfflinePage)();
};
_OfflinePage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _OfflinePage, selectors: [["app-offline"]], decls: 25, vars: 0, consts: [["fullscreen", ""], [1, "h-100", "d-flex", "flex-column", "justify-content-center", "align-items-center", "px-4"], ["id", "ticket-container"], [1, "ticket-main"], [1, "event-banner", "offline-banner"], [1, "overlay"], [1, "event-title-overlay"], [1, "badge-category"], [1, "p-3", "text-center"], [1, "success-icon-bg", "mx-auto", "mb-2"], ["name", "wifi-off-outline", "color", "danger", 2, "font-size", "40px"], [1, "text-muted", "mt-2"], [1, "ticket-rip"], [1, "circle-left"], [1, "dashed-line"], [1, "circle-right"], [1, "ticket-stub", "p-3", "text-center"], ["expand", "block", "shape", "round", "color", "dark", 3, "click"], [1, "text-muted", "mt-2", 2, "font-size", "12px"]], template: function OfflinePage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 4);
    \u0275\u0275element(5, "div", 5);
    \u0275\u0275elementStart(6, "div", 6)(7, "span", 7);
    \u0275\u0275text(8, "Offline");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "h1");
    \u0275\u0275text(10, "No Internet Connection");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(11, "div", 8)(12, "div", 9);
    \u0275\u0275element(13, "ion-icon", 10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "p", 11);
    \u0275\u0275text(15, " Looks like you're not connected to the internet. Please check your connection and try again. ");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(16, "div", 12);
    \u0275\u0275element(17, "div", 13)(18, "div", 14)(19, "div", 15);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "div", 16)(21, "ion-button", 17);
    \u0275\u0275listener("click", function OfflinePage_Template_ion_button_click_21_listener() {
      return ctx.retry();
    });
    \u0275\u0275text(22, " Retry Connection ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(23, "p", 18);
    \u0275\u0275text(24, " Turn on mobile data or Wi-Fi ");
    \u0275\u0275elementEnd()()()()();
  }
}, dependencies: [IonIcon, IonButton, IonContent], styles: ["\n\nion-content[_ngcontent-%COMP%] {\n  --background: #f8fafc;\n}\n.success-icon-bg[_ngcontent-%COMP%] {\n  width: 80px;\n  height: 80px;\n  background: rgba(239, 68, 68, 0.1);\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n#ticket-container[_ngcontent-%COMP%] {\n  width: 100%;\n  max-width: 380px;\n  margin: 5px auto 0;\n  box-shadow: 0 10px 30px -10px rgba(0, 0, 0, 0.15);\n  border-radius: 20px;\n  overflow: hidden;\n  background: transparent;\n}\n.ticket-main[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 20px 20px 0 0;\n  position: relative;\n}\n.event-banner[_ngcontent-%COMP%] {\n  height: 160px;\n  background-size: cover;\n  background-position: center;\n  position: relative;\n}\n.event-banner[_ngcontent-%COMP%]   .overlay[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  background:\n    linear-gradient(\n      to top,\n      rgba(0, 0, 0, 0.85),\n      transparent);\n}\n.event-banner[_ngcontent-%COMP%]   .event-title-overlay[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 15px;\n  left: 15px;\n  right: 15px;\n  color: white;\n}\n.event-banner[_ngcontent-%COMP%]   .event-title-overlay[_ngcontent-%COMP%]   .badge-category[_ngcontent-%COMP%] {\n  background: #6366f1;\n  color: white;\n  font-size: 10px;\n  padding: 4px 8px;\n  border-radius: 6px;\n  text-transform: uppercase;\n  font-weight: 700;\n  letter-spacing: 0.5px;\n}\n.event-banner[_ngcontent-%COMP%]   .event-title-overlay[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%] {\n  margin: 8px 0 0;\n  font-size: 22px;\n  font-weight: 800;\n  line-height: 1.2;\n  text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);\n}\n.offline-banner[_ngcontent-%COMP%] {\n  background-image:\n    linear-gradient(\n      135deg,\n      #ef4444,\n      #991b1b);\n}\n.ticket-rip[_ngcontent-%COMP%] {\n  height: 30px;\n  background: #ffffff;\n  position: relative;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.ticket-rip[_ngcontent-%COMP%]   .dashed-line[_ngcontent-%COMP%] {\n  width: 85%;\n  border-top: 2px dashed #e2e8f0;\n}\n.ticket-rip[_ngcontent-%COMP%]   .circle-left[_ngcontent-%COMP%], \n.ticket-rip[_ngcontent-%COMP%]   .circle-right[_ngcontent-%COMP%] {\n  position: absolute;\n  width: 30px;\n  height: 30px;\n  background: #f8fafc;\n  border-radius: 50%;\n  top: 0;\n}\n.ticket-rip[_ngcontent-%COMP%]   .circle-left[_ngcontent-%COMP%] {\n  left: -15px;\n}\n.ticket-rip[_ngcontent-%COMP%]   .circle-right[_ngcontent-%COMP%] {\n  right: -15px;\n}\n.ticket-stub[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 0 0 20px 20px;\n}\n/*# sourceMappingURL=offline.page.css.map */"] });
var OfflinePage = _OfflinePage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(OfflinePage, { className: "OfflinePage", filePath: "src/app/offline/offline.page.ts", lineNumber: 11 });
})();
export {
  OfflinePage
};
//# sourceMappingURL=offline.page-Q4RZVEZ5.js.map
