import {
  LocationService
} from "./chunk-4TQR4WSH.js";
import {
  addIcons,
  bookmarkOutline,
  briefcaseOutline,
  businessOutline,
  callOutline,
  checkmarkCircle,
  closeOutline,
  createOutline,
  homeOutline,
  locationOutline,
  personOutline,
  star,
  starOutline
} from "./chunk-I7AJKZVE.js";
import {
  AuthService
} from "./chunk-EB6T6TPT.js";
import {
  IonIcon,
  IonSpinner
} from "./chunk-CJE2NDTY.js";
import {
  CommonModule,
  DefaultValueAccessor,
  EventEmitter,
  FormsModule,
  NgControlStatus,
  NgModel,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-Z7XNNJSA.js";
import {
  __async,
  __spreadProps,
  __spreadValues
} from "./chunk-6B6DTIB5.js";

// src/app/components/address-save-form/address-save-form.component.ts
function AddressSaveFormComponent_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 10);
    \u0275\u0275element(1, "ion-icon", 9);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx_r0.errorMessage);
  }
}
function AddressSaveFormComponent_Conditional_77_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 39);
  }
}
function AddressSaveFormComponent_Conditional_82_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 39);
  }
}
function AddressSaveFormComponent_Conditional_87_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 39);
  }
}
function AddressSaveFormComponent_Conditional_88_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 42)(1, "input", 52);
    \u0275\u0275twoWayListener("ngModelChange", function AddressSaveFormComponent_Conditional_88_Template_input_ngModelChange_1_listener($event) {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r0.customLabel, $event) || (ctx_r0.customLabel = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275twoWayProperty("ngModel", ctx_r0.customLabel);
  }
}
function AddressSaveFormComponent_Conditional_101_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-spinner", 53);
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r0.isEditMode ? "Updating Address..." : "Saving Address...");
  }
}
function AddressSaveFormComponent_Conditional_102_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r0.isEditMode ? "Update Address" : "Save Address");
  }
}
var _AddressSaveFormComponent = class _AddressSaveFormComponent {
  get isEditMode() {
    var _a;
    return Boolean((_a = this.editAddress) == null ? void 0 : _a.id);
  }
  constructor(locationService, authService) {
    this.locationService = locationService;
    this.authService = authService;
    this.initialCoords = { lat: 12.8556, lng: 77.6818 };
    this.initialAddress = "";
    this.routeSource = "savedAddress";
    this.editAddress = null;
    this.addressSaved = new EventEmitter();
    this.cancel = new EventEmitter();
    this.houseNo = "";
    this.buildingName = "";
    this.landmark = "";
    this.currentAddress = "";
    this.receiverName = "";
    this.receiverPhone = "";
    this.selectedLabel = "home";
    this.customLabel = "";
    this.isPrimary = false;
    this.isSaving = false;
    this.errorMessage = "";
    this.token = "";
    addIcons({
      homeOutline,
      briefcaseOutline,
      bookmarkOutline,
      closeOutline,
      checkmarkCircle,
      locationOutline,
      callOutline,
      personOutline,
      businessOutline,
      createOutline,
      star,
      starOutline
    });
  }
  ngOnInit() {
    return __async(this, null, function* () {
      this.token = (yield this.authService.getToken()) || "";
      if (this.editAddress) {
        this.houseNo = this.editAddress.house_no || "";
        this.buildingName = this.editAddress.building_name || "";
        this.landmark = this.editAddress.landmark || "";
        this.currentAddress = this.editAddress.address || this.initialAddress || "";
        this.receiverName = this.editAddress.receiver_name || "";
        this.receiverPhone = this.editAddress.receiver_contact || "";
        this.isPrimary = Boolean(this.editAddress.is_primary);
        const l = (this.editAddress.label || "home").toLowerCase();
        if (["home", "work"].includes(l)) {
          this.selectedLabel = l;
        } else {
          this.selectedLabel = "other";
          this.customLabel = this.editAddress.label || "";
        }
        if (this.editAddress.lat && this.editAddress.lng) {
          this.initialCoords = {
            lat: Number(this.editAddress.lat),
            lng: Number(this.editAddress.lng)
          };
        }
      } else {
        this.currentAddress = this.initialAddress;
        const user = this.authService.getCurrentUser();
        if (user) {
          this.receiverName = user.name || `${user.first_name || ""} ${user.last_name || ""}`.trim() || "";
          this.receiverPhone = user.phone || "";
        }
      }
    });
  }
  selectLabel(label) {
    this.selectedLabel = label;
  }
  onCancel() {
    this.cancel.emit();
  }
  save() {
    var _a;
    if (!this.houseNo || !this.houseNo.trim()) {
      this.errorMessage = "Please enter House / Flat / Floor number.";
      return;
    }
    if (!this.currentAddress || !this.currentAddress.trim()) {
      this.errorMessage = "Please verify street address.";
      return;
    }
    this.errorMessage = "";
    this.isSaving = true;
    const labelToSave = this.selectedLabel === "other" && this.customLabel.trim() ? this.customLabel.trim() : this.selectedLabel || "Home";
    const params = {
      lat: this.initialCoords.lat,
      lng: this.initialCoords.lng,
      address: this.currentAddress.trim(),
      house_no: this.houseNo.trim(),
      building_name: this.buildingName ? this.buildingName.trim() : void 0,
      landmark: this.landmark ? this.landmark.trim() : "Near main road",
      label: labelToSave,
      receiver_name: this.receiverName ? this.receiverName.trim() : void 0,
      receiver_contact: this.receiverPhone ? this.receiverPhone.trim() : void 0,
      is_primary: this.isPrimary
    };
    if (this.isEditMode && ((_a = this.editAddress) == null ? void 0 : _a.id)) {
      this.locationService.updateAddress(this.editAddress.id, params, this.token).subscribe({
        next: (res) => {
          const updatedAddr = (res == null ? void 0 : res.data) || __spreadValues(__spreadValues({}, this.editAddress), params);
          this.isSaving = false;
          if (this.isPrimary) {
            this.locationService.setPrimaryAddress(this.editAddress.id, this.token).subscribe({
              next: () => console.log("\u2705 Updated address set as primary in DB"),
              error: (err) => console.warn("Set primary on update error:", err)
            });
          }
          const savedLoc = localStorage.getItem("location");
          if (savedLoc) {
            try {
              const parsed = JSON.parse(savedLoc);
              if ((parsed == null ? void 0 : parsed.id) === this.editAddress.id) {
                const locData = __spreadProps(__spreadValues({}, parsed), {
                  lat: updatedAddr.lat || params.lat,
                  lng: updatedAddr.lng || params.lng,
                  label: updatedAddr.label || params.label,
                  address: updatedAddr.address || params.address,
                  house_no: updatedAddr.house_no || params.house_no,
                  building_name: updatedAddr.building_name || params.building_name,
                  landmark: updatedAddr.landmark || params.landmark,
                  area: (updatedAddr.address || params.address || "").split(",")[0]
                });
                this.locationService.setAddress(locData);
              }
            } catch (e) {
            }
          }
          this.addressSaved.emit(updatedAddr);
        },
        error: (err) => {
          var _a2;
          this.isSaving = false;
          this.errorMessage = ((_a2 = err == null ? void 0 : err.error) == null ? void 0 : _a2.message) || "Failed to update address. Please try again.";
        }
      });
    } else {
      this.locationService.saveAddress(params, this.token).subscribe({
        next: (res) => {
          const savedAddr = (res == null ? void 0 : res.data) || res;
          this.isSaving = false;
          if (this.isPrimary && (savedAddr == null ? void 0 : savedAddr.id)) {
            this.locationService.setPrimaryAddress(savedAddr.id, this.token).subscribe({
              next: () => console.log("\u2705 New address set as primary in DB"),
              error: (err) => console.warn("Set primary on create error:", err)
            });
          }
          if (savedAddr == null ? void 0 : savedAddr.id) {
            const locData = {
              lat: savedAddr.lat || params.lat,
              lng: savedAddr.lng || params.lng,
              id: savedAddr.id,
              label: savedAddr.label || params.label,
              address: savedAddr.address || params.address,
              house_no: savedAddr.house_no || params.house_no,
              building_name: savedAddr.building_name || params.building_name,
              landmark: savedAddr.landmark || params.landmark,
              area: (savedAddr.address || params.address || "").split(",")[0]
            };
            this.locationService.setAddress(locData);
          }
          this.addressSaved.emit(savedAddr);
        },
        error: (err) => {
          var _a2;
          this.isSaving = false;
          this.errorMessage = ((_a2 = err == null ? void 0 : err.error) == null ? void 0 : _a2.message) || "Failed to save address. Please try again.";
        }
      });
    }
  }
};
_AddressSaveFormComponent.\u0275fac = function AddressSaveFormComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _AddressSaveFormComponent)(\u0275\u0275directiveInject(LocationService), \u0275\u0275directiveInject(AuthService));
};
_AddressSaveFormComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _AddressSaveFormComponent, selectors: [["app-address-save-form"]], inputs: { initialCoords: "initialCoords", initialAddress: "initialAddress", routeSource: "routeSource", editAddress: "editAddress" }, outputs: { addressSaved: "addressSaved", cancel: "cancel" }, decls: 103, vars: 30, consts: [[1, "address-save-form-container"], [1, "form-header-bar"], [1, "header-left"], [1, "header-icon-box"], [3, "name"], [1, "header-text-col"], [1, "header-title"], [1, "header-subtitle"], ["type", "button", "aria-label", "Close", 1, "btn-close-form", 3, "click"], ["name", "close-outline"], [1, "form-error-banner", "animate__animated", "animate__headShake"], [1, "form-scrollable-body"], [1, "location-preview-card"], [1, "preview-icon"], ["name", "location-outline"], [1, "preview-text-col"], [1, "preview-eyebrow"], [1, "preview-address", "text-truncate-2"], [1, "form-fields-group"], [1, "input-card"], [1, "input-label"], [1, "required-star"], [1, "input-field-wrap"], ["type", "text", "placeholder", "e.g. Flat 402, 4th Floor", "autocomplete", "off", 1, "app-text-input", 3, "ngModelChange", "ngModel"], [1, "optional-tag"], ["type", "text", "placeholder", "e.g. Shanti Residency", "autocomplete", "off", 1, "app-text-input", 3, "ngModelChange", "ngModel"], ["type", "text", "placeholder", "e.g. Near City Hospital / Metro Pillar 24", "autocomplete", "off", 1, "app-text-input", 3, "ngModelChange", "ngModel"], [1, "input-field-wrap", "textarea-wrap"], ["rows", "2", "placeholder", "Street address", 1, "app-textarea", 3, "ngModelChange", "ngModel"], [1, "form-row-2col"], [1, "input-card", "flex-1"], ["name", "person-outline", 1, "leading-icon"], ["type", "text", "placeholder", "Contact person", 1, "app-text-input", "with-icon", 3, "ngModelChange", "ngModel"], ["name", "call-outline", 1, "leading-icon"], ["type", "tel", "placeholder", "10-digit number", 1, "app-text-input", "with-icon", 3, "ngModelChange", "ngModel"], [1, "label-selector-card"], [1, "label-chips-grid"], ["type", "button", 1, "label-chip", 3, "click"], ["name", "home-outline"], ["name", "checkmark-circle", 1, "check-indicator"], ["name", "briefcase-outline"], ["name", "bookmark-outline"], [1, "custom-label-wrap", "animate__animated", "animate__fadeIn"], ["role", "button", "tabindex", "0", 1, "primary-toggle-card", 3, "click"], [1, "toggle-icon-box"], [1, "toggle-text-col"], [1, "toggle-title"], [1, "toggle-subtitle"], [1, "toggle-switch-ui"], [1, "toggle-knob"], [1, "form-action-footer"], ["type", "button", 1, "btn-save-submit", 3, "click", "disabled"], ["type", "text", "placeholder", "e.g. Parents, Gym, Friend's House", 1, "app-text-input", "custom-tag-input", 3, "ngModelChange", "ngModel"], ["name", "crescent"]], template: function AddressSaveFormComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3);
    \u0275\u0275element(4, "ion-icon", 4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 5)(6, "h3", 6);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "p", 7);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(10, "button", 8);
    \u0275\u0275listener("click", function AddressSaveFormComponent_Template_button_click_10_listener() {
      return ctx.onCancel();
    });
    \u0275\u0275element(11, "ion-icon", 9);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(12, AddressSaveFormComponent_Conditional_12_Template, 4, 1, "div", 10);
    \u0275\u0275elementStart(13, "div", 11)(14, "div", 12)(15, "div", 13);
    \u0275\u0275element(16, "ion-icon", 14);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "div", 15)(18, "span", 16);
    \u0275\u0275text(19, "PINNED LOCATION");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "p", 17);
    \u0275\u0275text(21);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(22, "div", 18)(23, "div", 19)(24, "label", 20)(25, "span");
    \u0275\u0275text(26, "House / Flat / Floor No.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(27, "span", 21);
    \u0275\u0275text(28, "*");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(29, "div", 22)(30, "input", 23);
    \u0275\u0275twoWayListener("ngModelChange", function AddressSaveFormComponent_Template_input_ngModelChange_30_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.houseNo, $event) || (ctx.houseNo = $event);
      return $event;
    });
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(31, "div", 19)(32, "label", 20)(33, "span");
    \u0275\u0275text(34, "Building / Apartment Name");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(35, "span", 24);
    \u0275\u0275text(36, "OPTIONAL");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(37, "div", 22)(38, "input", 25);
    \u0275\u0275twoWayListener("ngModelChange", function AddressSaveFormComponent_Template_input_ngModelChange_38_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.buildingName, $event) || (ctx.buildingName = $event);
      return $event;
    });
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(39, "div", 19)(40, "label", 20)(41, "span");
    \u0275\u0275text(42, "Nearby Landmark");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(43, "span", 24);
    \u0275\u0275text(44, "OPTIONAL");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(45, "div", 22)(46, "input", 26);
    \u0275\u0275twoWayListener("ngModelChange", function AddressSaveFormComponent_Template_input_ngModelChange_46_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.landmark, $event) || (ctx.landmark = $event);
      return $event;
    });
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(47, "div", 19)(48, "label", 20)(49, "span");
    \u0275\u0275text(50, "Street / Area Details");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(51, "div", 27)(52, "textarea", 28);
    \u0275\u0275twoWayListener("ngModelChange", function AddressSaveFormComponent_Template_textarea_ngModelChange_52_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.currentAddress, $event) || (ctx.currentAddress = $event);
      return $event;
    });
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(53, "div", 29)(54, "div", 30)(55, "label", 20)(56, "span");
    \u0275\u0275text(57, "Receiver Name");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(58, "div", 22);
    \u0275\u0275element(59, "ion-icon", 31);
    \u0275\u0275elementStart(60, "input", 32);
    \u0275\u0275twoWayListener("ngModelChange", function AddressSaveFormComponent_Template_input_ngModelChange_60_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.receiverName, $event) || (ctx.receiverName = $event);
      return $event;
    });
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(61, "div", 30)(62, "label", 20)(63, "span");
    \u0275\u0275text(64, "Contact Phone");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(65, "div", 22);
    \u0275\u0275element(66, "ion-icon", 33);
    \u0275\u0275elementStart(67, "input", 34);
    \u0275\u0275twoWayListener("ngModelChange", function AddressSaveFormComponent_Template_input_ngModelChange_67_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.receiverPhone, $event) || (ctx.receiverPhone = $event);
      return $event;
    });
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(68, "div", 35)(69, "label", 20)(70, "span");
    \u0275\u0275text(71, "Save Address As");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(72, "div", 36)(73, "button", 37);
    \u0275\u0275listener("click", function AddressSaveFormComponent_Template_button_click_73_listener() {
      return ctx.selectLabel("home");
    });
    \u0275\u0275element(74, "ion-icon", 38);
    \u0275\u0275elementStart(75, "span");
    \u0275\u0275text(76, "Home");
    \u0275\u0275elementEnd();
    \u0275\u0275template(77, AddressSaveFormComponent_Conditional_77_Template, 1, 0, "ion-icon", 39);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(78, "button", 37);
    \u0275\u0275listener("click", function AddressSaveFormComponent_Template_button_click_78_listener() {
      return ctx.selectLabel("work");
    });
    \u0275\u0275element(79, "ion-icon", 40);
    \u0275\u0275elementStart(80, "span");
    \u0275\u0275text(81, "Work");
    \u0275\u0275elementEnd();
    \u0275\u0275template(82, AddressSaveFormComponent_Conditional_82_Template, 1, 0, "ion-icon", 39);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(83, "button", 37);
    \u0275\u0275listener("click", function AddressSaveFormComponent_Template_button_click_83_listener() {
      return ctx.selectLabel("other");
    });
    \u0275\u0275element(84, "ion-icon", 41);
    \u0275\u0275elementStart(85, "span");
    \u0275\u0275text(86, "Other");
    \u0275\u0275elementEnd();
    \u0275\u0275template(87, AddressSaveFormComponent_Conditional_87_Template, 1, 0, "ion-icon", 39);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(88, AddressSaveFormComponent_Conditional_88_Template, 2, 1, "div", 42);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(89, "div", 43);
    \u0275\u0275listener("click", function AddressSaveFormComponent_Template_div_click_89_listener() {
      return ctx.isPrimary = !ctx.isPrimary;
    });
    \u0275\u0275elementStart(90, "div", 44);
    \u0275\u0275element(91, "ion-icon", 4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(92, "div", 45)(93, "span", 46);
    \u0275\u0275text(94, "Set as Default / Primary Address");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(95, "span", 47);
    \u0275\u0275text(96, "Orders and home deliveries will default to this address");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(97, "div", 48);
    \u0275\u0275element(98, "div", 49);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(99, "div", 50)(100, "button", 51);
    \u0275\u0275listener("click", function AddressSaveFormComponent_Template_button_click_100_listener() {
      return ctx.save();
    });
    \u0275\u0275template(101, AddressSaveFormComponent_Conditional_101_Template, 3, 1)(102, AddressSaveFormComponent_Conditional_102_Template, 2, 1, "span");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    \u0275\u0275advance(4);
    \u0275\u0275property("name", ctx.isEditMode ? "create-outline" : "location-outline");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx.isEditMode ? "Edit Delivery Address" : "Complete Address");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx.isEditMode ? "Update house, street or contact details" : "Provide delivery details for accurate drops");
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx.errorMessage ? 12 : -1);
    \u0275\u0275advance(9);
    \u0275\u0275textInterpolate(ctx.currentAddress || "Address details captured from map");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("has-error", ctx.errorMessage && !ctx.houseNo);
    \u0275\u0275advance(7);
    \u0275\u0275twoWayProperty("ngModel", ctx.houseNo);
    \u0275\u0275advance(8);
    \u0275\u0275twoWayProperty("ngModel", ctx.buildingName);
    \u0275\u0275advance(8);
    \u0275\u0275twoWayProperty("ngModel", ctx.landmark);
    \u0275\u0275advance(6);
    \u0275\u0275twoWayProperty("ngModel", ctx.currentAddress);
    \u0275\u0275advance(8);
    \u0275\u0275twoWayProperty("ngModel", ctx.receiverName);
    \u0275\u0275advance(7);
    \u0275\u0275twoWayProperty("ngModel", ctx.receiverPhone);
    \u0275\u0275advance(6);
    \u0275\u0275classProp("active", ctx.selectedLabel === "home");
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx.selectedLabel === "home" ? 77 : -1);
    \u0275\u0275advance();
    \u0275\u0275classProp("active", ctx.selectedLabel === "work");
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx.selectedLabel === "work" ? 82 : -1);
    \u0275\u0275advance();
    \u0275\u0275classProp("active", ctx.selectedLabel === "other");
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx.selectedLabel === "other" ? 87 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.selectedLabel === "other" ? 88 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx.isPrimary);
    \u0275\u0275advance();
    \u0275\u0275property("name", ctx.isPrimary ? "star" : "star-outline");
    \u0275\u0275advance(6);
    \u0275\u0275classProp("on", ctx.isPrimary);
    \u0275\u0275advance(3);
    \u0275\u0275property("disabled", ctx.isSaving || !ctx.houseNo);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.isSaving ? 101 : 102);
  }
}, dependencies: [
  CommonModule,
  FormsModule,
  DefaultValueAccessor,
  NgControlStatus,
  NgModel,
  IonIcon,
  IonSpinner
], styles: ["\n\n.address-save-form-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  width: 100%;\n  max-height: 90vh;\n  background: #ffffff;\n  border-radius: 24px 24px 0 0;\n  overflow: hidden;\n  box-sizing: border-box;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .form-header-bar[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 16px 20px 14px 20px;\n  border-bottom: 1px solid #f1f5f9;\n  flex-shrink: 0;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .form-header-bar[_ngcontent-%COMP%]   .header-left[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .form-header-bar[_ngcontent-%COMP%]   .header-left[_ngcontent-%COMP%]   .header-icon-box[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 38px;\n  border-radius: 12px;\n  background: #f3e8ff;\n  color: var(--app-theme-color, #a000e2);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 20px;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .form-header-bar[_ngcontent-%COMP%]   .header-left[_ngcontent-%COMP%]   .header-text-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .form-header-bar[_ngcontent-%COMP%]   .header-left[_ngcontent-%COMP%]   .header-text-col[_ngcontent-%COMP%]   .header-title[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 800;\n  color: #0f172a;\n  margin: 0;\n  letter-spacing: -0.2px;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .form-header-bar[_ngcontent-%COMP%]   .header-left[_ngcontent-%COMP%]   .header-text-col[_ngcontent-%COMP%]   .header-subtitle[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #64748b;\n  margin: 2px 0 0 0;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .form-header-bar[_ngcontent-%COMP%]   .btn-close-form[_ngcontent-%COMP%] {\n  width: 34px;\n  height: 34px;\n  border-radius: 50%;\n  background: #f1f5f9;\n  color: #475569;\n  border: none;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 18px;\n  cursor: pointer;\n  transition: background 0.15s;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .form-header-bar[_ngcontent-%COMP%]   .btn-close-form[_ngcontent-%COMP%]:active {\n  background: #e2e8f0;\n  transform: scale(0.95);\n}\n.address-save-form-container[_ngcontent-%COMP%]   .form-error-banner[_ngcontent-%COMP%] {\n  background: #fee2e2;\n  border: 1px solid #fecaca;\n  color: #991b1b;\n  padding: 10px 16px;\n  margin: 12px 18px 0 18px;\n  border-radius: 12px;\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  font-size: 12.5px;\n  font-weight: 600;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .form-error-banner[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 16px;\n  flex-shrink: 0;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .form-scrollable-body[_ngcontent-%COMP%] {\n  flex: 1;\n  overflow-y: auto;\n  padding: 16px 18px 24px 18px;\n  display: flex;\n  flex-direction: column;\n  gap: 16px;\n  -webkit-overflow-scrolling: touch;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .location-preview-card[_ngcontent-%COMP%] {\n  background: #f8fafc;\n  border: 1.5px dashed #cbd5e1;\n  border-radius: 14px;\n  padding: 12px 14px;\n  display: flex;\n  align-items: flex-start;\n  gap: 12px;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .location-preview-card[_ngcontent-%COMP%]   .preview-icon[_ngcontent-%COMP%] {\n  width: 28px;\n  height: 28px;\n  border-radius: 8px;\n  background: #ede9fe;\n  color: var(--app-theme-color, #a000e2);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 16px;\n  flex-shrink: 0;\n  margin-top: 2px;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .location-preview-card[_ngcontent-%COMP%]   .preview-text-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  overflow: hidden;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .location-preview-card[_ngcontent-%COMP%]   .preview-text-col[_ngcontent-%COMP%]   .preview-eyebrow[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 800;\n  color: #94a3b8;\n  letter-spacing: 0.6px;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .location-preview-card[_ngcontent-%COMP%]   .preview-text-col[_ngcontent-%COMP%]   .preview-address[_ngcontent-%COMP%] {\n  font-size: 12.5px;\n  color: #334155;\n  margin: 2px 0 0 0;\n  line-height: 1.4;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .form-fields-group[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 14px;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .input-card[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 6px;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .input-card.has-error[_ngcontent-%COMP%]   .app-text-input[_ngcontent-%COMP%] {\n  border-color: #ef4444;\n  background: #fff5f5;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .input-card[_ngcontent-%COMP%]   .input-label[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  font-size: 12px;\n  font-weight: 700;\n  color: #334155;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .input-card[_ngcontent-%COMP%]   .input-label[_ngcontent-%COMP%]   .required-star[_ngcontent-%COMP%] {\n  color: #ef4444;\n  margin-left: 2px;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .input-card[_ngcontent-%COMP%]   .input-label[_ngcontent-%COMP%]   .optional-tag[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  font-weight: 700;\n  color: #94a3b8;\n  letter-spacing: 0.5px;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .input-card[_ngcontent-%COMP%]   .input-field-wrap[_ngcontent-%COMP%] {\n  position: relative;\n  display: flex;\n  align-items: center;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .input-card[_ngcontent-%COMP%]   .input-field-wrap[_ngcontent-%COMP%]   .leading-icon[_ngcontent-%COMP%] {\n  position: absolute;\n  left: 12px;\n  font-size: 17px;\n  color: #94a3b8;\n  pointer-events: none;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .input-card[_ngcontent-%COMP%]   .input-field-wrap[_ngcontent-%COMP%]   .app-text-input[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 44px;\n  border-radius: 12px;\n  border: 1.5px solid #e2e8f0;\n  background: #f8fafc;\n  padding: 0 14px;\n  font-size: 13.5px;\n  color: #0f172a;\n  outline: none;\n  transition: all 0.15s ease;\n  box-sizing: border-box;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .input-card[_ngcontent-%COMP%]   .input-field-wrap[_ngcontent-%COMP%]   .app-text-input.with-icon[_ngcontent-%COMP%] {\n  padding-left: 38px;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .input-card[_ngcontent-%COMP%]   .input-field-wrap[_ngcontent-%COMP%]   .app-text-input[_ngcontent-%COMP%]::placeholder {\n  color: #94a3b8;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .input-card[_ngcontent-%COMP%]   .input-field-wrap[_ngcontent-%COMP%]   .app-text-input[_ngcontent-%COMP%]:focus {\n  border-color: var(--app-theme-color, #a000e2);\n  background: #ffffff;\n  box-shadow: 0 0 0 3px rgba(160, 0, 226, 0.1);\n}\n.address-save-form-container[_ngcontent-%COMP%]   .input-card[_ngcontent-%COMP%]   .input-field-wrap.textarea-wrap[_ngcontent-%COMP%]   .app-textarea[_ngcontent-%COMP%] {\n  width: 100%;\n  border-radius: 12px;\n  border: 1.5px solid #e2e8f0;\n  background: #f8fafc;\n  padding: 10px 14px;\n  font-size: 13px;\n  color: #0f172a;\n  outline: none;\n  resize: none;\n  font-family: inherit;\n  line-height: 1.4;\n  transition: all 0.15s ease;\n  box-sizing: border-box;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .input-card[_ngcontent-%COMP%]   .input-field-wrap.textarea-wrap[_ngcontent-%COMP%]   .app-textarea[_ngcontent-%COMP%]::placeholder {\n  color: #94a3b8;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .input-card[_ngcontent-%COMP%]   .input-field-wrap.textarea-wrap[_ngcontent-%COMP%]   .app-textarea[_ngcontent-%COMP%]:focus {\n  border-color: var(--app-theme-color, #a000e2);\n  background: #ffffff;\n  box-shadow: 0 0 0 3px rgba(160, 0, 226, 0.1);\n}\n.address-save-form-container[_ngcontent-%COMP%]   .form-row-2col[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 12px;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .form-row-2col[_ngcontent-%COMP%]   .flex-1[_ngcontent-%COMP%] {\n  flex: 1;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .label-selector-card[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .label-selector-card[_ngcontent-%COMP%]   .label-chips-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  gap: 10px;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .label-selector-card[_ngcontent-%COMP%]   .label-chips-grid[_ngcontent-%COMP%]   .label-chip[_ngcontent-%COMP%] {\n  height: 42px;\n  border-radius: 12px;\n  border: 1.5px solid #e2e8f0;\n  background: #f8fafc;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 6px;\n  font-size: 13px;\n  font-weight: 700;\n  color: #475569;\n  cursor: pointer;\n  position: relative;\n  transition: all 0.15s ease;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .label-selector-card[_ngcontent-%COMP%]   .label-chips-grid[_ngcontent-%COMP%]   .label-chip[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 16px;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .label-selector-card[_ngcontent-%COMP%]   .label-chips-grid[_ngcontent-%COMP%]   .label-chip[_ngcontent-%COMP%]   .check-indicator[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: var(--app-theme-color, #a000e2);\n}\n.address-save-form-container[_ngcontent-%COMP%]   .label-selector-card[_ngcontent-%COMP%]   .label-chips-grid[_ngcontent-%COMP%]   .label-chip.active[_ngcontent-%COMP%] {\n  border-color: var(--app-theme-color, #a000e2);\n  background: #fdf4ff;\n  color: var(--app-theme-color, #a000e2);\n  box-shadow: 0 2px 8px rgba(160, 0, 226, 0.12);\n}\n.address-save-form-container[_ngcontent-%COMP%]   .label-selector-card[_ngcontent-%COMP%]   .label-chips-grid[_ngcontent-%COMP%]   .label-chip[_ngcontent-%COMP%]:active {\n  transform: scale(0.97);\n}\n.address-save-form-container[_ngcontent-%COMP%]   .label-selector-card[_ngcontent-%COMP%]   .custom-label-wrap[_ngcontent-%COMP%] {\n  margin-top: 4px;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .label-selector-card[_ngcontent-%COMP%]   .custom-label-wrap[_ngcontent-%COMP%]   .custom-tag-input[_ngcontent-%COMP%] {\n  height: 40px;\n  font-size: 12.5px;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .primary-toggle-card[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  padding: 14px 16px;\n  background: #f8fafc;\n  border: 1.5px solid #e2e8f0;\n  border-radius: 16px;\n  cursor: pointer;\n  transition: all 0.2s ease;\n  -webkit-user-select: none;\n  user-select: none;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .primary-toggle-card[_ngcontent-%COMP%]:active {\n  transform: scale(0.99);\n  background: #f1f5f9;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .primary-toggle-card[_ngcontent-%COMP%]   .toggle-icon-box[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 38px;\n  border-radius: 12px;\n  background: #ffffff;\n  border: 1px solid #e2e8f0;\n  color: #94a3b8;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 20px;\n  flex-shrink: 0;\n  transition: all 0.2s ease;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .primary-toggle-card[_ngcontent-%COMP%]   .toggle-icon-box.active[_ngcontent-%COMP%] {\n  background: #fef9c3;\n  border-color: #fde047;\n  color: #ca8a04;\n  box-shadow: 0 2px 8px rgba(202, 138, 4, 0.2);\n}\n.address-save-form-container[_ngcontent-%COMP%]   .primary-toggle-card[_ngcontent-%COMP%]   .toggle-text-col[_ngcontent-%COMP%] {\n  flex: 1;\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .primary-toggle-card[_ngcontent-%COMP%]   .toggle-text-col[_ngcontent-%COMP%]   .toggle-title[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  font-weight: 800;\n  color: #0f172a;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .primary-toggle-card[_ngcontent-%COMP%]   .toggle-text-col[_ngcontent-%COMP%]   .toggle-subtitle[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  color: #64748b;\n  line-height: 1.35;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .primary-toggle-card[_ngcontent-%COMP%]   .toggle-switch-ui[_ngcontent-%COMP%] {\n  width: 44px;\n  height: 26px;\n  border-radius: 99px;\n  background: #cbd5e1;\n  position: relative;\n  flex-shrink: 0;\n  transition: background 0.2s ease;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .primary-toggle-card[_ngcontent-%COMP%]   .toggle-switch-ui[_ngcontent-%COMP%]   .toggle-knob[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 3px;\n  left: 3px;\n  width: 20px;\n  height: 20px;\n  border-radius: 50%;\n  background: #ffffff;\n  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.15);\n  transition: transform 0.2s cubic-bezier(0.4, 0, 0.2, 1);\n}\n.address-save-form-container[_ngcontent-%COMP%]   .primary-toggle-card[_ngcontent-%COMP%]   .toggle-switch-ui.on[_ngcontent-%COMP%] {\n  background: var(--app-theme-color, #a000e2);\n}\n.address-save-form-container[_ngcontent-%COMP%]   .primary-toggle-card[_ngcontent-%COMP%]   .toggle-switch-ui.on[_ngcontent-%COMP%]   .toggle-knob[_ngcontent-%COMP%] {\n  transform: translateX(18px);\n}\n.address-save-form-container[_ngcontent-%COMP%]   .form-action-footer[_ngcontent-%COMP%] {\n  padding: 12px 18px calc(14px + env(safe-area-inset-bottom)) 18px;\n  border-top: 1px solid #f1f5f9;\n  background: #ffffff;\n  flex-shrink: 0;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .form-action-footer[_ngcontent-%COMP%]   .btn-save-submit[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 48px;\n  border-radius: 14px;\n  border: none;\n  background: var(--app-theme-color, #a000e2);\n  color: #ffffff;\n  font-size: 14.5px;\n  font-weight: 800;\n  letter-spacing: 0.2px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 8px;\n  box-shadow: 0 4px 14px rgba(160, 0, 226, 0.32);\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .form-action-footer[_ngcontent-%COMP%]   .btn-save-submit[_ngcontent-%COMP%]:active {\n  transform: scale(0.98);\n  background: #8b00c4;\n}\n.address-save-form-container[_ngcontent-%COMP%]   .form-action-footer[_ngcontent-%COMP%]   .btn-save-submit[_ngcontent-%COMP%]:disabled {\n  background: #cbd5e1;\n  color: #94a3b8;\n  box-shadow: none;\n  cursor: not-allowed;\n}\n.text-truncate-2[_ngcontent-%COMP%] {\n  display: -webkit-box;\n  -webkit-line-clamp: 2;\n  -webkit-box-orient: vertical;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n/*# sourceMappingURL=address-save-form.component.css.map */"] });
var AddressSaveFormComponent = _AddressSaveFormComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(AddressSaveFormComponent, { className: "AddressSaveFormComponent", filePath: "src/app/components/address-save-form/address-save-form.component.ts", lineNumber: 51 });
})();

export {
  AddressSaveFormComponent
};
//# sourceMappingURL=chunk-FQ3CQ4UF.js.map
