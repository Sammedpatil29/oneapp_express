import {
  App
} from "./chunk-EBMCUG2R.js";
import {
  environment
} from "./chunk-YJYUHAOC.js";
import {
  ToastController
} from "./chunk-CJE2NDTY.js";
import {
  BehaviorSubject,
  NgZone,
  ɵɵdefineInjectable,
  ɵɵinject
} from "./chunk-Z7XNNJSA.js";
import {
  Capacitor,
  registerPlugin
} from "./chunk-FH4NU4VH.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// node_modules/@otakit/capacitor-updater/dist/esm/definitions.js
var BundleStatus;
(function(BundleStatus2) {
  BundleStatus2["BUILTIN"] = "builtin";
  BundleStatus2["PENDING"] = "pending";
  BundleStatus2["TRIAL"] = "trial";
  BundleStatus2["SUCCESS"] = "success";
  BundleStatus2["ERROR"] = "error";
})(BundleStatus || (BundleStatus = {}));

// node_modules/@otakit/capacitor-updater/dist/esm/index.js
var NativeOtaKit = registerPlugin("OtaKit", {
  web: () => import("./web-H2LV26FQ.js").then((m) => new m.OtaKitWeb())
});
function isEmptyObject(obj) {
  return obj !== null && typeof obj === "object" && Object.keys(obj).length === 0;
}
function normalizeNullable(value) {
  return isEmptyObject(value) ? null : value;
}
var OtaKit = {
  getState: () => NativeOtaKit.getState(),
  check: () => NativeOtaKit.check(),
  download: () => NativeOtaKit.download(),
  apply: () => NativeOtaKit.apply(),
  update: () => NativeOtaKit.update(),
  notifyAppReady: () => NativeOtaKit.notifyAppReady(),
  getLastFailure: () => __async(void 0, null, function* () {
    return normalizeNullable(yield NativeOtaKit.getLastFailure());
  }),
  setChannel: (options) => NativeOtaKit.setChannel(options),
  getChannel: () => NativeOtaKit.getChannel(),
  // NativeOtaKit is the registerPlugin proxy, which implements Capacitor's
  // listener API; this plain-object wrapper must forward it explicitly.
  addListener: (eventName, listenerFunc) => NativeOtaKit.addListener(eventName, listenerFunc),
  removeAllListeners: () => NativeOtaKit.removeAllListeners()
};

// src/app/services/ota.service.ts
function maskRequestUrl(url) {
  if (!url)
    return "";
  try {
    const parsed = new URL(url);
    const host = parsed.hostname;
    if (host.includes("pintu")) {
      return "https://pintuXXXXX";
    }
    if (host.includes("oneapp")) {
      return "https://oneappXXXX";
    }
    return `${parsed.protocol}//${host.slice(0, 5)}XXXXX`;
  } catch {
    if (url.includes("pintu"))
      return "https://pintuXXXXX";
    if (url.includes("oneapp"))
      return "https://oneappXXXX";
    return url;
  }
}
var OTA_UPDATED_KEY = "ota_just_updated";
var _OtaService = class _OtaService {
  constructor(toastCtrl, ngZone) {
    this.toastCtrl = toastCtrl;
    this.ngZone = ngZone;
    this.isDownloadingSubject = new BehaviorSubject(false);
    this.isDownloading$ = this.isDownloadingSubject.asObservable();
    this.downloadProgressSubject = new BehaviorSubject(0);
    this.downloadProgress$ = this.downloadProgressSubject.asObservable();
    this.progressInterval = null;
  }
  /**
   * Initializes OtaKit on native device.
   * Flow: download silently → show progress bar on bottom navbar → apply and restart immediately → notify user after reload.
   */
  initialize() {
    return __async(this, null, function* () {
      if (!Capacitor.isNativePlatform()) {
        console.log("\u2139\uFE0F [OtaKit] Running in browser, skipping native OTA checks.");
        return;
      }
      try {
        yield OtaKit.notifyAppReady();
        console.log("\u2705 [OtaKit] notifyAppReady sent");
      } catch (e) {
        console.warn("[OtaKit] notifyAppReady warning:", e);
      }
      this.showPostUpdateToast();
      this.setupOtaUpdates();
    });
  }
  // ─── Silent background check → download with progress bar → restart app ──
  setupOtaUpdates() {
    return __async(this, null, function* () {
      var _a, _b, _c, _d, _e, _f;
      try {
        yield OtaKit.addListener("updateStaged", (event) => __async(this, null, function* () {
          var _a2;
          console.log("\u{1F4E6} [OtaKit] Event updateStaged received:", event);
          yield this.completeDownloadAndRestart(((_a2 = event.bundle) == null ? void 0 : _a2.version) || "");
        }));
        yield OtaKit.addListener("updateAvailable", (latest) => __async(this, null, function* () {
          console.log("\u{1F680} [OtaKit] Event updateAvailable received:", latest);
          yield this.startDownloadAndRestart(latest == null ? void 0 : latest.version);
        }));
        yield OtaKit.addListener("downloadFailed", (event) => {
          console.warn("\u274C [OtaKit] Event downloadFailed received:", event);
          this.resetDownloadState();
        });
        const state = yield OtaKit.getState();
        console.log("\u{1F4CA} [OtaKit] Current state:", JSON.stringify(state));
        if (state.staged) {
          console.log("\u{1F4CC} [OtaKit] Staged update waiting:", (_a = state.staged) == null ? void 0 : _a.version);
          yield this.completeDownloadAndRestart(((_b = state.staged) == null ? void 0 : _b.version) || "");
          return;
        }
        console.log("\u{1F50E} [OtaKit] Checking for updates on CDN...");
        const check = yield OtaKit.check();
        console.log("\u{1F50E} [OtaKit] Check result:", JSON.stringify(check));
        if (check.kind === "update_available") {
          console.log("\u{1F680} [OtaKit] New update available:", (_c = check.latest) == null ? void 0 : _c.version);
          yield this.startDownloadAndRestart((_d = check.latest) == null ? void 0 : _d.version);
        } else if (check.kind === "already_staged") {
          console.log("\u{1F4CC} [OtaKit] Update already staged:", (_e = check.latest) == null ? void 0 : _e.version);
          yield this.completeDownloadAndRestart(((_f = check.latest) == null ? void 0 : _f.version) || "");
        } else {
          console.log("\u2705 [OtaKit] App is up to date.");
        }
      } catch (err) {
        console.warn("\u274C [OtaKit] Update error:", err);
        this.resetDownloadState();
      }
    });
  }
  /**
   * Starts downloading OTA bundle, displays progress bar on bottom navbar top border (2-3px),
   * and automatically restarts/applies the app once download completes.
   */
  startDownloadAndRestart(version) {
    return __async(this, null, function* () {
      var _a;
      if (!Capacitor.isNativePlatform()) {
        console.log("\u2139\uFE0F [OtaKit] Skipping download on non-native platform.");
        return { success: false, message: "OTA updates require physical device." };
      }
      if (this.isDownloadingSubject.value) {
        console.log("\u23F3 [OtaKit] Download already in progress...");
        return { success: true, message: "Download already in progress..." };
      }
      this.startProgressSimulation();
      try {
        console.log("\u{1F4E5} [OtaKit] Calling OtaKit.download()...");
        const downloadRes = yield OtaKit.download();
        console.log("\u{1F4E5} [OtaKit] Download result:", JSON.stringify(downloadRes));
        if (downloadRes.kind === "staged" || downloadRes.kind === "already_staged") {
          const targetVer = ((_a = downloadRes.bundle) == null ? void 0 : _a.version) || version || "";
          yield this.completeDownloadAndRestart(targetVer);
          return { success: true, message: "Update downloaded! Restarting app..." };
        } else {
          this.resetDownloadState();
          return { success: false, message: `Download returned status: ${downloadRes.kind}` };
        }
      } catch (err) {
        this.resetDownloadState();
        console.error("\u274C [OtaKit] Error downloading OTA bundle:", err);
        return { success: false, message: err.message || "Download failed" };
      }
    });
  }
  startProgressSimulation() {
    this.clearIntervalIfActive();
    this.ngZone.run(() => {
      this.isDownloadingSubject.next(true);
      this.downloadProgressSubject.next(10);
    });
    let current = 10;
    this.progressInterval = setInterval(() => {
      if (current < 92) {
        const step = Math.max(1, Math.floor((92 - current) / 6));
        current += step;
        this.ngZone.run(() => {
          this.downloadProgressSubject.next(current);
        });
      }
    }, 180);
  }
  completeDownloadAndRestart(version) {
    return __async(this, null, function* () {
      this.clearIntervalIfActive();
      this.ngZone.run(() => {
        this.isDownloadingSubject.next(true);
        this.downloadProgressSubject.next(100);
      });
      if (version) {
        localStorage.setItem(OTA_UPDATED_KEY, version);
      }
      yield new Promise((resolve) => setTimeout(resolve, 600));
      try {
        console.log(`\u{1F504} [OtaKit] Restarting app to apply update v${version}...`);
        yield OtaKit.apply();
      } catch (e) {
        console.error("\u274C [OtaKit] Failed to restart and apply update:", e);
        this.resetDownloadState();
      }
    });
  }
  resetDownloadState() {
    this.clearIntervalIfActive();
    this.ngZone.run(() => {
      this.isDownloadingSubject.next(false);
      this.downloadProgressSubject.next(0);
    });
  }
  clearIntervalIfActive() {
    if (this.progressInterval) {
      clearInterval(this.progressInterval);
      this.progressInterval = null;
    }
  }
  // ─── Post-reload notification ──────────────────────────────────────
  showPostUpdateToast() {
    return __async(this, null, function* () {
      const version = localStorage.getItem(OTA_UPDATED_KEY);
      if (!version)
        return;
      localStorage.removeItem(OTA_UPDATED_KEY);
      try {
        const toast = yield this.toastCtrl.create({
          message: `App updated${version ? " to v" + version : ""} successfully! \u{1F389}`,
          position: "bottom",
          duration: 4e3,
          color: "success",
          cssClass: "ota-success-toast"
        });
        yield toast.present();
        console.log("\u2705 [OtaKit] Post-update toast shown for version", version);
      } catch (e) {
        console.error("Toast display error:", e);
      }
    });
  }
  // ─── Manual Check & Diagnostics ───────────────────────────────────
  getCurrentVersion() {
    return __async(this, null, function* () {
      var _a;
      try {
        if (Capacitor.isNativePlatform()) {
          const state = yield OtaKit.getState();
          if ((_a = state == null ? void 0 : state.current) == null ? void 0 : _a.version) {
            return state.current.version;
          }
          const appInfo = yield App.getInfo();
          if (appInfo == null ? void 0 : appInfo.version) {
            return appInfo.version;
          }
        }
      } catch (e) {
        console.warn("[OtaService] Error getting version:", e);
      }
      return "0.0.16";
    });
  }
  checkUpdateDetails() {
    return __async(this, null, function* () {
      const currentVersion = yield this.getCurrentVersion();
      const manifestUrl = `${environment.apiUrl}/ota/manifests/io.ionic.oneapp/__base__/__default__/manifest.json`;
      const maskedUrl = maskRequestUrl(manifestUrl);
      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 9e3);
        const res = yield fetch(manifestUrl, {
          cache: "no-store",
          headers: {
            "Cache-Control": "no-cache, no-store, must-revalidate",
            "Pragma": "no-cache"
          },
          signal: controller.signal
        });
        clearTimeout(timer);
        if (!res.ok) {
          const text = yield res.text().catch(() => "");
          return {
            success: false,
            currentVersion,
            isUpToDate: false,
            updateAvailable: false,
            manifestUrl,
            maskedUrl,
            httpStatus: res.status,
            error: `Server HTTP ${res.status} (${res.statusText || "Error"})`,
            errorDetails: text || `Server returned status ${res.status}.`
          };
        }
        const manifest = yield res.json();
        const latestVersion = manifest.version || "";
        const isUpToDate = Boolean(latestVersion && latestVersion === currentVersion);
        const updateAvailable = Boolean(latestVersion && latestVersion !== currentVersion);
        if (Capacitor.isNativePlatform()) {
          try {
            yield OtaKit.check();
          } catch (e) {
          }
        }
        return {
          success: true,
          currentVersion,
          latestVersion,
          isUpToDate,
          updateAvailable,
          manifestUrl,
          maskedUrl,
          httpStatus: res.status,
          responseBody: manifest
        };
      } catch (err) {
        const isAbort = err.name === "AbortError";
        return {
          success: false,
          currentVersion,
          isUpToDate: false,
          updateAvailable: false,
          manifestUrl,
          maskedUrl,
          error: isAbort ? "Request Timeout (> 9s)" : err.name || "Network Error",
          errorDetails: err.message || String(err)
        };
      }
    });
  }
  applyUpdateNow() {
    return __async(this, null, function* () {
      var _a;
      if (!Capacitor.isNativePlatform()) {
        return { success: false, message: "OTA updates can only be downloaded on physical devices." };
      }
      try {
        const state = yield OtaKit.getState();
        if (state == null ? void 0 : state.staged) {
          const ver = ((_a = state.staged) == null ? void 0 : _a.version) || "";
          yield this.completeDownloadAndRestart(ver);
          return { success: true, message: "Update applied! Restarting app..." };
        }
        return yield this.startDownloadAndRestart();
      } catch (e) {
        this.resetDownloadState();
        return { success: false, message: e.message || "Failed to download and apply OTA bundle." };
      }
    });
  }
};
_OtaService.\u0275fac = function OtaService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _OtaService)(\u0275\u0275inject(ToastController), \u0275\u0275inject(NgZone));
};
_OtaService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _OtaService, factory: _OtaService.\u0275fac, providedIn: "root" });
var OtaService = _OtaService;

export {
  OtaKit,
  OtaService
};
//# sourceMappingURL=chunk-DCTFUYU7.js.map
