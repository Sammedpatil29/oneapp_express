import {
  addIcons,
  flash,
  heart,
  lockClosed,
  shieldCheckmark
} from "./chunk-I7AJKZVE.js";
import {
  IonIcon
} from "./chunk-CJE2NDTY.js";
import {
  CommonModule,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵtext,
  ɵɵtextInterpolate1
} from "./chunk-Z7XNNJSA.js";

// src/app/components/footer/footer.component.ts
var _FooterComponent = class _FooterComponent {
  constructor() {
    this.currentYear = (/* @__PURE__ */ new Date()).getFullYear();
    addIcons({
      heart,
      flash,
      shieldCheckmark,
      lockClosed
    });
  }
  ngOnInit() {
  }
};
_FooterComponent.\u0275fac = function FooterComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _FooterComponent)();
};
_FooterComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _FooterComponent, selectors: [["app-footer"]], decls: 35, vars: 1, consts: [[1, "app-brand-footer"], [1, "footer-divider-line"], [1, "footer-content-wrapper"], [1, "footer-watermark-box"], [1, "brand-watermark-text"], [1, "footer-love-tagline"], [1, "tagline-text"], [1, "tagline-heart"], [1, "footer-pillars-row"], [1, "pillar-chip"], ["name", "flash"], [1, "pillar-divider"], ["name", "shield-checkmark"], ["name", "lock-closed"], [1, "footer-footnote-col"], [1, "company-name"], [1, "copyright-text"]], template: function FooterComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "footer", 0);
    \u0275\u0275element(1, "div", 1);
    \u0275\u0275elementStart(2, "div", 2)(3, "div", 3)(4, "span", 4);
    \u0275\u0275text(5, "Pintu - Minutes App");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "div", 5)(7, "span", 6);
    \u0275\u0275text(8, "Made with");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "span", 7);
    \u0275\u0275text(10, "\u2764\uFE0F");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "span", 6);
    \u0275\u0275text(12, "for Athani");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(13, "div", 8)(14, "div", 9);
    \u0275\u0275element(15, "ion-icon", 10);
    \u0275\u0275elementStart(16, "span");
    \u0275\u0275text(17, "Instant Delivery");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(18, "div", 11);
    \u0275\u0275text(19, "\u2022");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "div", 9);
    \u0275\u0275element(21, "ion-icon", 12);
    \u0275\u0275elementStart(22, "span");
    \u0275\u0275text(23, "Zero Surge");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(24, "div", 11);
    \u0275\u0275text(25, "\u2022");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(26, "div", 9);
    \u0275\u0275element(27, "ion-icon", 13);
    \u0275\u0275elementStart(28, "span");
    \u0275\u0275text(29, "100% Secure");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(30, "div", 14)(31, "p", 15);
    \u0275\u0275text(32, "Pintu Technologies Private Limited");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(33, "p", 16);
    \u0275\u0275text(34);
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    \u0275\u0275advance(34);
    \u0275\u0275textInterpolate1("\xA9 ", ctx.currentYear, " Pintu \u2022 All rights reserved");
  }
}, dependencies: [CommonModule, IonIcon], styles: ['\n\n.app-brand-footer[_ngcontent-%COMP%] {\n  width: 100%;\n  max-width: 100%;\n  box-sizing: border-box;\n  margin-top: 10px;\n  position: relative;\n  overflow: hidden;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n}\n.app-brand-footer[_ngcontent-%COMP%]   .footer-divider-line[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 1px;\n  background:\n    linear-gradient(\n      90deg,\n      transparent 0%,\n      rgba(226, 232, 240, 0.9) 25%,\n      rgba(203, 213, 225, 0.9) 50%,\n      rgba(226, 232, 240, 0.9) 75%,\n      transparent 100%);\n  margin-bottom: 14px;\n}\n.app-brand-footer[_ngcontent-%COMP%]   .footer-content-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  text-align: center;\n  gap: 10px;\n  width: 100%;\n  padding: 0 16px 4px;\n  box-sizing: border-box;\n}\n.app-brand-footer[_ngcontent-%COMP%]   .footer-watermark-box[_ngcontent-%COMP%] {\n  line-height: 1;\n  margin-bottom: -6px;\n  -webkit-user-select: none;\n  user-select: none;\n  pointer-events: none;\n}\n.app-brand-footer[_ngcontent-%COMP%]   .footer-watermark-box[_ngcontent-%COMP%]   .brand-watermark-text[_ngcontent-%COMP%] {\n  font-family:\n    "Luckiest Guy",\n    cursive,\n    -apple-system,\n    sans-serif;\n  font-size: 22px;\n  letter-spacing: 2px;\n  color: transparent;\n  background:\n    linear-gradient(\n      180deg,\n      #e9d5ff 0%,\n      #cbd5e1 100%);\n  -webkit-background-clip: text;\n  background-clip: text;\n  text-shadow: 0 4px 12px rgba(160, 0, 226, 0.06);\n  display: inline-block;\n  transition: transform 0.3s ease;\n}\n.app-brand-footer[_ngcontent-%COMP%]   .footer-love-tagline[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 6px;\n  font-size: 13.5px;\n  font-weight: 700;\n  letter-spacing: -0.1px;\n}\n.app-brand-footer[_ngcontent-%COMP%]   .footer-love-tagline[_ngcontent-%COMP%]   .tagline-text[_ngcontent-%COMP%] {\n  color: #64748b;\n}\n.app-brand-footer[_ngcontent-%COMP%]   .footer-love-tagline[_ngcontent-%COMP%]   .tagline-heart[_ngcontent-%COMP%] {\n  display: inline-block;\n  font-size: 14px;\n  animation: _ngcontent-%COMP%_heartbeat 2s ease-in-out infinite;\n}\n.app-brand-footer[_ngcontent-%COMP%]   .footer-pillars-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 6px;\n  flex-wrap: nowrap;\n  width: 100%;\n  max-width: 100%;\n  margin-top: 4px;\n  box-sizing: border-box;\n}\n.app-brand-footer[_ngcontent-%COMP%]   .footer-pillars-row[_ngcontent-%COMP%]   .pillar-chip[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  font-size: clamp(9px, 2.7vw, 11px);\n  font-weight: 650;\n  color: #64748b;\n  background: #ffffff;\n  padding: 4px 8px;\n  border-radius: 99px;\n  border: 1px solid #f1f5f9;\n  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.02);\n  white-space: nowrap;\n  flex-shrink: 0;\n}\n.app-brand-footer[_ngcontent-%COMP%]   .footer-pillars-row[_ngcontent-%COMP%]   .pillar-chip[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #a000e2;\n  flex-shrink: 0;\n}\n.app-brand-footer[_ngcontent-%COMP%]   .footer-pillars-row[_ngcontent-%COMP%]   .pillar-chip[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  white-space: nowrap;\n  display: inline-block;\n}\n.app-brand-footer[_ngcontent-%COMP%]   .footer-pillars-row[_ngcontent-%COMP%]   .pillar-divider[_ngcontent-%COMP%] {\n  color: #cbd5e1;\n  font-size: 10px;\n  flex-shrink: 0;\n  line-height: 1;\n}\n.app-brand-footer[_ngcontent-%COMP%]   .footer-footnote-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  gap: 2px;\n  margin-top: 6px;\n}\n.app-brand-footer[_ngcontent-%COMP%]   .footer-footnote-col[_ngcontent-%COMP%]   .company-name[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 700;\n  color: #94a3b8;\n  letter-spacing: 0.2px;\n  margin: 0;\n}\n.app-brand-footer[_ngcontent-%COMP%]   .footer-footnote-col[_ngcontent-%COMP%]   .copyright-text[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 500;\n  color: #94a3b8;\n  margin: 0;\n}\n@keyframes _ngcontent-%COMP%_heartbeat {\n  0% {\n    transform: scale(1);\n  }\n  14% {\n    transform: scale(1.2);\n  }\n  28% {\n    transform: scale(1);\n  }\n  42% {\n    transform: scale(1.2);\n  }\n  70% {\n    transform: scale(1);\n  }\n}\n/*# sourceMappingURL=footer.component.css.map */'] });
var FooterComponent = _FooterComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(FooterComponent, { className: "FooterComponent", filePath: "src/app/components/footer/footer.component.ts", lineNumber: 14 });
})();

export {
  FooterComponent
};
//# sourceMappingURL=chunk-PTVB74IU.js.map
