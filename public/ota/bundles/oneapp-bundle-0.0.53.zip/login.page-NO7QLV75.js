import {
  ReferralService
} from "./chunk-A4U5EYAN.js";
import {
  register
} from "./chunk-TXY46XHU.js";
import {
  addIcons,
  alertCircleOutline,
  arrowBack,
  arrowForwardOutline,
  callOutline,
  checkmarkCircle,
  checkmarkCircleOutline,
  chevronBack,
  createOutline,
  gift,
  giftOutline,
  keypadOutline,
  lockClosedOutline,
  logoWhatsapp,
  mail,
  mailOutline,
  personOutline,
  shieldCheckmarkOutline,
  timeOutline
} from "./chunk-I7AJKZVE.js";
import {
  AuthService
} from "./chunk-EB6T6TPT.js";
import "./chunk-OE5MTPUR.js";
import "./chunk-YJYUHAOC.js";
import "./chunk-XR3JUECC.js";
import {
  IonContent,
  IonIcon,
  IonSpinner,
  IonToast
} from "./chunk-CJE2NDTY.js";
import {
  CommonModule,
  Component,
  DOCUMENT,
  DefaultValueAccessor,
  FormControl,
  FormControlDirective,
  FormGroup,
  FormsModule,
  Inject,
  Injector,
  Input,
  MaxLengthValidator,
  NG_VALUE_ACCESSOR,
  NavController,
  NgClass,
  NgControl,
  NgControlStatus,
  NgForOf,
  NgIf,
  NgModel,
  NgModule,
  NgStyle,
  Output,
  PatternValidator,
  ReactiveFormsModule,
  Router,
  Subject,
  forwardRef,
  setClassMetadata,
  takeUntil,
  ɵsetClassDebugInfo,
  ɵɵProvidersFeature,
  ɵɵadvance,
  ɵɵclassMapInterpolate1,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementContainerEnd,
  ɵɵelementContainerStart,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵpropertyInterpolate1,
  ɵɵpureFunction1,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵstyleProp,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-Z7XNNJSA.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// node_modules/ng-otp-input/fesm2022/ng-otp-input.mjs
var _c0 = (a0) => ({
  "error-input": a0
});
function NgOtpInputComponent_div_0_ng_container_2_span_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r1.config.separator, " ");
  }
}
function NgOtpInputComponent_div_0_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementContainerStart(0);
    \u0275\u0275elementStart(1, "input", 5, 0);
    \u0275\u0275listener("paste", function NgOtpInputComponent_div_0_ng_container_2_Template_input_paste_1_listener($event) {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.handlePaste($event));
    })("keyup", function NgOtpInputComponent_div_0_ng_container_2_Template_input_keyup_1_listener($event) {
      const i_r4 = \u0275\u0275restoreView(_r3).index;
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.onKeyUp($event, i_r4));
    })("input", function NgOtpInputComponent_div_0_ng_container_2_Template_input_input_1_listener($event) {
      const i_r4 = \u0275\u0275restoreView(_r3).index;
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.onInput($event, i_r4));
    })("keydown", function NgOtpInputComponent_div_0_ng_container_2_Template_input_keydown_1_listener($event) {
      const i_r4 = \u0275\u0275restoreView(_r3).index;
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.onKeyDown($event, i_r4));
    });
    \u0275\u0275elementEnd();
    \u0275\u0275template(3, NgOtpInputComponent_div_0_ng_container_2_span_3_Template, 2, 1, "span", 6);
    \u0275\u0275elementContainerEnd();
  }
  if (rf & 2) {
    const item_r5 = ctx.$implicit;
    const i_r4 = ctx.index;
    const last_r6 = ctx.last;
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275classMapInterpolate1("otp-input ", ctx_r1.config.inputClass, "");
    \u0275\u0275property("pattern", ctx_r1.config.allowNumbersOnly ? "\\d*" : "")("type", ctx_r1.inputType)("placeholder", (ctx_r1.config == null ? null : ctx_r1.config.placeholder) || "")("ngStyle", ctx_r1.config.inputStyles)("formControl", ctx_r1.otpForm.controls[item_r5])("id", ctx_r1.getBoxId(i_r4))("ngClass", \u0275\u0275pureFunction1(11, _c0, (ctx_r1.config == null ? null : ctx_r1.config.showError) && (ctx_r1.formControl == null ? null : ctx_r1.formControl.invalid) && ((ctx_r1.formControl == null ? null : ctx_r1.formControl.dirty) || (ctx_r1.formControl == null ? null : ctx_r1.formControl.touched))));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngIf", ctx_r1.config.separator && !last_r6);
  }
}
function NgOtpInputComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 2);
    \u0275\u0275listener("focusin", function NgOtpInputComponent_div_0_Template_div_focusin_0_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.onFocusIn());
    })("focusout", function NgOtpInputComponent_div_0_Template_div_focusout_0_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.onFocusOut());
    });
    \u0275\u0275elementStart(1, "div", 3);
    \u0275\u0275template(2, NgOtpInputComponent_div_0_ng_container_2_Template, 4, 13, "ng-container", 4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275classMapInterpolate1("ng-otp-input-wrapper wrapper ", ctx_r1.config.containerClass, "");
    \u0275\u0275propertyInterpolate1("id", "c_", ctx_r1.componentKey, "");
    \u0275\u0275property("ngStyle", ctx_r1.config.containerStyles);
    \u0275\u0275advance(2);
    \u0275\u0275property("ngForOf", ctx_r1.controlKeys);
  }
}
var KeyboardUtil = class {
  static ifTab(event) {
    return this.ifKey(event, "Tab");
  }
  static ifDelete(event) {
    return this.ifKey(event, "Delete;Del");
  }
  static ifBackspace(event) {
    return this.ifKey(event, "Backspace");
  }
  static ifRightArrow(event) {
    return this.ifKey(event, "ArrowRight;Right");
  }
  static ifLeftArrow(event) {
    return this.ifKey(event, "ArrowLeft;Left");
  }
  static ifSpacebar(event) {
    return this.ifKey(event, "Spacebar; ");
  }
  static ifKey(event, keys) {
    let keysToCheck = keys.split(";");
    return keysToCheck.some((k) => k === event.key);
  }
};
var ObjectUtil = class {
  static keys(obj) {
    if (!obj) return [];
    return Object.keys(obj);
  }
};
var _NgOtpInputComponent = class _NgOtpInputComponent {
  set disabled(isDisabled) {
    this.setDisabledState(isDisabled);
  }
  get inputType() {
    var _a, _b;
    return ((_a = this.config) == null ? void 0 : _a.isPasswordInput) ? "password" : ((_b = this.config) == null ? void 0 : _b.allowNumbersOnly) ? "tel" : "text";
  }
  get controlKeys() {
    var _a;
    return ObjectUtil.keys((_a = this.otpForm) == null ? void 0 : _a.controls);
  }
  get formControl() {
    var _a, _b;
    return (_b = this.formCtrl) != null ? _b : (_a = this.inj) == null ? void 0 : _a.get(NgControl);
  }
  constructor(document, inj) {
    this.document = document;
    this.inj = inj;
    this.config = {
      length: 4
    };
    this.onBlur = new Subject();
    this.onInputChange = new Subject();
    this.inputControls = new Array(this.config.length);
    this.componentKey = Math.random().toString(36).substring(2) + (/* @__PURE__ */ new Date()).getTime().toString(36);
    this.destroy$ = new Subject();
    this.activeFocusCount = 0;
    this.onChange = () => {
    };
    this.onTouched = () => {
    };
    this._isDisabled = false;
  }
  ngOnInit() {
    this.otpForm = new FormGroup({});
    for (let index = 0; index < this.config.length; index++) {
      this.otpForm.addControl(this.getControlName(index), new FormControl());
    }
    this.otpForm.valueChanges.pipe(takeUntil(this.destroy$)).subscribe((v) => {
      ObjectUtil.keys(this.otpForm.controls).forEach((k) => {
        var val = this.otpForm.controls[k].value;
        if (val && val.length > 1) {
          if (val.length >= this.config.length) {
            this.setValue(val);
          } else {
            this.rebuildValue();
          }
        }
      });
    });
  }
  setDisabledState(isDisabled) {
    this._isDisabled = isDisabled;
    if (this.otpForm) {
      if (isDisabled) {
        this.otpForm.disable({
          emitEvent: false
        });
      } else {
        this.otpForm.enable({
          emitEvent: false
        });
      }
    }
  }
  writeValue(value) {
    this.currentVal = !this.hasVal(value) ? null : value;
    this.setValue(this.currentVal);
  }
  registerOnChange(fn) {
    this.onChange = fn;
  }
  registerOnTouched(fn) {
    this.onTouched = fn;
  }
  onFocusIn() {
    this.onTouched();
    this.activeFocusCount++;
  }
  onFocusOut() {
    setTimeout(() => {
      this.activeFocusCount--;
      if (this.activeFocusCount === 0) {
        this.onTouched();
        this.onBlur.next();
      }
    }, 0);
  }
  ngAfterViewInit() {
    if (!this.config.disableAutoFocus) {
      const containerItem = this.document.getElementById(`c_${this.componentKey}`);
      if (containerItem) {
        const ele = containerItem.getElementsByClassName("otp-input")[0];
        if (ele && ele.focus) {
          ele.focus();
        }
      }
    }
  }
  getControlName(idx) {
    return `ctrl_${idx}`;
  }
  onKeyDown($event, inputIdx) {
    const prevInputId = this.getBoxId(inputIdx - 1);
    const currentInputId = this.getBoxId(inputIdx);
    if (KeyboardUtil.ifKey($event, "Enter")) {
      let inp = this.document.getElementById(currentInputId);
      const form = inp == null ? void 0 : inp.closest("form");
      if (form) {
        $event.preventDefault();
        const submitEvent = new Event("submit", {
          bubbles: true,
          cancelable: true
        });
        form.dispatchEvent(submitEvent);
        return;
      }
    }
    if (KeyboardUtil.ifSpacebar($event)) {
      $event.preventDefault();
      return false;
    }
    if (KeyboardUtil.ifBackspace($event)) {
      if (!$event.target.value) {
        this.clearInput(prevInputId, inputIdx - 1);
        this.setSelected(prevInputId);
      } else {
        this.clearInput(currentInputId, inputIdx);
      }
      this.rebuildValue();
      return;
    }
    if (KeyboardUtil.ifDelete($event)) {
      if (!$event.target.value) {
        this.clearInput(prevInputId, inputIdx - 1);
        this.setSelected(prevInputId);
      } else {
        this.clearInput(currentInputId, inputIdx);
      }
      this.rebuildValue();
      return;
    }
  }
  hasVal(val) {
    return val != null && val != void 0 && (!(val == null ? void 0 : val.trim) || val.trim() != "");
  }
  onInput($event, inputIdx) {
    var _a;
    let newVal = this.hasVal(this.currentVal) ? `${this.currentVal}${$event.target.value}` : $event.target.value;
    if (this.config.allowNumbersOnly && !this.validateNumber(newVal)) {
      $event.target.value = null;
      $event.stopPropagation();
      $event.preventDefault();
      this.clearInput(null, inputIdx);
      return;
    }
    if (this.ifValidKeyCode(null, $event.target.value)) {
      const nextInputId = this.getBoxId(inputIdx + 1);
      this.setSelected(nextInputId);
      this.rebuildValue();
    } else {
      $event.target.value = null;
      let ctrlName = this.getControlName(inputIdx);
      (_a = this.otpForm.controls[ctrlName]) == null ? void 0 : _a.setValue(null);
      this.rebuildValue();
    }
  }
  onKeyUp($event, inputIdx) {
    if (KeyboardUtil.ifTab($event)) {
      inputIdx -= 1;
    }
    const nextInputId = this.getBoxId(inputIdx + 1);
    const prevInputId = this.getBoxId(inputIdx - 1);
    if (KeyboardUtil.ifRightArrow($event)) {
      $event.preventDefault();
      this.setSelected(nextInputId);
      return;
    }
    if (KeyboardUtil.ifLeftArrow($event)) {
      $event.preventDefault();
      this.setSelected(prevInputId);
      return;
    }
  }
  validateNumber(val) {
    return val && /^[0-9]+$/.test(val);
  }
  getBoxId(idx) {
    return `otp_${idx}_${this.componentKey}`;
  }
  clearInput(eleId, inputIdx) {
    var _a;
    let ctrlName = this.getControlName(inputIdx);
    (_a = this.otpForm.controls[ctrlName]) == null ? void 0 : _a.setValue(null);
    if (eleId) {
      const ele = this.document.getElementById(eleId);
      if (ele && ele instanceof HTMLInputElement) {
        ele.value = null;
      }
    }
  }
  setSelected(eleId) {
    this.focusTo(eleId);
    const ele = this.document.getElementById(eleId);
    if (ele && ele.setSelectionRange) {
      setTimeout(() => {
        ele.setSelectionRange(0, 1);
      }, 0);
    }
  }
  ifValidKeyCode(event, val) {
    var _a;
    const inp = val != null ? val : event.key;
    if ((_a = this.config) == null ? void 0 : _a.allowNumbersOnly) {
      return this.validateNumber(inp);
    }
    const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
    return isMobile || /^[a-zA-Z0-9%*_\-@#$!]$/.test(inp) && inp.length == 1;
  }
  focusTo(eleId) {
    const ele = this.document.getElementById(eleId);
    if (ele) {
      ele.focus();
    }
  }
  // method to set component value
  setValue(value) {
    var _a;
    if (this.config.allowNumbersOnly && isNaN(value)) {
      return;
    }
    (_a = this.otpForm) == null ? void 0 : _a.reset();
    if (!this.hasVal(value)) {
      this.rebuildValue();
      return;
    }
    value = value.toString().replace(/\s/g, "");
    Array.from(value).forEach((c, idx) => {
      if (this.otpForm.get(this.getControlName(idx))) {
        this.otpForm.get(this.getControlName(idx)).setValue(c);
      }
    });
    if (!this.config.disableAutoFocus) {
      setTimeout(() => {
        const containerItem = this.document.getElementById(`c_${this.componentKey}`);
        var indexOfElementToFocus = value.length < this.config.length ? value.length : this.config.length - 1;
        let ele = containerItem.getElementsByClassName("otp-input")[indexOfElementToFocus];
        if (ele && ele.focus) {
          setTimeout(() => {
            ele.focus();
          }, 1);
        }
      }, 0);
    }
    this.rebuildValue();
  }
  rebuildValue() {
    var _a;
    let val = null;
    ObjectUtil.keys(this.otpForm.controls).forEach((k) => {
      let ctrlVal = this.otpForm.controls[k].value;
      if (ctrlVal) {
        let isLengthExceed = ctrlVal.length > 1;
        let isCaseTransformEnabled = !this.config.allowNumbersOnly && this.config.letterCase && (this.config.letterCase.toLocaleLowerCase() == "upper" || this.config.letterCase.toLocaleLowerCase() == "lower");
        ctrlVal = ctrlVal[0];
        let transformedVal = isCaseTransformEnabled ? this.config.letterCase.toLocaleLowerCase() == "upper" ? ctrlVal.toUpperCase() : ctrlVal.toLowerCase() : ctrlVal;
        if (isCaseTransformEnabled && transformedVal == ctrlVal) {
          isCaseTransformEnabled = false;
        } else {
          ctrlVal = transformedVal;
        }
        if (val == null) {
          val = ctrlVal;
        } else {
          val += ctrlVal;
        }
        if (isLengthExceed || isCaseTransformEnabled) {
          this.otpForm.controls[k].setValue(ctrlVal);
        }
      }
    });
    if (this.currentVal != val) {
      this.currentVal = val;
      this.onChange(val);
      if ((_a = this.formCtrl) == null ? void 0 : _a.setValue) {
        this.formCtrl.setValue(val);
      }
      this.onInputChange.next(val);
    }
  }
  handlePaste(e) {
    let clipboardData = e.clipboardData || window["clipboardData"];
    if (clipboardData) {
      var pastedData = clipboardData.getData("Text");
    }
    e.stopPropagation();
    e.preventDefault();
    if (!pastedData || this.config.allowNumbersOnly && !this.validateNumber(pastedData)) {
      return;
    }
    this.setValue(pastedData);
  }
  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }
};
_NgOtpInputComponent.\u0275fac = function NgOtpInputComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _NgOtpInputComponent)(\u0275\u0275directiveInject(DOCUMENT), \u0275\u0275directiveInject(Injector));
};
_NgOtpInputComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({
  type: _NgOtpInputComponent,
  selectors: [["ng-otp-input"], ["ngx-otp-input"]],
  inputs: {
    config: "config",
    formCtrl: "formCtrl",
    disabled: "disabled"
  },
  outputs: {
    onBlur: "onBlur",
    onInputChange: "onInputChange"
  },
  features: [\u0275\u0275ProvidersFeature([{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => _NgOtpInputComponent),
    multi: true
  }])],
  decls: 1,
  vars: 1,
  consts: [["inp", ""], ["tabindex", "0", 3, "class", "id", "ngStyle", "focusin", "focusout", 4, "ngIf"], ["tabindex", "0", 3, "focusin", "focusout", "id", "ngStyle"], [1, "n-o-c"], [4, "ngFor", "ngForOf"], ["autocomplete", "one-time-code", 3, "paste", "keyup", "input", "keydown", "pattern", "type", "placeholder", "ngStyle", "formControl", "id", "ngClass"], [4, "ngIf"]],
  template: function NgOtpInputComponent_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275template(0, NgOtpInputComponent_div_0_Template, 3, 7, "div", 1);
    }
    if (rf & 2) {
      \u0275\u0275property("ngIf", ctx.otpForm == null ? null : ctx.otpForm.controls);
    }
  },
  dependencies: [ReactiveFormsModule, DefaultValueAccessor, NgControlStatus, PatternValidator, FormControlDirective, NgIf, NgForOf, NgStyle, NgClass],
  styles: [".otp-input[_ngcontent-%COMP%]{width:50px;height:50px;border-radius:4px;border:solid 1px #c5c5c5;text-align:center;font-size:32px}.ng-otp-input-wrapper[_ngcontent-%COMP%]   .otp-input[_ngcontent-%COMP%]{margin:0 .51rem}.ng-otp-input-wrapper[_ngcontent-%COMP%]   .otp-input[_ngcontent-%COMP%]:first-child{margin-left:0}.ng-otp-input-wrapper[_ngcontent-%COMP%]   .otp-input[_ngcontent-%COMP%]:last-child{margin-right:0}.n-o-c[_ngcontent-%COMP%]{display:flex;align-items:center}.error-input[_ngcontent-%COMP%]{border-color:red}@media screen and (max-width: 767px){.otp-input[_ngcontent-%COMP%]{width:40px;font-size:24px;height:40px}}@media screen and (max-width: 420px){.otp-input[_ngcontent-%COMP%]{width:30px;font-size:18px;height:30px}}"]
});
var NgOtpInputComponent = _NgOtpInputComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgOtpInputComponent, [{
    type: Component,
    args: [{
      selector: "ng-otp-input, ngx-otp-input",
      imports: [ReactiveFormsModule, NgIf, NgForOf, NgStyle, NgClass],
      providers: [{
        provide: NG_VALUE_ACCESSOR,
        useExisting: forwardRef(() => NgOtpInputComponent),
        multi: true
      }],
      template: `<div class="ng-otp-input-wrapper wrapper {{config.containerClass}}" id="c_{{componentKey}}" *ngIf="otpForm?.controls"\r
  [ngStyle]="config.containerStyles" tabindex="0" \r
  (focusin)="onFocusIn()" \r
  (focusout)="onFocusOut()">\r
  <div class="n-o-c">\r
    <ng-container *ngFor="let item of controlKeys;let i=index;let last=last">\r
      <input (paste)="handlePaste($event)" [pattern]="config.allowNumbersOnly ? '\\\\d*' : ''" [type]="inputType"  [placeholder]="config?.placeholder || ''"\r
      [ngStyle]="config.inputStyles" \r
      class="otp-input {{config.inputClass}}" autocomplete="one-time-code" \r
      [formControl]="otpForm.controls[item]" #inp [id]="getBoxId(i)" \r
      (keyup)="onKeyUp($event,i)" (input)="onInput($event,i)" (keydown)="onKeyDown($event,i)" [ngClass]="{'error-input': (config?.showError && formControl?.invalid && (formControl?.dirty || formControl?.touched))}">\r
      <span *ngIf="config.separator && !last">\r
        {{config.separator}}\r
      </span>\r
    </ng-container>\r
  </div>  \r
</div>`,
      styles: [".otp-input{width:50px;height:50px;border-radius:4px;border:solid 1px #c5c5c5;text-align:center;font-size:32px}.ng-otp-input-wrapper .otp-input{margin:0 .51rem}.ng-otp-input-wrapper .otp-input:first-child{margin-left:0}.ng-otp-input-wrapper .otp-input:last-child{margin-right:0}.n-o-c{display:flex;align-items:center}.error-input{border-color:red}@media screen and (max-width: 767px){.otp-input{width:40px;font-size:24px;height:40px}}@media screen and (max-width: 420px){.otp-input{width:30px;font-size:18px;height:30px}}\n"]
    }]
  }], () => [{
    type: Document,
    decorators: [{
      type: Inject,
      args: [DOCUMENT]
    }]
  }, {
    type: Injector
  }], {
    config: [{
      type: Input
    }],
    formCtrl: [{
      type: Input
    }],
    disabled: [{
      type: Input
    }],
    onBlur: [{
      type: Output
    }],
    onInputChange: [{
      type: Output
    }]
  });
})();
var _NgOtpInputModule = class _NgOtpInputModule {
};
_NgOtpInputModule.\u0275fac = function NgOtpInputModule_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _NgOtpInputModule)();
};
_NgOtpInputModule.\u0275mod = /* @__PURE__ */ \u0275\u0275defineNgModule({
  type: _NgOtpInputModule
});
_NgOtpInputModule.\u0275inj = /* @__PURE__ */ \u0275\u0275defineInjector({
  imports: [NgOtpInputComponent]
});
var NgOtpInputModule = _NgOtpInputModule;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgOtpInputModule, [{
    type: NgModule,
    args: [{
      imports: [NgOtpInputComponent],
      exports: [NgOtpInputComponent]
    }]
  }], null, null);
})();

// src/app/pages/login/login.page.ts
function LoginPage_Conditional_1_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 16);
    \u0275\u0275listener("click", function LoginPage_Conditional_1_Conditional_5_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.goBack());
    });
    \u0275\u0275element(1, "ion-icon", 17);
    \u0275\u0275elementEnd();
  }
}
function LoginPage_Conditional_1_swiper_slide_8_span_15_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 28);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const chip_r4 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(chip_r4);
  }
}
function LoginPage_Conditional_1_swiper_slide_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "swiper-slide")(1, "div", 18)(2, "div", 19);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "h2", 20);
    \u0275\u0275text(5);
    \u0275\u0275element(6, "br");
    \u0275\u0275elementStart(7, "span", 21);
    \u0275\u0275text(8);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "p", 22);
    \u0275\u0275text(10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "div", 23);
    \u0275\u0275element(12, "div", 24);
    \u0275\u0275elementStart(13, "img", 25);
    \u0275\u0275listener("error", function LoginPage_Conditional_1_swiper_slide_8_Template_img_error_13_listener($event) {
      \u0275\u0275restoreView(_r3);
      return \u0275\u0275resetView($event.target.style.display = "none");
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(14, "div", 26);
    \u0275\u0275template(15, LoginPage_Conditional_1_swiper_slide_8_span_15_Template, 2, 1, "span", 27);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const slide_r5 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("background", slide_r5.badgeBg)("color", slide_r5.badgeColor);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", slide_r5.badge, " ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" ", slide_r5.title, "");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(slide_r5.highlight);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(slide_r5.subtitle);
    \u0275\u0275advance(3);
    \u0275\u0275property("src", slide_r5.image, \u0275\u0275sanitizeUrl);
    \u0275\u0275advance(2);
    \u0275\u0275property("ngForOf", slide_r5.chips);
  }
}
function LoginPage_Conditional_1_Conditional_12_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 35);
  }
}
function LoginPage_Conditional_1_Conditional_12_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-spinner", 39);
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2, "Sending Code...");
    \u0275\u0275elementEnd();
  }
}
function LoginPage_Conditional_1_Conditional_12_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1, "Continue with Email");
    \u0275\u0275elementEnd();
    \u0275\u0275element(2, "ion-icon", 40);
  }
}
function LoginPage_Conditional_1_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 15)(1, "div", 29)(2, "h3", 30);
    \u0275\u0275text(3, "Get Started with Pintu");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "p", 31);
    \u0275\u0275text(5, "Enter your email to sign in or create an account");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "div", 32);
    \u0275\u0275element(7, "ion-icon", 33);
    \u0275\u0275elementStart(8, "input", 34);
    \u0275\u0275twoWayListener("ngModelChange", function LoginPage_Conditional_1_Conditional_12_Template_input_ngModelChange_8_listener($event) {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext(2);
      \u0275\u0275twoWayBindingSet(ctx_r1.email, $event) || (ctx_r1.email = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275listener("keyup.enter", function LoginPage_Conditional_1_Conditional_12_Template_input_keyup_enter_8_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.sendVerification());
    });
    \u0275\u0275elementEnd();
    \u0275\u0275template(9, LoginPage_Conditional_1_Conditional_12_Conditional_9_Template, 1, 0, "ion-icon", 35);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "button", 36);
    \u0275\u0275listener("click", function LoginPage_Conditional_1_Conditional_12_Template_button_click_10_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.sendVerification());
    });
    \u0275\u0275template(11, LoginPage_Conditional_1_Conditional_12_Conditional_11_Template, 3, 0)(12, LoginPage_Conditional_1_Conditional_12_Conditional_12_Template, 3, 0);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "p", 37);
    \u0275\u0275text(14, " By continuing, you agree to Pintu's ");
    \u0275\u0275elementStart(15, "span", 38);
    \u0275\u0275listener("click", function LoginPage_Conditional_1_Conditional_12_Template_span_click_15_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.openTerms());
    });
    \u0275\u0275text(16, "Terms");
    \u0275\u0275elementEnd();
    \u0275\u0275text(17, " & ");
    \u0275\u0275elementStart(18, "span", 38);
    \u0275\u0275listener("click", function LoginPage_Conditional_1_Conditional_12_Template_span_click_18_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.openPrivacy());
    });
    \u0275\u0275text(19, "Privacy Policy");
    \u0275\u0275elementEnd();
    \u0275\u0275text(20, ". ");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(8);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.email);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.isValidEmail() ? 9 : -1);
    \u0275\u0275advance();
    \u0275\u0275property("disabled", ctx_r1.isSendingOtp || !ctx_r1.isValidEmail());
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.isSendingOtp ? 11 : 12);
  }
}
function LoginPage_Conditional_1_Conditional_13_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 48);
    \u0275\u0275text(1, "Resend code in ");
    \u0275\u0275elementStart(2, "b");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("", ctx_r1.timer, "s");
  }
}
function LoginPage_Conditional_1_Conditional_13_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "a", 50);
    \u0275\u0275listener("click", function LoginPage_Conditional_1_Conditional_13_Conditional_15_Template_a_click_0_listener() {
      \u0275\u0275restoreView(_r8);
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.sendVerification());
    });
    \u0275\u0275text(1, "Resend Code");
    \u0275\u0275elementEnd();
  }
}
function LoginPage_Conditional_1_Conditional_13_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-spinner", 39);
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.otpVerificationMessage || "Verifying...");
  }
}
function LoginPage_Conditional_1_Conditional_13_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 51);
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2, "Verify & Proceed");
    \u0275\u0275elementEnd();
    \u0275\u0275element(3, "ion-icon", 40);
  }
}
function LoginPage_Conditional_1_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 15)(1, "div", 41)(2, "h3", 30);
    \u0275\u0275text(3, "Verify 6-Digit Code");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "p", 31);
    \u0275\u0275text(5, " Code sent to ");
    \u0275\u0275elementStart(6, "b", 42);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "button", 43);
    \u0275\u0275listener("click", function LoginPage_Conditional_1_Conditional_13_Template_button_click_8_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.step = "email");
    });
    \u0275\u0275element(9, "ion-icon", 44);
    \u0275\u0275text(10, " Edit ");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(11, "div", 45)(12, "ng-otp-input", 46);
    \u0275\u0275listener("onInputChange", function LoginPage_Conditional_1_Conditional_13_Template_ng_otp_input_onInputChange_12_listener($event) {
      \u0275\u0275restoreView(_r7);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.onOtpChange($event));
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(13, "div", 47);
    \u0275\u0275template(14, LoginPage_Conditional_1_Conditional_13_Conditional_14_Template, 4, 1, "span", 48)(15, LoginPage_Conditional_1_Conditional_13_Conditional_15_Template, 2, 0, "a", 49);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "button", 36);
    \u0275\u0275listener("click", function LoginPage_Conditional_1_Conditional_13_Template_button_click_16_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.verifyOtp());
    });
    \u0275\u0275template(17, LoginPage_Conditional_1_Conditional_13_Conditional_17_Template, 3, 1)(18, LoginPage_Conditional_1_Conditional_13_Conditional_18_Template, 4, 0);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate(ctx_r1.email);
    \u0275\u0275advance(5);
    \u0275\u0275property("config", ctx_r1.otpConfig);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.timer > 0 ? 14 : 15);
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", ctx_r1.isVerifyingOtp || ctx_r1.enteredOtp.length !== 6);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.isVerifyingOtp ? 17 : 18);
  }
}
function LoginPage_Conditional_1_Conditional_14_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-spinner", 59);
  }
}
function LoginPage_Conditional_1_Conditional_14_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 60);
  }
}
function LoginPage_Conditional_1_Conditional_14_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 61);
  }
}
function LoginPage_Conditional_1_Conditional_14_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 62);
    \u0275\u0275element(1, "ion-icon", 65);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx_r1.referralMessage);
  }
}
function LoginPage_Conditional_1_Conditional_14_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 63);
    \u0275\u0275element(1, "ion-icon", 66);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx_r1.referralMessage);
  }
}
function LoginPage_Conditional_1_Conditional_14_Conditional_22_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-spinner", 39);
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2, "Setting up profile...");
    \u0275\u0275elementEnd();
  }
}
function LoginPage_Conditional_1_Conditional_14_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1, "Complete Setup & Start");
    \u0275\u0275elementEnd();
    \u0275\u0275element(2, "ion-icon", 40);
  }
}
function LoginPage_Conditional_1_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 15)(1, "div", 29)(2, "h3", 30);
    \u0275\u0275text(3, "Complete Profile");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "p", 31);
    \u0275\u0275text(5, "Welcome to Pintu! Let's set up your profile");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "div", 52);
    \u0275\u0275element(7, "ion-icon", 53);
    \u0275\u0275elementStart(8, "input", 54);
    \u0275\u0275twoWayListener("ngModelChange", function LoginPage_Conditional_1_Conditional_14_Template_input_ngModelChange_8_listener($event) {
      \u0275\u0275restoreView(_r9);
      const ctx_r1 = \u0275\u0275nextContext(2);
      \u0275\u0275twoWayBindingSet(ctx_r1.fullName, $event) || (ctx_r1.fullName = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "div", 52)(10, "span", 55);
    \u0275\u0275text(11, "+91");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "input", 56);
    \u0275\u0275twoWayListener("ngModelChange", function LoginPage_Conditional_1_Conditional_14_Template_input_ngModelChange_12_listener($event) {
      \u0275\u0275restoreView(_r9);
      const ctx_r1 = \u0275\u0275nextContext(2);
      \u0275\u0275twoWayBindingSet(ctx_r1.phoneNumber, $event) || (ctx_r1.phoneNumber = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275listener("keyup.enter", function LoginPage_Conditional_1_Conditional_14_Template_input_keyup_enter_12_listener() {
      \u0275\u0275restoreView(_r9);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.register());
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(13, "div", 52);
    \u0275\u0275element(14, "ion-icon", 57);
    \u0275\u0275elementStart(15, "input", 58);
    \u0275\u0275twoWayListener("ngModelChange", function LoginPage_Conditional_1_Conditional_14_Template_input_ngModelChange_15_listener($event) {
      \u0275\u0275restoreView(_r9);
      const ctx_r1 = \u0275\u0275nextContext(2);
      \u0275\u0275twoWayBindingSet(ctx_r1.referralCode, $event) || (ctx_r1.referralCode = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275listener("ngModelChange", function LoginPage_Conditional_1_Conditional_14_Template_input_ngModelChange_15_listener($event) {
      \u0275\u0275restoreView(_r9);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.onReferralCodeChange($event));
    });
    \u0275\u0275elementEnd();
    \u0275\u0275template(16, LoginPage_Conditional_1_Conditional_14_Conditional_16_Template, 1, 0, "ion-spinner", 59)(17, LoginPage_Conditional_1_Conditional_14_Conditional_17_Template, 1, 0, "ion-icon", 60)(18, LoginPage_Conditional_1_Conditional_14_Conditional_18_Template, 1, 0, "ion-icon", 61);
    \u0275\u0275elementEnd();
    \u0275\u0275template(19, LoginPage_Conditional_1_Conditional_14_Conditional_19_Template, 4, 1, "div", 62)(20, LoginPage_Conditional_1_Conditional_14_Conditional_20_Template, 4, 1, "div", 63);
    \u0275\u0275elementStart(21, "button", 64);
    \u0275\u0275listener("click", function LoginPage_Conditional_1_Conditional_14_Template_button_click_21_listener() {
      \u0275\u0275restoreView(_r9);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.register());
    });
    \u0275\u0275template(22, LoginPage_Conditional_1_Conditional_14_Conditional_22_Template, 3, 0)(23, LoginPage_Conditional_1_Conditional_14_Conditional_23_Template, 3, 0);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(8);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.fullName);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.phoneNumber);
    \u0275\u0275advance();
    \u0275\u0275classProp("border-valid", ctx_r1.referralStatus === "valid")("border-invalid", ctx_r1.referralStatus === "invalid");
    \u0275\u0275advance(2);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.referralCode);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.referralStatus === "checking" ? 16 : ctx_r1.referralStatus === "valid" ? 17 : ctx_r1.referralStatus === "invalid" ? 18 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx_r1.referralStatus === "valid" && ctx_r1.referralMessage ? 19 : ctx_r1.referralStatus === "invalid" && ctx_r1.referralMessage ? 20 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", ctx_r1.isLoading || !ctx_r1.fullName.trim() || ctx_r1.phoneNumber.length < 10);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.isLoading ? 22 : 23);
  }
}
function LoginPage_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 1)(1, "section", 4);
    \u0275\u0275element(2, "div", 5)(3, "div", 6)(4, "div", 7);
    \u0275\u0275template(5, LoginPage_Conditional_1_Conditional_5_Template, 2, 0, "button", 8);
    \u0275\u0275elementStart(6, "div", 9)(7, "swiper-container", 10);
    \u0275\u0275template(8, LoginPage_Conditional_1_swiper_slide_8_Template, 16, 10, "swiper-slide", 11);
    \u0275\u0275elementEnd()();
    \u0275\u0275element(9, "div", 12);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "section", 13);
    \u0275\u0275element(11, "div", 14);
    \u0275\u0275template(12, LoginPage_Conditional_1_Conditional_12_Template, 21, 4, "div", 15)(13, LoginPage_Conditional_1_Conditional_13_Template, 19, 5, "div", 15)(14, LoginPage_Conditional_1_Conditional_14_Template, 24, 11, "div", 15);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(5);
    \u0275\u0275conditional(ctx_r1.step !== "email" ? 5 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275property("ngForOf", ctx_r1.onboardingSlides);
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx_r1.step === "email" ? 12 : ctx_r1.step === "otp" ? 13 : ctx_r1.step === "register" ? 14 : -1);
  }
}
function LoginPage_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 2)(1, "div", 67)(2, "img", 68);
    \u0275\u0275listener("error", function LoginPage_Conditional_2_Template_img_error_2_listener($event) {
      \u0275\u0275restoreView(_r10);
      return \u0275\u0275resetView($event.target.style.display = "none");
    });
    \u0275\u0275elementEnd();
    \u0275\u0275element(3, "div", 69);
    \u0275\u0275elementStart(4, "p", 70);
    \u0275\u0275text(5, "Starting Pintu...");
    \u0275\u0275elementEnd()()();
  }
}
register();
var _LoginPage = class _LoginPage {
  constructor(navCtrl, authService, referralService, router) {
    this.navCtrl = navCtrl;
    this.authService = authService;
    this.referralService = referralService;
    this.router = router;
    this.step = "email";
    this.onboardingSlides = [
      {
        badge: "\u26A1 10-15 MIN DELIVERY",
        badgeBg: "rgba(250, 204, 21, 0.2)",
        badgeColor: "#fde047",
        title: "Everyday Needs,",
        highlight: "Delivered in Minutes",
        subtitle: "Groceries, snacks, daily essentials & more delivered to your doorstep at lightning speed.",
        image: "assets/icons/vecteezy_young-delivery-man-in-a-yellow-uniform-flying-to-deliver-an_55983285.png",
        chips: ["\u26A1 10-15 Mins", "\u{1F6CD}\uFE0F 5,000+ Products", "\u{1F6F5} Fast Delivery"]
      },
      {
        badge: "\u{1F6F5} RIDES & COMMUTE",
        badgeBg: "rgba(168, 85, 247, 0.2)",
        badgeColor: "#d8b4fe",
        title: "Fast & Affordable",
        highlight: "Daily Rides & Taxis",
        subtitle: "Instant bike taxis, autos & verified cabs with fair fares and zero surge shocks.",
        image: "assets/icons/vecteezy_young-delivery-man-in-a-yellow-uniform-flying-to-deliver-an_55983285.png",
        chips: ["\u{1F6F5} Bike Taxi", "\u{1F6FA} Auto", "\u{1F697} Cabs", "\u{1F6E1}\uFE0F Safe Rides"]
      },
      {
        badge: "\u{1F966} FRESH GROCERIES",
        badgeBg: "rgba(52, 211, 153, 0.2)",
        badgeColor: "#6ee7b7",
        title: "Farm Fresh Fruits &",
        highlight: "Daily Vegetables",
        subtitle: "Handpicked fresh vegetables and fruits delivered in clean hygienic packaging.",
        image: "assets/icons/wired-lineal-526-paper-bag-vegetables-hover-pinch.webp",
        chips: ["\u{1F33F} 100% Farm Fresh", "\u{1F3F7}\uFE0F Best Prices", "\u2728 Handpicked"]
      }
    ];
    this.email = "";
    this.enteredOtp = "";
    this.fullName = "";
    this.phoneNumber = "";
    this.referralCode = "";
    this.referralStatus = "idle";
    this.referralMessage = "";
    this.referralCheckTimeout = null;
    this.verifyingToken = false;
    this.isSendingOtp = false;
    this.isVerifyingOtp = false;
    this.isLoading = false;
    this.timer = 45;
    this.intervalIdforCount = null;
    this.toastMessage = "";
    this.isToastOpen = false;
    this.otpVerificationMessage = "";
    this.otpConfig = {
      length: 6,
      inputStyles: {
        width: "44px",
        height: "50px",
        "font-size": "20px",
        "font-weight": "700",
        margin: "0 4px",
        "border-radius": "12px",
        border: "1.5px solid #cbd5e1",
        background: "#f8fafc",
        "text-align": "center"
      }
    };
    addIcons({
      arrowBack,
      chevronBack,
      timeOutline,
      personOutline,
      mailOutline,
      mail,
      callOutline,
      arrowForwardOutline,
      checkmarkCircleOutline,
      alertCircleOutline,
      lockClosedOutline,
      shieldCheckmarkOutline,
      createOutline,
      keypadOutline,
      logoWhatsapp,
      giftOutline,
      gift,
      checkmarkCircle
    });
  }
  ngOnInit() {
    return __async(this, null, function* () {
      if (this.authService.hasToken()) {
        this.verifyingToken = true;
        this.navCtrl.navigateRoot("/layout/home");
        return;
      }
      this.verifyingToken = false;
    });
  }
  ngOnDestroy() {
    if (this.intervalIdforCount) {
      clearInterval(this.intervalIdforCount);
    }
    if (this.referralCheckTimeout) {
      clearTimeout(this.referralCheckTimeout);
    }
  }
  onReferralCodeChange(val) {
    if (this.referralCheckTimeout) {
      clearTimeout(this.referralCheckTimeout);
    }
    const trimmed = (val || "").trim();
    if (!trimmed) {
      this.referralStatus = "idle";
      this.referralMessage = "";
      return;
    }
    if (trimmed.length < 3) {
      this.referralStatus = "idle";
      this.referralMessage = "";
      return;
    }
    this.referralStatus = "checking";
    this.referralCheckTimeout = setTimeout(() => {
      this.validateReferralCode(trimmed);
    }, 450);
  }
  validateReferralCode(code) {
    this.referralService.validateReferralCode(code).subscribe({
      next: (res) => {
        if (res == null ? void 0 : res.valid) {
          this.referralStatus = "valid";
          this.referralMessage = (res == null ? void 0 : res.message) || `Referral code applied from ${res.referrer_name}!`;
        } else {
          this.referralStatus = "invalid";
          this.referralMessage = (res == null ? void 0 : res.message) || "Invalid code. You can continue without it.";
        }
      },
      error: () => {
        this.referralStatus = "invalid";
        this.referralMessage = "Could not verify code right now. You can continue without it.";
      }
    });
  }
  showToast(msg) {
    this.toastMessage = msg;
    this.isToastOpen = true;
    setTimeout(() => {
      this.isToastOpen = false;
    }, 3e3);
  }
  isValidEmail() {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(this.email.trim());
  }
  // ─── 1. Send OTP ──────────────────────────────────────────────────────────
  sendVerification() {
    if (!this.isValidEmail()) {
      this.showToast("Please enter a valid email address.");
      return;
    }
    this.isSendingOtp = true;
    this.authService.sendEmailOtp(this.email.trim().toLowerCase()).subscribe({
      next: (res) => {
        this.isSendingOtp = false;
        if (res == null ? void 0 : res.success) {
          this.step = "otp";
          this.enteredOtp = "";
          this.startTimer();
          const devHint = res.devOtp ? ` (Dev Code: ${res.devOtp})` : "";
          this.showToast(`Verification code sent to your email!${devHint}`);
        } else {
          this.showToast((res == null ? void 0 : res.message) || "Failed to send verification code.");
        }
      },
      error: (err) => {
        var _a;
        this.isSendingOtp = false;
        const msg = ((_a = err == null ? void 0 : err.error) == null ? void 0 : _a.message) || (err == null ? void 0 : err.message) || "Failed to send verification code. Please check your connection.";
        this.showToast(msg);
      }
    });
  }
  // ─── 2. Resend OTP ────────────────────────────────────────────────────────
  resendVerification() {
    if (this.timer > 0 || this.isSendingOtp)
      return;
    this.sendVerification();
  }
  startTimer() {
    if (this.intervalIdforCount) {
      clearInterval(this.intervalIdforCount);
    }
    this.timer = 45;
    this.intervalIdforCount = setInterval(() => {
      if (this.timer > 0) {
        this.timer--;
      } else {
        clearInterval(this.intervalIdforCount);
      }
    }, 1e3);
  }
  // ─── 3. Verify OTP ────────────────────────────────────────────────────────
  onOtpChange(otp) {
    this.enteredOtp = otp;
    if (otp && otp.length === 6) {
      this.verifyOtp();
    }
  }
  verifyOtp() {
    if (!this.enteredOtp || this.enteredOtp.length < 6) {
      this.showToast("Please enter the 6-digit verification code.");
      return;
    }
    this.isVerifyingOtp = true;
    this.otpVerificationMessage = "Verifying your code...";
    this.authService.verifyEmailOtp(this.email.trim().toLowerCase(), this.enteredOtp).subscribe({
      next: (res) => {
        this.isVerifyingOtp = false;
        this.otpVerificationMessage = "";
        if (res == null ? void 0 : res.success) {
          if (res.isNewUser) {
            this.step = "register";
            this.showToast("Email verified! Please complete your profile.");
          } else if (res.token) {
            this.authService.saveSession(res.token, res.user);
            this.showToast("Welcome back!");
            this.navCtrl.navigateRoot("/layout/home");
          }
        } else {
          this.showToast((res == null ? void 0 : res.message) || "Invalid verification code.");
        }
      },
      error: (err) => {
        var _a;
        this.isVerifyingOtp = false;
        this.otpVerificationMessage = "";
        const msg = ((_a = err == null ? void 0 : err.error) == null ? void 0 : _a.message) || (err == null ? void 0 : err.message) || "Verification failed. Please try again.";
        this.showToast(msg);
      }
    });
  }
  // ─── 4. Complete Registration (New User) ──────────────────────────────────
  register() {
    if (!this.fullName.trim()) {
      this.showToast("Please enter your full name.");
      return;
    }
    if (!this.phoneNumber || this.phoneNumber.trim().length < 10) {
      this.showToast("Please enter a valid 10-digit mobile number.");
      return;
    }
    this.isLoading = true;
    const cleanPhone = this.phoneNumber.replace(/\D/g, "").slice(-10);
    const params = {
      email: this.email.trim().toLowerCase(),
      username: this.email.trim().toLowerCase(),
      first_name: this.fullName.trim(),
      last_name: "",
      phone: cleanPhone,
      is_active: true,
      is_verified: true
    };
    const cleanReferral = this.referralCode ? this.referralCode.trim().toUpperCase() : "";
    if (cleanReferral && this.referralStatus !== "invalid") {
      params.referral_code = cleanReferral;
    }
    this.authService.register(params).subscribe({
      next: (res) => {
        this.isLoading = false;
        if ((res == null ? void 0 : res.success) && (res == null ? void 0 : res.token)) {
          this.authService.saveSession(res.token, res.user);
          this.showToast("Profile created successfully! Welcome bonus credited.");
          this.navCtrl.navigateRoot("/layout/home");
        } else {
          this.showToast((res == null ? void 0 : res.message) || "Registration failed. Please try again.");
        }
      },
      error: (err) => {
        var _a;
        this.isLoading = false;
        const msg = ((_a = err == null ? void 0 : err.error) == null ? void 0 : _a.message) || (err == null ? void 0 : err.message) || "Registration error. Please check your details.";
        this.showToast(msg);
      }
    });
  }
  // ─── 5. Navigation & Support ──────────────────────────────────────────────
  goBack() {
    if (this.step === "otp") {
      this.step = "email";
      if (this.intervalIdforCount) {
        clearInterval(this.intervalIdforCount);
      }
    } else if (this.step === "register") {
      this.step = "email";
    } else {
      this.navCtrl.back();
    }
  }
  openWhatsAppSupport() {
    window.open("https://wa.me/919999999999", "_system");
  }
  openTerms() {
    this.router.navigate(["/layout/about"], {
      state: { data: "terms" }
    });
  }
  openPrivacy() {
    this.router.navigate(["/layout/about"], {
      state: { data: "privacy" }
    });
  }
};
_LoginPage.\u0275fac = function LoginPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _LoginPage)(\u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(AuthService), \u0275\u0275directiveInject(ReferralService), \u0275\u0275directiveInject(Router));
};
_LoginPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _LoginPage, selectors: [["app-login"]], decls: 4, vars: 6, consts: [[1, "login-split-screen", 3, "fullscreen", "scrollY"], [1, "split-layout-container"], [1, "splash-screen"], ["mode", "ios", 1, "custom-toast", 3, "isOpen", "message", "duration"], [1, "top-slider-section"], [1, "ambient-glow", "glow-purple"], [1, "ambient-glow", "glow-indigo"], [1, "ambient-grid-pattern"], ["type", "button", "aria-label", "Go Back", 1, "btn-circle-back"], [1, "carousel-container"], ["autoplay", '{"delay": 3500, "disableOnInteraction": false}', "loop", "true", "pagination", "true", 1, "onboarding-swiper"], [4, "ngFor", "ngForOf"], [1, "slider-bottom-fade"], [1, "bottom-login-section"], [1, "sheet-handle-bar"], [1, "login-form-body", "animate__animated", "animate__fadeIn"], ["type", "button", "aria-label", "Go Back", 1, "btn-circle-back", 3, "click"], ["name", "arrow-back"], [1, "slide-card"], [1, "slide-badge"], [1, "slide-title"], [1, "highlight-text"], [1, "slide-desc"], [1, "slide-stage"], [1, "glow-halo"], ["alt", "Showcase", 1, "slide-img", 3, "error", "src"], [1, "chips-row"], ["class", "feature-chip", 4, "ngFor", "ngForOf"], [1, "feature-chip"], [1, "form-header"], [1, "form-title"], [1, "form-subtitle"], [1, "input-container-modern", "mb-3"], ["name", "mail-outline", 1, "input-icon-left"], ["type", "email", "placeholder", "Enter your email address", 1, "custom-input", "flex-grow-1", 3, "ngModelChange", "keyup.enter", "ngModel"], ["name", "checkmark-circle-outline", 1, "text-success", "fs-5"], ["type", "button", 1, "btn-primary-action", "w-100", "mb-2", 3, "click", "disabled"], [1, "terms-text", "text-center", "small", "mb-0"], ["role", "button", "tabindex", "0", 1, "text-dark", "fw-semibold", "text-decoration-underline", 3, "click"], ["name", "crescent", 1, "spinner-small", "me-2"], ["name", "arrow-forward-outline", 1, "ms-2", "fs-6"], [1, "form-header", "text-center"], [1, "text-dark"], ["type", "button", "aria-label", "Edit email", 1, "btn-link-edit", "ms-1", 3, "click"], ["name", "create-outline"], [1, "otp-wrapper", "mb-2"], [3, "onInputChange", "config"], [1, "resend-row", "text-center", "mb-3"], [1, "text-muted", "small"], [1, "resend-action", "small"], [1, "resend-action", "small", 3, "click"], ["name", "shield-checkmark-outline", 1, "me-2", "fs-5"], [1, "input-container-modern", "mb-2"], ["name", "person-outline", 1, "input-icon-left"], ["type", "text", "placeholder", "Full Name (e.g. Ramesh Patil)", 1, "custom-input", "flex-grow-1", 3, "ngModelChange", "ngModel"], [1, "phone-prefix"], ["type", "tel", "inputmode", "numeric", "pattern", "[0-9]*", "maxlength", "10", "placeholder", "10-digit mobile number", 1, "custom-input", "flex-grow-1", 3, "ngModelChange", "keyup.enter", "ngModel"], ["name", "gift-outline", 1, "input-icon-left", "text-primary"], ["type", "text", "placeholder", "Referral Code (Optional)", "maxlength", "20", 1, "custom-input", "flex-grow-1", "text-uppercase", 3, "ngModelChange", "ngModel"], ["name", "crescent", 1, "spinner-tiny", "me-1"], ["name", "checkmark-circle", 1, "referral-status-icon", "text-success", "me-1"], ["name", "alert-circle-outline", 1, "referral-status-icon", "text-warning", "me-1"], [1, "referral-feedback", "valid", "animate__animated", "animate__fadeIn", "mb-3"], [1, "referral-feedback", "invalid", "animate__animated", "animate__fadeIn", "mb-3"], ["type", "button", 1, "btn-primary-action", "w-100", "mb-2", "mt-1", 3, "click", "disabled"], ["name", "gift"], ["name", "alert-circle-outline"], [1, "splash-brand"], ["src", "assets/pintu startup.png", "alt", "Pintu", 1, "splash-logo", 3, "error"], [1, "splash-spinner-ring"], [1, "splash-text"]], template: function LoginPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 0);
    \u0275\u0275template(1, LoginPage_Conditional_1_Template, 15, 3, "div", 1)(2, LoginPage_Conditional_2_Template, 6, 0, "div", 2);
    \u0275\u0275element(3, "ion-toast", 3);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275property("fullscreen", true)("scrollY", true);
    \u0275\u0275advance();
    \u0275\u0275conditional(!ctx.verifyingToken ? 1 : 2);
    \u0275\u0275advance(2);
    \u0275\u0275property("isOpen", ctx.isToastOpen)("message", ctx.toastMessage)("duration", 3e3);
  }
}, dependencies: [
  NgOtpInputModule,
  NgOtpInputComponent,
  IonToast,
  IonSpinner,
  IonIcon,
  IonContent,
  CommonModule,
  NgForOf,
  FormsModule,
  DefaultValueAccessor,
  NgControlStatus,
  MaxLengthValidator,
  PatternValidator,
  NgModel
], styles: ["\n\n.login-split-screen[_ngcontent-%COMP%] {\n  --background: #090314;\n  --overflow: auto;\n  position: relative;\n  min-height: 100vh;\n}\n.split-layout-container[_ngcontent-%COMP%] {\n  min-height: 100vh;\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n  background: #090314;\n  position: relative;\n}\n.top-slider-section[_ngcontent-%COMP%] {\n  height: 65vh;\n  height: 65dvh;\n  min-height: 380px;\n  position: relative;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n  background:\n    radial-gradient(\n      circle at 80% 20%,\n      #4c1d95 0%,\n      #2e0854 45%,\n      #0d021a 100%);\n  overflow: hidden;\n  padding-top: calc(env(safe-area-inset-top, 0px) + 8px);\n  z-index: 1;\n}\n.top-slider-section[_ngcontent-%COMP%]   .ambient-glow[_ngcontent-%COMP%] {\n  position: absolute;\n  border-radius: 50%;\n  pointer-events: none;\n  filter: blur(80px);\n  z-index: 0;\n}\n.top-slider-section[_ngcontent-%COMP%]   .ambient-glow.glow-purple[_ngcontent-%COMP%] {\n  width: 320px;\n  height: 320px;\n  background:\n    radial-gradient(\n      circle,\n      rgba(160, 0, 226, 0.35) 0%,\n      rgba(160, 0, 226, 0) 70%);\n  top: -60px;\n  left: -80px;\n}\n.top-slider-section[_ngcontent-%COMP%]   .ambient-glow.glow-indigo[_ngcontent-%COMP%] {\n  width: 360px;\n  height: 360px;\n  background:\n    radial-gradient(\n      circle,\n      rgba(99, 102, 241, 0.22) 0%,\n      rgba(99, 102, 241, 0) 70%);\n  top: 100px;\n  right: -100px;\n}\n.top-slider-section[_ngcontent-%COMP%]   .ambient-grid-pattern[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  background-image:\n    linear-gradient(\n      to right,\n      rgba(255, 255, 255, 0.03) 1px,\n      transparent 1px),\n    linear-gradient(\n      to bottom,\n      rgba(255, 255, 255, 0.03) 1px,\n      transparent 1px);\n  background-size: 32px 32px;\n  pointer-events: none;\n  z-index: 0;\n  -webkit-mask-image:\n    radial-gradient(\n      ellipse at center,\n      black 40%,\n      transparent 80%);\n  mask-image:\n    radial-gradient(\n      ellipse at center,\n      black 40%,\n      transparent 80%);\n}\n.top-slider-section[_ngcontent-%COMP%]   .btn-circle-back[_ngcontent-%COMP%] {\n  position: absolute;\n  top: calc(env(safe-area-inset-top, 0px) + 14px);\n  left: 16px;\n  width: 38px;\n  height: 38px;\n  border-radius: 50%;\n  background: rgba(255, 255, 255, 0.18);\n  -webkit-backdrop-filter: blur(8px);\n  backdrop-filter: blur(8px);\n  border: 1px solid rgba(255, 255, 255, 0.25);\n  color: #ffffff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 20px;\n  cursor: pointer;\n  transition: transform 0.15s ease, background 0.15s ease;\n  z-index: 20;\n}\n.top-slider-section[_ngcontent-%COMP%]   .btn-circle-back[_ngcontent-%COMP%]:active {\n  transform: scale(0.92);\n  background: rgba(255, 255, 255, 0.28);\n}\n.carousel-container[_ngcontent-%COMP%] {\n  flex: 1;\n  width: 100%;\n  height: 100%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  position: relative;\n  z-index: 3;\n  padding-bottom: 20px;\n  box-sizing: border-box;\n}\n.carousel-container[_ngcontent-%COMP%]   .onboarding-swiper[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  --swiper-pagination-bottom: 6px;\n  --swiper-pagination-color: #facc15;\n  --swiper-pagination-bullet-inactive-color: rgba(255, 255, 255, 0.35);\n  --swiper-pagination-bullet-inactive-opacity: 0.8;\n}\n.carousel-container[_ngcontent-%COMP%]   swiper-slide[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  height: 100%;\n  width: 100%;\n  box-sizing: border-box;\n}\n.carousel-container[_ngcontent-%COMP%]   swiper-container[_ngcontent-%COMP%]::part(bullet) {\n  width: 6px;\n  height: 6px;\n  background: rgba(255, 255, 255, 0.4);\n  transition: all 0.3s ease;\n  border-radius: 99px;\n}\n.carousel-container[_ngcontent-%COMP%]   swiper-container[_ngcontent-%COMP%]::part(bullet-active) {\n  width: 20px;\n  height: 6px;\n  background: #facc15;\n  border-radius: 99px;\n}\n.carousel-container[_ngcontent-%COMP%]   .slide-card[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  text-align: center;\n  padding: 4px 20px;\n  box-sizing: border-box;\n  width: 100%;\n  max-width: 380px;\n  margin: auto;\n}\n.carousel-container[_ngcontent-%COMP%]   .slide-card[_ngcontent-%COMP%]   .slide-badge[_ngcontent-%COMP%] {\n  display: inline-block;\n  font-size: 10.5px;\n  font-weight: 800;\n  letter-spacing: 0.8px;\n  padding: 3.5px 11px;\n  border-radius: 99px;\n  margin-bottom: 8px;\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);\n  text-transform: uppercase;\n}\n.carousel-container[_ngcontent-%COMP%]   .slide-card[_ngcontent-%COMP%]   .slide-title[_ngcontent-%COMP%] {\n  font-size: 21px;\n  font-weight: 800;\n  line-height: 1.25;\n  color: #ffffff;\n  margin: 0 0 4px 0;\n  letter-spacing: -0.3px;\n}\n.carousel-container[_ngcontent-%COMP%]   .slide-card[_ngcontent-%COMP%]   .slide-title[_ngcontent-%COMP%]   .highlight-text[_ngcontent-%COMP%] {\n  color: #facc15;\n  background:\n    linear-gradient(\n      120deg,\n      #fef08a 0%,\n      #facc15 100%);\n  -webkit-background-clip: text;\n  -webkit-text-fill-color: transparent;\n}\n.carousel-container[_ngcontent-%COMP%]   .slide-card[_ngcontent-%COMP%]   .slide-desc[_ngcontent-%COMP%] {\n  font-size: 12.5px;\n  color: #e9d5ff;\n  line-height: 1.4;\n  margin: 0 0 8px 0;\n  max-width: 320px;\n}\n.carousel-container[_ngcontent-%COMP%]   .slide-card[_ngcontent-%COMP%]   .slide-stage[_ngcontent-%COMP%] {\n  position: relative;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  height: 130px;\n  width: 100%;\n  margin: 2px 0 8px;\n}\n.carousel-container[_ngcontent-%COMP%]   .slide-card[_ngcontent-%COMP%]   .slide-stage[_ngcontent-%COMP%]   .glow-halo[_ngcontent-%COMP%] {\n  position: absolute;\n  width: 110px;\n  height: 110px;\n  border-radius: 50%;\n  background:\n    radial-gradient(\n      circle,\n      rgba(250, 204, 21, 0.25) 0%,\n      rgba(160, 0, 226, 0) 70%);\n  filter: blur(14px);\n}\n.carousel-container[_ngcontent-%COMP%]   .slide-card[_ngcontent-%COMP%]   .slide-stage[_ngcontent-%COMP%]   .slide-img[_ngcontent-%COMP%] {\n  max-height: 125px;\n  max-width: 80%;\n  object-fit: contain;\n  filter: drop-shadow(0 12px 24px rgba(0, 0, 0, 0.35));\n  position: relative;\n  z-index: 2;\n}\n.carousel-container[_ngcontent-%COMP%]   .slide-card[_ngcontent-%COMP%]   .chips-row[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  justify-content: center;\n  gap: 6px;\n  max-width: 320px;\n}\n.carousel-container[_ngcontent-%COMP%]   .slide-card[_ngcontent-%COMP%]   .chips-row[_ngcontent-%COMP%]   .feature-chip[_ngcontent-%COMP%] {\n  background: rgba(255, 255, 255, 0.14);\n  -webkit-backdrop-filter: blur(8px);\n  backdrop-filter: blur(8px);\n  border: 1px solid rgba(255, 255, 255, 0.2);\n  color: #ffffff;\n  font-size: 10.5px;\n  font-weight: 700;\n  padding: 3.5px 9px;\n  border-radius: 99px;\n}\n.slider-bottom-fade[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  height: 20px;\n  background:\n    linear-gradient(\n      to bottom,\n      rgba(13, 2, 26, 0) 0%,\n      rgba(13, 2, 26, 0.35) 100%);\n  pointer-events: none;\n  z-index: 4;\n}\n.bottom-login-section[_ngcontent-%COMP%] {\n  min-height: 35vh;\n  min-height: 35dvh;\n  flex: 1 1 auto;\n  background: #ffffff;\n  border-radius: 28px 28px 0 0;\n  box-shadow: 0 -12px 36px rgba(0, 0, 0, 0.24);\n  padding: 16px 22px calc(20px + env(safe-area-inset-bottom, 12px));\n  position: relative;\n  z-index: 10;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  box-sizing: border-box;\n}\n.bottom-login-section[_ngcontent-%COMP%]   .sheet-handle-bar[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 4px;\n  border-radius: 99px;\n  background: #cbd5e1;\n  margin: 0 auto 12px;\n  flex-shrink: 0;\n}\n.bottom-login-section[_ngcontent-%COMP%]   .login-form-body[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  width: 100%;\n  max-width: 440px;\n  margin: 0 auto;\n}\n.bottom-login-section[_ngcontent-%COMP%]   .form-header[_ngcontent-%COMP%] {\n  margin-bottom: 12px;\n}\n.bottom-login-section[_ngcontent-%COMP%]   .form-header[_ngcontent-%COMP%]   .form-title[_ngcontent-%COMP%] {\n  font-size: 18px;\n  font-weight: 800;\n  color: #0f172a;\n  margin: 0 0 3px;\n  letter-spacing: -0.3px;\n}\n.bottom-login-section[_ngcontent-%COMP%]   .form-header[_ngcontent-%COMP%]   .form-subtitle[_ngcontent-%COMP%] {\n  font-size: 12.5px;\n  color: #64748b;\n  margin: 0;\n  line-height: 1.4;\n}\n.bottom-login-section[_ngcontent-%COMP%]   .form-header[_ngcontent-%COMP%]   .form-subtitle[_ngcontent-%COMP%]   .btn-link-edit[_ngcontent-%COMP%] {\n  background: transparent;\n  border: none;\n  color: #a000e2;\n  font-size: 12px;\n  font-weight: 700;\n  cursor: pointer;\n  padding: 0 4px;\n  display: inline-flex;\n  align-items: center;\n  gap: 2px;\n  text-decoration: underline;\n}\n.input-container-modern[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  background: #f8fafc;\n  border: 1.5px solid #e2e8f0;\n  border-radius: 14px;\n  padding: 4px 14px;\n  transition: all 0.2s ease;\n}\n.input-container-modern[_ngcontent-%COMP%]:focus-within {\n  border-color: #a000e2;\n  background: #ffffff;\n  box-shadow: 0 0 0 3px rgba(160, 0, 226, 0.12);\n}\n.input-container-modern[_ngcontent-%COMP%]   .input-icon-left[_ngcontent-%COMP%] {\n  color: #94a3b8;\n  font-size: 19px;\n  margin-right: 10px;\n  flex-shrink: 0;\n}\n.input-container-modern[_ngcontent-%COMP%]   .phone-prefix[_ngcontent-%COMP%] {\n  font-size: 15px;\n  font-weight: 700;\n  color: #0f172a;\n  padding-right: 10px;\n  margin-right: 10px;\n  border-right: 1.5px solid #e2e8f0;\n}\n.input-container-modern[_ngcontent-%COMP%]   .custom-input[_ngcontent-%COMP%] {\n  border: none;\n  background: transparent;\n  outline: none;\n  font-size: 14.5px;\n  font-weight: 600;\n  color: #0f172a;\n  padding: 10px 0;\n  width: 100%;\n}\n.input-container-modern[_ngcontent-%COMP%]   .custom-input[_ngcontent-%COMP%]::placeholder {\n  color: #94a3b8;\n  font-weight: 400;\n}\n.input-container-modern.border-valid[_ngcontent-%COMP%] {\n  border-color: #10b981;\n  background: #f0fdf4;\n}\n.input-container-modern.border-invalid[_ngcontent-%COMP%] {\n  border-color: #f59e0b;\n  background: #fffbeb;\n}\n.input-container-modern[_ngcontent-%COMP%]   .referral-status-icon[_ngcontent-%COMP%] {\n  font-size: 20px;\n  flex-shrink: 0;\n}\n.input-container-modern[_ngcontent-%COMP%]   .referral-status-icon.text-success[_ngcontent-%COMP%] {\n  color: #10b981;\n}\n.input-container-modern[_ngcontent-%COMP%]   .referral-status-icon.text-warning[_ngcontent-%COMP%] {\n  color: #f59e0b;\n}\n.input-container-modern[_ngcontent-%COMP%]   .spinner-tiny[_ngcontent-%COMP%] {\n  width: 16px;\n  height: 16px;\n  --color: #a000e2;\n}\n.referral-feedback[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  padding: 6px 12px;\n  border-radius: 10px;\n  font-size: 12px;\n  font-weight: 600;\n}\n.referral-feedback.valid[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  color: #065f46;\n  border: 1px solid #a7f3d0;\n}\n.referral-feedback.invalid[_ngcontent-%COMP%] {\n  background: #fffbeb;\n  color: #92400e;\n  border: 1px solid #fde68a;\n}\n.referral-feedback[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 15px;\n  flex-shrink: 0;\n}\n.otp-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: center;\n}\n.otp-wrapper[_ngcontent-%COMP%]     .otp-input {\n  width: 42px !important;\n  height: 48px !important;\n  border-radius: 12px !important;\n  border: 1.5px solid #cbd5e1 !important;\n  background: #f8fafc !important;\n  font-size: 19px !important;\n  font-weight: 700 !important;\n  color: #0f172a !important;\n  text-align: center !important;\n  margin: 0 4px !important;\n  outline: none !important;\n  transition: all 0.18s ease !important;\n}\n.otp-wrapper[_ngcontent-%COMP%]     .otp-input:focus {\n  border-color: #a000e2 !important;\n  background: #ffffff !important;\n  box-shadow: 0 0 0 3px rgba(160, 0, 226, 0.12) !important;\n}\n.resend-row[_ngcontent-%COMP%]   .resend-action[_ngcontent-%COMP%] {\n  color: #a000e2;\n  font-weight: 700;\n  cursor: pointer;\n  text-decoration: underline;\n}\n.btn-primary-action[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #a000e2 0%,\n      #7e00b3 100%);\n  color: #ffffff;\n  border: none;\n  border-radius: 14px;\n  padding: 13px 20px;\n  font-size: 14.5px;\n  font-weight: 700;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  box-shadow: 0 6px 18px rgba(160, 0, 226, 0.28);\n  transition: all 0.2s ease;\n  cursor: pointer;\n}\n.btn-primary-action[_ngcontent-%COMP%]:active {\n  transform: scale(0.985);\n}\n.btn-primary-action[_ngcontent-%COMP%]:disabled {\n  opacity: 0.55;\n  cursor: not-allowed;\n}\n.terms-text[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  color: #94a3b8;\n  line-height: 1.4;\n  margin-top: 8px;\n}\n.spinner-small[_ngcontent-%COMP%] {\n  width: 18px;\n  height: 18px;\n}\n.splash-screen[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  background: #f8fafc;\n  z-index: 10000;\n}\n.splash-screen[_ngcontent-%COMP%]   .splash-brand[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n}\n.splash-screen[_ngcontent-%COMP%]   .splash-brand[_ngcontent-%COMP%]   .splash-logo[_ngcontent-%COMP%] {\n  width: 72px;\n  height: 72px;\n  border-radius: 20px;\n  object-fit: contain;\n  margin-bottom: 24px;\n  box-shadow: 0 12px 32px rgba(160, 0, 226, 0.15);\n}\n.splash-screen[_ngcontent-%COMP%]   .splash-brand[_ngcontent-%COMP%]   .splash-spinner-ring[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n  border-radius: 50%;\n  border: 3px solid #e2e8f0;\n  border-top-color: #a000e2;\n  animation: _ngcontent-%COMP%_spin 0.8s linear infinite;\n  margin-bottom: 14px;\n}\n.splash-screen[_ngcontent-%COMP%]   .splash-brand[_ngcontent-%COMP%]   .splash-text[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 700;\n  color: #334155;\n  letter-spacing: 0.5px;\n  margin: 0;\n}\n@keyframes _ngcontent-%COMP%_spin {\n  to {\n    transform: rotate(360deg);\n  }\n}\n/*# sourceMappingURL=login.page.css.map */"] });
var LoginPage = _LoginPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(LoginPage, { className: "LoginPage", filePath: "src/app/pages/login/login.page.ts", lineNumber: 67 });
})();
export {
  LoginPage
};
//# sourceMappingURL=login.page-NO7QLV75.js.map
