import {
  PintuPocketService
} from "./chunk-PF5HLQEL.js";
import {
  addIcons,
  arrowBackOutline,
  arrowDownOutline,
  arrowForward,
  arrowUpOutline,
  cardOutline,
  cartOutline,
  checkmarkCircle,
  checkmarkOutline,
  flashOutline,
  giftOutline,
  helpCircleOutline,
  informationCircleOutline,
  receiptOutline,
  refreshOutline,
  shareSocialOutline,
  shieldCheckmarkOutline,
  sparklesOutline,
  starOutline,
  walletOutline
} from "./chunk-I7AJKZVE.js";
import {
  IonContent,
  IonHeader,
  IonIcon,
  IonRefresher,
  IonRefresherContent,
  IonToolbar,
  ToastController
} from "./chunk-CJE2NDTY.js";
import {
  AsyncPipe,
  CommonModule,
  DecimalPipe,
  NavController,
  Router,
  inject,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdeclareLet,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind1,
  ɵɵpipeBind2,
  ɵɵreadContextLet,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵstoreLet,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2
} from "./chunk-Z7XNNJSA.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import "./chunk-6B6DTIB5.js";

// src/app/pages/pintu-pocket/pintu-pocket.page.ts
var _forTrack0 = ($index, $item) => $item.id;
function PintuPocketPage_Conditional_151_For_1_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 51);
  }
}
function PintuPocketPage_Conditional_151_For_1_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 45);
  }
}
function PintuPocketPage_Conditional_151_For_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 76)(1, "div", 77);
    \u0275\u0275template(2, PintuPocketPage_Conditional_151_For_1_Conditional_2_Template, 1, 0, "ion-icon", 51)(3, PintuPocketPage_Conditional_151_For_1_Conditional_3_Template, 1, 0, "ion-icon", 45);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "div", 78)(5, "span", 79);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "span", 80);
    \u0275\u0275text(8);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "div", 81)(10, "span", 82);
    \u0275\u0275text(11);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "span", 83);
    \u0275\u0275text(13);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(14, "div", 84)(15, "span", 85);
    \u0275\u0275text(16);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "span", 86);
    \u0275\u0275text(18);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const txn_r2 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275classProp("credit", txn_r2.type === "credit")("debit", txn_r2.type === "debit");
    \u0275\u0275advance();
    \u0275\u0275conditional(txn_r2.type === "credit" ? 2 : 3);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(txn_r2.title);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(txn_r2.subtitle);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate2("", ctx_r2.formatDate(txn_r2.timestamp), " \u2022 ", ctx_r2.formatTime(txn_r2.timestamp), "");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("#", txn_r2.referenceId, "");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("credit", txn_r2.type === "credit")("debit", txn_r2.type === "debit");
    \u0275\u0275advance();
    \u0275\u0275textInterpolate2(" ", txn_r2.type === "credit" ? "+" : "-", "\u20B9", txn_r2.amount, " ");
    \u0275\u0275advance();
    \u0275\u0275classProp("credit", txn_r2.type === "credit");
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", txn_r2.type === "credit" ? "EARNED" : "REDEEMED", " ");
  }
}
function PintuPocketPage_Conditional_151_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275repeaterCreate(0, PintuPocketPage_Conditional_151_For_1_Template, 19, 19, "div", 76, _forTrack0);
  }
  if (rf & 2) {
    \u0275\u0275nextContext();
    const filteredTxns_r4 = \u0275\u0275readContextLet(149);
    \u0275\u0275repeater(filteredTxns_r4);
  }
}
function PintuPocketPage_Conditional_152_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 74)(1, "div", 87);
    \u0275\u0275element(2, "ion-icon", 88);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "h5");
    \u0275\u0275text(4, "No Transactions Found");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p");
    \u0275\u0275text(6, "Records for this filter will appear here");
    \u0275\u0275elementEnd()();
  }
}
var _PintuPocketPage = class _PintuPocketPage {
  constructor() {
    this.router = inject(Router);
    this.navCtrl = inject(NavController);
    this.toastCtrl = inject(ToastController);
    this.pocketService = inject(PintuPocketService);
    this.balance$ = this.pocketService.balance$;
    this.transactions$ = this.pocketService.transactions$;
    this.activeFilter = "all";
    addIcons({
      arrowBackOutline,
      walletOutline,
      checkmarkCircle,
      shieldCheckmarkOutline,
      flashOutline,
      giftOutline,
      receiptOutline,
      refreshOutline,
      helpCircleOutline,
      arrowDownOutline,
      arrowUpOutline,
      sparklesOutline,
      cardOutline,
      checkmarkOutline,
      shareSocialOutline,
      cartOutline,
      arrowForward,
      starOutline,
      informationCircleOutline
    });
  }
  ngOnInit() {
  }
  goBack() {
    this.navCtrl.back();
  }
  handleRefresh(event) {
    setTimeout(() => {
      event.target.complete();
    }, 600);
  }
  goToReferral() {
    this.router.navigate(["/layout/referral"]);
  }
  goToExplore() {
    this.router.navigate(["/layout/home"]);
  }
  filterTransactions(transactions) {
    if (!transactions)
      return [];
    if (this.activeFilter === "all")
      return transactions;
    if (this.activeFilter === "earned") {
      return transactions.filter((t) => t.type === "credit");
    }
    if (this.activeFilter === "spent") {
      return transactions.filter((t) => t.type === "debit");
    }
    return transactions;
  }
  formatDate(isoStr) {
    if (!isoStr)
      return "";
    const date = new Date(isoStr);
    return date.toLocaleDateString("en-IN", {
      day: "numeric",
      month: "short",
      year: "numeric"
    });
  }
  formatTime(isoStr) {
    if (!isoStr)
      return "";
    const date = new Date(isoStr);
    return date.toLocaleTimeString("en-IN", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: true
    });
  }
};
_PintuPocketPage.\u0275fac = function PintuPocketPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _PintuPocketPage)();
};
_PintuPocketPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _PintuPocketPage, selectors: [["app-pintu-pocket"]], decls: 154, vars: 16, consts: [[1, "pocket-header", "ion-no-border"], [1, "pocket-toolbar"], [1, "header-content-row"], ["type", "button", "aria-label", "Go Back", 1, "btn-back", 3, "click"], ["name", "arrow-back-outline"], [1, "header-title-col"], [1, "header-title"], [1, "header-subtitle"], ["title", "Rewards Wallet", 1, "pocket-icon-badge"], ["name", "wallet-outline"], [1, "pocket-content"], ["slot", "fixed", 3, "ionRefresh"], [1, "pocket-container"], [1, "pocket-hero-card"], [1, "hero-bg-glow", "glow-1"], [1, "hero-bg-glow", "glow-2"], [1, "card-top-row"], [1, "wallet-tag"], ["name", "sparkles-outline"], [1, "live-active-tag"], [1, "card-balance-block"], [1, "balance-label"], [1, "balance-number-row"], [1, "currency-symbol"], [1, "balance-amount"], [1, "card-perk-footer"], [1, "perk-pill"], ["name", "shield-checkmark-outline"], [1, "wallet-info-note"], [1, "note-icon-wrap"], ["name", "information-circle-outline"], [1, "note-text-col"], [1, "how-to-earn-section"], [1, "section-heading-row"], [1, "section-title-col"], [1, "section-title"], [1, "section-subtitle"], [1, "earn-cards-list"], [1, "earn-card", "welcome"], [1, "earn-icon-circle", "amber"], [1, "earn-info-col"], [1, "earn-title-row"], [1, "reward-tag", "amber"], [1, "earn-card", "cashback"], [1, "earn-icon-circle", "green"], ["name", "cart-outline"], [1, "reward-tag", "green"], ["type", "button", 1, "btn-earn-action", "green", 3, "click"], ["name", "arrow-forward"], [1, "earn-card", "referral"], [1, "earn-icon-circle", "purple"], ["name", "gift-outline"], [1, "reward-tag", "purple"], ["type", "button", 1, "btn-earn-action", "purple", 3, "click"], [1, "earn-card", "campaigns"], [1, "earn-icon-circle", "rose"], ["name", "star-outline"], [1, "reward-tag", "rose"], [1, "perks-grid"], [1, "perk-card"], [1, "perk-icon-circle", "purple"], ["name", "flash-outline"], [1, "perk-text"], [1, "perk-icon-circle", "green"], [1, "perk-icon-circle", "amber"], ["name", "refresh-outline"], [1, "passbook-section"], [1, "passbook-header"], [1, "passbook-title-col"], [1, "passbook-title"], [1, "passbook-sub"], [1, "filter-tabs-strip"], ["type", "button", 1, "filter-pill", 3, "click"], [1, "transactions-list"], [1, "empty-passbook"], [1, "pocket-bottom-spacer"], [1, "txn-card"], [1, "txn-icon-circle"], [1, "txn-info-col"], [1, "txn-title"], [1, "txn-subtitle"], [1, "txn-meta-row"], [1, "txn-time"], [1, "txn-ref"], [1, "txn-amount-col"], [1, "txn-amount"], [1, "txn-category-badge"], [1, "empty-icon-circle"], ["name", "receipt-outline"]], template: function PintuPocketPage_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar", 1)(2, "div", 2)(3, "button", 3);
    \u0275\u0275listener("click", function PintuPocketPage_Template_button_click_3_listener() {
      \u0275\u0275restoreView(_r1);
      return \u0275\u0275resetView(ctx.goBack());
    });
    \u0275\u0275element(4, "ion-icon", 4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 5)(6, "h3", 6);
    \u0275\u0275text(7, "Pintu Pocket");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "span", 7);
    \u0275\u0275text(9, "Rewards & Welcome Bonus Wallet");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(10, "div", 8);
    \u0275\u0275element(11, "ion-icon", 9);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(12, "ion-content", 10)(13, "ion-refresher", 11);
    \u0275\u0275listener("ionRefresh", function PintuPocketPage_Template_ion_refresher_ionRefresh_13_listener($event) {
      \u0275\u0275restoreView(_r1);
      return \u0275\u0275resetView(ctx.handleRefresh($event));
    });
    \u0275\u0275element(14, "ion-refresher-content");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "main", 12)(16, "section", 13);
    \u0275\u0275element(17, "div", 14)(18, "div", 15);
    \u0275\u0275elementStart(19, "div", 16)(20, "div", 17);
    \u0275\u0275element(21, "ion-icon", 18);
    \u0275\u0275elementStart(22, "span");
    \u0275\u0275text(23, "REWARDS & BONUS POCKET");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(24, "span", 19);
    \u0275\u0275text(25, "100% USABLE");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(26, "div", 20)(27, "span", 21);
    \u0275\u0275text(28, "Total Rewards Balance");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(29, "div", 22)(30, "span", 23);
    \u0275\u0275text(31, "\u20B9");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(32, "span", 24);
    \u0275\u0275text(33);
    \u0275\u0275pipe(34, "async");
    \u0275\u0275pipe(35, "number");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(36, "div", 25)(37, "div", 26);
    \u0275\u0275element(38, "ion-icon", 27);
    \u0275\u0275elementStart(39, "span");
    \u0275\u0275text(40, "Auto-applied to discount your next orders");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(41, "section", 28)(42, "div", 29);
    \u0275\u0275element(43, "ion-icon", 30);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(44, "div", 31)(45, "h6");
    \u0275\u0275text(46, "Promotional Rewards Wallet");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(47, "p");
    \u0275\u0275text(48, "Pintu Pocket cannot be manually loaded. It exclusively accumulates your Welcome Bonus, Order Cashbacks, and Referral Rewards.");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(49, "section", 32)(50, "div", 33)(51, "div", 34)(52, "h4", 35);
    \u0275\u0275text(53, "Ways to Earn Rewards");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(54, "span", 36);
    \u0275\u0275text(55, "Boost your Pocket balance across Pintu services");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(56, "div", 37)(57, "div", 38)(58, "div", 39);
    \u0275\u0275element(59, "ion-icon", 18);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(60, "div", 40)(61, "div", 41)(62, "h5");
    \u0275\u0275text(63, "Welcome Joining Bonus");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(64, "span", 42);
    \u0275\u0275text(65, "\u20B950 Bonus");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(66, "p");
    \u0275\u0275text(67, "Instant bonus credited to your Pintu Pocket upon account onboarding & profile verification.");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(68, "div", 43)(69, "div", 44);
    \u0275\u0275element(70, "ion-icon", 45);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(71, "div", 40)(72, "div", 41)(73, "h5");
    \u0275\u0275text(74, "Order Cashbacks");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(75, "span", 46);
    \u0275\u0275text(76, "Up to 10%");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(77, "p");
    \u0275\u0275text(78, "Earn instant cashback on Groceries, Rides, Medicines & Dineout bill payments.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(79, "button", 47);
    \u0275\u0275listener("click", function PintuPocketPage_Template_button_click_79_listener() {
      \u0275\u0275restoreView(_r1);
      return \u0275\u0275resetView(ctx.goToExplore());
    });
    \u0275\u0275elementStart(80, "span");
    \u0275\u0275text(81, "Order Now & Earn");
    \u0275\u0275elementEnd();
    \u0275\u0275element(82, "ion-icon", 48);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(83, "div", 49)(84, "div", 50);
    \u0275\u0275element(85, "ion-icon", 51);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(86, "div", 40)(87, "div", 41)(88, "h5");
    \u0275\u0275text(89, "Refer Friends & Family");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(90, "span", 52);
    \u0275\u0275text(91, "\u20B950 / Friend");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(92, "p");
    \u0275\u0275text(93, "Share your invite code. You both receive bonus rewards when your friend places their first order.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(94, "button", 53);
    \u0275\u0275listener("click", function PintuPocketPage_Template_button_click_94_listener() {
      \u0275\u0275restoreView(_r1);
      return \u0275\u0275resetView(ctx.goToReferral());
    });
    \u0275\u0275elementStart(95, "span");
    \u0275\u0275text(96, "Invite Friends");
    \u0275\u0275elementEnd();
    \u0275\u0275element(97, "ion-icon", 48);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(98, "div", 54)(99, "div", 55);
    \u0275\u0275element(100, "ion-icon", 56);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(101, "div", 40)(102, "div", 41)(103, "h5");
    \u0275\u0275text(104, "Seasonal Drops & Contests");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(105, "span", 57);
    \u0275\u0275text(106, "Surprise Drops");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(107, "p");
    \u0275\u0275text(108, "Participate in festive scratch cards and promotional sales events for surprise rewards.");
    \u0275\u0275elementEnd()()()()();
    \u0275\u0275elementStart(109, "section", 58)(110, "div", 59)(111, "div", 60);
    \u0275\u0275element(112, "ion-icon", 61);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(113, "div", 62)(114, "h5");
    \u0275\u0275text(115, "1-Tap Auto-Apply");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(116, "p");
    \u0275\u0275text(117, "Deducts automatically at checkout without entering coupon codes");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(118, "div", 59)(119, "div", 63);
    \u0275\u0275element(120, "ion-icon", 27);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(121, "div", 62)(122, "h5");
    \u0275\u0275text(123, "Stacks with Coupons");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(124, "p");
    \u0275\u0275text(125, "Use your Pocket rewards on top of merchant discounts and offers");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(126, "div", 59)(127, "div", 64);
    \u0275\u0275element(128, "ion-icon", 65);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(129, "div", 62)(130, "h5");
    \u0275\u0275text(131, "Instant Re-credit");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(132, "p");
    \u0275\u0275text(133, "Cancelled orders immediately restore your spent Pocket rewards");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(134, "section", 66)(135, "div", 67)(136, "div", 68)(137, "h4", 69);
    \u0275\u0275text(138, "Pocket Passbook");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(139, "span", 70);
    \u0275\u0275text(140, "Complete rewards earnings & redemptions");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(141, "div", 71)(142, "button", 72);
    \u0275\u0275listener("click", function PintuPocketPage_Template_button_click_142_listener() {
      \u0275\u0275restoreView(_r1);
      return \u0275\u0275resetView(ctx.activeFilter = "all");
    });
    \u0275\u0275text(143, " All History ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(144, "button", 72);
    \u0275\u0275listener("click", function PintuPocketPage_Template_button_click_144_listener() {
      \u0275\u0275restoreView(_r1);
      return \u0275\u0275resetView(ctx.activeFilter = "earned");
    });
    \u0275\u0275text(145, " \u{1F381} Rewards Earned ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(146, "button", 72);
    \u0275\u0275listener("click", function PintuPocketPage_Template_button_click_146_listener() {
      \u0275\u0275restoreView(_r1);
      return \u0275\u0275resetView(ctx.activeFilter = "spent");
    });
    \u0275\u0275text(147, " \u{1F6D2} Redeemed on Orders ");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(148, "div", 73);
    \u0275\u0275declareLet(149);
    \u0275\u0275pipe(150, "async");
    \u0275\u0275template(151, PintuPocketPage_Conditional_151_Template, 2, 0)(152, PintuPocketPage_Conditional_152_Template, 7, 0, "div", 74);
    \u0275\u0275elementEnd()();
    \u0275\u0275element(153, "div", 75);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(33);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(35, 10, \u0275\u0275pipeBind1(34, 8, ctx.balance$), "1.2-2"));
    \u0275\u0275advance(109);
    \u0275\u0275classProp("active", ctx.activeFilter === "all");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx.activeFilter === "earned");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx.activeFilter === "spent");
    \u0275\u0275advance(3);
    const filteredTxns_r5 = \u0275\u0275storeLet(ctx.filterTransactions(\u0275\u0275pipeBind1(150, 13, ctx.transactions$)));
    \u0275\u0275advance(2);
    \u0275\u0275conditional(filteredTxns_r5.length > 0 ? 151 : 152);
  }
}, dependencies: [
  CommonModule,
  AsyncPipe,
  DecimalPipe,
  IonHeader,
  IonToolbar,
  IonContent,
  IonIcon,
  IonRefresher,
  IonRefresherContent
], styles: ['@charset "UTF-8";\n\n\n\n[_nghost-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  width: 100%;\n  height: 100%;\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  overflow: hidden;\n  --theme-purple: #7c3aed;\n  --theme-purple-dark: #4c1d95;\n}\n.pocket-content[_ngcontent-%COMP%] {\n  flex: 1;\n  width: 100%;\n  height: 100%;\n  position: relative;\n  --background: #f8fafc;\n}\n.pocket-header[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-bottom: 1px solid #f1f5f9;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);\n  padding: 0 !important;\n  margin: 0 !important;\n  --ion-safe-area-top: 0px;\n  flex-shrink: 0;\n}\n.pocket-toolbar[_ngcontent-%COMP%] {\n  --background: #ffffff;\n  --padding-top: env(safe-area-inset-top, 0px);\n  --padding-bottom: 8px;\n  --padding-start: 14px;\n  --padding-end: 14px;\n}\n.header-content-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  width: 100%;\n}\n.header-content-row[_ngcontent-%COMP%]   .btn-back[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 38px;\n  border-radius: 10px;\n  background: #f1f5f9;\n  border: 1px solid #e2e8f0;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  color: #0f172a;\n  font-size: 19px;\n  cursor: pointer;\n  flex-shrink: 0;\n}\n.header-content-row[_ngcontent-%COMP%]   .btn-back[_ngcontent-%COMP%]:active {\n  transform: scale(0.94);\n}\n.header-content-row[_ngcontent-%COMP%]   .header-title-col[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 0;\n}\n.header-content-row[_ngcontent-%COMP%]   .header-title-col[_ngcontent-%COMP%]   .header-title[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 17px;\n  font-weight: 850;\n  color: #0f172a;\n  letter-spacing: -0.2px;\n}\n.header-content-row[_ngcontent-%COMP%]   .header-title-col[_ngcontent-%COMP%]   .header-subtitle[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #64748b;\n  font-weight: 500;\n}\n.header-content-row[_ngcontent-%COMP%]   .pocket-icon-badge[_ngcontent-%COMP%] {\n  width: 36px;\n  height: 36px;\n  border-radius: 50%;\n  background: #f3e8ff;\n  color: #7c3aed;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 18px;\n  flex-shrink: 0;\n}\n.pocket-container[_ngcontent-%COMP%] {\n  padding: 16px;\n  display: flex;\n  flex-direction: column;\n  gap: 16px;\n  max-width: 600px;\n  margin: 0 auto;\n}\n.pocket-hero-card[_ngcontent-%COMP%] {\n  position: relative;\n  background:\n    linear-gradient(\n      135deg,\n      #3b0764 0%,\n      #581c87 40%,\n      #7c3aed 100%);\n  border-radius: 22px;\n  padding: 20px 22px;\n  color: #ffffff;\n  overflow: hidden;\n  box-shadow: 0 10px 28px rgba(88, 28, 135, 0.28);\n}\n.pocket-hero-card[_ngcontent-%COMP%]   .hero-bg-glow[_ngcontent-%COMP%] {\n  position: absolute;\n  border-radius: 50%;\n  filter: blur(35px);\n  pointer-events: none;\n}\n.pocket-hero-card[_ngcontent-%COMP%]   .hero-bg-glow.glow-1[_ngcontent-%COMP%] {\n  width: 140px;\n  height: 140px;\n  background: rgba(216, 180, 254, 0.25);\n  top: -30px;\n  right: -30px;\n}\n.pocket-hero-card[_ngcontent-%COMP%]   .hero-bg-glow.glow-2[_ngcontent-%COMP%] {\n  width: 120px;\n  height: 120px;\n  background: rgba(168, 85, 247, 0.2);\n  bottom: -40px;\n  left: 10px;\n}\n.pocket-hero-card[_ngcontent-%COMP%]   .card-top-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  position: relative;\n  z-index: 2;\n}\n.pocket-hero-card[_ngcontent-%COMP%]   .card-top-row[_ngcontent-%COMP%]   .wallet-tag[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n  font-size: 10px;\n  font-weight: 850;\n  letter-spacing: 0.8px;\n  color: #e9d5ff;\n}\n.pocket-hero-card[_ngcontent-%COMP%]   .card-top-row[_ngcontent-%COMP%]   .wallet-tag[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 13px;\n  color: #facc15;\n}\n.pocket-hero-card[_ngcontent-%COMP%]   .card-top-row[_ngcontent-%COMP%]   .live-active-tag[_ngcontent-%COMP%] {\n  font-size: 9px;\n  font-weight: 850;\n  background: rgba(16, 185, 129, 0.25);\n  color: #6ee7b7;\n  border: 0.5px solid rgba(52, 211, 153, 0.4);\n  padding: 2px 8px;\n  border-radius: 99px;\n  letter-spacing: 0.5px;\n}\n.pocket-hero-card[_ngcontent-%COMP%]   .card-balance-block[_ngcontent-%COMP%] {\n  margin: 16px 0 18px;\n  position: relative;\n  z-index: 2;\n}\n.pocket-hero-card[_ngcontent-%COMP%]   .card-balance-block[_ngcontent-%COMP%]   .balance-label[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: rgba(255, 255, 255, 0.8);\n  font-weight: 500;\n  display: block;\n  margin-bottom: 4px;\n}\n.pocket-hero-card[_ngcontent-%COMP%]   .card-balance-block[_ngcontent-%COMP%]   .balance-number-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: baseline;\n  gap: 3px;\n}\n.pocket-hero-card[_ngcontent-%COMP%]   .card-balance-block[_ngcontent-%COMP%]   .balance-number-row[_ngcontent-%COMP%]   .currency-symbol[_ngcontent-%COMP%] {\n  font-size: 24px;\n  font-weight: 700;\n  color: rgba(255, 255, 255, 0.9);\n}\n.pocket-hero-card[_ngcontent-%COMP%]   .card-balance-block[_ngcontent-%COMP%]   .balance-number-row[_ngcontent-%COMP%]   .balance-amount[_ngcontent-%COMP%] {\n  font-size: 34px;\n  font-weight: 900;\n  letter-spacing: -0.5px;\n  color: #ffffff;\n}\n.pocket-hero-card[_ngcontent-%COMP%]   .card-perk-footer[_ngcontent-%COMP%] {\n  position: relative;\n  z-index: 2;\n  padding-top: 12px;\n  border-top: 1px solid rgba(255, 255, 255, 0.15);\n}\n.pocket-hero-card[_ngcontent-%COMP%]   .card-perk-footer[_ngcontent-%COMP%]   .perk-pill[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n  font-size: 11px;\n  font-weight: 600;\n  color: #f3e8ff;\n}\n.pocket-hero-card[_ngcontent-%COMP%]   .card-perk-footer[_ngcontent-%COMP%]   .perk-pill[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: #34d399;\n}\n.wallet-info-note[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 12px;\n  background: #fdf4ff;\n  border: 1px solid #f5d0fe;\n  border-radius: 14px;\n  padding: 12px 14px;\n}\n.wallet-info-note[_ngcontent-%COMP%]   .note-icon-wrap[_ngcontent-%COMP%] {\n  width: 32px;\n  height: 32px;\n  border-radius: 8px;\n  background: #fae8ff;\n  color: #a855f7;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 18px;\n  flex-shrink: 0;\n}\n.wallet-info-note[_ngcontent-%COMP%]   .note-text-col[_ngcontent-%COMP%] {\n  flex: 1;\n}\n.wallet-info-note[_ngcontent-%COMP%]   .note-text-col[_ngcontent-%COMP%]   h6[_ngcontent-%COMP%] {\n  margin: 0 0 2px;\n  font-size: 12.5px;\n  font-weight: 800;\n  color: #7e22ce;\n}\n.wallet-info-note[_ngcontent-%COMP%]   .note-text-col[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 11.5px;\n  color: #9333ea;\n  line-height: 1.4;\n}\n.how-to-earn-section[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n}\n.how-to-earn-section[_ngcontent-%COMP%]   .section-heading-row[_ngcontent-%COMP%]   .section-title[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 15px;\n  font-weight: 850;\n  color: #0f172a;\n}\n.how-to-earn-section[_ngcontent-%COMP%]   .section-heading-row[_ngcontent-%COMP%]   .section-subtitle[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #64748b;\n}\n.how-to-earn-section[_ngcontent-%COMP%]   .earn-cards-list[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n}\n.how-to-earn-section[_ngcontent-%COMP%]   .earn-cards-list[_ngcontent-%COMP%]   .earn-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 16px;\n  padding: 14px;\n  border: 1px solid #e2e8f0;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.02);\n  display: flex;\n  gap: 12px;\n  align-items: flex-start;\n}\n.how-to-earn-section[_ngcontent-%COMP%]   .earn-cards-list[_ngcontent-%COMP%]   .earn-card[_ngcontent-%COMP%]   .earn-icon-circle[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n  border-radius: 12px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 20px;\n  flex-shrink: 0;\n}\n.how-to-earn-section[_ngcontent-%COMP%]   .earn-cards-list[_ngcontent-%COMP%]   .earn-card[_ngcontent-%COMP%]   .earn-icon-circle.amber[_ngcontent-%COMP%] {\n  background: #fef3c7;\n  color: #d97706;\n}\n.how-to-earn-section[_ngcontent-%COMP%]   .earn-cards-list[_ngcontent-%COMP%]   .earn-card[_ngcontent-%COMP%]   .earn-icon-circle.green[_ngcontent-%COMP%] {\n  background: #dcfce7;\n  color: #16a34a;\n}\n.how-to-earn-section[_ngcontent-%COMP%]   .earn-cards-list[_ngcontent-%COMP%]   .earn-card[_ngcontent-%COMP%]   .earn-icon-circle.purple[_ngcontent-%COMP%] {\n  background: #f3e8ff;\n  color: #7c3aed;\n}\n.how-to-earn-section[_ngcontent-%COMP%]   .earn-cards-list[_ngcontent-%COMP%]   .earn-card[_ngcontent-%COMP%]   .earn-icon-circle.rose[_ngcontent-%COMP%] {\n  background: #ffe4e6;\n  color: #e11d48;\n}\n.how-to-earn-section[_ngcontent-%COMP%]   .earn-cards-list[_ngcontent-%COMP%]   .earn-card[_ngcontent-%COMP%]   .earn-info-col[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 0;\n}\n.how-to-earn-section[_ngcontent-%COMP%]   .earn-cards-list[_ngcontent-%COMP%]   .earn-card[_ngcontent-%COMP%]   .earn-info-col[_ngcontent-%COMP%]   .earn-title-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 8px;\n  margin-bottom: 3px;\n}\n.how-to-earn-section[_ngcontent-%COMP%]   .earn-cards-list[_ngcontent-%COMP%]   .earn-card[_ngcontent-%COMP%]   .earn-info-col[_ngcontent-%COMP%]   .earn-title-row[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 13.5px;\n  font-weight: 800;\n  color: #0f172a;\n}\n.how-to-earn-section[_ngcontent-%COMP%]   .earn-cards-list[_ngcontent-%COMP%]   .earn-card[_ngcontent-%COMP%]   .earn-info-col[_ngcontent-%COMP%]   .earn-title-row[_ngcontent-%COMP%]   .reward-tag[_ngcontent-%COMP%] {\n  font-size: 10.5px;\n  font-weight: 850;\n  padding: 2px 8px;\n  border-radius: 99px;\n  white-space: nowrap;\n}\n.how-to-earn-section[_ngcontent-%COMP%]   .earn-cards-list[_ngcontent-%COMP%]   .earn-card[_ngcontent-%COMP%]   .earn-info-col[_ngcontent-%COMP%]   .earn-title-row[_ngcontent-%COMP%]   .reward-tag.amber[_ngcontent-%COMP%] {\n  background: #fffbeb;\n  color: #b45309;\n  border: 1px solid #fde68a;\n}\n.how-to-earn-section[_ngcontent-%COMP%]   .earn-cards-list[_ngcontent-%COMP%]   .earn-card[_ngcontent-%COMP%]   .earn-info-col[_ngcontent-%COMP%]   .earn-title-row[_ngcontent-%COMP%]   .reward-tag.green[_ngcontent-%COMP%] {\n  background: #f0fdf4;\n  color: #15803d;\n  border: 1px solid #bbf7d0;\n}\n.how-to-earn-section[_ngcontent-%COMP%]   .earn-cards-list[_ngcontent-%COMP%]   .earn-card[_ngcontent-%COMP%]   .earn-info-col[_ngcontent-%COMP%]   .earn-title-row[_ngcontent-%COMP%]   .reward-tag.purple[_ngcontent-%COMP%] {\n  background: #faf5ff;\n  color: #6b21a8;\n  border: 1px solid #e9d5ff;\n}\n.how-to-earn-section[_ngcontent-%COMP%]   .earn-cards-list[_ngcontent-%COMP%]   .earn-card[_ngcontent-%COMP%]   .earn-info-col[_ngcontent-%COMP%]   .earn-title-row[_ngcontent-%COMP%]   .reward-tag.rose[_ngcontent-%COMP%] {\n  background: #fff1f2;\n  color: #be123c;\n  border: 1px solid #fecdd3;\n}\n.how-to-earn-section[_ngcontent-%COMP%]   .earn-cards-list[_ngcontent-%COMP%]   .earn-card[_ngcontent-%COMP%]   .earn-info-col[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 11.5px;\n  color: #64748b;\n  line-height: 1.4;\n}\n.how-to-earn-section[_ngcontent-%COMP%]   .earn-cards-list[_ngcontent-%COMP%]   .earn-card[_ngcontent-%COMP%]   .earn-info-col[_ngcontent-%COMP%]   .btn-earn-action[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  margin-top: 8px;\n  padding: 5px 12px;\n  border-radius: 99px;\n  font-size: 11px;\n  font-weight: 800;\n  border: none;\n  cursor: pointer;\n  transition: transform 0.15s ease;\n}\n.how-to-earn-section[_ngcontent-%COMP%]   .earn-cards-list[_ngcontent-%COMP%]   .earn-card[_ngcontent-%COMP%]   .earn-info-col[_ngcontent-%COMP%]   .btn-earn-action[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 13px;\n}\n.how-to-earn-section[_ngcontent-%COMP%]   .earn-cards-list[_ngcontent-%COMP%]   .earn-card[_ngcontent-%COMP%]   .earn-info-col[_ngcontent-%COMP%]   .btn-earn-action[_ngcontent-%COMP%]:active {\n  transform: scale(0.96);\n}\n.how-to-earn-section[_ngcontent-%COMP%]   .earn-cards-list[_ngcontent-%COMP%]   .earn-card[_ngcontent-%COMP%]   .earn-info-col[_ngcontent-%COMP%]   .btn-earn-action.green[_ngcontent-%COMP%] {\n  background: #dcfce7;\n  color: #166534;\n}\n.how-to-earn-section[_ngcontent-%COMP%]   .earn-cards-list[_ngcontent-%COMP%]   .earn-card[_ngcontent-%COMP%]   .earn-info-col[_ngcontent-%COMP%]   .btn-earn-action.purple[_ngcontent-%COMP%] {\n  background: #f3e8ff;\n  color: #6b21a8;\n}\n.perks-grid[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n}\n.perks-grid[_ngcontent-%COMP%]   .perk-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 14px;\n  padding: 12px 14px;\n  border: 1px solid #f1f5f9;\n  display: flex;\n  align-items: center;\n  gap: 12px;\n}\n.perks-grid[_ngcontent-%COMP%]   .perk-card[_ngcontent-%COMP%]   .perk-icon-circle[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 38px;\n  border-radius: 10px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 19px;\n  flex-shrink: 0;\n}\n.perks-grid[_ngcontent-%COMP%]   .perk-card[_ngcontent-%COMP%]   .perk-icon-circle.purple[_ngcontent-%COMP%] {\n  background: #f3e8ff;\n  color: #7c3aed;\n}\n.perks-grid[_ngcontent-%COMP%]   .perk-card[_ngcontent-%COMP%]   .perk-icon-circle.green[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  color: #059669;\n}\n.perks-grid[_ngcontent-%COMP%]   .perk-card[_ngcontent-%COMP%]   .perk-icon-circle.amber[_ngcontent-%COMP%] {\n  background: #fffbeb;\n  color: #d97706;\n}\n.perks-grid[_ngcontent-%COMP%]   .perk-card[_ngcontent-%COMP%]   .perk-text[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 12.5px;\n  font-weight: 800;\n  color: #0f172a;\n}\n.perks-grid[_ngcontent-%COMP%]   .perk-card[_ngcontent-%COMP%]   .perk-text[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 2px 0 0;\n  font-size: 11px;\n  color: #64748b;\n}\n.passbook-section[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n}\n.passbook-section[_ngcontent-%COMP%]   .passbook-header[_ngcontent-%COMP%]   .passbook-title[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 15px;\n  font-weight: 850;\n  color: #0f172a;\n}\n.passbook-section[_ngcontent-%COMP%]   .passbook-header[_ngcontent-%COMP%]   .passbook-sub[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #64748b;\n}\n.passbook-section[_ngcontent-%COMP%]   .filter-tabs-strip[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  overflow-x: auto;\n  padding-bottom: 4px;\n}\n.passbook-section[_ngcontent-%COMP%]   .filter-tabs-strip[_ngcontent-%COMP%]::-webkit-scrollbar {\n  display: none;\n}\n.passbook-section[_ngcontent-%COMP%]   .filter-tabs-strip[_ngcontent-%COMP%]   .filter-pill[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border: 1px solid #e2e8f0;\n  border-radius: 99px;\n  padding: 6px 14px;\n  font-size: 11.5px;\n  font-weight: 700;\n  color: #475569;\n  white-space: nowrap;\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n.passbook-section[_ngcontent-%COMP%]   .filter-tabs-strip[_ngcontent-%COMP%]   .filter-pill.active[_ngcontent-%COMP%] {\n  background: #7c3aed;\n  border-color: #7c3aed;\n  color: #ffffff;\n}\n.passbook-section[_ngcontent-%COMP%]   .transactions-list[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n}\n.passbook-section[_ngcontent-%COMP%]   .transactions-list[_ngcontent-%COMP%]   .txn-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 14px;\n  padding: 12px 14px;\n  border: 1px solid #f1f5f9;\n  display: flex;\n  align-items: center;\n  gap: 12px;\n}\n.passbook-section[_ngcontent-%COMP%]   .transactions-list[_ngcontent-%COMP%]   .txn-card[_ngcontent-%COMP%]   .txn-icon-circle[_ngcontent-%COMP%] {\n  width: 36px;\n  height: 36px;\n  border-radius: 10px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 16px;\n  flex-shrink: 0;\n}\n.passbook-section[_ngcontent-%COMP%]   .transactions-list[_ngcontent-%COMP%]   .txn-card[_ngcontent-%COMP%]   .txn-icon-circle.credit[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  color: #059669;\n}\n.passbook-section[_ngcontent-%COMP%]   .transactions-list[_ngcontent-%COMP%]   .txn-card[_ngcontent-%COMP%]   .txn-icon-circle.debit[_ngcontent-%COMP%] {\n  background: #f8fafc;\n  color: #64748b;\n  border: 1px solid #e2e8f0;\n}\n.passbook-section[_ngcontent-%COMP%]   .transactions-list[_ngcontent-%COMP%]   .txn-card[_ngcontent-%COMP%]   .txn-info-col[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 0;\n}\n.passbook-section[_ngcontent-%COMP%]   .transactions-list[_ngcontent-%COMP%]   .txn-card[_ngcontent-%COMP%]   .txn-info-col[_ngcontent-%COMP%]   .txn-title[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-weight: 750;\n  color: #0f172a;\n  display: block;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.passbook-section[_ngcontent-%COMP%]   .transactions-list[_ngcontent-%COMP%]   .txn-card[_ngcontent-%COMP%]   .txn-info-col[_ngcontent-%COMP%]   .txn-subtitle[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #64748b;\n  display: block;\n  margin-top: 1px;\n}\n.passbook-section[_ngcontent-%COMP%]   .transactions-list[_ngcontent-%COMP%]   .txn-card[_ngcontent-%COMP%]   .txn-info-col[_ngcontent-%COMP%]   .txn-meta-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  font-size: 10px;\n  color: #94a3b8;\n  margin-top: 2px;\n}\n.passbook-section[_ngcontent-%COMP%]   .transactions-list[_ngcontent-%COMP%]   .txn-card[_ngcontent-%COMP%]   .txn-info-col[_ngcontent-%COMP%]   .txn-meta-row[_ngcontent-%COMP%]   .txn-ref[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  color: #cbd5e1;\n}\n.passbook-section[_ngcontent-%COMP%]   .transactions-list[_ngcontent-%COMP%]   .txn-card[_ngcontent-%COMP%]   .txn-amount-col[_ngcontent-%COMP%] {\n  text-align: right;\n  flex-shrink: 0;\n}\n.passbook-section[_ngcontent-%COMP%]   .transactions-list[_ngcontent-%COMP%]   .txn-card[_ngcontent-%COMP%]   .txn-amount-col[_ngcontent-%COMP%]   .txn-amount[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 850;\n  display: block;\n}\n.passbook-section[_ngcontent-%COMP%]   .transactions-list[_ngcontent-%COMP%]   .txn-card[_ngcontent-%COMP%]   .txn-amount-col[_ngcontent-%COMP%]   .txn-amount.credit[_ngcontent-%COMP%] {\n  color: #059669;\n}\n.passbook-section[_ngcontent-%COMP%]   .transactions-list[_ngcontent-%COMP%]   .txn-card[_ngcontent-%COMP%]   .txn-amount-col[_ngcontent-%COMP%]   .txn-amount.debit[_ngcontent-%COMP%] {\n  color: #0f172a;\n}\n.passbook-section[_ngcontent-%COMP%]   .transactions-list[_ngcontent-%COMP%]   .txn-card[_ngcontent-%COMP%]   .txn-amount-col[_ngcontent-%COMP%]   .txn-category-badge[_ngcontent-%COMP%] {\n  font-size: 9px;\n  font-weight: 800;\n  color: #94a3b8;\n  letter-spacing: 0.4px;\n}\n.passbook-section[_ngcontent-%COMP%]   .transactions-list[_ngcontent-%COMP%]   .txn-card[_ngcontent-%COMP%]   .txn-amount-col[_ngcontent-%COMP%]   .txn-category-badge.credit[_ngcontent-%COMP%] {\n  color: #059669;\n}\n.passbook-section[_ngcontent-%COMP%]   .transactions-list[_ngcontent-%COMP%]   .empty-passbook[_ngcontent-%COMP%] {\n  text-align: center;\n  padding: 30px 20px;\n  background: #ffffff;\n  border-radius: 14px;\n  border: 1px dashed #cbd5e1;\n}\n.passbook-section[_ngcontent-%COMP%]   .transactions-list[_ngcontent-%COMP%]   .empty-passbook[_ngcontent-%COMP%]   .empty-icon-circle[_ngcontent-%COMP%] {\n  width: 44px;\n  height: 44px;\n  border-radius: 50%;\n  background: #f1f5f9;\n  color: #94a3b8;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 22px;\n  margin: 0 auto 10px;\n}\n.passbook-section[_ngcontent-%COMP%]   .transactions-list[_ngcontent-%COMP%]   .empty-passbook[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 13.5px;\n  font-weight: 800;\n  color: #334155;\n}\n.passbook-section[_ngcontent-%COMP%]   .transactions-list[_ngcontent-%COMP%]   .empty-passbook[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 4px 0 0;\n  font-size: 11.5px;\n  color: #94a3b8;\n}\n.pocket-bottom-spacer[_ngcontent-%COMP%] {\n  height: 40px;\n}\n/*# sourceMappingURL=pintu-pocket.page.css.map */'] });
var PintuPocketPage = _PintuPocketPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(PintuPocketPage, { className: "PintuPocketPage", filePath: "src/app/pages/pintu-pocket/pintu-pocket.page.ts", lineNumber: 53 });
})();
export {
  PintuPocketPage
};
//# sourceMappingURL=pintu-pocket.page-DR4H7QTL.js.map
