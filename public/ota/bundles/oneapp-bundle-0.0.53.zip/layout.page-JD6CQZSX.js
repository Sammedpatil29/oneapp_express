import {
  TranslatePipe
} from "./chunk-EAEIPGUF.js";
import {
  addIcons,
  alertCircleOutline,
  arrowForwardOutline,
  arrowUpCircle,
  bagHandle,
  bagHandleOutline,
  chatbubbleEllipses,
  chatbubbleEllipsesOutline,
  checkmarkCircleOutline,
  compass,
  compassOutline,
  gift,
  giftOutline,
  headset,
  headsetOutline,
  helpCircleOutline,
  home,
  homeOutline,
  informationCircleOutline,
  logoGooglePlaystore,
  person,
  personOutline,
  receipt,
  receiptOutline,
  warningOutline
} from "./chunk-I7AJKZVE.js";
import {
  PlayStoreUpdateService
} from "./chunk-7T6YL63B.js";
import {
  OtaService
} from "./chunk-DCTFUYU7.js";
import "./chunk-EBMCUG2R.js";
import {
  AppDialogService
} from "./chunk-W37RSO62.js";
import "./chunk-YJYUHAOC.js";
import {
  IonIcon,
  IonRouterOutlet
} from "./chunk-CJE2NDTY.js";
import {
  AsyncPipe,
  CommonModule,
  EventEmitter,
  FormsModule,
  NavigationEnd,
  NgClass,
  Router,
  RouterModule,
  filter,
  inject,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind1,
  ɵɵproperty,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵstyleProp,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1
} from "./chunk-Z7XNNJSA.js";
import "./chunk-FH4NU4VH.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/components/alert-modal/alert-modal.component.ts
function AlertModalComponent_Conditional_0_Case_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 4);
  }
}
function AlertModalComponent_Conditional_0_Case_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 5);
  }
}
function AlertModalComponent_Conditional_0_Case_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 6);
  }
}
function AlertModalComponent_Conditional_0_Case_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 7);
  }
}
function AlertModalComponent_Conditional_0_Case_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 8);
  }
}
function AlertModalComponent_Conditional_0_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 14);
    \u0275\u0275listener("click", function AlertModalComponent_Conditional_0_Conditional_13_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.onCancel());
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r1.cancelText, " ");
  }
}
function AlertModalComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 1);
    \u0275\u0275listener("click", function AlertModalComponent_Conditional_0_Template_div_click_0_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.onBackdropClick());
    });
    \u0275\u0275elementStart(1, "div", 2);
    \u0275\u0275listener("click", function AlertModalComponent_Conditional_0_Template_div_click_1_listener($event) {
      \u0275\u0275restoreView(_r1);
      return \u0275\u0275resetView($event.stopPropagation());
    });
    \u0275\u0275elementStart(2, "div", 3);
    \u0275\u0275template(3, AlertModalComponent_Conditional_0_Case_3_Template, 1, 0, "ion-icon", 4)(4, AlertModalComponent_Conditional_0_Case_4_Template, 1, 0, "ion-icon", 5)(5, AlertModalComponent_Conditional_0_Case_5_Template, 1, 0, "ion-icon", 6)(6, AlertModalComponent_Conditional_0_Case_6_Template, 1, 0, "ion-icon", 7)(7, AlertModalComponent_Conditional_0_Case_7_Template, 1, 0, "ion-icon", 8);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "h3", 9);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "p", 10);
    \u0275\u0275text(11);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "div", 11);
    \u0275\u0275template(13, AlertModalComponent_Conditional_0_Conditional_13_Template, 2, 1, "button", 12);
    \u0275\u0275elementStart(14, "button", 13);
    \u0275\u0275listener("click", function AlertModalComponent_Conditional_0_Template_button_click_14_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.onConfirm());
    });
    \u0275\u0275text(15);
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    let tmp_2_0;
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(2);
    \u0275\u0275property("ngClass", ctx_r1.type);
    \u0275\u0275advance();
    \u0275\u0275conditional((tmp_2_0 = ctx_r1.type) === "success" ? 3 : tmp_2_0 === "error" ? 4 : tmp_2_0 === "warning" ? 5 : tmp_2_0 === "confirm" ? 6 : 7);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(ctx_r1.title);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.message);
    \u0275\u0275advance();
    \u0275\u0275classProp("single", !ctx_r1.showCancel);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.showCancel ? 13 : -1);
    \u0275\u0275advance();
    \u0275\u0275property("ngClass", ctx_r1.type);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r1.confirmText, " ");
  }
}
var _AlertModalComponent = class _AlertModalComponent {
  constructor() {
    this.isOpen = false;
    this.type = "info";
    this.title = "";
    this.message = "";
    this.confirmText = "OK";
    this.cancelText = "Cancel";
    this.showCancel = false;
    this.confirmed = new EventEmitter();
    this.cancelled = new EventEmitter();
    addIcons({
      checkmarkCircleOutline,
      alertCircleOutline,
      warningOutline,
      informationCircleOutline,
      helpCircleOutline
    });
  }
  onConfirm() {
    this.confirmed.emit();
  }
  onCancel() {
    this.cancelled.emit();
  }
  onBackdropClick() {
    if (this.showCancel) {
      this.onCancel();
    }
  }
};
_AlertModalComponent.\u0275fac = function AlertModalComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _AlertModalComponent)();
};
_AlertModalComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _AlertModalComponent, selectors: [["app-alert-modal"]], inputs: { isOpen: "isOpen", type: "type", title: "title", message: "message", confirmText: "confirmText", cancelText: "cancelText", showCancel: "showCancel" }, outputs: { confirmed: "confirmed", cancelled: "cancelled" }, decls: 1, vars: 1, consts: [[1, "alert-modal-backdrop"], [1, "alert-modal-backdrop", 3, "click"], [1, "alert-modal-card", 3, "click"], [1, "alert-icon-wrap", 3, "ngClass"], ["name", "checkmark-circle-outline"], ["name", "alert-circle-outline"], ["name", "warning-outline"], ["name", "help-circle-outline"], ["name", "information-circle-outline"], [1, "alert-title"], [1, "alert-msg"], [1, "alert-actions"], [1, "btn-cancel"], [1, "btn-confirm", 3, "click", "ngClass"], [1, "btn-cancel", 3, "click"]], template: function AlertModalComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275template(0, AlertModalComponent_Conditional_0_Template, 16, 9, "div", 0);
  }
  if (rf & 2) {
    \u0275\u0275conditional(ctx.isOpen ? 0 : -1);
  }
}, dependencies: [CommonModule, NgClass, IonIcon], styles: ["\n\n.alert-modal-backdrop[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  background: rgba(15, 23, 42, 0.6);\n  backdrop-filter: blur(6px);\n  -webkit-backdrop-filter: blur(6px);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  padding: 24px 20px;\n  z-index: 10000;\n  animation: _ngcontent-%COMP%_fadeIn 0.18s ease-out;\n}\n.alert-modal-card[_ngcontent-%COMP%] {\n  position: relative;\n  background: #ffffff;\n  border-radius: 24px;\n  padding: 32px 24px 24px;\n  width: 100%;\n  max-width: 340px;\n  text-align: center;\n  box-shadow: 0 24px 48px rgba(0, 0, 0, 0.18);\n  animation: _ngcontent-%COMP%_scaleUp 0.25s cubic-bezier(0.34, 1.56, 0.64, 1);\n  border: 1px solid #f1f5f9;\n}\n.alert-icon-wrap[_ngcontent-%COMP%] {\n  width: 68px;\n  height: 68px;\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 34px;\n  margin: 0 auto 18px;\n}\n.alert-icon-wrap.success[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  color: #10b981;\n  box-shadow: 0 0 0 8px rgba(16, 185, 129, 0.1);\n}\n.alert-icon-wrap.error[_ngcontent-%COMP%] {\n  background: #fef2f2;\n  color: #ef4444;\n  box-shadow: 0 0 0 8px rgba(239, 68, 68, 0.1);\n}\n.alert-icon-wrap.warning[_ngcontent-%COMP%] {\n  background: #fffbeb;\n  color: #f59e0b;\n  box-shadow: 0 0 0 8px rgba(245, 158, 11, 0.1);\n}\n.alert-icon-wrap.confirm[_ngcontent-%COMP%], \n.alert-icon-wrap.info[_ngcontent-%COMP%] {\n  background: #fbf0ff;\n  color: var(--app-theme-color, #a000e2);\n  box-shadow: 0 0 0 8px rgba(160, 0, 226, 0.1);\n}\n.alert-title[_ngcontent-%COMP%] {\n  font-size: 18px;\n  font-weight: 800;\n  color: #0f172a;\n  margin: 0 0 8px;\n  line-height: 1.3;\n}\n.alert-msg[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  color: #64748b;\n  line-height: 1.55;\n  margin: 0 0 22px;\n}\n.alert-actions[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 10px;\n}\n.alert-actions[_ngcontent-%COMP%]:not(.single) {\n  flex-direction: row;\n}\n.alert-actions[_ngcontent-%COMP%]:not(.single)   button[_ngcontent-%COMP%] {\n  flex: 1;\n}\n.alert-actions.single[_ngcontent-%COMP%] {\n  flex-direction: column;\n  align-items: center;\n}\n.alert-actions.single[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  width: 85%;\n}\n.alert-actions[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  padding: 13px 16px;\n  border-radius: 14px;\n  font-size: 14px;\n  font-weight: 700;\n  border: none;\n  cursor: pointer;\n  letter-spacing: 0.2px;\n  transition: transform 0.15s ease, opacity 0.15s ease;\n}\n.alert-actions[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:active {\n  transform: scale(0.97);\n  opacity: 0.9;\n}\n.alert-actions[_ngcontent-%COMP%]   .btn-cancel[_ngcontent-%COMP%] {\n  background: #f1f5f9;\n  color: #475569;\n}\n.alert-actions[_ngcontent-%COMP%]   .btn-confirm[_ngcontent-%COMP%] {\n  background: var(--app-theme-color, #a000e2);\n  color: #ffffff;\n  box-shadow: 0 4px 14px rgba(160, 0, 226, 0.3);\n}\n.alert-actions[_ngcontent-%COMP%]   .btn-confirm.success[_ngcontent-%COMP%] {\n  background: #10b981;\n  box-shadow: 0 4px 12px rgba(16, 185, 129, 0.25);\n}\n.alert-actions[_ngcontent-%COMP%]   .btn-confirm.error[_ngcontent-%COMP%] {\n  background: #ef4444;\n  box-shadow: 0 4px 12px rgba(239, 68, 68, 0.25);\n}\n.alert-actions[_ngcontent-%COMP%]   .btn-confirm.warning[_ngcontent-%COMP%] {\n  background: #f59e0b;\n  box-shadow: 0 4px 12px rgba(245, 158, 11, 0.25);\n  color: #ffffff;\n}\n.alert-actions[_ngcontent-%COMP%]   .btn-confirm.confirm[_ngcontent-%COMP%] {\n  background: var(--app-theme-color, #a000e2);\n  box-shadow: 0 4px 14px rgba(160, 0, 226, 0.3);\n}\n@keyframes _ngcontent-%COMP%_fadeIn {\n  from {\n    opacity: 0;\n  }\n  to {\n    opacity: 1;\n  }\n}\n@keyframes _ngcontent-%COMP%_scaleUp {\n  0% {\n    transform: scale(0.85);\n    opacity: 0;\n  }\n  100% {\n    transform: scale(1);\n    opacity: 1;\n  }\n}\n/*# sourceMappingURL=alert-modal.component.css.map */"] });
var AlertModalComponent = _AlertModalComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(AlertModalComponent, { className: "AlertModalComponent", filePath: "src/app/components/alert-modal/alert-modal.component.ts", lineNumber: 22 });
})();

// src/app/pages/layout/layout.page.ts
function LayoutPage_Conditional_3_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 6);
    \u0275\u0275pipe(1, "async");
    \u0275\u0275element(2, "div", 15);
    \u0275\u0275pipe(3, "async");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275attribute("aria-valuenow", \u0275\u0275pipeBind1(1, 3, ctx_r1.otaProgress$));
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("width", \u0275\u0275pipeBind1(3, 5, ctx_r1.otaProgress$), "%");
  }
}
function LayoutPage_Conditional_3_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "span", 10);
  }
}
function LayoutPage_Conditional_3_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "span", 10);
  }
}
function LayoutPage_Conditional_3_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "span", 10);
  }
}
function LayoutPage_Conditional_3_Conditional_30_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "span", 10);
  }
}
function LayoutPage_Conditional_3_Conditional_37_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "span", 10);
  }
}
function LayoutPage_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "nav", 2);
    \u0275\u0275template(1, LayoutPage_Conditional_3_Conditional_1_Template, 4, 7, "div", 6);
    \u0275\u0275pipe(2, "async");
    \u0275\u0275elementStart(3, "button", 7);
    \u0275\u0275listener("click", function LayoutPage_Conditional_3_Template_button_click_3_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.navigateTab("/layout/home"));
    });
    \u0275\u0275elementStart(4, "div", 8);
    \u0275\u0275element(5, "ion-icon", 9);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span");
    \u0275\u0275text(7);
    \u0275\u0275pipe(8, "translate");
    \u0275\u0275elementEnd();
    \u0275\u0275template(9, LayoutPage_Conditional_3_Conditional_9_Template, 1, 0, "span", 10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "button", 11);
    \u0275\u0275listener("click", function LayoutPage_Conditional_3_Template_button_click_10_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.navigateTab("/layout/history"));
    });
    \u0275\u0275elementStart(11, "div", 8);
    \u0275\u0275element(12, "ion-icon", 9);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "span");
    \u0275\u0275text(14);
    \u0275\u0275pipe(15, "translate");
    \u0275\u0275elementEnd();
    \u0275\u0275template(16, LayoutPage_Conditional_3_Conditional_16_Template, 1, 0, "span", 10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "button", 12);
    \u0275\u0275listener("click", function LayoutPage_Conditional_3_Template_button_click_17_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.navigateTab("/layout/referral"));
    });
    \u0275\u0275elementStart(18, "div", 8);
    \u0275\u0275element(19, "ion-icon", 9);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "span");
    \u0275\u0275text(21);
    \u0275\u0275pipe(22, "translate");
    \u0275\u0275elementEnd();
    \u0275\u0275template(23, LayoutPage_Conditional_3_Conditional_23_Template, 1, 0, "span", 10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(24, "button", 13);
    \u0275\u0275listener("click", function LayoutPage_Conditional_3_Template_button_click_24_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.navigateTab("/layout/support"));
    });
    \u0275\u0275elementStart(25, "div", 8);
    \u0275\u0275element(26, "ion-icon", 9);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(27, "span");
    \u0275\u0275text(28);
    \u0275\u0275pipe(29, "translate");
    \u0275\u0275elementEnd();
    \u0275\u0275template(30, LayoutPage_Conditional_3_Conditional_30_Template, 1, 0, "span", 10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(31, "button", 14);
    \u0275\u0275listener("click", function LayoutPage_Conditional_3_Template_button_click_31_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.navigateTab("/layout/profile"));
    });
    \u0275\u0275elementStart(32, "div", 8);
    \u0275\u0275element(33, "ion-icon", 9);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(34, "span");
    \u0275\u0275text(35);
    \u0275\u0275pipe(36, "translate");
    \u0275\u0275elementEnd();
    \u0275\u0275template(37, LayoutPage_Conditional_3_Conditional_37_Template, 1, 0, "span", 10);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275conditional(\u0275\u0275pipeBind1(2, 26, ctx_r1.isDownloadingOta$) ? 1 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r1.isTabActive("/layout/home"));
    \u0275\u0275advance(2);
    \u0275\u0275property("name", ctx_r1.isTabActive("/layout/home") ? "compass" : "compass-outline");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(8, 28, "home"));
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.isTabActive("/layout/home") ? 9 : -1);
    \u0275\u0275advance();
    \u0275\u0275classProp("active", ctx_r1.isTabActive("/layout/history"));
    \u0275\u0275advance(2);
    \u0275\u0275property("name", ctx_r1.isTabActive("/layout/history") ? "receipt" : "receipt-outline");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(15, 30, "orders"));
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.isTabActive("/layout/history") ? 16 : -1);
    \u0275\u0275advance();
    \u0275\u0275classProp("active", ctx_r1.isTabActive("/layout/referral"));
    \u0275\u0275advance(2);
    \u0275\u0275property("name", ctx_r1.isTabActive("/layout/referral") ? "gift" : "gift-outline");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(22, 32, "refer"));
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.isTabActive("/layout/referral") ? 23 : -1);
    \u0275\u0275advance();
    \u0275\u0275classProp("active", ctx_r1.isTabActive("/layout/support"));
    \u0275\u0275advance(2);
    \u0275\u0275property("name", ctx_r1.isTabActive("/layout/support") ? "chatbubble-ellipses" : "chatbubble-ellipses-outline");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(29, 34, "support"));
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.isTabActive("/layout/support") ? 30 : -1);
    \u0275\u0275advance();
    \u0275\u0275classProp("active", ctx_r1.isTabActive("/layout/profile"));
    \u0275\u0275advance(2);
    \u0275\u0275property("name", ctx_r1.isTabActive("/layout/profile") ? "person" : "person-outline");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(36, 36, "account"));
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.isTabActive("/layout/profile") ? 37 : -1);
  }
}
function LayoutPage_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 3);
    \u0275\u0275pipe(1, "async");
    \u0275\u0275element(2, "div", 15);
    \u0275\u0275pipe(3, "async");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275attribute("aria-valuenow", \u0275\u0275pipeBind1(1, 3, ctx_r1.otaProgress$));
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("width", \u0275\u0275pipeBind1(3, 5, ctx_r1.otaProgress$), "%");
  }
}
function LayoutPage_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 5)(1, "div", 16)(2, "div", 17);
    \u0275\u0275element(3, "ion-icon", 18);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "h3", 19);
    \u0275\u0275text(5, "Update Required");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "p", 20);
    \u0275\u0275text(7, " A new version of ");
    \u0275\u0275elementStart(8, "strong");
    \u0275\u0275text(9, "Pintu");
    \u0275\u0275elementEnd();
    \u0275\u0275text(10, " is available on Google Play Store with critical fixes, enhancements, and features. ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "div", 21)(12, "span", 22);
    \u0275\u0275text(13);
    \u0275\u0275pipe(14, "async");
    \u0275\u0275elementEnd();
    \u0275\u0275element(15, "ion-icon", 23);
    \u0275\u0275elementStart(16, "span", 24);
    \u0275\u0275text(17);
    \u0275\u0275pipe(18, "async");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(19, "div", 25);
    \u0275\u0275text(20, " Please update the application on Google Play Store to continue using Pintu. ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(21, "button", 26);
    \u0275\u0275listener("click", function LayoutPage_Conditional_14_Template_button_click_21_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.onUpdatePlayStoreClick());
    });
    \u0275\u0275element(22, "ion-icon", 27);
    \u0275\u0275text(23, " Update on Google Play ");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    let tmp_1_0;
    let tmp_2_0;
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(13);
    \u0275\u0275textInterpolate1("Current: v", ((tmp_1_0 = \u0275\u0275pipeBind1(14, 2, ctx_r1.playStoreState$)) == null ? null : tmp_1_0.currentVersionName) || "0.0.21", "");
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("Latest: v", ((tmp_2_0 = \u0275\u0275pipeBind1(18, 4, ctx_r1.playStoreState$)) == null ? null : tmp_2_0.availableVersionName) || "Latest", "");
  }
}
var _LayoutPage = class _LayoutPage {
  get showBottomBar() {
    return this.mainTabRoutes.some((tab) => this.currentRoute === tab || this.currentRoute.startsWith(tab + "/"));
  }
  constructor() {
    this.dialogService = inject(AppDialogService);
    this.otaService = inject(OtaService);
    this.playStoreUpdateService = inject(PlayStoreUpdateService);
    this.router = inject(Router);
    this.isDownloadingOta$ = this.otaService.isDownloading$;
    this.otaProgress$ = this.otaService.downloadProgress$;
    this.playStoreState$ = this.playStoreUpdateService.state$;
    this.currentRoute = "/layout/home";
    this.dialogState$ = this.dialogService.state$;
    this.mainTabRoutes = [
      "/layout/home",
      "/layout/history",
      "/layout/referral",
      "/layout/support",
      "/layout/profile"
    ];
    addIcons({
      compass,
      compassOutline,
      home,
      homeOutline,
      receipt,
      receiptOutline,
      bagHandle,
      bagHandleOutline,
      gift,
      giftOutline,
      chatbubbleEllipses,
      chatbubbleEllipsesOutline,
      headset,
      headsetOutline,
      person,
      personOutline,
      arrowUpCircle,
      arrowForwardOutline,
      logoGooglePlaystore
    });
  }
  ngOnInit() {
    this.currentRoute = this.router.url;
    this.router.events.pipe(filter((event) => event instanceof NavigationEnd)).subscribe((event) => {
      this.currentRoute = event.urlAfterRedirects || event.url;
    });
  }
  navigateTab(route) {
    this.router.navigate([route]);
  }
  isTabActive(route) {
    return this.currentRoute === route || this.currentRoute.startsWith(route + "/");
  }
  onUpdatePlayStoreClick() {
    return __async(this, null, function* () {
      yield this.playStoreUpdateService.redirectToPlayStore();
    });
  }
};
_LayoutPage.\u0275fac = function LayoutPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _LayoutPage)();
};
_LayoutPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _LayoutPage, selectors: [["app-layout"]], decls: 16, vars: 28, consts: [[1, "customer-app-wrapper"], [1, "main-content-outlet"], [1, "customer-bottom-bar"], ["role", "progressbar", "aria-valuemin", "0", "aria-valuemax", "100", 1, "ota-floating-progress-bar"], [3, "confirmed", "cancelled", "isOpen", "type", "title", "message", "confirmText", "cancelText", "showCancel"], [1, "playstore-mandatory-backdrop"], ["role", "progressbar", "aria-valuemin", "0", "aria-valuemax", "100", 1, "ota-top-progress-bar"], ["type", "button", "aria-label", "Home", 1, "nav-tab", 3, "click"], [1, "tab-icon-wrapper"], [3, "name"], [1, "active-dot"], ["type", "button", "aria-label", "Orders History", 1, "nav-tab", 3, "click"], ["type", "button", "aria-label", "Refer and Earn", 1, "nav-tab", 3, "click"], ["type", "button", "aria-label", "Help & Support", 1, "nav-tab", 3, "click"], ["type", "button", "aria-label", "Account Profile", 1, "nav-tab", 3, "click"], [1, "ota-progress-fill"], [1, "playstore-mandatory-card"], [1, "playstore-icon-wrap"], ["name", "arrow-up-circle"], [1, "playstore-update-title"], [1, "playstore-update-subtitle"], [1, "playstore-version-badge-wrap"], [1, "version-tag", "current"], ["name", "arrow-forward-outline", 1, "arrow-between"], [1, "version-tag", "latest"], [1, "playstore-strict-note"], ["type", "button", 1, "btn-playstore-update", 3, "click"], ["name", "logo-google-playstore", 1, "me-2"]], template: function LayoutPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 0)(1, "div", 1);
    \u0275\u0275element(2, "ion-router-outlet");
    \u0275\u0275elementEnd();
    \u0275\u0275template(3, LayoutPage_Conditional_3_Template, 38, 38, "nav", 2)(4, LayoutPage_Conditional_4_Template, 4, 7, "div", 3);
    \u0275\u0275pipe(5, "async");
    \u0275\u0275elementStart(6, "app-alert-modal", 4);
    \u0275\u0275pipe(7, "async");
    \u0275\u0275pipe(8, "async");
    \u0275\u0275pipe(9, "async");
    \u0275\u0275pipe(10, "async");
    \u0275\u0275pipe(11, "async");
    \u0275\u0275pipe(12, "async");
    \u0275\u0275pipe(13, "async");
    \u0275\u0275listener("confirmed", function LayoutPage_Template_app_alert_modal_confirmed_6_listener() {
      return ctx.dialogService.handleConfirm();
    })("cancelled", function LayoutPage_Template_app_alert_modal_cancelled_6_listener() {
      return ctx.dialogService.handleCancel();
    });
    \u0275\u0275elementEnd();
    \u0275\u0275template(14, LayoutPage_Conditional_14_Template, 24, 6, "div", 5);
    \u0275\u0275pipe(15, "async");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    let tmp_2_0;
    let tmp_3_0;
    let tmp_4_0;
    let tmp_5_0;
    let tmp_6_0;
    let tmp_7_0;
    let tmp_8_0;
    let tmp_9_0;
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx.showBottomBar ? 3 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(!ctx.showBottomBar && \u0275\u0275pipeBind1(5, 10, ctx.isDownloadingOta$) ? 4 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275property("isOpen", (tmp_2_0 = (tmp_2_0 = \u0275\u0275pipeBind1(7, 12, ctx.dialogState$)) == null ? null : tmp_2_0.isOpen) !== null && tmp_2_0 !== void 0 ? tmp_2_0 : false)("type", (tmp_3_0 = (tmp_3_0 = \u0275\u0275pipeBind1(8, 14, ctx.dialogState$)) == null ? null : tmp_3_0.type) !== null && tmp_3_0 !== void 0 ? tmp_3_0 : "info")("title", (tmp_4_0 = (tmp_4_0 = \u0275\u0275pipeBind1(9, 16, ctx.dialogState$)) == null ? null : tmp_4_0.title) !== null && tmp_4_0 !== void 0 ? tmp_4_0 : "")("message", (tmp_5_0 = (tmp_5_0 = \u0275\u0275pipeBind1(10, 18, ctx.dialogState$)) == null ? null : tmp_5_0.message) !== null && tmp_5_0 !== void 0 ? tmp_5_0 : "")("confirmText", (tmp_6_0 = (tmp_6_0 = \u0275\u0275pipeBind1(11, 20, ctx.dialogState$)) == null ? null : tmp_6_0.confirmText) !== null && tmp_6_0 !== void 0 ? tmp_6_0 : "OK")("cancelText", (tmp_7_0 = (tmp_7_0 = \u0275\u0275pipeBind1(12, 22, ctx.dialogState$)) == null ? null : tmp_7_0.cancelText) !== null && tmp_7_0 !== void 0 ? tmp_7_0 : "Cancel")("showCancel", (tmp_8_0 = (tmp_8_0 = \u0275\u0275pipeBind1(13, 24, ctx.dialogState$)) == null ? null : tmp_8_0.showCancel) !== null && tmp_8_0 !== void 0 ? tmp_8_0 : false);
    \u0275\u0275advance(8);
    \u0275\u0275conditional(((tmp_9_0 = \u0275\u0275pipeBind1(15, 26, ctx.playStoreState$)) == null ? null : tmp_9_0.isMandatoryUpdateRequired) ? 14 : -1);
  }
}, dependencies: [
  IonRouterOutlet,
  IonIcon,
  CommonModule,
  AsyncPipe,
  FormsModule,
  RouterModule,
  AlertModalComponent,
  TranslatePipe
], styles: ['\n\n.customer-app-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  height: 100%;\n  width: 100%;\n  max-width: 100vw;\n  overflow: hidden;\n  background: #f8fafc;\n  position: relative;\n}\n.main-content-outlet[_ngcontent-%COMP%] {\n  flex: 1;\n  width: 100%;\n  max-width: 100%;\n  overflow: hidden;\n  position: relative;\n}\n.customer-bottom-bar[_ngcontent-%COMP%] {\n  position: relative;\n  display: flex;\n  align-items: center;\n  justify-content: space-around;\n  background: #ffffff;\n  min-height: 64px;\n  height: calc(64px + env(safe-area-inset-bottom, 0px));\n  border-top: 1px solid #e2e8f0;\n  box-shadow: 0 -4px 20px rgba(0, 0, 0, 0.05);\n  z-index: 100;\n  flex-shrink: 0;\n  box-sizing: border-box;\n  padding-top: 4px;\n  padding-left: 6px;\n  padding-right: 6px;\n  padding-bottom: max(env(safe-area-inset-bottom, 0px), 8px);\n}\n.customer-bottom-bar[_ngcontent-%COMP%]   .ota-top-progress-bar[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  width: 100%;\n  height: 3px;\n  background: #f1f5f9;\n  overflow: hidden;\n  z-index: 105;\n}\n.customer-bottom-bar[_ngcontent-%COMP%]   .ota-top-progress-bar[_ngcontent-%COMP%]   .ota-progress-fill[_ngcontent-%COMP%] {\n  height: 100%;\n  background:\n    linear-gradient(\n      90deg,\n      #a000e2 0%,\n      #d946ef 50%,\n      #ec4899 100%);\n  box-shadow: 0 0 8px rgba(160, 0, 226, 0.6);\n  transition: width 0.2s cubic-bezier(0.4, 0, 0.2, 1);\n  position: relative;\n}\n.customer-bottom-bar[_ngcontent-%COMP%]   .ota-top-progress-bar[_ngcontent-%COMP%]   .ota-progress-fill[_ngcontent-%COMP%]::after {\n  content: "";\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  background:\n    linear-gradient(\n      90deg,\n      transparent,\n      rgba(255, 255, 255, 0.7),\n      transparent);\n  animation: _ngcontent-%COMP%_otaShimmer 1.4s infinite linear;\n}\n.customer-bottom-bar[_ngcontent-%COMP%]   .nav-tab[_ngcontent-%COMP%] {\n  flex: 1;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  gap: 2px;\n  background: transparent;\n  border: none;\n  outline: none;\n  padding: 4px 2px 2px;\n  height: 100%;\n  max-height: 58px;\n  cursor: pointer;\n  color: #64748b;\n  transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);\n  position: relative;\n  box-sizing: border-box;\n}\n.customer-bottom-bar[_ngcontent-%COMP%]   .nav-tab[_ngcontent-%COMP%]   .tab-icon-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  width: 44px;\n  height: 28px;\n  border-radius: 14px;\n  transition: all 0.25s cubic-bezier(0.34, 1.56, 0.64, 1);\n}\n.customer-bottom-bar[_ngcontent-%COMP%]   .nav-tab[_ngcontent-%COMP%]   .tab-icon-wrapper[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 22px;\n  transition: transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1), color 0.2s ease;\n}\n.customer-bottom-bar[_ngcontent-%COMP%]   .nav-tab[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 600;\n  letter-spacing: -0.15px;\n  line-height: 1.2;\n  transition: color 0.2s ease;\n}\n.customer-bottom-bar[_ngcontent-%COMP%]   .nav-tab[_ngcontent-%COMP%]   .active-dot[_ngcontent-%COMP%] {\n  width: 4px;\n  height: 4px;\n  background: var(--app-theme-color, #a000e2);\n  border-radius: 50%;\n  margin-top: 1px;\n  animation: _ngcontent-%COMP%_tabDotPulse 0.3s ease;\n}\n.customer-bottom-bar[_ngcontent-%COMP%]   .nav-tab.active[_ngcontent-%COMP%] {\n  color: var(--app-theme-color, #a000e2);\n}\n.customer-bottom-bar[_ngcontent-%COMP%]   .nav-tab.active[_ngcontent-%COMP%]   .tab-icon-wrapper[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      rgba(160, 0, 226, 0.16) 0%,\n      rgba(160, 0, 226, 0.04) 100%);\n  transform: translateY(-1px);\n}\n.customer-bottom-bar[_ngcontent-%COMP%]   .nav-tab.active[_ngcontent-%COMP%]   .tab-icon-wrapper[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  transform: scale(1.08);\n  color: var(--app-theme-color, #a000e2);\n}\n.customer-bottom-bar[_ngcontent-%COMP%]   .nav-tab.active[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-weight: 700;\n  color: var(--app-theme-color, #a000e2);\n}\n.customer-bottom-bar[_ngcontent-%COMP%]   .nav-tab[_ngcontent-%COMP%]:active {\n  transform: scale(0.94);\n}\n@keyframes _ngcontent-%COMP%_tabDotPulse {\n  0% {\n    transform: scale(0);\n    opacity: 0;\n  }\n  100% {\n    transform: scale(1);\n    opacity: 1;\n  }\n}\n  .custom-alert .alert-wrapper {\n  width: 90%;\n  max-width: 400px;\n  display: flex !important;\n  justify-content: center !important;\n  border-radius: 20px !important;\n  padding: 10px !important;\n}\n.ota-floating-progress-bar[_ngcontent-%COMP%] {\n  position: fixed;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  width: 100%;\n  height: 3px;\n  background: #f1f5f9;\n  overflow: hidden;\n  z-index: 9999;\n}\n.ota-floating-progress-bar[_ngcontent-%COMP%]   .ota-progress-fill[_ngcontent-%COMP%] {\n  height: 100%;\n  background:\n    linear-gradient(\n      90deg,\n      #a000e2 0%,\n      #d946ef 50%,\n      #ec4899 100%);\n  box-shadow: 0 0 8px rgba(160, 0, 226, 0.6);\n  transition: width 0.2s cubic-bezier(0.4, 0, 0.2, 1);\n  position: relative;\n}\n.ota-floating-progress-bar[_ngcontent-%COMP%]   .ota-progress-fill[_ngcontent-%COMP%]::after {\n  content: "";\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  background:\n    linear-gradient(\n      90deg,\n      transparent,\n      rgba(255, 255, 255, 0.7),\n      transparent);\n  animation: _ngcontent-%COMP%_otaShimmer 1.4s infinite linear;\n}\n@keyframes _ngcontent-%COMP%_otaShimmer {\n  0% {\n    transform: translateX(-100%);\n  }\n  100% {\n    transform: translateX(100%);\n  }\n}\n.playstore-mandatory-backdrop[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  background: rgba(15, 23, 42, 0.78);\n  backdrop-filter: blur(8px);\n  -webkit-backdrop-filter: blur(8px);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  padding: 24px 20px;\n  z-index: 100000;\n  animation: _ngcontent-%COMP%_fadeIn 0.25s ease-out;\n}\n.playstore-mandatory-card[_ngcontent-%COMP%] {\n  position: relative;\n  background: #ffffff;\n  border-radius: 28px;\n  padding: 36px 24px 28px;\n  width: 100%;\n  max-width: 360px;\n  text-align: center;\n  box-shadow: 0 32px 64px rgba(0, 0, 0, 0.35);\n  border: 1px solid rgba(255, 255, 255, 0.2);\n  animation: _ngcontent-%COMP%_scaleUp 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);\n}\n.playstore-icon-wrap[_ngcontent-%COMP%] {\n  width: 76px;\n  height: 76px;\n  border-radius: 50%;\n  background: #fbf0ff;\n  color: var(--app-theme-color, #a000e2);\n  box-shadow: 0 0 0 10px rgba(160, 0, 226, 0.12);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 42px;\n  margin: 0 auto 20px;\n}\n.playstore-update-title[_ngcontent-%COMP%] {\n  font-size: 20px;\n  font-weight: 800;\n  color: #0f172a;\n  margin: 0 0 8px;\n  letter-spacing: -0.2px;\n}\n.playstore-update-subtitle[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  color: #64748b;\n  line-height: 1.55;\n  margin: 0 0 18px;\n}\n.playstore-update-subtitle[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: #1e293b;\n  font-weight: 700;\n}\n.playstore-version-badge-wrap[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 8px;\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n  border-radius: 20px;\n  padding: 6px 14px;\n  margin-bottom: 18px;\n}\n.playstore-version-badge-wrap[_ngcontent-%COMP%]   .version-tag[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 700;\n}\n.playstore-version-badge-wrap[_ngcontent-%COMP%]   .version-tag.current[_ngcontent-%COMP%] {\n  color: #64748b;\n}\n.playstore-version-badge-wrap[_ngcontent-%COMP%]   .version-tag.latest[_ngcontent-%COMP%] {\n  color: #a000e2;\n}\n.playstore-version-badge-wrap[_ngcontent-%COMP%]   .arrow-between[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: #94a3b8;\n}\n.playstore-strict-note[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 600;\n  color: #b91c1c;\n  background: #fef2f2;\n  border-radius: 12px;\n  padding: 8px 12px;\n  margin-bottom: 24px;\n  line-height: 1.4;\n}\n.btn-playstore-update[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 15px 20px;\n  border-radius: 16px;\n  font-size: 15px;\n  font-weight: 800;\n  border: none;\n  cursor: pointer;\n  background:\n    linear-gradient(\n      135deg,\n      #a000e2 0%,\n      #7c00b3 100%);\n  color: #ffffff;\n  box-shadow: 0 8px 24px rgba(160, 0, 226, 0.35);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 8px;\n  transition: transform 0.15s ease, box-shadow 0.15s ease;\n}\n.btn-playstore-update[_ngcontent-%COMP%]:active {\n  transform: scale(0.98);\n  box-shadow: 0 4px 12px rgba(160, 0, 226, 0.25);\n}\n.btn-playstore-update[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 20px;\n}\n@keyframes _ngcontent-%COMP%_fadeIn {\n  from {\n    opacity: 0;\n  }\n  to {\n    opacity: 1;\n  }\n}\n@keyframes _ngcontent-%COMP%_scaleUp {\n  0% {\n    transform: scale(0.85);\n    opacity: 0;\n  }\n  100% {\n    transform: scale(1);\n    opacity: 1;\n  }\n}\n/*# sourceMappingURL=layout.page.css.map */'] });
var LayoutPage = _LayoutPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(LayoutPage, { className: "LayoutPage", filePath: "src/app/pages/layout/layout.page.ts", lineNumber: 51 });
})();
export {
  LayoutPage
};
//# sourceMappingURL=layout.page-JD6CQZSX.js.map
