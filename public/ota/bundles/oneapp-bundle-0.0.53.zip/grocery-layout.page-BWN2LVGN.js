import {
  GroceryService
} from "./chunk-UOJDERHI.js";
import "./chunk-OE5MTPUR.js";
import "./chunk-YJYUHAOC.js";
import "./chunk-XR3JUECC.js";
import {
  IonApp,
  IonFooter,
  IonIcon,
  IonRouterOutlet
} from "./chunk-CJE2NDTY.js";
import {
  CommonModule,
  FormsModule,
  NavController,
  NavigationEnd,
  NgIf,
  Router,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate1
} from "./chunk-Z7XNNJSA.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import "./chunk-6B6DTIB5.js";

// src/app/pages/grocery-layout/grocery-layout.page.ts
function GroceryLayoutPage_Conditional_2_ion_footer_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-footer", 2);
    \u0275\u0275listener("click", function GroceryLayoutPage_Conditional_2_ion_footer_0_Template_ion_footer_click_0_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.goToCart());
    });
    \u0275\u0275elementStart(1, "div", 3)(2, "div", 4)(3, "small");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "h6");
    \u0275\u0275text(6);
    \u0275\u0275elementStart(7, "small", 5);
    \u0275\u0275text(8, "+ charges");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(9, "div", 6);
    \u0275\u0275text(10, " View Cart ");
    \u0275\u0275element(11, "ion-icon", 7);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("", ctx_r1.totalItems, " ITEMS");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r1.totalPrice, " ");
  }
}
function GroceryLayoutPage_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275template(0, GroceryLayoutPage_Conditional_2_ion_footer_0_Template, 12, 2, "ion-footer", 1);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275property("ngIf", ctx_r1.totalItems > 0);
  }
}
var _GroceryLayoutPage = class _GroceryLayoutPage {
  constructor(groceryService, router, navCtrl) {
    this.groceryService = groceryService;
    this.router = router;
    this.navCtrl = navCtrl;
    this.totalPrice = 0;
    this.totalItems = 0;
    this.currentRoute = "";
    this.currentRoute = this.router.url;
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.currentRoute = event.urlAfterRedirects;
      }
    });
  }
  ngOnInit() {
    this.groceryService.summary$.subscribe((summary) => {
      this.totalPrice = summary.totalAmount;
      this.totalItems = summary.itemCount;
      console.log("Updated Summary:", summary);
    });
  }
  goToCart() {
    this.navCtrl.navigateForward("/layout/grocery-layout/cart");
  }
};
_GroceryLayoutPage.\u0275fac = function GroceryLayoutPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _GroceryLayoutPage)(\u0275\u0275directiveInject(GroceryService), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(NavController));
};
_GroceryLayoutPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _GroceryLayoutPage, selectors: [["app-grocery-layout"]], decls: 3, vars: 1, consts: [[1, "cart-footer", "position-fixed", "bottom-0", "w-100"], ["class", "cart-footer position-fixed bottom-0 w-100", 3, "click", 4, "ngIf"], [1, "cart-footer", "position-fixed", "bottom-0", "w-100", 3, "click"], [1, "cart-bar"], [1, "cart-info"], [1, "tax"], [1, "view-cart-btn"], ["name", "caret-forward-outline"]], template: function GroceryLayoutPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-app");
    \u0275\u0275element(1, "ion-router-outlet");
    \u0275\u0275elementEnd();
    \u0275\u0275template(2, GroceryLayoutPage_Conditional_2_Template, 1, 1, "ion-footer", 0);
  }
  if (rf & 2) {
    \u0275\u0275advance(2);
    \u0275\u0275conditional(!ctx.currentRoute.includes("/layout/grocery-layout/grocery-item-details") && !ctx.currentRoute.includes("/layout/grocery-layout/cart") && !ctx.currentRoute.includes("/layout/grocery-layout/grocery-order-details") ? 2 : -1);
  }
}, dependencies: [IonIcon, IonFooter, IonRouterOutlet, IonApp, CommonModule, NgIf, FormsModule], styles: ["\n\n.cart-footer[_ngcontent-%COMP%] {\n  padding: 10px 15px 20px;\n  background: transparent;\n  position: absolute;\n  bottom: 0;\n  width: 100%;\n  pointer-events: none;\n}\n.cart-footer[_ngcontent-%COMP%]   .cart-bar[_ngcontent-%COMP%] {\n  pointer-events: auto;\n  background: #a000e2;\n  border-radius: 12px;\n  padding: 12px 16px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  color: white;\n}\n.cart-footer[_ngcontent-%COMP%]   .cart-bar[_ngcontent-%COMP%]   .cart-info[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  line-height: 1.2;\n}\n.cart-footer[_ngcontent-%COMP%]   .cart-bar[_ngcontent-%COMP%]   .cart-info[_ngcontent-%COMP%]   small[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 700;\n  opacity: 0.8;\n  letter-spacing: 0.5px;\n}\n.cart-footer[_ngcontent-%COMP%]   .cart-bar[_ngcontent-%COMP%]   .cart-info[_ngcontent-%COMP%]   h6[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 16px;\n  font-weight: 700;\n}\n.cart-footer[_ngcontent-%COMP%]   .cart-bar[_ngcontent-%COMP%]   .cart-info[_ngcontent-%COMP%]   .tax[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 400;\n  opacity: 0.7;\n}\n.cart-footer[_ngcontent-%COMP%]   .cart-bar[_ngcontent-%COMP%]   .view-cart-btn[_ngcontent-%COMP%] {\n  font-weight: 700;\n  font-size: 14px;\n  display: flex;\n  align-items: center;\n  gap: 5px;\n}\n.footer-md[_ngcontent-%COMP%] {\n  -webkit-box-shadow: none;\n  box-shadow: none;\n}\n/*# sourceMappingURL=grocery-layout.page.css.map */"] });
var GroceryLayoutPage = _GroceryLayoutPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(GroceryLayoutPage, { className: "GroceryLayoutPage", filePath: "src/app/pages/grocery-layout/grocery-layout.page.ts", lineNumber: 16 });
})();
export {
  GroceryLayoutPage
};
//# sourceMappingURL=grocery-layout.page-BWN2LVGN.js.map
