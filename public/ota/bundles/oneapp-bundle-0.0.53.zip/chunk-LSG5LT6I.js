import {
  addIcons,
  timeOutline
} from "./chunk-I7AJKZVE.js";
import {
  IonicModule
} from "./chunk-OE5MTPUR.js";
import {
  CommonModule,
  EventEmitter,
  NgIf,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵstyleProp,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1
} from "./chunk-Z7XNNJSA.js";

// src/app/components/product-card/product-card.component.ts
function ProductCardComponent_span_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 10);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("", ctx_r0.product.discount, "% OFF");
  }
}
function ProductCardComponent_Conditional_10_span_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 13);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("\u20B9", ctx_r0.product.originalPrice, "");
  }
}
function ProductCardComponent_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 6)(1, "span", 11);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275template(3, ProductCardComponent_Conditional_10_span_3_Template, 2, 1, "span", 12);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r0.product.price, "");
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", ctx_r0.product.discount > 0);
  }
}
function ProductCardComponent_button_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "button", 14);
    \u0275\u0275text(1, " OUT OF STOCK ");
    \u0275\u0275elementEnd();
  }
}
function ProductCardComponent_button_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 15);
    \u0275\u0275listener("click", function ProductCardComponent_button_12_Template_button_click_0_listener($event) {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.onIncrease($event));
    });
    \u0275\u0275text(1, " ADD ");
    \u0275\u0275elementEnd();
  }
}
function ProductCardComponent_div_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 16)(1, "div", 17);
    \u0275\u0275listener("click", function ProductCardComponent_div_13_Template_div_click_1_listener($event) {
      \u0275\u0275restoreView(_r3);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.onDecrease($event));
    });
    \u0275\u0275text(2, "-");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 18);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 19);
    \u0275\u0275listener("click", function ProductCardComponent_div_13_Template_div_click_5_listener($event) {
      \u0275\u0275restoreView(_r3);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.onIncrease($event));
    });
    \u0275\u0275text(6, "+");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r0.qty);
  }
}
var _ProductCardComponent = class _ProductCardComponent {
  constructor() {
    this.qty = 0;
    this.itemClicked = new EventEmitter();
    this.increase = new EventEmitter();
    this.decrease = new EventEmitter();
    this.backgroundColors = [
      // --- Warm Off-Whites (Rose, Peach, Cream) ---
      "#FFF5F5",
      // Very Pale Red
      "#FFF0F5",
      // Lavender Blush
      "#FFFAFA",
      // Snow
      "#FFF8E1",
      // Cosmic Latte
      "#FFF3E0",
      // Bleached Almond
      "#FFF5E5",
      // Warm Cream
      "#FFF9F0",
      // Floral White
      "#FAF0E6",
      // Linen
      // --- Cool Off-Whites (Ice, Mist, Sky) ---
      "#F0F8FF",
      // Alice Blue
      "#F5F9FF",
      // Whisper Blue
      "#E6F7FF",
      // Pale Sky
      "#F0FFFF",
      // Azure Mist
      "#E0FFFF",
      // Light Cyan (Very faint)
      "#F2FDFF",
      // Ice Water
      "#F5FFFA",
      // Mint Cream
      // --- Nature Off-Whites (Lime, Mint, Tea) ---
      "#F1F8E9",
      // Pale Green
      "#F0FFF0",
      // Honeydew
      "#F5FFF5",
      // White Smoke Green
      "#F9FBE7",
      // Lime Tint
      "#FFFFF0",
      // Ivory
      // --- Elegant Neutrals (Lavender, Grey) ---
      "#F3E5F5",
      // Pale Lavender
      "#F8F5FF",
      // Magnolia
      "#FAFAFA",
      // Alabaster (Very Light Grey)
      "#F5F5F5",
      // White Smoke
      "#F2F2F2"
      // Concrete (Light)
    ];
    this.cardBackground = "";
    addIcons({ timeOutline });
  }
  ngOnInit() {
    this.cardBackground = this.getRandomColor();
  }
  onCardClick() {
    this.itemClicked.emit(this.product);
  }
  onIncrease(event) {
    event.stopPropagation();
    this.increase.emit(this.product.id);
  }
  onDecrease(event) {
    event.stopPropagation();
    this.decrease.emit(this.product.id);
  }
  getRandomColor() {
    const randomIndex = Math.floor(Math.random() * this.backgroundColors.length);
    return this.backgroundColors[randomIndex];
  }
};
_ProductCardComponent.\u0275fac = function ProductCardComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _ProductCardComponent)();
};
_ProductCardComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _ProductCardComponent, selectors: [["app-product-card"]], inputs: { product: "product", qty: "qty" }, outputs: { itemClicked: "itemClicked", increase: "increase", decrease: "decrease" }, decls: 14, vars: 10, consts: [[1, "product-card", 3, "click"], [1, "img-wrapper"], [2, "width", "100%", "height", "100%", "object-fit", "cover", "border-radius", "15px 15px 0 0", 3, "src"], ["class", "discount", 4, "ngIf"], [1, "p-details", "px-2", "pb-2"], [1, "price-row"], [1, "prices"], ["class", "add-btn", "disabled", "", "style", "opacity: 0.7; background-color: #dcdcdc; color: #555; border: none;", 4, "ngIf"], ["class", "add-btn", 3, "click", 4, "ngIf"], ["class", "qty-counter", 4, "ngIf"], [1, "discount"], [1, "current"], ["class", "original", 4, "ngIf"], [1, "original"], ["disabled", "", 1, "add-btn", 2, "opacity", "0.7", "background-color", "#dcdcdc", "color", "#555", "border", "none"], [1, "add-btn", 3, "click"], [1, "qty-counter"], [1, "minus", 3, "click"], [1, "count"], [1, "plus", 3, "click"]], template: function ProductCardComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 0);
    \u0275\u0275listener("click", function ProductCardComponent_Template_div_click_0_listener() {
      return ctx.onCardClick();
    });
    \u0275\u0275elementStart(1, "div", 1);
    \u0275\u0275element(2, "img", 2);
    \u0275\u0275template(3, ProductCardComponent_span_3_Template, 2, 1, "span", 3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "div", 4)(5, "h5");
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "small");
    \u0275\u0275text(8);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "div", 5);
    \u0275\u0275template(10, ProductCardComponent_Conditional_10_Template, 4, 2, "div", 6)(11, ProductCardComponent_button_11_Template, 2, 0, "button", 7)(12, ProductCardComponent_button_12_Template, 2, 0, "button", 8)(13, ProductCardComponent_div_13_Template, 7, 1, "div", 9);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    \u0275\u0275advance();
    \u0275\u0275styleProp("background", ctx.cardBackground);
    \u0275\u0275advance();
    \u0275\u0275property("src", ctx.product.img, \u0275\u0275sanitizeUrl);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", ctx.product.discount > 0);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx.product.name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx.product.weight);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx.product.stock > 0 ? 10 : -1);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", ctx.product.stock === 0);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", ctx.product.stock !== 0 && ctx.qty === 0);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", ctx.product.stock !== 0 && ctx.qty > 0);
  }
}, dependencies: [CommonModule, NgIf, IonicModule], styles: ["\n\n.product-card[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  background: white;\n  border-radius: 16px;\n  border: 1px solid #f0f0f0;\n  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.02);\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n  height: 100%;\n}\n.product-card[_ngcontent-%COMP%]   .img-wrapper[_ngcontent-%COMP%] {\n  position: relative;\n  height: auto;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  margin-bottom: 5px;\n  border-radius: 15px 15px 0 0;\n}\n.product-card[_ngcontent-%COMP%]   .img-wrapper[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  max-height: auto;\n  max-width: 100%;\n  object-fit: contain;\n}\n.product-card[_ngcontent-%COMP%]   .img-wrapper[_ngcontent-%COMP%]   .discount[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0px;\n  left: 0px;\n  background: #5c6bc0;\n  color: white;\n  font-size: 9px;\n  padding: 3px 6px;\n  border-radius: 4px 0 6px 0;\n  font-weight: 700;\n}\n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   .time-tag[_ngcontent-%COMP%] {\n  background: #f5f5f5;\n  width: fit-content;\n  font-size: 9px;\n  padding: 2px 5px;\n  border-radius: 4px;\n  font-weight: 700;\n  color: #555;\n  display: flex;\n  align-items: center;\n  gap: 3px;\n}\n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   .time-tag[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 10px;\n}\n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-weight: 600;\n  margin: 6px 0 2px;\n  color: #222;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   small[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #888;\n  font-weight: 500;\n}\n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   .price-row[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-end;\n  margin-top: 10px;\n  height: 28px;\n}\n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   .price-row[_ngcontent-%COMP%]   .prices[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   .price-row[_ngcontent-%COMP%]   .prices[_ngcontent-%COMP%]   .current[_ngcontent-%COMP%] {\n  font-weight: 700;\n  font-size: 13px;\n  color: #222;\n}\n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   .price-row[_ngcontent-%COMP%]   .prices[_ngcontent-%COMP%]   .original[_ngcontent-%COMP%] {\n  font-size: 10px;\n  color: #999;\n  text-decoration: line-through;\n}\n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   .price-row[_ngcontent-%COMP%]   .add-btn[_ngcontent-%COMP%] {\n  background: white;\n  color: #a000e2;\n  border: 1px solid #a000e2;\n  border-radius: 6px;\n  padding: 5px 12px;\n  font-weight: 800;\n  font-size: 12px;\n  box-shadow: 0 2px 5px rgba(255, 50, 105, 0.1);\n  text-transform: uppercase;\n  height: 28px;\n  display: flex;\n  align-items: center;\n}\n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   .price-row[_ngcontent-%COMP%]   .qty-counter[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  background: #a000e2;\n  border-radius: 6px;\n  height: 28px;\n  box-shadow: 0 2px 5px rgba(255, 50, 105, 0.3);\n}\n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   .price-row[_ngcontent-%COMP%]   .qty-counter[_ngcontent-%COMP%]   .minus[_ngcontent-%COMP%], \n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   .price-row[_ngcontent-%COMP%]   .qty-counter[_ngcontent-%COMP%]   .plus[_ngcontent-%COMP%] {\n  width: 25px;\n  height: 100%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  color: white;\n  font-weight: bold;\n  font-size: 16px;\n}\n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   .price-row[_ngcontent-%COMP%]   .qty-counter[_ngcontent-%COMP%]   .count[_ngcontent-%COMP%] {\n  color: white;\n  font-weight: 700;\n  font-size: 12px;\n  min-width: 15px;\n  text-align: center;\n}\n/*# sourceMappingURL=product-card.component.css.map */"] });
var ProductCardComponent = _ProductCardComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(ProductCardComponent, { className: "ProductCardComponent", filePath: "src/app/components/product-card/product-card.component.ts", lineNumber: 14 });
})();

export {
  ProductCardComponent
};
//# sourceMappingURL=chunk-LSG5LT6I.js.map
