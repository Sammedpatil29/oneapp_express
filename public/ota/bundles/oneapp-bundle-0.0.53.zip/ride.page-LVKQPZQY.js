import {
  RideSelectionComponent
} from "./chunk-GK2RCAPS.js";
import {
  Geolocation
} from "./chunk-V444GY6B.js";
import "./chunk-QH3WR2OQ.js";
import {
  addIcons,
  arrowBack,
  bag,
  briefcaseOutline,
  buildOutline,
  constructOutline,
  cube,
  home,
  library,
  person,
  personCircle,
  personCircleOutline,
  playCircle,
  radio,
  receiptOutline,
  search
} from "./chunk-I7AJKZVE.js";
import "./chunk-EB6T6TPT.js";
import {
  ToastController
} from "./chunk-OE5MTPUR.js";
import "./chunk-YJYUHAOC.js";
import "./chunk-XR3JUECC.js";
import {
  IonContent,
  IonSpinner,
  IonTitle
} from "./chunk-CJE2NDTY.js";
import {
  CommonModule,
  DefaultValueAccessor,
  FormsModule,
  NavController,
  NgControlStatus,
  NgModel,
  NgZone,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵloadQuery,
  ɵɵnamespaceHTML,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵqueryRefresh,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIndex,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty,
  ɵɵviewQuery
} from "./chunk-Z7XNNJSA.js";
import "./chunk-FH4NU4VH.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/pages/ride/ride.page.ts
var _c0 = ["autocompleteInput"];
var _c1 = ["dropInput"];
function RidePage_Conditional_0_Conditional_1_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 19);
    \u0275\u0275listener("click", function RidePage_Conditional_0_Conditional_1_Conditional_11_Template_div_click_0_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.pickup = "");
    });
    \u0275\u0275text(1, " \u2715 ");
    \u0275\u0275elementEnd();
  }
}
function RidePage_Conditional_0_Conditional_1_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 19);
    \u0275\u0275listener("click", function RidePage_Conditional_0_Conditional_1_Conditional_17_Template_div_click_0_listener() {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.drop = "");
    });
    \u0275\u0275text(1, " \u2715 ");
    \u0275\u0275elementEnd();
  }
}
function RidePage_Conditional_0_Conditional_1_Conditional_23_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-title", 20);
    \u0275\u0275text(1, "Recent");
    \u0275\u0275elementEnd();
  }
}
function RidePage_Conditional_0_Conditional_1_Conditional_23_For_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 22);
    \u0275\u0275listener("click", function RidePage_Conditional_0_Conditional_1_Conditional_23_For_2_Template_div_click_0_listener() {
      const item_r6 = \u0275\u0275restoreView(_r5).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(4);
      return \u0275\u0275resetView(ctx_r1.setPickupDropbyHistory(item_r6));
    });
    \u0275\u0275elementStart(1, "div", 23);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(2, "svg", 24);
    \u0275\u0275element(3, "path", 25);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(4, "div", 26)(5, "b");
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "small");
    \u0275\u0275text(8);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const item_r6 = ctx.$implicit;
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(item_r6.name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(item_r6.formatted_address);
  }
}
function RidePage_Conditional_0_Conditional_1_Conditional_23_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-title", 20);
    \u0275\u0275text(1, "Local");
    \u0275\u0275elementEnd();
  }
}
function RidePage_Conditional_0_Conditional_1_Conditional_23_For_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 22);
    \u0275\u0275listener("click", function RidePage_Conditional_0_Conditional_1_Conditional_23_For_5_Template_div_click_0_listener() {
      const item_r8 = \u0275\u0275restoreView(_r7).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(4);
      return \u0275\u0275resetView(ctx_r1.setPickupDropbyHistory(item_r8));
    });
    \u0275\u0275elementStart(1, "div", 23);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(2, "svg", 24);
    \u0275\u0275element(3, "path", 25);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(4, "div", 26)(5, "b");
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "small");
    \u0275\u0275text(8);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const item_r8 = ctx.$implicit;
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(item_r8.name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(item_r8.formatted_address);
  }
}
function RidePage_Conditional_0_Conditional_1_Conditional_23_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-title", 20);
    \u0275\u0275text(1, "Out Station");
    \u0275\u0275elementEnd();
  }
}
function RidePage_Conditional_0_Conditional_1_Conditional_23_For_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 22);
    \u0275\u0275listener("click", function RidePage_Conditional_0_Conditional_1_Conditional_23_For_8_Template_div_click_0_listener() {
      const item_r10 = \u0275\u0275restoreView(_r9).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(4);
      return \u0275\u0275resetView(ctx_r1.setPickupDropbyHistory(item_r10));
    });
    \u0275\u0275elementStart(1, "div", 23);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(2, "svg", 24);
    \u0275\u0275element(3, "path", 25);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(4, "div", 26)(5, "b");
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "small");
    \u0275\u0275text(8);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const item_r10 = ctx.$implicit;
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(item_r10.name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(item_r10.formatted_address);
  }
}
function RidePage_Conditional_0_Conditional_1_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275template(0, RidePage_Conditional_0_Conditional_1_Conditional_23_Conditional_0_Template, 2, 0, "ion-title", 20);
    \u0275\u0275repeaterCreate(1, RidePage_Conditional_0_Conditional_1_Conditional_23_For_2_Template, 9, 2, "div", 21, \u0275\u0275repeaterTrackByIndex);
    \u0275\u0275template(3, RidePage_Conditional_0_Conditional_1_Conditional_23_Conditional_3_Template, 2, 0, "ion-title", 20);
    \u0275\u0275repeaterCreate(4, RidePage_Conditional_0_Conditional_1_Conditional_23_For_5_Template, 9, 2, "div", 21, \u0275\u0275repeaterTrackByIndex);
    \u0275\u0275template(6, RidePage_Conditional_0_Conditional_1_Conditional_23_Conditional_6_Template, 2, 0, "ion-title", 20);
    \u0275\u0275repeaterCreate(7, RidePage_Conditional_0_Conditional_1_Conditional_23_For_8_Template, 9, 2, "div", 21, \u0275\u0275repeaterTrackByIndex);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275conditional(ctx_r1.filteredHistory.length > 0 ? 0 : -1);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r1.filteredHistory);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.filteredPredictions.length > 0 ? 3 : -1);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r1.filteredPredictions);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.filteredPredictionsOut.length > 0 ? 6 : -1);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r1.filteredPredictionsOut);
  }
}
function RidePage_Conditional_0_Conditional_1_Conditional_24_For_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 22);
    \u0275\u0275listener("click", function RidePage_Conditional_0_Conditional_1_Conditional_24_For_1_Template_div_click_0_listener() {
      const item_r12 = \u0275\u0275restoreView(_r11).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(4);
      return \u0275\u0275resetView(ctx_r1.setPickupDropbyHistory(item_r12));
    });
    \u0275\u0275elementStart(1, "div", 23);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(2, "svg", 24);
    \u0275\u0275element(3, "path", 25);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(4, "div", 26)(5, "b");
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "small");
    \u0275\u0275text(8);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const item_r12 = ctx.$implicit;
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(item_r12.name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(item_r12.formatted_address);
  }
}
function RidePage_Conditional_0_Conditional_1_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275repeaterCreate(0, RidePage_Conditional_0_Conditional_1_Conditional_24_For_1_Template, 9, 2, "div", 21, \u0275\u0275repeaterTrackByIndex);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275repeater(ctx_r1.userHistory);
  }
}
function RidePage_Conditional_0_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "section")(1, "div", 3)(2, "ion-title", 4)(3, "div", 5);
    \u0275\u0275listener("click", function RidePage_Conditional_0_Conditional_1_Template_div_click_3_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.goBack());
    });
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(4, "svg", 6);
    \u0275\u0275element(5, "path", 7);
    \u0275\u0275elementEnd();
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(7, "div", 8)(8, "div", 9);
    \u0275\u0275element(9, "div", 10);
    \u0275\u0275elementStart(10, "input", 11);
    \u0275\u0275twoWayListener("ngModelChange", function RidePage_Conditional_0_Conditional_1_Template_input_ngModelChange_10_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext(2);
      \u0275\u0275twoWayBindingSet(ctx_r1.pickup, $event) || (ctx_r1.pickup = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275listener("input", function RidePage_Conditional_0_Conditional_1_Template_input_input_10_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.onInputChange("Pickup"));
    })("focus", function RidePage_Conditional_0_Conditional_1_Template_input_focus_10_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.selectedInput = "Pickup");
    });
    \u0275\u0275elementEnd();
    \u0275\u0275template(11, RidePage_Conditional_0_Conditional_1_Conditional_11_Template, 2, 0, "div", 12);
    \u0275\u0275elementEnd();
    \u0275\u0275element(12, "div", 13);
    \u0275\u0275elementStart(13, "div", 9);
    \u0275\u0275element(14, "div", 14);
    \u0275\u0275elementStart(15, "input", 15, 0);
    \u0275\u0275twoWayListener("ngModelChange", function RidePage_Conditional_0_Conditional_1_Template_input_ngModelChange_15_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext(2);
      \u0275\u0275twoWayBindingSet(ctx_r1.drop, $event) || (ctx_r1.drop = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275listener("input", function RidePage_Conditional_0_Conditional_1_Template_input_input_15_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.onInputChange("Drop"));
    })("focus", function RidePage_Conditional_0_Conditional_1_Template_input_focus_15_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.selectedInput = "Drop");
    });
    \u0275\u0275elementEnd();
    \u0275\u0275template(17, RidePage_Conditional_0_Conditional_1_Conditional_17_Template, 2, 0, "div", 12);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "button", 16)(19, "small");
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(20, "svg", 17);
    \u0275\u0275element(21, "path", 18);
    \u0275\u0275elementEnd();
    \u0275\u0275text(22, " Select on map ");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275template(23, RidePage_Conditional_0_Conditional_1_Conditional_23_Template, 9, 3)(24, RidePage_Conditional_0_Conditional_1_Conditional_24_Template, 2, 0);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1(" ", ctx_r1.selectedInput, " ");
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.pickup);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.pickup != "" ? 11 : -1);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.drop);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.drop != "" ? 17 : -1);
    \u0275\u0275advance(6);
    \u0275\u0275conditional(ctx_r1.filteredPredictions.length != 0 || ctx_r1.filteredPredictionsOut.length != 0 || ctx_r1.filteredHistory.length != 0 ? 23 : 24);
  }
}
function RidePage_Conditional_0_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section");
    \u0275\u0275element(1, "app-ride-selection");
    \u0275\u0275elementEnd();
  }
}
function RidePage_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 1);
    \u0275\u0275template(1, RidePage_Conditional_0_Conditional_1_Template, 25, 6, "section")(2, RidePage_Conditional_0_Conditional_2_Template, 2, 0, "section");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance();
    \u0275\u0275conditional(!ctx_r1.isAddressSelected ? 1 : 2);
  }
}
function RidePage_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 2);
    \u0275\u0275element(1, "ion-spinner", 27);
    \u0275\u0275elementStart(2, "p");
    \u0275\u0275text(3, "Getting Rides Ready...");
    \u0275\u0275elementEnd()();
  }
}
var _RidePage = class _RidePage {
  constructor(navCtrl, ngZone, toastController) {
    this.navCtrl = navCtrl;
    this.ngZone = ngZone;
    this.toastController = toastController;
    this.selectedInput = "Drop";
    this.pickup = "";
    this.drop = "";
    this.isAddressSelected = false;
    this.isLoading = true;
    this.currentCity = "Athani";
    this.polygonCoords = [
      { lat: 16.734104849994047, lng: 75.05205138360644 },
      { lat: 16.73369387020915, lng: 75.05050643121386 },
      { lat: 16.73657071008989, lng: 75.04604323541308 },
      { lat: 16.732132138943395, lng: 75.0447128597417 },
      { lat: 16.7316184087561, lng: 75.0424812618413 },
      { lat: 16.730088126755223, lng: 75.04177181755686 },
      { lat: 16.72841398545857, lng: 75.04335834418917 },
      { lat: 16.726257551643595, lng: 75.0438491884389 },
      { lat: 16.726403969005577, lng: 75.04536731874133 },
      { lat: 16.72562821257917, lng: 75.04548533593798 },
      { lat: 16.723809539444744, lng: 75.04548533593798 },
      { lat: 16.71750056147832, lng: 75.04578574334765 },
      { lat: 16.717654692091298, lng: 75.04477723275805 },
      { lat: 16.716498709458545, lng: 75.04517419969226 },
      { lat: 16.715057574633803, lng: 75.04455729161883 },
      { lat: 16.714583616149646, lng: 75.04532172118807 },
      { lat: 16.71542492376014, lng: 75.04591448938037 },
      { lat: 16.711294132008202, lng: 75.05059226190234 },
      { lat: 16.709808001288184, lng: 75.05209161674166 },
      { lat: 16.706472192963027, lng: 75.05221768056536 },
      { lat: 16.704294958939602, lng: 75.05359901820803 },
      { lat: 16.706392554161923, lng: 75.0549803558507 },
      { lat: 16.7107392427215, lng: 75.05587084924365 },
      { lat: 16.71068786400223, lng: 75.05737288629199 },
      { lat: 16.707856875193816, lng: 75.05754454766894 },
      { lat: 16.7078388923721, lng: 75.05926116143847 },
      { lat: 16.708944190517236, lng: 75.05929334794665 },
      { lat: 16.709001349863748, lng: 75.06149275933886 },
      { lat: 16.7107392427215, lng: 75.06350978051806 },
      { lat: 16.705991790658622, lng: 75.06480796968127 },
      { lat: 16.706193135889265, lng: 75.06558765431429 },
      { lat: 16.705017495107235, lng: 75.06621713524247 },
      { lat: 16.705091354205877, lng: 75.06702548598433 },
      { lat: 16.705485697083773, lng: 75.06714015041972 },
      { lat: 16.705390643826167, lng: 75.06762697135592 },
      { lat: 16.70527246943987, lng: 75.06835384999896 },
      { lat: 16.705215951229267, lng: 75.06924166118289 },
      { lat: 16.704156231682543, lng: 75.06997055148268 },
      { lat: 16.702898529624107, lng: 75.07079792914475 },
      { lat: 16.699441692922672, lng: 75.07131417056108 },
      { lat: 16.699447955073694, lng: 75.07169093710864 },
      { lat: 16.700699658599643, lng: 75.07219582104618 },
      { lat: 16.701181639743147, lng: 75.07311345085064 },
      { lat: 16.70164306720707, lng: 75.07250758593464 },
      { lat: 16.70313761086503, lng: 75.07309197222376 },
      { lat: 16.704478001694028, lng: 75.07221187239075 },
      { lat: 16.705633414890166, lng: 75.07404616808081 },
      { lat: 16.7073231700134, lng: 75.07405656164075 },
      { lat: 16.70703993958234, lng: 75.07209284936572 },
      { lat: 16.710040490954373, lng: 75.07346614038134 },
      { lat: 16.71478784230752, lng: 75.07260783349658 },
      { lat: 16.714407647523835, lng: 75.0754402462163 },
      { lat: 16.715368408555975, lng: 75.07548316156054 },
      { lat: 16.716362559931852, lng: 75.07371290361071 },
      { lat: 16.717027893488662, lng: 75.07685645257617 },
      { lat: 16.718692501643023, lng: 75.07773621713305 },
      { lat: 16.72221690183278, lng: 75.07685108815814 },
      { lat: 16.721035258880637, lng: 75.07892711793566 },
      { lat: 16.721733970380477, lng: 75.08106752072955 },
      { lat: 16.724056140208326, lng: 75.08050425683642 },
      { lat: 16.728166105980854, lng: 75.07844432031298 },
      { lat: 16.729043957499268, lng: 75.08094615077162 },
      { lat: 16.728559598447053, lng: 75.08592483361745 },
      { lat: 16.73067033211383, lng: 75.0875022239753 },
      { lat: 16.731686789133466, lng: 75.09078125592815 },
      { lat: 16.731812469995507, lng: 75.09230107046925 },
      { lat: 16.732355051133144, lng: 75.09468195202963 },
      { lat: 16.733421631985838, lng: 75.0949707105584 },
      { lat: 16.735484827161876, lng: 75.09539894395594 },
      { lat: 16.735184896830816, lng: 75.09206135589658 },
      { lat: 16.734162222541105, lng: 75.08884607355604 },
      { lat: 16.73348264070347, lng: 75.08491133579547 },
      { lat: 16.731054909364524, lng: 75.08249210899258 },
      { lat: 16.731586300573486, lng: 75.08116273914958 },
      { lat: 16.73026536524928, lng: 75.08070341085578 },
      { lat: 16.72956090547798, lng: 75.07866694366122 },
      { lat: 16.729476138948996, lng: 75.07713003789569 },
      { lat: 16.72838187673607, lng: 75.07568700944567 },
      { lat: 16.728823692282347, lng: 75.07320864831591 },
      { lat: 16.732111589762486, lng: 75.07054789697314 },
      { lat: 16.733508929016757, lng: 75.06350978051806 },
      { lat: 16.736786471330014, lng: 75.06529076730395 },
      { lat: 16.740885888466465, lng: 75.06672843133593 },
      { lat: 16.739293393540695, lng: 75.06407840882922 },
      { lat: 16.737996270900556, lng: 75.06235374843264 },
      { lat: 16.739021126946596, lng: 75.06185217534686 },
      { lat: 16.739098183569208, lng: 75.06024821435595 },
      { lat: 16.73947832911852, lng: 75.05769743358279 },
      { lat: 16.737094701249244, lng: 75.0567988935628 },
      { lat: 16.736467966556344, lng: 75.0556991878667 },
      { lat: 16.734084301025856, lng: 75.05784495507861 }
    ];
    this.filteredPredictions = [];
    this.filteredPredictionsOut = [];
    this.filteredHistory = [];
    this.autocompleteService = new google.maps.places.AutocompleteService();
    this.mapDiv = null;
    this.userHistory = [
      {
        "name": "Vegan Cafe",
        "formatted_address": "123 Main St, Manhattan, NY 10001, USA",
        "geometry": {
          "location": {
            lat: 40.7127753,
            lng: -74.0059728
          }
        }
      },
      {
        "name": "Sunrise Bakery",
        "formatted_address": "456 Broadway, Brooklyn, NY 11211, USA",
        "geometry": {
          "location": {
            lat: 40.7121,
            lng: -73.9555
          }
        }
      },
      {
        "name": "GreenLeaf Market",
        "formatted_address": "789 Flatbush Ave, Brooklyn, NY 11226, USA",
        "geometry": {
          "location": {
            lat: 40.6469,
            lng: -73.9578
          }
        }
      },
      {
        "name": "Juice & Smoothie Bar",
        "formatted_address": "321 5th Ave, New York, NY 10016, USA",
        "geometry": {
          "location": {
            lat: 40.7465,
            lng: -73.9847
          }
        }
      },
      {
        "name": "Nature's Bowl",
        "formatted_address": "555 Hudson St, New York, NY 10014, USA",
        "geometry": {
          "location": {
            lat: 40.7359,
            lng: -74.0061
          }
        }
      },
      {
        "name": "Herbal Caf\xE9",
        "formatted_address": "12 Avenue B, New York, NY 10009, USA",
        "geometry": {
          "location": {
            lat: 40.7233,
            lng: -73.9805
          }
        }
      },
      {
        "name": "Vita Organics",
        "formatted_address": "88 7th Ave, New York, NY 10011, USA",
        "geometry": {
          "location": {
            lat: 40.7396,
            lng: -73.9997
          }
        }
      },
      {
        "name": "Whole Foodies",
        "formatted_address": "160 W 24th St, New York, NY 10011, USA",
        "geometry": {
          "location": {
            lat: 40.7442,
            lng: -73.9955
          }
        }
      },
      {
        "name": "Organic Treats",
        "formatted_address": "33 St Marks Pl, New York, NY 10003, USA",
        "geometry": {
          "location": {
            lat: 40.7296,
            lng: -73.9871
          }
        }
      },
      {
        "name": "Healthy Harvest",
        "formatted_address": "420 Lexington Ave, New York, NY 10170, USA",
        "geometry": {
          "location": {
            lat: 40.7517,
            lng: -73.9763
          }
        }
      }
    ];
    this.tripData = {
      "origin": "",
      "drop": ""
    };
    addIcons({ arrowBack, home, buildOutline, receiptOutline, personCircleOutline, briefcaseOutline, constructOutline, library, personCircle, person, search, bag, cube, radio, playCircle });
  }
  ngOnInit() {
    return __async(this, null, function* () {
      this.isLoading = true;
      try {
        const locationPromise = this.getCurrentPosition();
        const rideData = yield this.mockLoadRideData();
        if (rideData.currentRide) {
          this.navCtrl.navigateRoot("/layout/ongoing-ride");
          return;
        }
        if (rideData.history) {
          this.userHistory = rideData.history;
        }
        const current = yield locationPromise;
        if (current) {
          const coords = {
            lat: current.coords.latitude,
            lng: current.coords.longitude
          };
          let address = "Your Location";
          if (window.google && window.google.maps) {
            try {
              const result = yield this.reverseGeocode(coords);
              address = result.address;
              this.currentCity = "Athani";
            } catch (e) {
              console.warn("Reverse geocoding failed", e);
            }
          }
          this.pickup = address;
          this.pickupCoords = coords;
          this.pickupLocation = {
            name: address,
            address,
            coords
          };
          this.tripData.origin = this.pickupLocation;
          this.selectedInput = "Drop";
        } else {
          this.presentToast("Location access denied. Please enter pickup manually.");
        }
      } catch (error) {
        console.error("Error during initialization:", error);
        this.presentToast("An error occurred. Please try again.");
      } finally {
        this.isLoading = false;
      }
    });
  }
  getCurrentPosition() {
    return new Promise((resolve) => __async(this, null, function* () {
      try {
        const permissionStatus = yield Geolocation.checkPermissions();
        if (permissionStatus.location !== "granted" && permissionStatus.coarseLocation !== "granted") {
          const requestResult = yield Geolocation.requestPermissions();
          if (requestResult.location !== "granted" && requestResult.coarseLocation !== "granted") {
            console.warn("Location permission not granted.");
            resolve(null);
            return;
          }
        }
        const position = yield Geolocation.getCurrentPosition({
          enableHighAccuracy: true,
          timeout: 1e4
          // 10 second timeout
        });
        resolve(position);
      } catch (error) {
        console.error("Error getting location", error);
        resolve(null);
      }
    }));
  }
  presentToast(message) {
    return __async(this, null, function* () {
      const toast = yield this.toastController.create({
        message,
        duration: 3e3,
        position: "top",
        color: "dark"
      });
      yield toast.present();
    });
  }
  mockLoadRideData() {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          history: this.userHistory,
          currentRide: null
        });
      }, 500);
    });
  }
  reverseGeocode(coords) {
    return new Promise((resolve, reject) => {
      const geocoder = new google.maps.Geocoder();
      geocoder.geocode({ location: coords }, (results, status) => {
        if (status === "OK" && results && results[0]) {
          const address = results[0].formatted_address;
          let city = "";
          if (results[0].address_components) {
            for (const component of results[0].address_components) {
              if (component.types.includes("locality")) {
                city = component.long_name;
                break;
              }
            }
            if (!city) {
              for (const component of results[0].address_components) {
                if (component.types.includes("administrative_area_level_2")) {
                  city = component.long_name;
                  break;
                }
              }
            }
          }
          resolve({ address, city });
        } else {
          reject(status);
        }
      });
    });
  }
  goBack() {
    this.navCtrl.navigateRoot("/layout/home");
  }
  setPickupDropbyHistory(data) {
    if (this.selectedInput === "Pickup") {
      this.pickup = `${data.name} - ${data.formatted_address}`;
      this.pickupCoords = {
        lat: data.geometry.location.lat,
        lng: data.geometry.location.lng
      };
      this.pickupLocation = {
        name: data.name,
        address: data.formatted_address,
        coords: this.pickupCoords
      };
      this.tripData.origin = this.pickupLocation;
      if (this.drop === "") {
        this.selectedInput = "Drop";
      } else {
        this.navCtrl.navigateForward("/layout/ride-selection-page", {
          state: {
            data: this.tripData
          }
        });
      }
    } else {
      this.drop = `${data.name} - ${data.formatted_address}`;
      this.dropCoords = {
        lat: data.geometry.location.lat,
        lng: data.geometry.location.lng
      };
      this.dropLocation = {
        name: data.name,
        address: data.formatted_address,
        coords: this.dropCoords
      };
      this.tripData.drop = this.dropLocation;
      if (this.pickup === "") {
        this.selectedInput = "Pickup";
      } else {
        this.navCtrl.navigateForward("/layout/ride-selection-page", {
          state: {
            data: this.tripData
          }
        });
      }
    }
  }
  ngAfterViewInit() {
    setTimeout(() => {
      this.dropInput.nativeElement.focus();
    });
    if (!window.google || !(google.maps && google.maps.places)) {
      console.error("Google Maps or Places library not loaded.");
      return;
    }
    console.log("Google Maps loaded, initializing services.");
    this.autocompleteService = new google.maps.places.AutocompleteService();
    this.mapDiv = document.createElement("div");
    this.mapDiv.style.display = "none";
    document.body.appendChild(this.mapDiv);
    const map = new google.maps.Map(this.mapDiv);
    this.placesService = new google.maps.places.PlacesService(map);
    this.polygon = new google.maps.Polygon({ paths: this.polygonCoords });
    console.log("AutocompleteService, PlacesService, and polygon are set up.");
  }
  ngOnDestroy() {
    if (this.mapDiv && this.mapDiv.parentNode) {
      this.mapDiv.parentNode.removeChild(this.mapDiv);
    }
  }
  onInputChange(type) {
    return __async(this, null, function* () {
      const input = type === "Pickup" ? this.pickup.trim() : this.drop.trim();
      console.log("Input changed:", input);
      if (!input) {
        this.filteredPredictions = [];
        this.filteredPredictionsOut = [];
        this.filteredHistory = [];
        return;
      }
      const lowerInput = input.toLowerCase();
      this.filteredHistory = this.userHistory.filter((item) => item.name.toLowerCase().includes(lowerInput) || item.formatted_address.toLowerCase().includes(lowerInput));
      const request = {
        input: this.currentCity && !input.toLowerCase().includes(this.currentCity.toLowerCase()) ? `${this.currentCity} ${input}` : input,
        componentRestrictions: { country: "in" }
      };
      if (this.pickupCoords) {
        request.locationBias = {
          radius: 5e4,
          // 50km radius to focus on local areas
          center: this.pickupCoords
        };
      }
      this.autocompleteService.getPlacePredictions(request, (predictions, status) => __async(this, null, function* () {
        if (status !== google.maps.places.PlacesServiceStatus.OK || !predictions) {
          this.ngZone.run(() => {
            this.filteredPredictions = [];
            this.filteredPredictionsOut = [];
          });
          return;
        }
        const places = yield Promise.all(predictions.map((p) => this.getPlaceDetails(p)));
        const validPlaces = places.filter((p) => p !== null);
        this.ngZone.run(() => {
          this.filteredPredictions = validPlaces.filter((p) => p.isInside);
          this.filteredPredictionsOut = validPlaces.filter((p) => !p.isInside);
        });
      }));
    });
  }
  getPlaceDetails(prediction) {
    return new Promise((resolve) => {
      this.placesService.getDetails({ placeId: prediction.place_id, fields: ["name", "formatted_address", "geometry"] }, (place, status) => {
        var _a;
        if (status === google.maps.places.PlacesServiceStatus.OK && ((_a = place == null ? void 0 : place.geometry) == null ? void 0 : _a.location)) {
          const loc = place.geometry.location;
          const isInside = google.maps.geometry.poly.containsLocation(loc, this.polygon);
          resolve({
            name: place.name,
            formatted_address: place.formatted_address,
            geometry: {
              location: {
                lat: loc.lat(),
                lng: loc.lng()
              }
            },
            isInside
          });
        } else {
          resolve(null);
        }
      });
    });
  }
};
_RidePage.\u0275fac = function RidePage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _RidePage)(\u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(NgZone), \u0275\u0275directiveInject(ToastController));
};
_RidePage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _RidePage, selectors: [["app-ride"]], viewQuery: function RidePage_Query(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275viewQuery(_c0, 5);
    \u0275\u0275viewQuery(_c1, 5);
  }
  if (rf & 2) {
    let _t;
    \u0275\u0275queryRefresh(_t = \u0275\u0275loadQuery()) && (ctx.autocompleteInput = _t.first);
    \u0275\u0275queryRefresh(_t = \u0275\u0275loadQuery()) && (ctx.dropInput = _t.first);
  }
}, decls: 2, vars: 1, consts: [["dropInput", ""], [3, "fullscreen"], [1, "loader-state"], [1, "topbar", "bg-white", "position-sticky", "pt-4"], [1, "title-row"], [1, "back-row", 3, "click"], ["xmlns", "http://www.w3.org/2000/svg", "height", "24px", "viewBox", "0 -960 960 960", "width", "24px", 1, "me-2"], ["d", "M400-240 160-480l240-240 56 58-142 142h486v80H314l142 142-56 58Z"], [1, "inputs-wrapper"], [1, "input-row"], [1, "dot", "green"], ["placeholder", "Pickup", "type", "text", 1, "location-input", 3, "ngModelChange", "input", "focus", "ngModel"], [1, "clear-btn"], [1, "line"], [1, "dot", "orange"], ["placeholder", "Drop", "type", "text", 1, "location-input", 3, "ngModelChange", "input", "focus", "ngModel"], [1, "map-btn"], ["xmlns", "http://www.w3.org/2000/svg", "height", "18px", "viewBox", "0 -960 960 960", "width", "18px"], ["d", "M460-420h40v-120h120v-40H500v-120h-40v120H340v40h120v120Z"], [1, "clear-btn", 3, "click"], [1, "list-title"], [1, "result-card", "gap-3"], [1, "result-card", "gap-3", 3, "click"], [1, "icon"], ["xmlns", "http://www.w3.org/2000/svg", "height", "24px", "viewBox", "0 -960 960 960", "width", "24px", "fill", "#000000"], ["d", "M480-100q-147.06 0-255.22-97.04T102-440h61q14.62 121 105.23 200.5Q358.85-160 480-160q134 0 227-93t93-227q0-134-93-227t-227-93q-90.23 0-166.04 46.35-75.81 46.34-116.88 127.11h118.3v60H110.31q30.15-129.23 133.42-211.34Q347-860 480-860q78.85 0 148.2 29.92t120.65 81.21q51.3 51.29 81.22 120.63Q860-558.9 860-480.07q0 78.84-29.93 148.21-29.92 69.37-81.22 120.68T628.2-129.93Q558.85-100 480-100Zm108.92-228.92L450-467.9v-197.48h60v173.23l120.69 121.07-41.77 42.16Z"], [1, "text"], ["name", "crescent"]], template: function RidePage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275template(0, RidePage_Conditional_0_Template, 3, 2, "ion-content", 1)(1, RidePage_Conditional_1_Template, 4, 0, "div", 2);
  }
  if (rf & 2) {
    \u0275\u0275conditional(!ctx.isLoading ? 0 : 1);
  }
}, dependencies: [IonSpinner, IonContent, IonTitle, CommonModule, FormsModule, DefaultValueAccessor, NgControlStatus, NgModel, RideSelectionComponent], styles: ["\n\n.topbar[_ngcontent-%COMP%] {\n  top: 0;\n  z-index: 10;\n  border-bottom: 1px solid #e5e5e5;\n}\n.title-row[_ngcontent-%COMP%] {\n  padding: 12px 16px;\n}\n.back-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  font-weight: 600;\n}\n.inputs-wrapper[_ngcontent-%COMP%] {\n  padding: 0 16px 12px;\n}\n.input-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  background: #f9f9f9;\n  border-radius: 12px;\n  padding: 8px;\n  margin-bottom: 6px;\n}\n.location-input[_ngcontent-%COMP%] {\n  flex: 1;\n  border: none;\n  background: transparent;\n  outline: none;\n  padding: 6px;\n}\n.dot[_ngcontent-%COMP%] {\n  width: 12px;\n  height: 12px;\n  border-radius: 50%;\n  margin-right: 10px;\n}\n.green[_ngcontent-%COMP%] {\n  background: green;\n}\n.orange[_ngcontent-%COMP%] {\n  background: #e05f09;\n}\n.line[_ngcontent-%COMP%] {\n  height: 16px;\n  border-left: 2px dashed #ccc;\n  margin-left: 22px;\n}\n.clear-btn[_ngcontent-%COMP%] {\n  padding: 0 8px;\n  color: #999;\n  font-size: 18px;\n}\n.map-btn[_ngcontent-%COMP%] {\n  margin-top: 6px;\n  background: white;\n  border: 1px solid #ccc;\n  border-radius: 10px;\n  padding: 4px 10px;\n}\n.list-title[_ngcontent-%COMP%] {\n  padding: 10px 16px;\n  font-weight: bold;\n}\n.result-card[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  padding: 12px 16px;\n  border-bottom: 1px solid #eee;\n}\n.result-card[_ngcontent-%COMP%]   .icon[_ngcontent-%COMP%] {\n  width: 32px;\n  text-align: center;\n}\n.result-card[_ngcontent-%COMP%]   .text[_ngcontent-%COMP%] {\n  flex: 1;\n  overflow: hidden;\n}\n.result-card[_ngcontent-%COMP%]   small[_ngcontent-%COMP%] {\n  display: block;\n  color: #666;\n}\n/*# sourceMappingURL=ride.page.css.map */"] });
var RidePage = _RidePage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(RidePage, { className: "RidePage", filePath: "src/app/pages/ride/ride.page.ts", lineNumber: 19 });
})();
export {
  RidePage
};
//# sourceMappingURL=ride.page-LVKQPZQY.js.map
