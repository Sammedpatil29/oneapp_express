import {
  ErrorComponent
} from "./chunk-DH3PQJ2C.js";
import {
  GroceryService
} from "./chunk-UOJDERHI.js";
import {
  addIcons,
  arrowBack,
  arrowBackOutline,
  bicycleOutline,
  callOutline,
  chatbubbleEllipsesOutline,
  checkmarkCircle,
  checkmarkDoneCircleOutline,
  checkmarkOutline,
  chevronBackOutline,
  closeCircleOutline,
  closeOutline,
  cubeOutline,
  homeOutline,
  mapOutline,
  receiptOutline,
  star,
  timeOutline
} from "./chunk-I7AJKZVE.js";
import {
  AuthService
} from "./chunk-EB6T6TPT.js";
import {
  IonButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonIcon,
  IonRefresher,
  IonRefresherContent,
  IonSkeletonText,
  IonTitle,
  IonToolbar,
  IonicModule
} from "./chunk-OE5MTPUR.js";
import "./chunk-YJYUHAOC.js";
import "./chunk-XR3JUECC.js";
import {
  ActivatedRoute,
  CommonModule,
  DatePipe,
  FormsModule,
  NavController,
  NgStyle,
  Platform,
  Router,
  TitleCasePipe,
  UpperCasePipe,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵloadQuery,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind1,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵpropertyInterpolate,
  ɵɵpureFunction0,
  ɵɵpureFunction1,
  ɵɵqueryRefresh,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIdentity,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵviewQuery
} from "./chunk-Z7XNNJSA.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/pages/grocery-order-details/grocery-order-details.page.ts
var _c0 = ["mapElement"];
var _c1 = () => [1, 2, 3];
var _c2 = (a0) => ({ background: a0 });
var _forTrack0 = ($index, $item) => $item.status;
var _forTrack1 = ($index, $item) => $item.name;
function GroceryOrderDetailsPage_Conditional_14_For_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 29)(1, "div", 37);
    \u0275\u0275element(2, "ion-skeleton-text", 38);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 39);
    \u0275\u0275element(4, "ion-skeleton-text", 40)(5, "ion-skeleton-text", 41);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "div", 42);
    \u0275\u0275element(7, "ion-skeleton-text", 43);
    \u0275\u0275elementEnd()();
  }
}
function GroceryOrderDetailsPage_Conditional_14_For_26_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 32);
    \u0275\u0275element(1, "ion-skeleton-text", 19)(2, "ion-skeleton-text", 44);
    \u0275\u0275elementEnd();
  }
}
function GroceryOrderDetailsPage_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 14)(1, "div", 15)(2, "div", 16)(3, "div", 17);
    \u0275\u0275element(4, "ion-skeleton-text", 18)(5, "ion-skeleton-text", 19);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(6, "div", 20)(7, "div", 21);
    \u0275\u0275element(8, "ion-skeleton-text", 22)(9, "ion-skeleton-text", 23);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "div", 24);
    \u0275\u0275element(11, "ion-skeleton-text", 25)(12, "ion-skeleton-text", 26);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(13, "div", 20)(14, "div", 21);
    \u0275\u0275element(15, "ion-skeleton-text", 22)(16, "ion-skeleton-text", 27);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "div", 28);
    \u0275\u0275repeaterCreate(18, GroceryOrderDetailsPage_Conditional_14_For_19_Template, 8, 0, "div", 29, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(20, "div", 20)(21, "div", 21);
    \u0275\u0275element(22, "ion-skeleton-text", 22)(23, "ion-skeleton-text", 30);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(24, "div", 31);
    \u0275\u0275repeaterCreate(25, GroceryOrderDetailsPage_Conditional_14_For_26_Template, 3, 0, "div", 32, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275element(27, "div", 33);
    \u0275\u0275elementStart(28, "div", 34);
    \u0275\u0275element(29, "ion-skeleton-text", 35)(30, "ion-skeleton-text", 36);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    \u0275\u0275advance(18);
    \u0275\u0275repeater(\u0275\u0275pureFunction0(0, _c1));
    \u0275\u0275advance(7);
    \u0275\u0275repeater(\u0275\u0275pureFunction0(1, _c1));
  }
}
function GroceryOrderDetailsPage_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "app-error", 45);
    \u0275\u0275listener("retry", function GroceryOrderDetailsPage_Conditional_15_Template_app_error_retry_0_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.getOrderDetails(true));
    });
    \u0275\u0275elementEnd();
  }
}
function GroceryOrderDetailsPage_Conditional_16_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 50)(1, "div", 59);
    \u0275\u0275element(2, "div", 60, 0);
    \u0275\u0275elementEnd()();
  }
}
function GroceryOrderDetailsPage_Conditional_16_Conditional_9_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "img", 64);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275property("src", ctx_r1.orderDetails.rider_details.image_url, \u0275\u0275sanitizeUrl);
  }
}
function GroceryOrderDetailsPage_Conditional_16_Conditional_9_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275textInterpolate1(" ", ctx_r1.getInitials(ctx_r1.orderDetails.rider_details.name || "Partner Assigned"), " ");
  }
}
function GroceryOrderDetailsPage_Conditional_16_Conditional_9_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-button", 69);
    \u0275\u0275listener("click", function GroceryOrderDetailsPage_Conditional_16_Conditional_9_Conditional_16_Template_ion_button_click_0_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.openMap());
    });
    \u0275\u0275element(1, "ion-icon", 70);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "ion-button", 71);
    \u0275\u0275element(3, "ion-icon", 72);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275property("disabled", !ctx_r1.orderDetails.rider_details.contact);
    \u0275\u0275advance(2);
    \u0275\u0275property("href", "tel:" + ctx_r1.orderDetails.rider_details.contact)("disabled", !ctx_r1.orderDetails.rider_details.contact);
  }
}
function GroceryOrderDetailsPage_Conditional_16_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 20)(1, "div", 21);
    \u0275\u0275element(2, "ion-icon", 61);
    \u0275\u0275elementStart(3, "span");
    \u0275\u0275text(4, "Delivery Partner");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "div", 62)(6, "div", 63);
    \u0275\u0275template(7, GroceryOrderDetailsPage_Conditional_16_Conditional_9_Conditional_7_Template, 1, 1, "img", 64)(8, GroceryOrderDetailsPage_Conditional_16_Conditional_9_Conditional_8_Template, 1, 1);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "div", 65)(10, "h4", 66);
    \u0275\u0275text(11);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "div", 67);
    \u0275\u0275element(13, "ion-icon", 68);
    \u0275\u0275text(14);
    \u0275\u0275pipe(15, "titlecase");
    \u0275\u0275elementEnd()();
    \u0275\u0275template(16, GroceryOrderDetailsPage_Conditional_16_Conditional_9_Conditional_16_Template, 4, 3);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(7);
    \u0275\u0275conditional(ctx_r1.orderDetails.rider_details.image_url ? 7 : 8);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1(" ", ctx_r1.orderDetails.rider_details.name || "Partner Assigned", " ");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate2(" ", ctx_r1.orderDetails.rider_details.rating || "New", " \u2022 ", \u0275\u0275pipeBind1(15, 5, ctx_r1.orderDetails.rider_details.vehicle_type), " ");
    \u0275\u0275advance(2);
    \u0275\u0275conditional((ctx_r1.orderDetails == null ? null : ctx_r1.orderDetails.status == null ? null : ctx_r1.orderDetails.status.toLowerCase()) != "delivered" || (ctx_r1.orderDetails == null ? null : ctx_r1.orderDetails.status == null ? null : ctx_r1.orderDetails.status.toLowerCase()) != "cancelled" ? 16 : -1);
  }
}
function GroceryOrderDetailsPage_Conditional_16_For_17_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 74);
    \u0275\u0275element(1, "ion-icon", 80);
    \u0275\u0275elementEnd();
  }
}
function GroceryOrderDetailsPage_Conditional_16_For_17_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 75);
    \u0275\u0275element(1, "ion-icon", 81);
    \u0275\u0275elementEnd();
  }
}
function GroceryOrderDetailsPage_Conditional_16_For_17_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "div", 76);
  }
}
function GroceryOrderDetailsPage_Conditional_16_For_17_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 53)(1, "div", 73);
    \u0275\u0275template(2, GroceryOrderDetailsPage_Conditional_16_For_17_Conditional_2_Template, 2, 0, "div", 74)(3, GroceryOrderDetailsPage_Conditional_16_For_17_Conditional_3_Template, 2, 0, "div", 75)(4, GroceryOrderDetailsPage_Conditional_16_For_17_Conditional_4_Template, 1, 0, "div", 76);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 77)(6, "div", 78);
    \u0275\u0275text(7);
    \u0275\u0275pipe(8, "titlecase");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "div", 79);
    \u0275\u0275text(10);
    \u0275\u0275pipe(11, "date");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const step_r4 = ctx.$implicit;
    const \u0275$index_181_r5 = ctx.$index;
    const \u0275$count_181_r6 = ctx.$count;
    \u0275\u0275advance(2);
    \u0275\u0275conditional((step_r4 == null ? null : step_r4.status == null ? null : step_r4.status.toLowerCase()) == "cancelled" ? 2 : 3);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(!(\u0275$index_181_r5 === \u0275$count_181_r6 - 1) ? 4 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" ", \u0275\u0275pipeBind1(8, 4, step_r4.status.split("_").join(" ")), " ");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" ", \u0275\u0275pipeBind2(11, 6, step_r4.time, "dd MMM yyyy, hh:mm a"), " ");
  }
}
function GroceryOrderDetailsPage_Conditional_16_For_33_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 29)(1, "div", 37);
    \u0275\u0275element(2, "img", 82);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 83)(4, "h4");
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "small");
    \u0275\u0275text(7);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "div", 84)(9, "span", 85);
    \u0275\u0275text(10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "span", 86);
    \u0275\u0275text(12);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const item_r7 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275propertyInterpolate("alt", item_r7.name);
    \u0275\u0275property("src", item_r7.image, \u0275\u0275sanitizeUrl);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(item_r7.name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(item_r7.weight);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("x", item_r7.quantity, "");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("\u20B9", item_r7.total, "");
  }
}
function GroceryOrderDetailsPage_Conditional_16_Conditional_55_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 58)(1, "span");
    \u0275\u0275text(2, "Your Savings");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("-\u20B9", ctx_r1.orderDetails.bill_details == null ? null : ctx_r1.orderDetails.bill_details.totalSavings, "");
  }
}
function GroceryOrderDetailsPage_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 46)(1, "div", 47)(2, "div", 48)(3, "div", 49)(4, "h2");
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "p");
    \u0275\u0275text(7);
    \u0275\u0275elementEnd()()()()();
    \u0275\u0275template(8, GroceryOrderDetailsPage_Conditional_16_Conditional_8_Template, 4, 0, "div", 50)(9, GroceryOrderDetailsPage_Conditional_16_Conditional_9_Template, 17, 7, "div", 20);
    \u0275\u0275elementStart(10, "div", 20)(11, "div", 21);
    \u0275\u0275element(12, "ion-icon", 51);
    \u0275\u0275elementStart(13, "span");
    \u0275\u0275text(14, "Order Timeline");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "div", 52);
    \u0275\u0275repeaterCreate(16, GroceryOrderDetailsPage_Conditional_16_For_17_Template, 12, 9, "div", 53, _forTrack0);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(18, "div", 20)(19, "div", 21);
    \u0275\u0275element(20, "ion-icon", 54);
    \u0275\u0275elementStart(21, "span");
    \u0275\u0275text(22, "Delivery Address");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(23, "div", 24)(24, "p", 55);
    \u0275\u0275text(25);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(26, "div", 20)(27, "div", 21);
    \u0275\u0275element(28, "ion-icon", 56);
    \u0275\u0275elementStart(29, "span");
    \u0275\u0275text(30);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(31, "div", 28);
    \u0275\u0275repeaterCreate(32, GroceryOrderDetailsPage_Conditional_16_For_33_Template, 13, 6, "div", 29, _forTrack1);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(34, "div", 20)(35, "div", 21);
    \u0275\u0275element(36, "ion-icon", 57);
    \u0275\u0275elementStart(37, "span");
    \u0275\u0275text(38, "Bill Details");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(39, "div", 31)(40, "div", 32)(41, "span");
    \u0275\u0275text(42, "Item Total");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(43, "span");
    \u0275\u0275text(44);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(45, "div", 32)(46, "span");
    \u0275\u0275text(47, "Handling Charge");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(48, "span");
    \u0275\u0275text(49);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(50, "div", 32)(51, "span");
    \u0275\u0275text(52, "Delivery Fee");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(53, "span");
    \u0275\u0275text(54);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(55, GroceryOrderDetailsPage_Conditional_16_Conditional_55_Template, 5, 1, "div", 58);
    \u0275\u0275element(56, "div", 33);
    \u0275\u0275elementStart(57, "div", 34)(58, "span");
    \u0275\u0275text(59);
    \u0275\u0275pipe(60, "uppercase");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(61, "span");
    \u0275\u0275text(62);
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275property("ngStyle", \u0275\u0275pureFunction1(15, _c2, ctx_r1.getColor(ctx_r1.orderDetails == null ? null : ctx_r1.orderDetails.status)));
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r1.getStatusText(ctx_r1.orderDetails == null ? null : ctx_r1.orderDetails.status));
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.getMessage(ctx_r1.orderDetails == null ? null : ctx_r1.orderDetails.status));
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.viewMap ? 8 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional((ctx_r1.orderDetails == null ? null : ctx_r1.orderDetails.rider_details) ? 9 : -1);
    \u0275\u0275advance(7);
    \u0275\u0275repeater(ctx_r1.orderDetails == null ? null : ctx_r1.orderDetails.timeline);
    \u0275\u0275advance(9);
    \u0275\u0275textInterpolate(ctx_r1.orderDetails == null ? null : ctx_r1.orderDetails.address == null ? null : ctx_r1.orderDetails.address.address);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate1("Items (", ctx_r1.orderDetails.cart_items == null ? null : ctx_r1.orderDetails.cart_items.length, ")");
    \u0275\u0275advance(2);
    \u0275\u0275repeater(ctx_r1.orderDetails.cart_items);
    \u0275\u0275advance(12);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r1.orderDetails.bill_details == null ? null : ctx_r1.orderDetails.bill_details.itemTotal, "");
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r1.orderDetails.bill_details == null ? null : ctx_r1.orderDetails.bill_details.handlingCharge, "");
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r1.orderDetails.bill_details == null ? null : ctx_r1.orderDetails.bill_details.deliveryFee, "");
    \u0275\u0275advance();
    \u0275\u0275conditional((ctx_r1.orderDetails.bill_details == null ? null : ctx_r1.orderDetails.bill_details.totalSavings) !== "0.00" ? 55 : -1);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("To Pay (", \u0275\u0275pipeBind1(60, 13, ctx_r1.orderDetails.payment_details == null ? null : ctx_r1.orderDetails.payment_details.mode), ")");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r1.orderDetails.bill_details == null ? null : ctx_r1.orderDetails.bill_details.toPay, "");
  }
}
function GroceryOrderDetailsPage_Conditional_17_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0, " Cancelling... ");
  }
}
function GroceryOrderDetailsPage_Conditional_17_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0, " Cancel Order ");
  }
}
function GroceryOrderDetailsPage_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-button", 87);
    \u0275\u0275listener("click", function GroceryOrderDetailsPage_Conditional_17_Template_ion_button_click_0_listener() {
      \u0275\u0275restoreView(_r8);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cancelOrder());
    });
    \u0275\u0275template(1, GroceryOrderDetailsPage_Conditional_17_Conditional_1_Template, 1, 0)(2, GroceryOrderDetailsPage_Conditional_17_Conditional_2_Template, 1, 0);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275property("disabled", ctx_r1.isCancelling);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.isCancelling ? 1 : 2);
  }
}
var _GroceryOrderDetailsPage = class _GroceryOrderDetailsPage {
  // [
  //   { status: 'confirmed', title: 'Order Confirmed', icon: 'checkmark-circle', active: false },
  //   { status: 'preparing', title: 'Being Prepared', icon: 'cube-outline', active: false },
  //   { status: 'out_for_delivery', title: 'Out for Delivery', icon: 'bicycle-outline', active: false },
  //   { status: 'delivered', title: 'Delivered', icon: 'home-outline', active: false }
  // ];
  constructor(navCtrl, route, router, groceryService, authServcie, platform) {
    this.navCtrl = navCtrl;
    this.route = route;
    this.router = router;
    this.groceryService = groceryService;
    this.authServcie = authServcie;
    this.platform = platform;
    this.orderDetails = {};
    this.isLoading = false;
    this.isCancelling = false;
    this.viewMap = false;
    this.isError = false;
    this.timeline = [];
    addIcons({
      checkmarkCircle,
      timeOutline,
      bicycleOutline,
      homeOutline,
      receiptOutline,
      chevronBackOutline,
      chatbubbleEllipsesOutline,
      cubeOutline,
      checkmarkDoneCircleOutline,
      closeCircleOutline,
      star,
      callOutline,
      mapOutline,
      checkmarkOutline,
      closeOutline,
      arrowBack,
      arrowBackOutline
    });
  }
  ngOnInit() {
    return __async(this, null, function* () {
      var _a;
      this.orderId = this.route.snapshot.paramMap.get("id");
      this.currentRoute = (_a = history.state) == null ? void 0 : _a.from;
      this.token = yield this.authServcie.getToken();
      this.getOrderDetails(true);
    });
  }
  // ionViewDidEnter() {
  //   this.backButtonSubscription = this.platform.backButton.subscribeWithPriority(9999, () => {
  //     this.goBack();
  //   });
  // }
  // ionViewWillLeave() {
  //   this.backButtonSubscription?.unsubscribe();
  // }
  openHelp(orderId) {
    this.router.navigate(["/layout/example/support"], {
      state: { from: "order_details", orderId, service: "grocery" }
    });
  }
  updateTimeline() {
    const statusMap = { "confirmed": 0, "preparing": 1, "out_for_delivery": 2, "delivered": 3 };
    const currentStepIndex = statusMap[this.orderDetails.status] || 0;
    this.timeline.forEach((step, index) => {
      step.active = index <= currentStepIndex;
    });
  }
  getStatusColor(status) {
    switch (status) {
      case "confirmed":
        return "primary";
      case "preparing":
        return "warning";
      case "out_for_delivery":
        return "tertiary";
      case "delivered":
        return "success";
      case "cancelled":
        return "danger";
      default:
        return "medium";
    }
  }
  getStatusText(status) {
    if (!status)
      return "LOADING...";
    return status.replace(/_/g, " ").toUpperCase();
  }
  getInitials(name) {
    if (!name)
      return "";
    return name.trim().split(/\s+/).map((n) => n[0]).join("").toUpperCase().substring(0, 2);
  }
  getOrderDetails(reload) {
    if (reload) {
      this.isLoading = true;
    }
    this.isError = false;
    this.groceryService.getOrderById(this.token, this.orderId).subscribe((res) => {
      this.orderDetails = res.data;
      this.isLoading = false;
      this.updateTimeline();
    }, (error) => {
      this.isLoading = false;
      this.isError = true;
    });
  }
  doRefresh(event) {
    setTimeout(() => {
      this.getOrderDetails(true);
      if (this.viewMap) {
        this.initMap();
      }
      event.target.complete();
    }, 500);
  }
  goBack() {
    if (this.currentRoute == "history") {
      this.navCtrl.back();
    } else {
      this.navCtrl.navigateRoot("/layout/example/home");
    }
  }
  initMap() {
    var _a, _b;
    if (!this.mapElement || !((_a = this.orderDetails) == null ? void 0 : _a.address) || !((_b = this.orderDetails) == null ? void 0 : _b.rider_details))
      return;
    const deliveryLat = parseFloat(this.orderDetails.address.lat);
    const deliveryLng = parseFloat(this.orderDetails.address.lng);
    const riderLat = parseFloat(this.orderDetails.rider_details.current_lat);
    const riderLng = parseFloat(this.orderDetails.rider_details.current_lng);
    if (!deliveryLat || !deliveryLng || !riderLat || !riderLng)
      return;
    const deliveryLoc = { lat: deliveryLat, lng: deliveryLng };
    const riderLoc = { lat: riderLat, lng: riderLng };
    const styleId = "google-maps-hide-logo";
    if (!document.getElementById(styleId)) {
      const style = document.createElement("style");
      style.id = styleId;
      style.innerHTML = `
        .gmnoprint a, .gmnoprint span, .gm-style-cc { display: none !important; }
        .gmnoprint div { background: none !important; }
        a[href^="https://maps.google.com/maps"], a[href^="https://www.google.com/maps"] { display: none !important; }
      `;
      document.head.appendChild(style);
    }
    const mapStyles = [
      // Base background (Land) - Very soft purple tint
      { elementType: "geometry", stylers: [{ color: "#f9f6fb" }] },
      // Hide standard icons to keep it clean
      { elementType: "labels.icon", stylers: [{ visibility: "off" }] },
      // Text styling matching the theme subtly
      { elementType: "labels.text.fill", stylers: [{ color: "#8b7d91" }] },
      { elementType: "labels.text.stroke", stylers: [{ color: "#ffffff" }] },
      // Water elements - Soft theme purple
      { featureType: "water", elementType: "geometry", stylers: [{ color: "#ebdcf0" }] },
      // Parks & Nature
      { featureType: "poi.park", elementType: "geometry", stylers: [{ color: "#eaf3eb" }] },
      // Points of interest - Subtle grey-purple
      { featureType: "poi", elementType: "geometry", stylers: [{ color: "#f2ebf5" }] },
      // General roads - Crisp white
      { featureType: "road", elementType: "geometry", stylers: [{ color: "#ffffff" }] },
      // Highways - Slightly more prominent theme tint
      { featureType: "road.highway", elementType: "geometry", stylers: [{ color: "#e6d6eb" }] },
      { featureType: "road.highway", elementType: "labels.text.fill", stylers: [{ color: "#7c6885" }] }
    ];
    this.map = new google.maps.Map(this.mapElement.nativeElement, {
      zoom: 14,
      center: riderLoc,
      disableDefaultUI: true,
      keyboardShortcuts: false,
      styles: mapStyles,
      gestureHandling: "greedy"
    });
    this.directionsService = new google.maps.DirectionsService();
    this.directionsRenderer = new google.maps.DirectionsRenderer({
      map: this.map,
      suppressMarkers: true,
      polylineOptions: {
        strokeColor: "#a000e2",
        strokeWeight: 4,
        strokeOpacity: 0.8
      }
    });
    this.calculateAndDisplayRoute(riderLoc, deliveryLoc);
  }
  calculateAndDisplayRoute(origin, destination) {
    this.directionsService.route({ origin, destination, travelMode: google.maps.TravelMode.DRIVING }, (response, status) => {
      if (status === "OK") {
        this.directionsRenderer.setDirections(response);
        const route = response.routes[0].legs[0];
        this.addCustomMarkers(route.start_location, route.end_location);
      } else {
        console.error("Directions request failed due to " + status);
        this.addCustomMarkers(origin, destination);
        const bounds = new google.maps.LatLngBounds();
        bounds.extend(origin);
        bounds.extend(destination);
        this.map.fitBounds(bounds);
      }
    });
  }
  addCustomMarkers(origin, destination) {
    const riderIcon = {
      url: "data:image/svg+xml;charset=UTF-8," + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#a000e2" stroke="#fff" stroke-width="2"/><circle cx="12" cy="12" r="4" fill="#fff"/></svg>'),
      scaledSize: new google.maps.Size(32, 32),
      anchor: new google.maps.Point(16, 16)
    };
    const homeIcon = {
      url: "data:image/svg+xml;charset=UTF-8," + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24"><path d="M12 2L1 11h3v11h16V11h3L12 2zm0 2.8l7 6.4V20H5v-8.8l7-6.4z" fill="#000" stroke="#fff" stroke-width="1"/><path d="M12 5.8L6 11.3V19h12v-7.7L12 5.8z" fill="#a000e2"/></svg>'),
      scaledSize: new google.maps.Size(36, 36),
      anchor: new google.maps.Point(18, 18)
    };
    new google.maps.Marker({
      position: origin,
      map: this.map,
      icon: riderIcon
    });
    new google.maps.Marker({
      position: destination,
      map: this.map,
      icon: homeIcon
    });
  }
  cancelOrder() {
    var _a;
    let params = {
      "orderId": (_a = this.orderDetails) == null ? void 0 : _a.id
    };
    this.isCancelling = true;
    this.groceryService.cancelOrder(params).subscribe((res) => {
      this.isCancelling = false;
      this.viewMap = false;
      this.getOrderDetails(true);
    }, (error) => {
      this.isCancelling = false;
    });
  }
  getColor(status) {
    switch (status == null ? void 0 : status.toLowerCase()) {
      case "pending":
        return "linear-gradient(135deg, #4CAF50, #66BB6A)";
      // Green
      case "confirmed":
        return "linear-gradient(135deg, #2196F3, #42A5F5)";
      // Blue
      case "rider assigned":
        return "linear-gradient(135deg, #FF9800, #FFB74D)";
      // Orange
      case "packed":
        return "linear-gradient(135deg, #9C27B0, #BA68C8)";
      // Purple
      case "cancelled":
        return "linear-gradient(135deg, #F44336, #EF5350)";
      // Red
      case "on the way":
        return "linear-gradient(135deg, #3F51B5, #5C6BC0)";
      // Indigo
      case "reached":
        return "linear-gradient(135deg, #607D8B, #78909C)";
      // Blue Grey
      case "delivered":
        return "linear-gradient(135deg, #009688, #26A69A)";
      // Teal
      default:
        return "#a000e2";
    }
  }
  getMessage(status) {
    switch (status == null ? void 0 : status.toLowerCase()) {
      case "pending":
        return "\u23F3 Order received! We\u2019re on it.";
      case "confirmed":
        return "\u2705 Order confirmed! Preparing it now.";
      case "rider assigned":
        return "\u{1F6F5} Rider assigned! Pickup happening soon.";
      case "packed":
        return "\u{1F4E6} Packed & ready! Dispatching shortly.";
      case "cancelled":
        return "Order is cancelled.";
      case "on the way":
        return "\u{1F680} On the way! Almost there.";
      case "reached":
        return "\u{1F4CD} Rider has arrived! Please be ready.";
      case "delivered":
        return "\u{1F389} Delivered! Enjoy your order.";
      default:
        return "\u26A1 We\u2019re preparing your order!";
    }
  }
  openMap() {
    this.viewMap = !this.viewMap;
    if (this.viewMap) {
      setTimeout(() => {
        this.initMap();
      }, 50);
    }
  }
};
_GroceryOrderDetailsPage.\u0275fac = function GroceryOrderDetailsPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _GroceryOrderDetailsPage)(\u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(ActivatedRoute), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(GroceryService), \u0275\u0275directiveInject(AuthService), \u0275\u0275directiveInject(Platform));
};
_GroceryOrderDetailsPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _GroceryOrderDetailsPage, selectors: [["app-grocery-order-details"]], viewQuery: function GroceryOrderDetailsPage_Query(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275viewQuery(_c0, 5);
  }
  if (rf & 2) {
    let _t;
    \u0275\u0275queryRefresh(_t = \u0275\u0275loadQuery()) && (ctx.mapElement = _t.first);
  }
}, decls: 19, vars: 3, consts: [["mapElement", ""], [1, "ion-no-border", "bg-white", "pt-2"], ["slot", "start"], [3, "click"], ["name", "arrow-back-outline", "color", "dark"], [1, "fw-bold", "text-dark"], ["slot", "end"], ["color", "primary", 3, "click"], ["name", "chatbubble-ellipses-outline"], [1, "bg-light"], ["slot", "fixed", 3, "ionRefresh"], ["title", "Failed to Load Categories", "subtitle", "Please check your internet connection and try again.", "buttonText", "Retry"], ["color", "danger", 1, "book-btn", "w-100", "px-3", 3, "disabled"], [1, "mb-5"], [1, "status-card-wrapper"], [1, "status-card"], [1, "status-header"], [1, "text-content", 2, "width", "100%"], ["animated", "", 2, "width", "60%", "height", "24px", "margin-bottom", "8px", "border-radius", "4px"], ["animated", "", 2, "width", "40%", "height", "16px", "border-radius", "4px"], [1, "section-card"], [1, "section-header"], ["animated", "", 2, "width", "24px", "height", "24px", "margin-right", "10px", "border-radius", "4px"], ["animated", "", 2, "width", "150px", "height", "20px", "border-radius", "4px"], [1, "address-box"], ["animated", "", 2, "width", "100%", "height", "16px", "margin-bottom", "6px", "border-radius", "4px"], ["animated", "", 2, "width", "80%", "height", "16px", "border-radius", "4px"], ["animated", "", 2, "width", "100px", "height", "20px", "border-radius", "4px"], [1, "items-list"], [1, "item-row"], ["animated", "", 2, "width", "120px", "height", "20px", "border-radius", "4px"], [1, "bill-details"], [1, "bill-row"], [1, "divider"], [1, "bill-row", "total"], ["animated", "", 2, "width", "50%", "height", "20px", "border-radius", "4px"], ["animated", "", 2, "width", "30%", "height", "20px", "border-radius", "4px"], [1, "item-img"], ["animated", "", 2, "width", "100%", "height", "100%", "border-radius", "8px"], [1, "item-info", 2, "flex", "1"], ["animated", "", 2, "width", "70%", "height", "16px", "margin-bottom", "6px", "border-radius", "4px"], ["animated", "", 2, "width", "40%", "height", "12px", "border-radius", "4px"], [1, "item-price", 2, "width", "60px"], ["animated", "", 2, "width", "100%", "height", "16px", "border-radius", "4px"], ["animated", "", 2, "width", "20%", "height", "16px", "border-radius", "4px"], ["title", "Failed to Load Categories", "subtitle", "Please check your internet connection and try again.", "buttonText", "Retry", 3, "retry"], [1, "status-card-wrapper", 2, "position", "relative", "z-index", "1"], [1, "status-card", 3, "ngStyle"], [1, "status-header", "m-0"], [1, "text-content"], [1, "status-card-wrapper", "pt-0"], ["name", "time-outline"], [1, "timeline-container", "mt-2", "px-2"], [1, "d-flex"], ["name", "home-outline"], [1, "address-text"], ["name", "cube-outline"], ["name", "receipt-outline"], [1, "bill-row", "savings"], [1, "status-card", "p-0", 2, "position", "relative", "background-color", "white", "border-radius", "12px", "overflow", "hidden", "box-shadow", "0 4px 10px rgba(0,0,0,0.05)", "margin-top", "-41px", "z-index", "0"], ["id", "map", 2, "width", "100%", "height", "255px", "display", "block"], ["name", "bicycle-outline"], [1, "d-flex", "align-items-center", "mt-2", "p-2", 2, "background", "#f9f9f9", "border-radius", "12px", "border", "1px dashed #ddd"], [2, "width", "48px", "height", "48px", "border-radius", "50%", "background", "#e0e0e0", "overflow", "hidden", "margin-right", "12px", "display", "flex", "align-items", "center", "justify-content", "center", "font-weight", "bold", "color", "#555", "font-size", "18px"], ["alt", "Rider", 2, "width", "100%", "height", "100%", "object-fit", "cover", 3, "src"], [2, "flex", "1"], [2, "margin", "0 0 2px", "font-size", "14px", "font-weight", "600", "color", "var(--text-dark)"], [2, "font-size", "12px", "color", "var(--text-grey)", "display", "flex", "align-items", "center", "gap", "4px"], ["name", "star", 2, "color", "#f5b041"], ["fill", "clear", "color", "primary", 2, "--padding-start", "8px", "--padding-end", "8px", "height", "36px", "margin", "0", 3, "click", "disabled"], ["name", "map-outline", "slot", "icon-only", 2, "font-size", "22px"], ["fill", "clear", "color", "primary", 2, "--padding-start", "8px", "--padding-end", "8px", "height", "36px", "margin", "0", 3, "href", "disabled"], ["name", "call-outline", "slot", "icon-only", 2, "font-size", "22px"], [1, "d-flex", "flex-column", "align-items-center", "me-3", "mt-1"], [1, "rounded-circle", "d-flex", "align-items-center", "justify-content-center", 2, "width", "15px", "height", "15px", "background-color", "#d60000", "color", "white"], [1, "rounded-circle", "d-flex", "align-items-center", "justify-content-center", 2, "width", "15px", "height", "15px", "background-color", "var(--ion-color-success, #2dd36f)", "color", "white"], [2, "width", "2px", "height", "30px", "background-color", "var(--ion-color-success, #2dd36f)", "opacity", "0.5", "margin", "4px 0"], [1, "pb-3", 2, "margin-top", "2px"], [2, "font-weight", "600", "font-size", "14px", "color", "var(--ion-color-dark)"], [2, "font-size", "12px", "color", "var(--ion-color-medium)"], ["name", "close-outline", 2, "font-size", "16px"], ["name", "checkmark-outline", 2, "font-size", "16px"], [3, "src", "alt"], [1, "item-info"], [1, "item-price"], [1, "qty"], [1, "price"], ["color", "danger", 1, "book-btn", "w-100", "px-3", 3, "click", "disabled"]], template: function GroceryOrderDetailsPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 1)(1, "ion-toolbar")(2, "ion-buttons", 2)(3, "ion-button", 3);
    \u0275\u0275listener("click", function GroceryOrderDetailsPage_Template_ion_button_click_3_listener() {
      return ctx.goBack();
    });
    \u0275\u0275element(4, "ion-icon", 4);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "ion-title", 5);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "ion-buttons", 6)(8, "ion-button", 7);
    \u0275\u0275listener("click", function GroceryOrderDetailsPage_Template_ion_button_click_8_listener() {
      return ctx.openHelp(ctx.orderDetails == null ? null : ctx.orderDetails.id);
    });
    \u0275\u0275element(9, "ion-icon", 8);
    \u0275\u0275text(10, " Help ");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(11, "ion-content", 9)(12, "ion-refresher", 10);
    \u0275\u0275listener("ionRefresh", function GroceryOrderDetailsPage_Template_ion_refresher_ionRefresh_12_listener($event) {
      return ctx.doRefresh($event);
    });
    \u0275\u0275element(13, "ion-refresher-content");
    \u0275\u0275elementEnd();
    \u0275\u0275template(14, GroceryOrderDetailsPage_Conditional_14_Template, 31, 2)(15, GroceryOrderDetailsPage_Conditional_15_Template, 1, 0, "app-error", 11)(16, GroceryOrderDetailsPage_Conditional_16_Template, 63, 17)(17, GroceryOrderDetailsPage_Conditional_17_Template, 3, 2, "ion-button", 12);
    \u0275\u0275element(18, "div", 13);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1("Track Order #", ctx.orderDetails == null ? null : ctx.orderDetails.id, "");
    \u0275\u0275advance(8);
    \u0275\u0275conditional(ctx.isLoading ? 14 : ctx.isError ? 15 : 16);
    \u0275\u0275advance(3);
    \u0275\u0275conditional((ctx.orderDetails == null ? null : ctx.orderDetails.status == null ? null : ctx.orderDetails.status.toLowerCase()) == "confirmed" ? 17 : -1);
  }
}, dependencies: [IonicModule, IonButton, IonButtons, IonContent, IonHeader, IonIcon, IonRefresher, IonRefresherContent, IonSkeletonText, IonTitle, IonToolbar, CommonModule, NgStyle, UpperCasePipe, TitleCasePipe, DatePipe, FormsModule, ErrorComponent], styles: ["\n\n[_nghost-%COMP%] {\n  --bg-color: #f4f6f8;\n  --card-bg: #ffffff;\n  --primary: #24963f;\n  --text-dark: #1f1f1f;\n  --text-grey: #666;\n  --radius: 16px;\n}\n.bg-light[_ngcontent-%COMP%] {\n  --background: var(--bg-color);\n}\n.status-card-wrapper[_ngcontent-%COMP%] {\n  padding: 16px;\n}\n.status-card[_ngcontent-%COMP%] {\n  background: var(--card-bg);\n  border-radius: var(--radius);\n  padding: 20px;\n  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.05);\n  text-align: center;\n  color: white;\n}\n.status-card[_ngcontent-%COMP%]   .status-header[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  margin-bottom: 24px;\n}\n.status-card[_ngcontent-%COMP%]   .status-header[_ngcontent-%COMP%]   .icon-box[_ngcontent-%COMP%] {\n  width: 60px;\n  height: 60px;\n  border-radius: 50%;\n  background: #e8f5e9;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin-bottom: 12px;\n  font-size: 32px;\n}\n.status-card[_ngcontent-%COMP%]   .status-header[_ngcontent-%COMP%]   .icon-box.primary[_ngcontent-%COMP%] {\n  color: var(--primary);\n  background: #e8f5e9;\n}\n.status-card[_ngcontent-%COMP%]   .status-header[_ngcontent-%COMP%]   .icon-box.warning[_ngcontent-%COMP%] {\n  color: #f39c12;\n  background: #fff3cd;\n}\n.status-card[_ngcontent-%COMP%]   .status-header[_ngcontent-%COMP%]   .icon-box.tertiary[_ngcontent-%COMP%] {\n  color: #3498db;\n  background: #d6eaf8;\n}\n.status-card[_ngcontent-%COMP%]   .status-header[_ngcontent-%COMP%]   .icon-box.success[_ngcontent-%COMP%] {\n  color: #27ae60;\n  background: #d5f5e3;\n}\n.status-card[_ngcontent-%COMP%]   .status-header[_ngcontent-%COMP%]   .icon-box.danger[_ngcontent-%COMP%] {\n  color: #e74c3c;\n  background: #fadbd8;\n}\n.status-card[_ngcontent-%COMP%]   .status-header[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 20px;\n  font-weight: 800;\n  color: white;\n}\n.status-card[_ngcontent-%COMP%]   .status-header[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 4px 0 0;\n  color: rgb(243, 238, 238);\n  font-size: 14px;\n}\n.status-card[_ngcontent-%COMP%]   .timeline-container[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  position: relative;\n}\n.status-card[_ngcontent-%COMP%]   .timeline-container[_ngcontent-%COMP%]   .step[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  position: relative;\n  z-index: 2;\n  width: 60px;\n}\n.status-card[_ngcontent-%COMP%]   .timeline-container[_ngcontent-%COMP%]   .step[_ngcontent-%COMP%]   .step-icon[_ngcontent-%COMP%] {\n  width: 32px;\n  height: 32px;\n  background: #eee;\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  color: #999;\n  font-size: 16px;\n  transition: all 0.3s ease;\n}\n.status-card[_ngcontent-%COMP%]   .timeline-container[_ngcontent-%COMP%]   .step[_ngcontent-%COMP%]   .step-label[_ngcontent-%COMP%] {\n  margin-top: 6px;\n  font-size: 9px;\n  font-weight: 600;\n  color: #999;\n  text-align: center;\n  line-height: 1.2;\n}\n.status-card[_ngcontent-%COMP%]   .timeline-container[_ngcontent-%COMP%]   .step.active[_ngcontent-%COMP%]   .step-icon[_ngcontent-%COMP%] {\n  background: var(--primary);\n  color: white;\n  box-shadow: 0 4px 10px rgba(36, 150, 63, 0.3);\n}\n.status-card[_ngcontent-%COMP%]   .timeline-container[_ngcontent-%COMP%]   .step.active[_ngcontent-%COMP%]   .step-label[_ngcontent-%COMP%] {\n  color: var(--primary);\n}\n.status-card[_ngcontent-%COMP%]   .timeline-container[_ngcontent-%COMP%]   .connector[_ngcontent-%COMP%] {\n  flex: 1;\n  height: 3px;\n  background: #eee;\n  margin: 0 -15px 18px;\n  position: relative;\n  z-index: 1;\n}\n.status-card[_ngcontent-%COMP%]   .timeline-container[_ngcontent-%COMP%]   .connector.active[_ngcontent-%COMP%] {\n  background: var(--primary);\n}\n.section-card[_ngcontent-%COMP%] {\n  background: var(--card-bg);\n  margin: 0 16px 16px;\n  padding: 16px;\n  border-radius: var(--radius);\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.03);\n}\n.section-card[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  margin-bottom: 12px;\n  font-size: 14px;\n  font-weight: 700;\n  color: var(--text-dark);\n  text-transform: uppercase;\n  letter-spacing: 0.5px;\n}\n.section-card[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n  color: var(--primary);\n}\n.address-box[_ngcontent-%COMP%] {\n  background: #f9f9f9;\n  padding: 12px;\n  border-radius: 12px;\n  border: 1px dashed #ddd;\n}\n.address-box[_ngcontent-%COMP%]   .address-text[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 13px;\n  color: #555;\n  line-height: 1.5;\n}\n.items-list[_ngcontent-%COMP%]   .item-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  padding: 12px 0;\n  border-bottom: 1px solid #f0f0f0;\n}\n.items-list[_ngcontent-%COMP%]   .item-row[_ngcontent-%COMP%]:last-child {\n  border-bottom: none;\n}\n.items-list[_ngcontent-%COMP%]   .item-row[_ngcontent-%COMP%]   .item-img[_ngcontent-%COMP%] {\n  width: 48px;\n  height: 48px;\n  background: #f8f8f8;\n  border-radius: 8px;\n  margin-right: 12px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.items-list[_ngcontent-%COMP%]   .item-row[_ngcontent-%COMP%]   .item-img[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 80%;\n  height: 80%;\n  object-fit: contain;\n}\n.items-list[_ngcontent-%COMP%]   .item-row[_ngcontent-%COMP%]   .item-info[_ngcontent-%COMP%] {\n  flex: 1;\n}\n.items-list[_ngcontent-%COMP%]   .item-row[_ngcontent-%COMP%]   .item-info[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  margin: 0 0 2px;\n  font-size: 14px;\n  font-weight: 600;\n  color: var(--text-dark);\n}\n.items-list[_ngcontent-%COMP%]   .item-row[_ngcontent-%COMP%]   .item-info[_ngcontent-%COMP%]   small[_ngcontent-%COMP%] {\n  color: var(--text-grey);\n  font-size: 12px;\n}\n.items-list[_ngcontent-%COMP%]   .item-row[_ngcontent-%COMP%]   .item-price[_ngcontent-%COMP%] {\n  text-align: right;\n}\n.items-list[_ngcontent-%COMP%]   .item-row[_ngcontent-%COMP%]   .item-price[_ngcontent-%COMP%]   .qty[_ngcontent-%COMP%] {\n  display: block;\n  font-size: 11px;\n  color: #888;\n  margin-bottom: 2px;\n}\n.items-list[_ngcontent-%COMP%]   .item-row[_ngcontent-%COMP%]   .item-price[_ngcontent-%COMP%]   .price[_ngcontent-%COMP%] {\n  display: block;\n  font-size: 14px;\n  font-weight: 700;\n  color: var(--text-dark);\n}\n.bill-details[_ngcontent-%COMP%]   .bill-row[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  margin-bottom: 10px;\n  font-size: 13px;\n  color: #555;\n}\n.bill-details[_ngcontent-%COMP%]   .bill-row.savings[_ngcontent-%COMP%] {\n  color: var(--primary);\n  font-weight: 600;\n  background: #e8f5e9;\n  padding: 6px 10px;\n  border-radius: 6px;\n  margin-top: 4px;\n}\n.bill-details[_ngcontent-%COMP%]   .bill-row.total[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 800;\n  color: var(--text-dark);\n  margin-bottom: 0;\n}\n.bill-details[_ngcontent-%COMP%]   .divider[_ngcontent-%COMP%] {\n  height: 1px;\n  background: #eee;\n  margin: 12px 0;\n  border-top: 1px dashed #ccc;\n}\n/*# sourceMappingURL=grocery-order-details.page.css.map */"] });
var GroceryOrderDetailsPage = _GroceryOrderDetailsPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(GroceryOrderDetailsPage, { className: "GroceryOrderDetailsPage", filePath: "src/app/pages/grocery-order-details/grocery-order-details.page.ts", lineNumber: 34 });
})();
export {
  GroceryOrderDetailsPage
};
//# sourceMappingURL=grocery-order-details.page-EUK24X6D.js.map
