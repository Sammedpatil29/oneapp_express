import {
  PropertyFooterComponent
} from "./chunk-UEAGU4IM.js";
import {
  DUMMY_PROPERTIES,
  PropertyService
} from "./chunk-4TVXGIYM.js";
import {
  Share
} from "./chunk-XS4AIG4E.js";
import {
  addIcons,
  alertCircleOutline,
  arrowBackOutline,
  bedOutline,
  businessOutline,
  calendarOutline,
  callOutline,
  cameraOutline,
  carOutline,
  chatbubbleEllipsesOutline,
  checkmarkCircle,
  chevronBackOutline,
  chevronDownOutline,
  chevronForwardOutline,
  chevronUpOutline,
  closeOutline,
  compassOutline,
  documentTextOutline,
  expandOutline,
  heart,
  heartOutline,
  leafOutline,
  location,
  lockClosedOutline,
  logoWhatsapp,
  navigateOutline,
  openOutline,
  pause,
  play,
  playCircle,
  shareSocialOutline,
  shieldCheckmarkOutline,
  shieldOutline,
  sparkles,
  timeOutline,
  videocamOutline,
  waterOutline
} from "./chunk-V2INQVNG.js";
import {
  ToastController
} from "./chunk-OE5MTPUR.js";
import "./chunk-YJYUHAOC.js";
import "./chunk-XR3JUECC.js";
import {
  IonContent,
  IonIcon,
  IonModal
} from "./chunk-CJE2NDTY.js";
import {
  ActivatedRoute,
  CommonModule,
  DecimalPipe,
  DomSanitizer,
  FormsModule,
  NavController,
  Router,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind1,
  ɵɵproperty,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIdentity,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeResourceUrl,
  ɵɵsanitizeUrl,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2
} from "./chunk-Z7XNNJSA.js";
import "./chunk-FH4NU4VH.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/pages/property-details/property-details.page.ts
var _forTrack0 = ($index, $item) => $item.title;
var _forTrack1 = ($index, $item) => $item.name;
function PropertyDetailsPage_Conditional_1_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 82);
    \u0275\u0275listener("click", function PropertyDetailsPage_Conditional_1_Conditional_6_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.openVideoModal());
    });
    \u0275\u0275element(1, "ion-icon", 83);
    \u0275\u0275elementEnd();
  }
}
function PropertyDetailsPage_Conditional_1_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 84);
    \u0275\u0275listener("click", function PropertyDetailsPage_Conditional_1_Conditional_14_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.prevImage());
    });
    \u0275\u0275element(1, "ion-icon", 85);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "button", 86);
    \u0275\u0275listener("click", function PropertyDetailsPage_Conditional_1_Conditional_14_Template_button_click_2_listener() {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.nextImage());
    });
    \u0275\u0275element(3, "ion-icon", 87);
    \u0275\u0275elementEnd();
  }
}
function PropertyDetailsPage_Conditional_1_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 88);
    \u0275\u0275listener("click", function PropertyDetailsPage_Conditional_1_Conditional_16_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r5);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.openVideoModal());
    });
    \u0275\u0275element(1, "ion-icon", 89);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3, "Video Tour");
    \u0275\u0275elementEnd()();
  }
}
function PropertyDetailsPage_Conditional_1_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 22);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r1.property.category === "rent_house" ? "Rented Out" : "Sold Out", " ");
  }
}
function PropertyDetailsPage_Conditional_1_Conditional_26_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 22);
    \u0275\u0275text(1, " Closed ");
    \u0275\u0275elementEnd();
  }
}
function PropertyDetailsPage_Conditional_1_Conditional_27_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 23);
    \u0275\u0275element(1, "ion-icon", 90);
    \u0275\u0275text(2, " Pintu Verified ");
    \u0275\u0275elementEnd();
  }
}
function PropertyDetailsPage_Conditional_1_Conditional_35_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 29);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.property.priceUnit);
  }
}
function PropertyDetailsPage_Conditional_1_Conditional_36_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 30);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.property.pricePerSqFt);
  }
}
function PropertyDetailsPage_Conditional_1_Conditional_37_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 31)(1, "span", 91);
    \u0275\u0275text(2, "Estimate");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 92);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r1.property.emiEstimate);
  }
}
function PropertyDetailsPage_Conditional_1_Conditional_38_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 93)(1, "span", 94);
    \u0275\u0275text(2, "Security Deposit:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 95);
    \u0275\u0275text(4);
    \u0275\u0275pipe(5, "number");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("\u20B9", \u0275\u0275pipeBind1(5, 1, ctx_r1.property.securityDeposit), "");
  }
}
function PropertyDetailsPage_Conditional_1_Conditional_38_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 93)(1, "span", 94);
    \u0275\u0275text(2, "Maintenance:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 95);
    \u0275\u0275text(4);
    \u0275\u0275pipe(5, "number");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("\u20B9", \u0275\u0275pipeBind1(5, 1, ctx_r1.property.maintenancePerMonth), "/mo");
  }
}
function PropertyDetailsPage_Conditional_1_Conditional_38_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 32);
    \u0275\u0275template(1, PropertyDetailsPage_Conditional_1_Conditional_38_Conditional_1_Template, 6, 3, "div", 93)(2, PropertyDetailsPage_Conditional_1_Conditional_38_Conditional_2_Template, 6, 3, "div", 93);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.property.securityDeposit ? 1 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.property.maintenancePerMonth ? 2 : -1);
  }
}
function PropertyDetailsPage_Conditional_1_Conditional_59_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 46)(1, "div", 47);
    \u0275\u0275element(2, "ion-icon", 96);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 49)(4, "span", 50);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span", 51);
    \u0275\u0275text(7, "Total Land Area");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate1("", ctx_r1.property.totalAcres, " Acres");
  }
}
function PropertyDetailsPage_Conditional_1_Conditional_60_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 46)(1, "div", 97);
    \u0275\u0275element(2, "ion-icon", 98);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 49)(4, "span", 50);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span", 51);
    \u0275\u0275text(7, "Configuration");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate1("", ctx_r1.property.bedrooms, " Bedrooms");
  }
}
function PropertyDetailsPage_Conditional_1_Conditional_61_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 46)(1, "div", 99);
    \u0275\u0275element(2, "ion-icon", 100);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 49)(4, "span", 50);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span", 51);
    \u0275\u0275text(7, "Baths");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate1("", ctx_r1.property.bathrooms, " Bathrooms");
  }
}
function PropertyDetailsPage_Conditional_1_Conditional_79_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 54)(1, "div", 101);
    \u0275\u0275element(2, "ion-icon", 102);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 49)(4, "span", 50);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span", 51);
    \u0275\u0275text(7, "Furnishing Status");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r1.property.furnishing);
  }
}
function PropertyDetailsPage_Conditional_1_Conditional_80_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 54)(1, "div", 103);
    \u0275\u0275element(2, "ion-icon", 104);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 49)(4, "span", 50);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span", 51);
    \u0275\u0275text(7, "Parking Space");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r1.property.parking);
  }
}
function PropertyDetailsPage_Conditional_1_Conditional_81_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 46)(1, "div", 105);
    \u0275\u0275element(2, "ion-icon", 106);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 49)(4, "span", 50);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span", 51);
    \u0275\u0275text(7, "Floor Level");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r1.property.floor);
  }
}
function PropertyDetailsPage_Conditional_1_For_103_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 109);
    \u0275\u0275element(1, "ion-icon", 90);
    \u0275\u0275elementEnd();
  }
}
function PropertyDetailsPage_Conditional_1_For_103_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 110);
    \u0275\u0275element(1, "ion-icon", 118);
    \u0275\u0275elementEnd();
  }
}
function PropertyDetailsPage_Conditional_1_For_103_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 114);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const check_r6 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(check_r6.statusLabel);
  }
}
function PropertyDetailsPage_Conditional_1_For_103_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 115);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const check_r6 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(check_r6.statusLabel);
  }
}
function PropertyDetailsPage_Conditional_1_For_103_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 107)(1, "div", 108);
    \u0275\u0275template(2, PropertyDetailsPage_Conditional_1_For_103_Conditional_2_Template, 2, 0, "div", 109)(3, PropertyDetailsPage_Conditional_1_For_103_Conditional_3_Template, 2, 0, "div", 110);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "div", 111)(5, "div", 112)(6, "span", 113);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275template(8, PropertyDetailsPage_Conditional_1_For_103_Conditional_8_Template, 2, 1, "span", 114)(9, PropertyDetailsPage_Conditional_1_For_103_Conditional_9_Template, 2, 1, "span", 115);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "span", 116);
    \u0275\u0275text(11);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "p", 117);
    \u0275\u0275text(13);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const check_r6 = ctx.$implicit;
    \u0275\u0275classProp("is-clear", check_r6.status === "clear")("is-pending", check_r6.status === "pending");
    \u0275\u0275advance(2);
    \u0275\u0275conditional(check_r6.status === "clear" ? 2 : 3);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(check_r6.title);
    \u0275\u0275advance();
    \u0275\u0275conditional(check_r6.status === "clear" ? 8 : 9);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(check_r6.category);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(check_r6.details);
  }
}
function PropertyDetailsPage_Conditional_1_Conditional_104_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 119);
    \u0275\u0275listener("click", function PropertyDetailsPage_Conditional_1_Conditional_104_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.toggleDocsExpanded());
    });
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275element(3, "ion-icon", 11);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.isDocsExpanded ? "Show Less" : "View All " + ctx_r1.propertyLegalChecks.length + " Documents");
    \u0275\u0275advance();
    \u0275\u0275property("name", ctx_r1.isDocsExpanded ? "chevron-up-outline" : "chevron-down-outline");
  }
}
function PropertyDetailsPage_Conditional_1_Conditional_110_For_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 121)(1, "div", 122);
    \u0275\u0275element(2, "ion-icon", 90);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 123);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const item_r8 = ctx.$implicit;
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(item_r8);
  }
}
function PropertyDetailsPage_Conditional_1_Conditional_110_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 68)(1, "h3", 43);
    \u0275\u0275text(2, "Features & Amenities");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 120);
    \u0275\u0275repeaterCreate(4, PropertyDetailsPage_Conditional_1_Conditional_110_For_5_Template, 5, 1, "div", 121, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(4);
    \u0275\u0275repeater(ctx_r1.property.amenities);
  }
}
function PropertyDetailsPage_Conditional_1_Conditional_111_For_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 125)(1, "div", 126);
    \u0275\u0275element(2, "ion-icon", 127);
    \u0275\u0275elementStart(3, "span", 128);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "span", 129);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const lm_r9 = ctx.$implicit;
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(lm_r9.name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(lm_r9.distance);
  }
}
function PropertyDetailsPage_Conditional_1_Conditional_111_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 69)(1, "h3", 43);
    \u0275\u0275text(2, "Nearby & Connectivity");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 124);
    \u0275\u0275repeaterCreate(4, PropertyDetailsPage_Conditional_1_Conditional_111_For_5_Template, 7, 2, "div", 125, _forTrack1);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(4);
    \u0275\u0275repeater(ctx_r1.property.nearbyLandmarks);
  }
}
function PropertyDetailsPage_Conditional_1_Conditional_119_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 75);
    \u0275\u0275element(1, "ion-icon", 90);
    \u0275\u0275text(2, " Verified ");
    \u0275\u0275elementEnd();
  }
}
function PropertyDetailsPage_Conditional_1_Conditional_125_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 79);
    \u0275\u0275element(1, "ion-icon", 130);
    \u0275\u0275elementStart(2, "div", 131)(3, "span", 132);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "span", 133);
    \u0275\u0275text(6, "Direct contact and callback requests are currently disabled");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("This Property is ", ctx_r1.property.category === "rent_house" ? "Rented Out" : "Sold Out", "");
  }
}
function PropertyDetailsPage_Conditional_1_Conditional_126_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 80)(1, "button", 134);
    \u0275\u0275listener("click", function PropertyDetailsPage_Conditional_1_Conditional_126_Template_button_click_1_listener() {
      \u0275\u0275restoreView(_r10);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.bookCallback());
    });
    \u0275\u0275element(2, "ion-icon", 106);
    \u0275\u0275elementStart(3, "span");
    \u0275\u0275text(4, "Callback");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "button", 135);
    \u0275\u0275listener("click", function PropertyDetailsPage_Conditional_1_Conditional_126_Template_button_click_5_listener() {
      \u0275\u0275restoreView(_r10);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.callSeller());
    });
    \u0275\u0275element(6, "ion-icon", 136);
    \u0275\u0275elementStart(7, "span");
    \u0275\u0275text(8, "Call");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "button", 137);
    \u0275\u0275listener("click", function PropertyDetailsPage_Conditional_1_Conditional_126_Template_button_click_9_listener() {
      \u0275\u0275restoreView(_r10);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.openWhatsApp());
    });
    \u0275\u0275element(10, "ion-icon", 138);
    \u0275\u0275elementStart(11, "span");
    \u0275\u0275text(12, "WhatsApp");
    \u0275\u0275elementEnd()()();
  }
}
function PropertyDetailsPage_Conditional_1_ng_template_128_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 148);
    \u0275\u0275element(1, "ion-icon", 11);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275property("name", ctx_r1.isPlaying ? "play" : "pause");
  }
}
function PropertyDetailsPage_Conditional_1_ng_template_128_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "iframe", 149);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275property("src", ctx_r1.embedVideoUrl, \u0275\u0275sanitizeResourceUrl);
  }
}
function PropertyDetailsPage_Conditional_1_ng_template_128_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 150)(1, "p");
    \u0275\u0275text(2, "Video link is unavailable or could not be loaded.");
    \u0275\u0275elementEnd()();
  }
}
function PropertyDetailsPage_Conditional_1_ng_template_128_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 139)(1, "button", 140);
    \u0275\u0275listener("click", function PropertyDetailsPage_Conditional_1_ng_template_128_Template_button_click_1_listener() {
      \u0275\u0275restoreView(_r11);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.closeVideoModal());
    });
    \u0275\u0275element(2, "ion-icon", 141);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "button", 142);
    \u0275\u0275listener("click", function PropertyDetailsPage_Conditional_1_ng_template_128_Template_button_click_3_listener() {
      \u0275\u0275restoreView(_r11);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.toggleVideoAspect());
    });
    \u0275\u0275elementStart(4, "span", 143);
    \u0275\u0275text(5, "RES");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span", 144);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "div", 145);
    \u0275\u0275element(9, "div", 146);
    \u0275\u0275elementStart(10, "div", 147);
    \u0275\u0275listener("click", function PropertyDetailsPage_Conditional_1_ng_template_128_Template_div_click_10_listener() {
      \u0275\u0275restoreView(_r11);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.togglePlayPause());
    });
    \u0275\u0275template(11, PropertyDetailsPage_Conditional_1_ng_template_128_Conditional_11_Template, 2, 1, "div", 148);
    \u0275\u0275elementEnd();
    \u0275\u0275template(12, PropertyDetailsPage_Conditional_1_ng_template_128_Conditional_12_Template, 1, 1, "iframe", 149)(13, PropertyDetailsPage_Conditional_1_ng_template_128_Conditional_13_Template, 3, 0, "div", 150);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275classProp("is-reel", ctx_r1.isVideoReel);
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate(ctx_r1.isVideoReel ? "9:16" : "16:9");
    \u0275\u0275advance();
    \u0275\u0275classProp("is-reel", ctx_r1.isVideoReel);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx_r1.showPlayPauseIndicator ? 11 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.embedVideoUrl ? 12 : 13);
  }
}
function PropertyDetailsPage_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "main", 1)(1, "section", 2)(2, "header", 3)(3, "button", 4);
    \u0275\u0275listener("click", function PropertyDetailsPage_Conditional_1_Template_button_click_3_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.goBack());
    });
    \u0275\u0275element(4, "ion-icon", 5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 6);
    \u0275\u0275template(6, PropertyDetailsPage_Conditional_1_Conditional_6_Template, 2, 0, "button", 7);
    \u0275\u0275elementStart(7, "button", 8);
    \u0275\u0275listener("click", function PropertyDetailsPage_Conditional_1_Template_button_click_7_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.shareProperty());
    });
    \u0275\u0275element(8, "ion-icon", 9);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "button", 10);
    \u0275\u0275listener("click", function PropertyDetailsPage_Conditional_1_Template_button_click_9_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.toggleFavorite());
    });
    \u0275\u0275element(10, "ion-icon", 11);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(11, "div", 12);
    \u0275\u0275listener("touchstart", function PropertyDetailsPage_Conditional_1_Template_div_touchstart_11_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.onTouchStart($event));
    })("touchend", function PropertyDetailsPage_Conditional_1_Template_div_touchend_11_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.onTouchEnd($event));
    });
    \u0275\u0275element(12, "img", 13)(13, "div", 14);
    \u0275\u0275template(14, PropertyDetailsPage_Conditional_1_Conditional_14_Template, 4, 0);
    \u0275\u0275elementStart(15, "div", 15);
    \u0275\u0275template(16, PropertyDetailsPage_Conditional_1_Conditional_16_Template, 4, 0, "button", 16);
    \u0275\u0275elementStart(17, "div", 17);
    \u0275\u0275element(18, "ion-icon", 18);
    \u0275\u0275elementStart(19, "span");
    \u0275\u0275text(20);
    \u0275\u0275elementEnd()()()()();
    \u0275\u0275elementStart(21, "section", 19)(22, "div", 20)(23, "span", 21);
    \u0275\u0275text(24);
    \u0275\u0275elementEnd();
    \u0275\u0275template(25, PropertyDetailsPage_Conditional_1_Conditional_25_Template, 2, 1, "span", 22)(26, PropertyDetailsPage_Conditional_1_Conditional_26_Template, 2, 0, "span", 22)(27, PropertyDetailsPage_Conditional_1_Conditional_27_Template, 3, 0, "span", 23);
    \u0275\u0275elementStart(28, "span", 24);
    \u0275\u0275text(29);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(30, "div", 25)(31, "div", 26)(32, "div", 27)(33, "span", 28);
    \u0275\u0275text(34);
    \u0275\u0275elementEnd();
    \u0275\u0275template(35, PropertyDetailsPage_Conditional_1_Conditional_35_Template, 2, 1, "span", 29);
    \u0275\u0275elementEnd();
    \u0275\u0275template(36, PropertyDetailsPage_Conditional_1_Conditional_36_Template, 2, 1, "span", 30);
    \u0275\u0275elementEnd();
    \u0275\u0275template(37, PropertyDetailsPage_Conditional_1_Conditional_37_Template, 5, 1, "div", 31);
    \u0275\u0275elementEnd();
    \u0275\u0275template(38, PropertyDetailsPage_Conditional_1_Conditional_38_Template, 3, 2, "div", 32);
    \u0275\u0275elementStart(39, "h1", 33);
    \u0275\u0275text(40);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(41, "div", 34);
    \u0275\u0275element(42, "ion-icon", 35);
    \u0275\u0275elementStart(43, "div", 36)(44, "span", 37);
    \u0275\u0275text(45);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(46, "span", 38);
    \u0275\u0275text(47);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(48, "button", 39);
    \u0275\u0275listener("click", function PropertyDetailsPage_Conditional_1_Template_button_click_48_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.openMapLocation());
    });
    \u0275\u0275element(49, "ion-icon", 40);
    \u0275\u0275elementStart(50, "span");
    \u0275\u0275text(51, "Google Maps");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(52, "div", 41)(53, "div", 42)(54, "h3", 43);
    \u0275\u0275text(55, "Overview & Dimensions");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(56, "span", 44);
    \u0275\u0275text(57, "Verified Specs");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(58, "div", 45);
    \u0275\u0275template(59, PropertyDetailsPage_Conditional_1_Conditional_59_Template, 8, 1, "div", 46)(60, PropertyDetailsPage_Conditional_1_Conditional_60_Template, 8, 1, "div", 46)(61, PropertyDetailsPage_Conditional_1_Conditional_61_Template, 8, 1, "div", 46);
    \u0275\u0275elementStart(62, "div", 46)(63, "div", 47);
    \u0275\u0275element(64, "ion-icon", 48);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(65, "div", 49)(66, "span", 50);
    \u0275\u0275text(67);
    \u0275\u0275pipe(68, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(69, "span", 51);
    \u0275\u0275text(70);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(71, "div", 46)(72, "div", 52);
    \u0275\u0275element(73, "ion-icon", 53);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(74, "div", 49)(75, "span", 50);
    \u0275\u0275text(76);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(77, "span", 51);
    \u0275\u0275text(78, "Orientation");
    \u0275\u0275elementEnd()()();
    \u0275\u0275template(79, PropertyDetailsPage_Conditional_1_Conditional_79_Template, 8, 1, "div", 54)(80, PropertyDetailsPage_Conditional_1_Conditional_80_Template, 8, 1, "div", 54)(81, PropertyDetailsPage_Conditional_1_Conditional_81_Template, 8, 1, "div", 46);
    \u0275\u0275elementStart(82, "div", 55)(83, "div", 56);
    \u0275\u0275element(84, "ion-icon", 57);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(85, "div", 49)(86, "span", 50);
    \u0275\u0275text(87);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(88, "span", 51);
    \u0275\u0275text(89, "Water Supply");
    \u0275\u0275elementEnd()()()()();
    \u0275\u0275elementStart(90, "div", 58)(91, "div", 59)(92, "div", 60)(93, "h3", 43);
    \u0275\u0275text(94, "Docs & Legal Verification");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(95, "span", 61);
    \u0275\u0275text(96, "Complete title search & compliance status");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(97, "div", 62);
    \u0275\u0275element(98, "ion-icon", 57);
    \u0275\u0275elementStart(99, "span");
    \u0275\u0275text(100);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(101, "div", 63);
    \u0275\u0275repeaterCreate(102, PropertyDetailsPage_Conditional_1_For_103_Template, 14, 9, "div", 64, _forTrack0);
    \u0275\u0275elementEnd();
    \u0275\u0275template(104, PropertyDetailsPage_Conditional_1_Conditional_104_Template, 4, 2, "button", 65);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(105, "div", 66)(106, "h3", 43);
    \u0275\u0275text(107, "About This Property");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(108, "p", 67);
    \u0275\u0275text(109);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(110, PropertyDetailsPage_Conditional_1_Conditional_110_Template, 6, 0, "div", 68)(111, PropertyDetailsPage_Conditional_1_Conditional_111_Template, 6, 0, "div", 69);
    \u0275\u0275elementStart(112, "div", 70)(113, "div", 71);
    \u0275\u0275text(114);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(115, "div", 72)(116, "div", 73)(117, "h4", 74);
    \u0275\u0275text(118);
    \u0275\u0275elementEnd();
    \u0275\u0275template(119, PropertyDetailsPage_Conditional_1_Conditional_119_Template, 3, 0, "span", 75);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(120, "span", 76);
    \u0275\u0275text(121);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275element(122, "app-property-footer")(123, "div", 77);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(124, "footer", 78);
    \u0275\u0275template(125, PropertyDetailsPage_Conditional_1_Conditional_125_Template, 7, 1, "div", 79)(126, PropertyDetailsPage_Conditional_1_Conditional_126_Template, 13, 0, "div", 80);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(127, "ion-modal", 81);
    \u0275\u0275listener("didDismiss", function PropertyDetailsPage_Conditional_1_Template_ion_modal_didDismiss_127_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.closeVideoModal());
    });
    \u0275\u0275template(128, PropertyDetailsPage_Conditional_1_ng_template_128_Template, 14, 7, "ng-template");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(6);
    \u0275\u0275conditional(ctx_r1.property.videoUrl ? 6 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275classProp("active", ctx_r1.isFavorite);
    \u0275\u0275advance();
    \u0275\u0275property("name", ctx_r1.isFavorite ? "heart" : "heart-outline");
    \u0275\u0275advance(2);
    \u0275\u0275property("src", ctx_r1.property.images[ctx_r1.activeImageIndex], \u0275\u0275sanitizeUrl)("alt", ctx_r1.property.title);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.property.images.length > 1 ? 14 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.property.videoUrl ? 16 : -1);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate2("", ctx_r1.activeImageIndex + 1, " / ", ctx_r1.property.images.length, " Photos");
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r1.property.propertyType);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.property.status === "sold" ? 25 : ctx_r1.property.status === "closed" ? 26 : ctx_r1.property.tags.includes("Verified") || ctx_r1.property.is_verified ? 27 : -1);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r1.property.possessionStatus);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r1.property.priceDisplay);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.property.priceUnit ? 35 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.property.pricePerSqFt ? 36 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.property.emiEstimate ? 37 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.property.category === "rent_house" && (ctx_r1.property.securityDeposit || ctx_r1.property.maintenancePerMonth) ? 38 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.property.title);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate2("", ctx_r1.property.locality, ", ", ctx_r1.property.city, "");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.property.fullAddress);
    \u0275\u0275advance(12);
    \u0275\u0275conditional(ctx_r1.property.totalAcres ? 59 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.property.bedrooms ? 60 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.property.bathrooms ? 61 : -1);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1("", \u0275\u0275pipeBind1(68, 52, ctx_r1.property.superBuiltUpAreaSqFt), " sq.ft");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx_r1.property.category === "buy_plot" ? "Plot Area" : ctx_r1.property.category === "buy_land" ? "Converted Area" : "Super Area");
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1("", ctx_r1.property.facing, " Facing");
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx_r1.property.category === "buy_house" || ctx_r1.property.category === "rent_house" ? 79 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.property.parking ? 80 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.property.floor ? 81 : -1);
    \u0275\u0275advance();
    \u0275\u0275classProp("span-6", ctx_r1.property.floor)("span-12", !ctx_r1.property.floor);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r1.property.waterSupply);
    \u0275\u0275advance(10);
    \u0275\u0275classProp("all-clear", ctx_r1.clearChecksCount === ctx_r1.propertyLegalChecks.length);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate2("", ctx_r1.clearChecksCount, "/", ctx_r1.propertyLegalChecks.length, " Verified");
    \u0275\u0275advance(2);
    \u0275\u0275repeater(ctx_r1.displayedLegalChecks);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.propertyLegalChecks.length > 3 ? 104 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r1.property.description);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.property.amenities.length > 0 ? 110 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.property.nearbyLandmarks.length > 0 ? 111 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" ", ctx_r1.property.seller.name.charAt(0).toUpperCase(), " ");
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r1.property.seller.name);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.property.seller.verified ? 119 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("", ctx_r1.property.seller.type, " \u2022 Pintu Real Estate Partner");
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx_r1.property.status === "sold" ? 125 : 126);
    \u0275\u0275advance(2);
    \u0275\u0275classProp("is-reel", ctx_r1.isVideoReel);
    \u0275\u0275property("isOpen", ctx_r1.isVideoModalOpen);
  }
}
var _PropertyDetailsPage = class _PropertyDetailsPage {
  constructor(route, router, navCtrl, propertyService, toastController, sanitizer) {
    this.route = route;
    this.router = router;
    this.navCtrl = navCtrl;
    this.propertyService = propertyService;
    this.toastController = toastController;
    this.sanitizer = sanitizer;
    this.property = null;
    this.activeImageIndex = 0;
    this.isFavorite = false;
    this.isDocsExpanded = false;
    this.isVideoModalOpen = false;
    this.isVideoReel = false;
    this.isPlaying = true;
    this.showPlayPauseIndicator = false;
    this.playPauseIndicatorTimeout = null;
    this.embedVideoUrl = null;
    this.touchStartX = 0;
    this.touchEndX = 0;
    this.touchStartY = 0;
    this.touchEndY = 0;
    addIcons({ arrowBackOutline, shareSocialOutline, chevronBackOutline, chevronForwardOutline, cameraOutline, checkmarkCircle, location, openOutline, leafOutline, bedOutline, waterOutline, expandOutline, compassOutline, businessOutline, carOutline, calendarOutline, shieldCheckmarkOutline, alertCircleOutline, callOutline, logoWhatsapp, heartOutline, heart, sparkles, navigateOutline, shieldOutline, chatbubbleEllipsesOutline, documentTextOutline, timeOutline, chevronDownOutline, chevronUpOutline, lockClosedOutline, videocamOutline, playCircle, closeOutline, play, pause });
  }
  ngOnInit() {
    this.route.paramMap.subscribe((params) => {
      const propId = params.get("id");
      if (propId) {
        this.loadProperty(propId);
      }
    });
  }
  loadProperty(id) {
    this.propertyService.getPropertyById(id).subscribe({
      next: (found) => {
        if (found) {
          this.property = found;
          this.isFavorite = !!found.isFavorite;
        } else {
          this.property = DUMMY_PROPERTIES[0];
          this.isFavorite = !!this.property.isFavorite;
        }
      },
      error: () => {
        const found = DUMMY_PROPERTIES.find((p) => p.id === id);
        this.property = found || DUMMY_PROPERTIES[0];
        this.isFavorite = !!this.property.isFavorite;
      }
    });
  }
  goBack() {
    this.navCtrl.navigateBack("/layout/property");
  }
  setImageIndex(idx) {
    this.activeImageIndex = idx;
  }
  // Swipe event handlers
  onTouchStart(event) {
    if (event.touches.length > 0) {
      this.touchStartX = event.touches[0].clientX;
      this.touchStartY = event.touches[0].clientY;
    }
  }
  onTouchEnd(event) {
    if (event.changedTouches.length > 0) {
      this.touchEndX = event.changedTouches[0].clientX;
      this.touchEndY = event.changedTouches[0].clientY;
      this.handleSwipeGesture();
    }
  }
  handleSwipeGesture() {
    const deltaX = this.touchEndX - this.touchStartX;
    const deltaY = this.touchEndY - this.touchStartY;
    if (Math.abs(deltaX) > 35 && Math.abs(deltaX) > Math.abs(deltaY)) {
      if (deltaX < 0) {
        this.nextImage();
      } else {
        this.prevImage();
      }
    }
  }
  nextImage() {
    if (!this.property || this.property.images.length <= 1)
      return;
    this.activeImageIndex = (this.activeImageIndex + 1) % this.property.images.length;
  }
  prevImage() {
    if (!this.property || this.property.images.length <= 1)
      return;
    this.activeImageIndex = (this.activeImageIndex - 1 + this.property.images.length) % this.property.images.length;
  }
  toggleFavorite() {
    this.isFavorite = !this.isFavorite;
    if (this.property) {
      this.property.isFavorite = this.isFavorite;
    }
  }
  shareProperty() {
    return __async(this, null, function* () {
      if (!this.property)
        return;
      try {
        yield Share.share({
          title: this.property.title,
          text: `Check out this property on Pintu: ${this.property.title} in ${this.property.locality} for ${this.property.priceDisplay}!

Download Pintu: https://tinyurl.com/5d4mrdpn`,
          url: "https://tinyurl.com/5d4mrdpn",
          dialogTitle: "Share Property"
        });
      } catch {
        this.openWhatsApp();
      }
    });
  }
  callSeller() {
    if (!this.property || this.property.status === "sold")
      return;
    window.open(`tel:${this.property.seller.phone.replace(/[^0-9+]/g, "")}`, "_system");
  }
  openWhatsApp() {
    if (!this.property || this.property.status === "sold")
      return;
    const text = encodeURIComponent(`Hello ${this.property.seller.name}, I am interested in your property on Pintu:
"${this.property.title}" (${this.property.priceDisplay})
Locality: ${this.property.locality}.
Please share more details and arrange a site visit.`);
    window.open(`https://wa.me/${this.property.seller.whatsapp}?text=${text}`, "_system");
  }
  openMapLocation() {
    var _a, _b;
    if (!this.property)
      return;
    const query = ((_a = this.property.coordinates) == null ? void 0 : _a.lat) && ((_b = this.property.coordinates) == null ? void 0 : _b.lng) ? `${this.property.coordinates.lat},${this.property.coordinates.lng}` : encodeURIComponent(`${this.property.title}, ${this.property.locality}, ${this.property.city}`);
    const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${query}`;
    window.open(mapsUrl, "_system");
  }
  openVideoModal() {
    var _a;
    if (!((_a = this.property) == null ? void 0 : _a.videoUrl))
      return;
    this.isPlaying = true;
    this.showPlayPauseIndicator = false;
    const rawUrl = (this.property.videoUrl || "").toLowerCase();
    this.isVideoReel = rawUrl.includes("/shorts/") || rawUrl.includes("shorts") || rawUrl.includes("/reel/") || rawUrl.includes("/reels/") || rawUrl.includes("tiktok.com") || rawUrl.includes("vertical") || rawUrl.includes("9:16") || rawUrl.includes("9-16");
    const videoId = this.extractYouTubeId(this.property.videoUrl);
    if (videoId) {
      const embed = `https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&controls=0&rel=0&modestbranding=1&playsinline=1&iv_load_policy=3&disablekb=1&fs=0&enablejsapi=1`;
      this.embedVideoUrl = this.sanitizer.bypassSecurityTrustResourceUrl(embed);
    } else {
      this.embedVideoUrl = this.sanitizer.bypassSecurityTrustResourceUrl(this.property.videoUrl);
    }
    this.isVideoModalOpen = true;
  }
  togglePlayPause() {
    this.isPlaying = !this.isPlaying;
    this.showPlayPauseIndicator = true;
    if (this.playPauseIndicatorTimeout) {
      clearTimeout(this.playPauseIndicatorTimeout);
    }
    this.playPauseIndicatorTimeout = setTimeout(() => {
      this.showPlayPauseIndicator = false;
    }, 600);
    const iframe = document.querySelector(".property-video-modal iframe");
    if (iframe && iframe.contentWindow) {
      const action = this.isPlaying ? "playVideo" : "pauseVideo";
      iframe.contentWindow.postMessage(JSON.stringify({ event: "command", func: action, args: [] }), "*");
    }
  }
  toggleVideoAspect() {
    this.isVideoReel = !this.isVideoReel;
  }
  closeVideoModal() {
    this.isVideoModalOpen = false;
    this.embedVideoUrl = null;
    this.showPlayPauseIndicator = false;
    if (this.playPauseIndicatorTimeout) {
      clearTimeout(this.playPauseIndicatorTimeout);
      this.playPauseIndicatorTimeout = null;
    }
  }
  extractYouTubeId(url) {
    if (!url)
      return null;
    const cleanUrl = url.trim();
    const regExp = /(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=|shorts\/))([\w-]{11})/;
    const match = cleanUrl.match(regExp);
    if (match && match[1]) {
      return match[1];
    }
    if (/^[a-zA-Z0-9_-]{11}$/.test(cleanUrl)) {
      return cleanUrl;
    }
    return null;
  }
  get propertyLegalChecks() {
    var _a, _b, _c, _d, _e, _f;
    if (((_a = this.property) == null ? void 0 : _a.legalChecks) && this.property.legalChecks.length > 0) {
      return this.property.legalChecks;
    }
    if (((_b = this.property) == null ? void 0 : _b.category) === "rent_house") {
      return [
        {
          title: "Registered Rental Agreement",
          category: "Rental Agreement",
          status: "clear",
          statusLabel: "Draft Ready",
          details: "Standard 11-month bilingual rental agreement ready for execution."
        },
        {
          title: "Owner ID & Tenancy NOC",
          category: "Ownership Verification",
          status: "clear",
          statusLabel: "Verified",
          details: "Verified owner identity card, electricity bill, and tenancy permission."
        },
        {
          title: "Police Tenant Verification Form",
          category: "Safety & Verification",
          status: "clear",
          statusLabel: "Available",
          details: "Assistance with local police verification form and record keeping."
        }
      ];
    }
    const isUnderConstruction = ((_c = this.property) == null ? void 0 : _c.possessionStatus) === "Under Construction" || ((_d = this.property) == null ? void 0 : _d.possessionStatus) === "Under Development";
    const isLandOrPlot = ((_e = this.property) == null ? void 0 : _e.category) === "buy_land" || ((_f = this.property) == null ? void 0 : _f.category) === "buy_plot";
    return [
      {
        title: "Title Deed & Ownership Proof",
        category: "Ownership Verification",
        status: "clear",
        statusLabel: "Clear Title",
        details: "Registered Sale Deed with unbroken chain of title records."
      },
      {
        title: isLandOrPlot ? "7/12 RTC & Mutation Extract" : "Khata Certificate & Extract",
        category: "Revenue & Land Records",
        status: "clear",
        statusLabel: isLandOrPlot ? "Clear RTC" : "A-Khata Verified",
        details: isLandOrPlot ? "Clear RTC in seller name with updated mutation register copy." : "Town Municipal Council (TMC) A-Khata with updated tax assessment."
      },
      {
        title: "Encumbrance Certificate (EC)",
        category: "Encumbrance Verification",
        status: "clear",
        statusLabel: "Clear (15 Years)",
        details: "15-Year Nil Encumbrance Certificate verified free of any bank/legal dues."
      },
      {
        title: isLandOrPlot ? "DC Conversion (NA Order)" : "Sanctioned Building Plan",
        category: "Government Approvals",
        status: "clear",
        statusLabel: "Approved",
        details: isLandOrPlot ? "Deputy Commissioner (DC) approved Non-Agricultural residential order." : "TMC & Town Planning authority approved residential layout plan."
      },
      {
        title: "Property Tax Receipts",
        category: "Tax Compliance",
        status: "clear",
        statusLabel: "Paid (2025-26)",
        details: "All municipal property taxes paid up to current financial year."
      },
      {
        title: isLandOrPlot ? "Boundary Survey & Sketch" : "Occupancy Certificate (OC)",
        category: "Possession & Compliance",
        status: isUnderConstruction ? "pending" : "clear",
        statusLabel: isUnderConstruction ? "Under Process" : isLandOrPlot ? "Demarcated" : "OC Issued",
        details: isUnderConstruction ? "Occupancy Certificate applied with TMC, site inspection in progress." : isLandOrPlot ? "ADLR digital survey sketch & stone demarcation verified." : "TMC issued Occupancy Certificate verified."
      },
      {
        title: "Bank Loan Eligibility",
        category: "Finance Clearance",
        status: "clear",
        statusLabel: "Pre-Approved",
        details: "Pre-approved for fast home/plot loans by SBI, HDFC & Canara Bank."
      }
    ];
  }
  get clearChecksCount() {
    return this.propertyLegalChecks.filter((c) => c.status === "clear").length;
  }
  get displayedLegalChecks() {
    return this.isDocsExpanded ? this.propertyLegalChecks : this.propertyLegalChecks.slice(0, 3);
  }
  toggleDocsExpanded() {
    this.isDocsExpanded = !this.isDocsExpanded;
  }
  bookCallback() {
    return __async(this, null, function* () {
      if (!this.property || this.property.status === "sold")
        return;
      const toast = yield this.toastController.create({
        message: `Callback requested! ${this.property.seller.name} will call you back shortly.`,
        duration: 3e3,
        position: "top",
        color: "success",
        icon: "checkmark-circle"
      });
      yield toast.present();
    });
  }
};
_PropertyDetailsPage.\u0275fac = function PropertyDetailsPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _PropertyDetailsPage)(\u0275\u0275directiveInject(ActivatedRoute), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(PropertyService), \u0275\u0275directiveInject(ToastController), \u0275\u0275directiveInject(DomSanitizer));
};
_PropertyDetailsPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _PropertyDetailsPage, selectors: [["app-property-details"]], decls: 2, vars: 2, consts: [[1, "property-details-content", 3, "fullscreen"], [1, "details-body-container"], [1, "hero-gallery-section"], [1, "floating-nav-header"], ["type", "button", "aria-label", "Back", 1, "btn-circle-nav", 3, "click"], ["name", "arrow-back-outline"], [1, "header-right-actions"], ["type", "button", "aria-label", "Watch Video Tour", "title", "Watch Video Tour", 1, "btn-circle-nav", "btn-video"], ["type", "button", "aria-label", "Share", 1, "btn-circle-nav", 3, "click"], ["name", "share-social-outline"], ["type", "button", "aria-label", "Save", 1, "btn-circle-nav", 3, "click"], [3, "name"], [1, "main-image-viewport", 3, "touchstart", "touchend"], [1, "hero-property-img", 3, "src", "alt"], [1, "hero-image-overlay"], [1, "hero-bottom-badges"], ["type", "button", "aria-label", "Watch Video Tour", 1, "video-tour-badge"], [1, "photo-counter-badge"], ["name", "camera-outline"], [1, "property-info-card"], [1, "tags-badge-row"], [1, "type-pill"], [1, "sold-pill"], [1, "verified-pill"], [1, "possession-pill"], [1, "pricing-header-row"], [1, "price-block"], [1, "price-main-row"], [1, "price-val"], [1, "price-unit"], [1, "price-rate"], [1, "emi-pill"], [1, "rent-meta-row"], [1, "details-title"], [1, "locality-address-box"], ["name", "location", 1, "loc-icon"], [1, "loc-text-wrap"], [1, "loc-name"], [1, "loc-full"], ["type", "button", 1, "btn-view-map", 3, "click"], ["name", "open-outline"], [1, "specs-bento-section"], [1, "specs-heading-row"], [1, "section-heading"], [1, "specs-sub-badge"], [1, "specs-bento-grid"], [1, "bento-tile", "span-6"], [1, "spec-icon-halo", "emerald"], ["name", "expand-outline"], [1, "spec-text-col"], [1, "spec-val"], [1, "spec-lbl"], [1, "spec-icon-halo", "amber"], ["name", "compass-outline"], [1, "bento-tile", "span-12"], [1, "bento-tile"], [1, "spec-icon-halo", "green"], ["name", "shield-checkmark-outline"], [1, "legal-docs-section"], [1, "legal-heading-row"], [1, "legal-title-col"], [1, "legal-subtitle"], [1, "legal-status-counter"], [1, "legal-checks-list"], [1, "legal-check-card", 3, "is-clear", "is-pending"], ["type", "button", 1, "btn-toggle-docs"], [1, "description-section"], [1, "description-text"], [1, "amenities-section"], [1, "landmarks-section"], [1, "seller-card"], [1, "seller-avatar-wrap"], [1, "seller-details-col"], [1, "seller-title-row"], [1, "seller-name"], [1, "seller-verified-badge"], [1, "seller-type-text"], [1, "bottom-action-spacer"], [1, "sticky-contact-footer"], [1, "sold-footer-notice"], [1, "footer-actions-grid"], [1, "property-video-modal", 3, "didDismiss", "isOpen"], ["type", "button", "aria-label", "Watch Video Tour", "title", "Watch Video Tour", 1, "btn-circle-nav", "btn-video", 3, "click"], ["name", "videocam-outline"], ["type", "button", "aria-label", "Previous photo", 1, "btn-gallery-nav", "btn-prev", 3, "click"], ["name", "chevron-back-outline"], ["type", "button", "aria-label", "Next photo", 1, "btn-gallery-nav", "btn-next", 3, "click"], ["name", "chevron-forward-outline"], ["type", "button", "aria-label", "Watch Video Tour", 1, "video-tour-badge", 3, "click"], ["name", "play-circle"], ["name", "checkmark-circle"], [1, "emi-label"], [1, "emi-amount"], [1, "rent-meta-chip"], [1, "meta-label"], [1, "meta-value"], ["name", "leaf-outline"], [1, "spec-icon-halo", "purple"], ["name", "bed-outline"], [1, "spec-icon-halo", "blue"], ["name", "water-outline"], [1, "spec-icon-halo", "indigo"], ["name", "business-outline"], [1, "spec-icon-halo", "teal"], ["name", "car-outline"], [1, "spec-icon-halo", "rose"], ["name", "calendar-outline"], [1, "legal-check-card"], [1, "check-icon-col"], [1, "status-badge-circle", "clear"], [1, "status-badge-circle", "pending"], [1, "check-info-col"], [1, "check-title-row"], [1, "check-doc-title"], [1, "status-pill", "clear"], [1, "status-pill", "pending"], [1, "check-doc-category"], [1, "check-doc-details"], ["name", "alert-circle-outline"], ["type", "button", 1, "btn-toggle-docs", 3, "click"], [1, "amenities-full-grid"], [1, "amenity-grid-item"], [1, "amenity-check-halo"], [1, "amenity-item-text"], [1, "landmarks-list"], [1, "landmark-item"], [1, "lm-left"], ["name", "location", 1, "lm-pin"], [1, "lm-name"], [1, "lm-distance"], ["name", "lock-closed-outline"], [1, "sold-notice-text"], [1, "sold-notice-title"], [1, "sold-notice-sub"], ["type", "button", 1, "btn-footer-action", "btn-callback", 3, "click"], ["type", "button", 1, "btn-footer-action", "btn-call", 3, "click"], ["name", "call-outline"], ["type", "button", 1, "btn-footer-action", "btn-whatsapp", 3, "click"], ["name", "logo-whatsapp"], [1, "video-card-wrapper"], ["type", "button", "aria-label", "Close video", "title", "Close", 1, "video-overlay-close-btn", 3, "click"], ["name", "close-outline"], ["type", "button", "aria-label", "Resolution selection", "title", "Toggle 9:16 / 16:9 ratio", 1, "video-aspect-pill", 3, "click"], [1, "res-tag"], [1, "res-value"], [1, "video-frame-box"], [1, "top-branding-blocker"], ["aria-label", "Play or Pause", 1, "iframe-touch-shield", 3, "click"], [1, "play-pause-feedback"], ["frameborder", "0", "allow", "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share", "referrerpolicy", "strict-origin-when-cross-origin", "allowfullscreen", "", 1, "video-iframe", 3, "src"], [1, "no-video-box"]], template: function PropertyDetailsPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 0);
    \u0275\u0275template(1, PropertyDetailsPage_Conditional_1_Template, 129, 54);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.property ? 1 : -1);
  }
}, dependencies: [
  IonContent,
  IonIcon,
  IonModal,
  CommonModule,
  DecimalPipe,
  FormsModule,
  PropertyFooterComponent
], styles: ["\n\n.property-details-content[_ngcontent-%COMP%] {\n  --background: #f8fafc;\n}\n.details-body-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  position: relative;\n}\n.hero-gallery-section[_ngcontent-%COMP%] {\n  position: relative;\n  width: 100%;\n  background: #0f172a;\n  overflow: hidden;\n}\n.hero-gallery-section[_ngcontent-%COMP%]   .floating-nav-header[_ngcontent-%COMP%] {\n  position: absolute;\n  top: max(env(safe-area-inset-top, 0px), 16px);\n  left: 14px;\n  right: 14px;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  z-index: 20;\n}\n.hero-gallery-section[_ngcontent-%COMP%]   .floating-nav-header[_ngcontent-%COMP%]   .header-right-actions[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n}\n.hero-gallery-section[_ngcontent-%COMP%]   .floating-nav-header[_ngcontent-%COMP%]   .btn-circle-nav[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n  border-radius: 50%;\n  background: rgba(15, 23, 42, 0.55);\n  backdrop-filter: blur(10px);\n  -webkit-backdrop-filter: blur(10px);\n  border: 1px solid rgba(255, 255, 255, 0.2);\n  color: #ffffff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 20px;\n  cursor: pointer;\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);\n  transition: all 0.2s ease;\n}\n.hero-gallery-section[_ngcontent-%COMP%]   .floating-nav-header[_ngcontent-%COMP%]   .btn-circle-nav[_ngcontent-%COMP%]:active {\n  transform: scale(0.9);\n}\n.hero-gallery-section[_ngcontent-%COMP%]   .floating-nav-header[_ngcontent-%COMP%]   .btn-circle-nav.active[_ngcontent-%COMP%] {\n  color: #ef4444;\n  background: rgba(255, 255, 255, 0.95);\n  border-color: #ef4444;\n}\n.hero-gallery-section[_ngcontent-%COMP%]   .floating-nav-header[_ngcontent-%COMP%]   .btn-circle-nav.btn-video[_ngcontent-%COMP%] {\n  background: rgba(220, 38, 38, 0.85);\n  border-color: rgba(255, 255, 255, 0.4);\n  color: #ffffff;\n}\n.hero-gallery-section[_ngcontent-%COMP%]   .floating-nav-header[_ngcontent-%COMP%]   .btn-circle-nav.btn-video[_ngcontent-%COMP%]:active {\n  background: rgb(220, 38, 38);\n}\n.hero-gallery-section[_ngcontent-%COMP%]   .main-image-viewport[_ngcontent-%COMP%] {\n  position: relative;\n  width: 100%;\n  height: 330px;\n  background: #1e293b;\n  touch-action: pan-y;\n  user-select: none;\n  -webkit-user-select: none;\n}\n.hero-gallery-section[_ngcontent-%COMP%]   .main-image-viewport[_ngcontent-%COMP%]   .hero-property-img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n  display: block;\n  transition: transform 0.25s ease-out, opacity 0.2s ease;\n}\n.hero-gallery-section[_ngcontent-%COMP%]   .main-image-viewport[_ngcontent-%COMP%]   .hero-image-overlay[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  background:\n    linear-gradient(\n      to bottom,\n      rgba(15, 23, 42, 0.5) 0%,\n      transparent 35%,\n      transparent 65%,\n      rgba(15, 23, 42, 0.7) 100%);\n  pointer-events: none;\n}\n.hero-gallery-section[_ngcontent-%COMP%]   .main-image-viewport[_ngcontent-%COMP%]   .btn-gallery-nav[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 50%;\n  transform: translateY(-50%);\n  width: 36px;\n  height: 36px;\n  border-radius: 50%;\n  background: rgba(15, 23, 42, 0.45);\n  -webkit-backdrop-filter: blur(6px);\n  backdrop-filter: blur(6px);\n  border: 1px solid rgba(255, 255, 255, 0.2);\n  color: #ffffff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 20px;\n  cursor: pointer;\n  z-index: 10;\n  transition: all 0.15s ease;\n}\n.hero-gallery-section[_ngcontent-%COMP%]   .main-image-viewport[_ngcontent-%COMP%]   .btn-gallery-nav[_ngcontent-%COMP%]:active {\n  background: rgba(15, 23, 42, 0.75);\n  transform: translateY(-50%) scale(0.92);\n}\n.hero-gallery-section[_ngcontent-%COMP%]   .main-image-viewport[_ngcontent-%COMP%]   .btn-gallery-nav.btn-prev[_ngcontent-%COMP%] {\n  left: 12px;\n}\n.hero-gallery-section[_ngcontent-%COMP%]   .main-image-viewport[_ngcontent-%COMP%]   .btn-gallery-nav.btn-next[_ngcontent-%COMP%] {\n  right: 12px;\n}\n.hero-gallery-section[_ngcontent-%COMP%]   .main-image-viewport[_ngcontent-%COMP%]   .hero-bottom-badges[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 18px;\n  right: 14px;\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  z-index: 5;\n}\n.hero-gallery-section[_ngcontent-%COMP%]   .main-image-viewport[_ngcontent-%COMP%]   .hero-bottom-badges[_ngcontent-%COMP%]   .video-tour-badge[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #ef4444 0%,\n      #dc2626 100%);\n  box-shadow: 0 4px 14px rgba(239, 68, 68, 0.4);\n  color: #ffffff;\n  font-size: 11.5px;\n  font-weight: 750;\n  padding: 6px 13px;\n  border-radius: 999px;\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  border: 1px solid rgba(255, 255, 255, 0.25);\n  cursor: pointer;\n  transition: transform 0.15s ease, filter 0.15s ease;\n}\n.hero-gallery-section[_ngcontent-%COMP%]   .main-image-viewport[_ngcontent-%COMP%]   .hero-bottom-badges[_ngcontent-%COMP%]   .video-tour-badge[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 15px;\n  color: #ffffff;\n}\n.hero-gallery-section[_ngcontent-%COMP%]   .main-image-viewport[_ngcontent-%COMP%]   .hero-bottom-badges[_ngcontent-%COMP%]   .video-tour-badge[_ngcontent-%COMP%]:active {\n  transform: scale(0.93);\n}\n.hero-gallery-section[_ngcontent-%COMP%]   .main-image-viewport[_ngcontent-%COMP%]   .hero-bottom-badges[_ngcontent-%COMP%]   .photo-counter-badge[_ngcontent-%COMP%] {\n  background: rgba(15, 23, 42, 0.75);\n  backdrop-filter: blur(8px);\n  -webkit-backdrop-filter: blur(8px);\n  color: #ffffff;\n  font-size: 11.5px;\n  font-weight: 750;\n  padding: 6px 12px;\n  border-radius: 999px;\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n  border: 1px solid rgba(255, 255, 255, 0.2);\n}\n.hero-gallery-section[_ngcontent-%COMP%]   .main-image-viewport[_ngcontent-%COMP%]   .hero-bottom-badges[_ngcontent-%COMP%]   .photo-counter-badge[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: #f1f5f9;\n}\n.property-info-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 26px 26px 0 0;\n  margin-top: -16px;\n  position: relative;\n  z-index: 10;\n  padding: 20px 16px 24px;\n  display: flex;\n  flex-direction: column;\n  gap: 22px;\n  box-shadow: 0 -4px 20px rgba(15, 23, 42, 0.06);\n}\n.property-info-card[_ngcontent-%COMP%]   .tags-badge-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  flex-wrap: wrap;\n}\n.property-info-card[_ngcontent-%COMP%]   .tags-badge-row[_ngcontent-%COMP%]   .type-pill[_ngcontent-%COMP%] {\n  background: #fdf4ff;\n  color: #a000e2;\n  border: 1px solid #f5d0fe;\n  font-size: 11px;\n  font-weight: 800;\n  padding: 4px 10px;\n  border-radius: 8px;\n  text-transform: uppercase;\n  letter-spacing: 0.3px;\n}\n.property-info-card[_ngcontent-%COMP%]   .tags-badge-row[_ngcontent-%COMP%]   .verified-pill[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  color: #059669;\n  border: 1px solid #a7f3d0;\n  font-size: 11px;\n  font-weight: 800;\n  padding: 4px 10px;\n  border-radius: 8px;\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n}\n.property-info-card[_ngcontent-%COMP%]   .tags-badge-row[_ngcontent-%COMP%]   .verified-pill[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 13px;\n}\n.property-info-card[_ngcontent-%COMP%]   .tags-badge-row[_ngcontent-%COMP%]   .sold-pill[_ngcontent-%COMP%] {\n  background: #fef2f2;\n  color: #dc2626;\n  border: 1px solid #fecaca;\n  font-size: 11px;\n  font-weight: 800;\n  padding: 4px 10px;\n  border-radius: 8px;\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  text-transform: uppercase;\n  letter-spacing: 0.4px;\n}\n.property-info-card[_ngcontent-%COMP%]   .tags-badge-row[_ngcontent-%COMP%]   .verifying-pill[_ngcontent-%COMP%] {\n  background: #fffbeb;\n  color: #d97706;\n  border: 1px solid #fde68a;\n  font-size: 11px;\n  font-weight: 800;\n  padding: 4px 10px;\n  border-radius: 8px;\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  letter-spacing: 0.3px;\n}\n.property-info-card[_ngcontent-%COMP%]   .tags-badge-row[_ngcontent-%COMP%]   .possession-pill[_ngcontent-%COMP%] {\n  background: #f1f5f9;\n  color: #475569;\n  font-size: 11px;\n  font-weight: 700;\n  padding: 4px 10px;\n  border-radius: 8px;\n}\n.property-info-card[_ngcontent-%COMP%]   .pricing-header-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: baseline;\n  justify-content: space-between;\n  gap: 12px;\n  padding-bottom: 2px;\n}\n.property-info-card[_ngcontent-%COMP%]   .pricing-header-row[_ngcontent-%COMP%]   .price-block[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n.property-info-card[_ngcontent-%COMP%]   .pricing-header-row[_ngcontent-%COMP%]   .price-block[_ngcontent-%COMP%]   .price-main-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: baseline;\n  gap: 4px;\n}\n.property-info-card[_ngcontent-%COMP%]   .pricing-header-row[_ngcontent-%COMP%]   .price-block[_ngcontent-%COMP%]   .price-main-row[_ngcontent-%COMP%]   .price-val[_ngcontent-%COMP%] {\n  font-size: 27px;\n  font-weight: 900;\n  color: #0f172a;\n  letter-spacing: -0.5px;\n}\n.property-info-card[_ngcontent-%COMP%]   .pricing-header-row[_ngcontent-%COMP%]   .price-block[_ngcontent-%COMP%]   .price-main-row[_ngcontent-%COMP%]   .price-unit[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 700;\n  color: #64748b;\n}\n.property-info-card[_ngcontent-%COMP%]   .pricing-header-row[_ngcontent-%COMP%]   .price-block[_ngcontent-%COMP%]   .price-rate[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 650;\n  color: #64748b;\n  margin-top: 2px;\n}\n.property-info-card[_ngcontent-%COMP%]   .pricing-header-row[_ngcontent-%COMP%]   .emi-pill[_ngcontent-%COMP%] {\n  background: #eff6ff;\n  border: 1px solid #dbeafe;\n  border-radius: 12px;\n  padding: 6px 12px;\n  display: flex;\n  flex-direction: column;\n  align-items: flex-end;\n}\n.property-info-card[_ngcontent-%COMP%]   .pricing-header-row[_ngcontent-%COMP%]   .emi-pill[_ngcontent-%COMP%]   .emi-label[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  font-weight: 750;\n  color: #3b82f6;\n  text-transform: uppercase;\n  letter-spacing: 0.3px;\n}\n.property-info-card[_ngcontent-%COMP%]   .pricing-header-row[_ngcontent-%COMP%]   .emi-pill[_ngcontent-%COMP%]   .emi-amount[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 800;\n  color: #1d4ed8;\n}\n.property-info-card[_ngcontent-%COMP%]   .rent-meta-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  flex-wrap: wrap;\n  margin-top: -12px;\n}\n.property-info-card[_ngcontent-%COMP%]   .rent-meta-row[_ngcontent-%COMP%]   .rent-meta-chip[_ngcontent-%COMP%] {\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n  border-radius: 8px;\n  padding: 4px 10px;\n  font-size: 11.5px;\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n}\n.property-info-card[_ngcontent-%COMP%]   .rent-meta-row[_ngcontent-%COMP%]   .rent-meta-chip[_ngcontent-%COMP%]   .meta-label[_ngcontent-%COMP%] {\n  color: #64748b;\n  font-weight: 600;\n}\n.property-info-card[_ngcontent-%COMP%]   .rent-meta-row[_ngcontent-%COMP%]   .rent-meta-chip[_ngcontent-%COMP%]   .meta-value[_ngcontent-%COMP%] {\n  color: #0f172a;\n  font-weight: 800;\n}\n.property-info-card[_ngcontent-%COMP%]   .details-title[_ngcontent-%COMP%] {\n  font-size: 18.5px;\n  font-weight: 850;\n  color: #0f172a;\n  line-height: 1.35;\n  margin: 0;\n  letter-spacing: -0.3px;\n}\n.property-info-card[_ngcontent-%COMP%]   .locality-address-box[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  background: #f8fafc;\n  border: 1.5px solid #e2e8f0;\n  border-radius: 16px;\n  padding: 10px 12px;\n}\n.property-info-card[_ngcontent-%COMP%]   .locality-address-box[_ngcontent-%COMP%]   .loc-icon[_ngcontent-%COMP%] {\n  color: #a000e2;\n  font-size: 24px;\n  flex-shrink: 0;\n}\n.property-info-card[_ngcontent-%COMP%]   .locality-address-box[_ngcontent-%COMP%]   .loc-text-wrap[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 0;\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n}\n.property-info-card[_ngcontent-%COMP%]   .locality-address-box[_ngcontent-%COMP%]   .loc-text-wrap[_ngcontent-%COMP%]   .loc-name[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  font-weight: 800;\n  color: #0f172a;\n}\n.property-info-card[_ngcontent-%COMP%]   .locality-address-box[_ngcontent-%COMP%]   .loc-text-wrap[_ngcontent-%COMP%]   .loc-full[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 500;\n  color: #64748b;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.property-info-card[_ngcontent-%COMP%]   .locality-address-box[_ngcontent-%COMP%]   .btn-view-map[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  background: #ffffff;\n  border: 1.5px solid #e2e8f0;\n  border-radius: 10px;\n  padding: 7px 12px;\n  color: #0f172a;\n  font-size: 11.5px;\n  font-weight: 800;\n  cursor: pointer;\n  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);\n  flex-shrink: 0;\n  transition: all 0.15s ease;\n}\n.property-info-card[_ngcontent-%COMP%]   .locality-address-box[_ngcontent-%COMP%]   .btn-view-map[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  color: #a000e2;\n  font-size: 15px;\n}\n.property-info-card[_ngcontent-%COMP%]   .locality-address-box[_ngcontent-%COMP%]   .btn-view-map[_ngcontent-%COMP%]:active {\n  background: #f1f5f9;\n  transform: scale(0.96);\n}\n.property-info-card[_ngcontent-%COMP%]   .section-heading[_ngcontent-%COMP%] {\n  font-size: 15.5px;\n  font-weight: 850;\n  color: #0f172a;\n  margin: 0;\n  letter-spacing: -0.2px;\n}\n.property-info-card[_ngcontent-%COMP%]   .specs-bento-section[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border: 1.5px solid #f1f5f9;\n  border-radius: 20px;\n  padding: 16px;\n  box-shadow: 0 2px 10px rgba(15, 23, 42, 0.03);\n}\n.property-info-card[_ngcontent-%COMP%]   .specs-bento-section[_ngcontent-%COMP%]   .specs-heading-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin-bottom: 14px;\n}\n.property-info-card[_ngcontent-%COMP%]   .specs-bento-section[_ngcontent-%COMP%]   .specs-heading-row[_ngcontent-%COMP%]   .specs-sub-badge[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 800;\n  text-transform: uppercase;\n  color: #a000e2;\n  background: #fdf4ff;\n  padding: 3px 8px;\n  border-radius: 6px;\n  letter-spacing: 0.3px;\n}\n.property-info-card[_ngcontent-%COMP%]   .specs-bento-section[_ngcontent-%COMP%]   .specs-bento-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(12, 1fr);\n  gap: 10px;\n  width: 100%;\n  box-sizing: border-box;\n}\n.property-info-card[_ngcontent-%COMP%]   .specs-bento-section[_ngcontent-%COMP%]   .specs-bento-grid[_ngcontent-%COMP%]   .bento-tile[_ngcontent-%COMP%] {\n  background: #f8fafc;\n  border: 1.5px solid #e2e8f0;\n  border-radius: 14px;\n  padding: 10px 12px;\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  box-sizing: border-box;\n  min-width: 0;\n}\n.property-info-card[_ngcontent-%COMP%]   .specs-bento-section[_ngcontent-%COMP%]   .specs-bento-grid[_ngcontent-%COMP%]   .bento-tile.span-6[_ngcontent-%COMP%] {\n  grid-column: span 6;\n}\n@media (max-width: 340px) {\n  .property-info-card[_ngcontent-%COMP%]   .specs-bento-section[_ngcontent-%COMP%]   .specs-bento-grid[_ngcontent-%COMP%]   .bento-tile.span-6[_ngcontent-%COMP%] {\n    grid-column: span 12;\n  }\n}\n.property-info-card[_ngcontent-%COMP%]   .specs-bento-section[_ngcontent-%COMP%]   .specs-bento-grid[_ngcontent-%COMP%]   .bento-tile.span-12[_ngcontent-%COMP%] {\n  grid-column: span 12;\n}\n.property-info-card[_ngcontent-%COMP%]   .specs-bento-section[_ngcontent-%COMP%]   .specs-bento-grid[_ngcontent-%COMP%]   .bento-tile[_ngcontent-%COMP%]   .spec-icon-halo[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 38px;\n  border-radius: 10px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 19px;\n  flex-shrink: 0;\n}\n.property-info-card[_ngcontent-%COMP%]   .specs-bento-section[_ngcontent-%COMP%]   .specs-bento-grid[_ngcontent-%COMP%]   .bento-tile[_ngcontent-%COMP%]   .spec-icon-halo.purple[_ngcontent-%COMP%] {\n  background: #faf5ff;\n  color: #9333ea;\n}\n.property-info-card[_ngcontent-%COMP%]   .specs-bento-section[_ngcontent-%COMP%]   .specs-bento-grid[_ngcontent-%COMP%]   .bento-tile[_ngcontent-%COMP%]   .spec-icon-halo.blue[_ngcontent-%COMP%] {\n  background: #eff6ff;\n  color: #2563eb;\n}\n.property-info-card[_ngcontent-%COMP%]   .specs-bento-section[_ngcontent-%COMP%]   .specs-bento-grid[_ngcontent-%COMP%]   .bento-tile[_ngcontent-%COMP%]   .spec-icon-halo.emerald[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  color: #059669;\n}\n.property-info-card[_ngcontent-%COMP%]   .specs-bento-section[_ngcontent-%COMP%]   .specs-bento-grid[_ngcontent-%COMP%]   .bento-tile[_ngcontent-%COMP%]   .spec-icon-halo.amber[_ngcontent-%COMP%] {\n  background: #fffbeb;\n  color: #d97706;\n}\n.property-info-card[_ngcontent-%COMP%]   .specs-bento-section[_ngcontent-%COMP%]   .specs-bento-grid[_ngcontent-%COMP%]   .bento-tile[_ngcontent-%COMP%]   .spec-icon-halo.indigo[_ngcontent-%COMP%] {\n  background: #eef2ff;\n  color: #4f46e5;\n}\n.property-info-card[_ngcontent-%COMP%]   .specs-bento-section[_ngcontent-%COMP%]   .specs-bento-grid[_ngcontent-%COMP%]   .bento-tile[_ngcontent-%COMP%]   .spec-icon-halo.teal[_ngcontent-%COMP%] {\n  background: #f0fdfa;\n  color: #0d9488;\n}\n.property-info-card[_ngcontent-%COMP%]   .specs-bento-section[_ngcontent-%COMP%]   .specs-bento-grid[_ngcontent-%COMP%]   .bento-tile[_ngcontent-%COMP%]   .spec-icon-halo.rose[_ngcontent-%COMP%] {\n  background: #fff1f2;\n  color: #e11d48;\n}\n.property-info-card[_ngcontent-%COMP%]   .specs-bento-section[_ngcontent-%COMP%]   .specs-bento-grid[_ngcontent-%COMP%]   .bento-tile[_ngcontent-%COMP%]   .spec-icon-halo.green[_ngcontent-%COMP%] {\n  background: #f0fdf4;\n  color: #16a34a;\n}\n.property-info-card[_ngcontent-%COMP%]   .specs-bento-section[_ngcontent-%COMP%]   .specs-bento-grid[_ngcontent-%COMP%]   .bento-tile[_ngcontent-%COMP%]   .spec-text-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  min-width: 0;\n  overflow: hidden;\n}\n.property-info-card[_ngcontent-%COMP%]   .specs-bento-section[_ngcontent-%COMP%]   .specs-bento-grid[_ngcontent-%COMP%]   .bento-tile[_ngcontent-%COMP%]   .spec-text-col[_ngcontent-%COMP%]   .spec-val[_ngcontent-%COMP%] {\n  font-size: 12.5px;\n  font-weight: 850;\n  color: #0f172a;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  line-height: 1.25;\n}\n.property-info-card[_ngcontent-%COMP%]   .specs-bento-section[_ngcontent-%COMP%]   .specs-bento-grid[_ngcontent-%COMP%]   .bento-tile[_ngcontent-%COMP%]   .spec-text-col[_ngcontent-%COMP%]   .spec-lbl[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  font-weight: 650;\n  color: #64748b;\n  text-transform: uppercase;\n  letter-spacing: 0.2px;\n  margin-top: 2px;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.property-info-card[_ngcontent-%COMP%]   .legal-docs-section[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border: 1.5px solid #f1f5f9;\n  border-radius: 20px;\n  padding: 16px;\n  display: flex;\n  flex-direction: column;\n  gap: 14px;\n  box-shadow: 0 2px 10px rgba(15, 23, 42, 0.03);\n}\n.property-info-card[_ngcontent-%COMP%]   .legal-docs-section[_ngcontent-%COMP%]   .legal-heading-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 10px;\n}\n.property-info-card[_ngcontent-%COMP%]   .legal-docs-section[_ngcontent-%COMP%]   .legal-heading-row[_ngcontent-%COMP%]   .legal-title-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n}\n.property-info-card[_ngcontent-%COMP%]   .legal-docs-section[_ngcontent-%COMP%]   .legal-heading-row[_ngcontent-%COMP%]   .legal-title-col[_ngcontent-%COMP%]   .legal-subtitle[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #64748b;\n  font-weight: 500;\n}\n.property-info-card[_ngcontent-%COMP%]   .legal-docs-section[_ngcontent-%COMP%]   .legal-heading-row[_ngcontent-%COMP%]   .legal-status-counter[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  background: #ecfdf5;\n  border: 1px solid #a7f3d0;\n  color: #059669;\n  font-size: 11px;\n  font-weight: 850;\n  padding: 4px 10px;\n  border-radius: 999px;\n  white-space: nowrap;\n  flex-shrink: 0;\n}\n.property-info-card[_ngcontent-%COMP%]   .legal-docs-section[_ngcontent-%COMP%]   .legal-heading-row[_ngcontent-%COMP%]   .legal-status-counter[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 13px;\n}\n.property-info-card[_ngcontent-%COMP%]   .legal-docs-section[_ngcontent-%COMP%]   .legal-checks-list[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n}\n.property-info-card[_ngcontent-%COMP%]   .legal-docs-section[_ngcontent-%COMP%]   .legal-checks-list[_ngcontent-%COMP%]   .legal-check-card[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-start;\n  gap: 12px;\n  background: #f8fafc;\n  border: 1.5px solid #e2e8f0;\n  border-radius: 14px;\n  padding: 12px;\n  transition: all 0.15s ease;\n}\n.property-info-card[_ngcontent-%COMP%]   .legal-docs-section[_ngcontent-%COMP%]   .legal-checks-list[_ngcontent-%COMP%]   .legal-check-card.is-clear[_ngcontent-%COMP%] {\n  border-left: 4px solid #10b981;\n}\n.property-info-card[_ngcontent-%COMP%]   .legal-docs-section[_ngcontent-%COMP%]   .legal-checks-list[_ngcontent-%COMP%]   .legal-check-card.is-pending[_ngcontent-%COMP%] {\n  border-left: 4px solid #f59e0b;\n  background: #fffbeb;\n}\n.property-info-card[_ngcontent-%COMP%]   .legal-docs-section[_ngcontent-%COMP%]   .legal-checks-list[_ngcontent-%COMP%]   .legal-check-card[_ngcontent-%COMP%]   .check-icon-col[_ngcontent-%COMP%] {\n  flex-shrink: 0;\n  margin-top: 1px;\n}\n.property-info-card[_ngcontent-%COMP%]   .legal-docs-section[_ngcontent-%COMP%]   .legal-checks-list[_ngcontent-%COMP%]   .legal-check-card[_ngcontent-%COMP%]   .check-icon-col[_ngcontent-%COMP%]   .status-badge-circle[_ngcontent-%COMP%] {\n  width: 28px;\n  height: 28px;\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 17px;\n}\n.property-info-card[_ngcontent-%COMP%]   .legal-docs-section[_ngcontent-%COMP%]   .legal-checks-list[_ngcontent-%COMP%]   .legal-check-card[_ngcontent-%COMP%]   .check-icon-col[_ngcontent-%COMP%]   .status-badge-circle.clear[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  color: #10b981;\n}\n.property-info-card[_ngcontent-%COMP%]   .legal-docs-section[_ngcontent-%COMP%]   .legal-checks-list[_ngcontent-%COMP%]   .legal-check-card[_ngcontent-%COMP%]   .check-icon-col[_ngcontent-%COMP%]   .status-badge-circle.pending[_ngcontent-%COMP%] {\n  background: #fef3c7;\n  color: #d97706;\n}\n.property-info-card[_ngcontent-%COMP%]   .legal-docs-section[_ngcontent-%COMP%]   .legal-checks-list[_ngcontent-%COMP%]   .legal-check-card[_ngcontent-%COMP%]   .check-info-col[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 0;\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n}\n.property-info-card[_ngcontent-%COMP%]   .legal-docs-section[_ngcontent-%COMP%]   .legal-checks-list[_ngcontent-%COMP%]   .legal-check-card[_ngcontent-%COMP%]   .check-info-col[_ngcontent-%COMP%]   .check-title-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 8px;\n}\n.property-info-card[_ngcontent-%COMP%]   .legal-docs-section[_ngcontent-%COMP%]   .legal-checks-list[_ngcontent-%COMP%]   .legal-check-card[_ngcontent-%COMP%]   .check-info-col[_ngcontent-%COMP%]   .check-title-row[_ngcontent-%COMP%]   .check-doc-title[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-weight: 850;\n  color: #0f172a;\n  line-height: 1.25;\n}\n.property-info-card[_ngcontent-%COMP%]   .legal-docs-section[_ngcontent-%COMP%]   .legal-checks-list[_ngcontent-%COMP%]   .legal-check-card[_ngcontent-%COMP%]   .check-info-col[_ngcontent-%COMP%]   .check-title-row[_ngcontent-%COMP%]   .status-pill[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 850;\n  padding: 2px 7px;\n  border-radius: 6px;\n  white-space: nowrap;\n  flex-shrink: 0;\n}\n.property-info-card[_ngcontent-%COMP%]   .legal-docs-section[_ngcontent-%COMP%]   .legal-checks-list[_ngcontent-%COMP%]   .legal-check-card[_ngcontent-%COMP%]   .check-info-col[_ngcontent-%COMP%]   .check-title-row[_ngcontent-%COMP%]   .status-pill.clear[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  color: #059669;\n  border: 1px solid #a7f3d0;\n}\n.property-info-card[_ngcontent-%COMP%]   .legal-docs-section[_ngcontent-%COMP%]   .legal-checks-list[_ngcontent-%COMP%]   .legal-check-card[_ngcontent-%COMP%]   .check-info-col[_ngcontent-%COMP%]   .check-title-row[_ngcontent-%COMP%]   .status-pill.pending[_ngcontent-%COMP%] {\n  background: #fef3c7;\n  color: #b45309;\n  border: 1px solid #fde68a;\n}\n.property-info-card[_ngcontent-%COMP%]   .legal-docs-section[_ngcontent-%COMP%]   .legal-checks-list[_ngcontent-%COMP%]   .legal-check-card[_ngcontent-%COMP%]   .check-info-col[_ngcontent-%COMP%]   .check-doc-category[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 700;\n  color: #64748b;\n  text-transform: uppercase;\n  letter-spacing: 0.2px;\n}\n.property-info-card[_ngcontent-%COMP%]   .legal-docs-section[_ngcontent-%COMP%]   .legal-checks-list[_ngcontent-%COMP%]   .legal-check-card[_ngcontent-%COMP%]   .check-info-col[_ngcontent-%COMP%]   .check-doc-details[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  color: #475569;\n  line-height: 1.4;\n  margin: 4px 0 0;\n}\n.property-info-card[_ngcontent-%COMP%]   .legal-docs-section[_ngcontent-%COMP%]   .btn-toggle-docs[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 6px;\n  width: 100%;\n  height: 42px;\n  border-radius: 12px;\n  background: #f8fafc;\n  border: 1.5px solid #e2e8f0;\n  color: #a000e2;\n  font-size: 12.5px;\n  font-weight: 800;\n  cursor: pointer;\n  transition: all 0.15s ease;\n  margin-top: 4px;\n}\n.property-info-card[_ngcontent-%COMP%]   .legal-docs-section[_ngcontent-%COMP%]   .btn-toggle-docs[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 15px;\n}\n.property-info-card[_ngcontent-%COMP%]   .legal-docs-section[_ngcontent-%COMP%]   .btn-toggle-docs[_ngcontent-%COMP%]:active {\n  background: #f1f5f9;\n  transform: scale(0.98);\n}\n.property-info-card[_ngcontent-%COMP%]   .description-section[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n.property-info-card[_ngcontent-%COMP%]   .description-section[_ngcontent-%COMP%]   .description-text[_ngcontent-%COMP%] {\n  font-size: 13px;\n  line-height: 1.6;\n  color: #334155;\n  margin: 0;\n}\n.property-info-card[_ngcontent-%COMP%]   .amenities-section[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n  width: 100%;\n}\n.property-info-card[_ngcontent-%COMP%]   .amenities-section[_ngcontent-%COMP%]   .amenities-full-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 10px;\n  width: 100%;\n  box-sizing: border-box;\n}\n.property-info-card[_ngcontent-%COMP%]   .amenities-section[_ngcontent-%COMP%]   .amenities-full-grid[_ngcontent-%COMP%]   .amenity-grid-item[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  background: #f8fafc;\n  border: 1.5px solid #e2e8f0;\n  border-radius: 14px;\n  padding: 10px 12px;\n  width: 100%;\n  box-sizing: border-box;\n}\n.property-info-card[_ngcontent-%COMP%]   .amenities-section[_ngcontent-%COMP%]   .amenities-full-grid[_ngcontent-%COMP%]   .amenity-grid-item[_ngcontent-%COMP%]   .amenity-check-halo[_ngcontent-%COMP%] {\n  width: 26px;\n  height: 26px;\n  border-radius: 50%;\n  background: #ecfdf5;\n  color: #10b981;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 16px;\n  flex-shrink: 0;\n}\n.property-info-card[_ngcontent-%COMP%]   .amenities-section[_ngcontent-%COMP%]   .amenities-full-grid[_ngcontent-%COMP%]   .amenity-grid-item[_ngcontent-%COMP%]   .amenity-item-text[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 750;\n  color: #1e293b;\n  line-height: 1.3;\n}\n.property-info-card[_ngcontent-%COMP%]   .landmarks-section[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n}\n.property-info-card[_ngcontent-%COMP%]   .landmarks-section[_ngcontent-%COMP%]   .landmarks-list[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n.property-info-card[_ngcontent-%COMP%]   .landmarks-section[_ngcontent-%COMP%]   .landmarks-list[_ngcontent-%COMP%]   .landmark-item[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n  border-radius: 12px;\n  padding: 10px 12px;\n}\n.property-info-card[_ngcontent-%COMP%]   .landmarks-section[_ngcontent-%COMP%]   .landmarks-list[_ngcontent-%COMP%]   .landmark-item[_ngcontent-%COMP%]   .lm-left[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.property-info-card[_ngcontent-%COMP%]   .landmarks-section[_ngcontent-%COMP%]   .landmarks-list[_ngcontent-%COMP%]   .landmark-item[_ngcontent-%COMP%]   .lm-left[_ngcontent-%COMP%]   .lm-pin[_ngcontent-%COMP%] {\n  color: #a000e2;\n  font-size: 16px;\n}\n.property-info-card[_ngcontent-%COMP%]   .landmarks-section[_ngcontent-%COMP%]   .landmarks-list[_ngcontent-%COMP%]   .landmark-item[_ngcontent-%COMP%]   .lm-left[_ngcontent-%COMP%]   .lm-name[_ngcontent-%COMP%] {\n  font-size: 12.5px;\n  font-weight: 750;\n  color: #1e293b;\n}\n.property-info-card[_ngcontent-%COMP%]   .landmarks-section[_ngcontent-%COMP%]   .landmarks-list[_ngcontent-%COMP%]   .landmark-item[_ngcontent-%COMP%]   .lm-distance[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  font-weight: 800;\n  color: #059669;\n  background: #ecfdf5;\n  padding: 2px 8px;\n  border-radius: 6px;\n}\n.property-info-card[_ngcontent-%COMP%]   .seller-card[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #fdf4ff 0%,\n      #faf5ff 100%);\n  border: 1.5px solid #f5d0fe;\n  border-radius: 18px;\n  padding: 14px;\n  display: flex;\n  align-items: center;\n  gap: 12px;\n}\n.property-info-card[_ngcontent-%COMP%]   .seller-card[_ngcontent-%COMP%]   .seller-avatar-wrap[_ngcontent-%COMP%] {\n  width: 48px;\n  height: 48px;\n  border-radius: 50%;\n  background:\n    linear-gradient(\n      135deg,\n      #a000e2 0%,\n      #7e00b3 100%);\n  color: #ffffff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 20px;\n  font-weight: 900;\n  flex-shrink: 0;\n  box-shadow: 0 4px 10px rgba(160, 0, 226, 0.25);\n}\n.property-info-card[_ngcontent-%COMP%]   .seller-card[_ngcontent-%COMP%]   .seller-details-col[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 0;\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n}\n.property-info-card[_ngcontent-%COMP%]   .seller-card[_ngcontent-%COMP%]   .seller-details-col[_ngcontent-%COMP%]   .seller-title-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n}\n.property-info-card[_ngcontent-%COMP%]   .seller-card[_ngcontent-%COMP%]   .seller-details-col[_ngcontent-%COMP%]   .seller-title-row[_ngcontent-%COMP%]   .seller-name[_ngcontent-%COMP%] {\n  font-size: 14.5px;\n  font-weight: 850;\n  color: #0f172a;\n  margin: 0;\n}\n.property-info-card[_ngcontent-%COMP%]   .seller-card[_ngcontent-%COMP%]   .seller-details-col[_ngcontent-%COMP%]   .seller-title-row[_ngcontent-%COMP%]   .seller-verified-badge[_ngcontent-%COMP%] {\n  background: #10b981;\n  color: #ffffff;\n  font-size: 9.5px;\n  font-weight: 800;\n  padding: 2px 6px;\n  border-radius: 4px;\n  display: inline-flex;\n  align-items: center;\n  gap: 2px;\n}\n.property-info-card[_ngcontent-%COMP%]   .seller-card[_ngcontent-%COMP%]   .seller-details-col[_ngcontent-%COMP%]   .seller-title-row[_ngcontent-%COMP%]   .seller-verified-badge[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 10px;\n}\n.property-info-card[_ngcontent-%COMP%]   .seller-card[_ngcontent-%COMP%]   .seller-details-col[_ngcontent-%COMP%]   .seller-type-text[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 600;\n  color: #64748b;\n}\n.bottom-action-spacer[_ngcontent-%COMP%] {\n  height: calc(110px + env(safe-area-inset-bottom, 0px));\n}\n.sticky-contact-footer[_ngcontent-%COMP%] {\n  position: fixed;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  z-index: 100;\n  background: #ffffff;\n  border-top: 1px solid #e2e8f0;\n  padding: 12px 14px max(env(safe-area-inset-bottom, 0px), 18px);\n  box-shadow: 0 -4px 18px rgba(15, 23, 42, 0.08);\n}\n.sticky-contact-footer[_ngcontent-%COMP%]   .sold-footer-notice[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  background: #f8fafc;\n  border: 1.5px dashed #cbd5e1;\n  border-radius: 14px;\n  padding: 10px 14px;\n  width: 100%;\n}\n.sticky-contact-footer[_ngcontent-%COMP%]   .sold-footer-notice[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 24px;\n  color: #64748b;\n  flex-shrink: 0;\n}\n.sticky-contact-footer[_ngcontent-%COMP%]   .sold-footer-notice[_ngcontent-%COMP%]   .sold-notice-text[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n  min-width: 0;\n}\n.sticky-contact-footer[_ngcontent-%COMP%]   .sold-footer-notice[_ngcontent-%COMP%]   .sold-notice-text[_ngcontent-%COMP%]   .sold-notice-title[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  font-weight: 800;\n  color: #334155;\n}\n.sticky-contact-footer[_ngcontent-%COMP%]   .sold-footer-notice[_ngcontent-%COMP%]   .sold-notice-text[_ngcontent-%COMP%]   .sold-notice-sub[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #64748b;\n  font-weight: 500;\n}\n.sticky-contact-footer[_ngcontent-%COMP%]   .footer-actions-grid[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  width: 100%;\n}\n.sticky-contact-footer[_ngcontent-%COMP%]   .footer-actions-grid[_ngcontent-%COMP%]   .btn-footer-action[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 0;\n  height: 48px;\n  border-radius: 14px;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  gap: 5px;\n  font-size: 13px;\n  font-weight: 800;\n  cursor: pointer;\n  white-space: nowrap;\n  transition: all 0.15s ease;\n}\n.sticky-contact-footer[_ngcontent-%COMP%]   .footer-actions-grid[_ngcontent-%COMP%]   .btn-footer-action[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 17px;\n  flex-shrink: 0;\n}\n.sticky-contact-footer[_ngcontent-%COMP%]   .footer-actions-grid[_ngcontent-%COMP%]   .btn-footer-action[_ngcontent-%COMP%]:active {\n  transform: scale(0.96);\n}\n.sticky-contact-footer[_ngcontent-%COMP%]   .footer-actions-grid[_ngcontent-%COMP%]   .btn-footer-action.btn-callback[_ngcontent-%COMP%] {\n  background: #fdf4ff;\n  border: 1.5px solid #f5d0fe;\n  color: #a000e2;\n}\n.sticky-contact-footer[_ngcontent-%COMP%]   .footer-actions-grid[_ngcontent-%COMP%]   .btn-footer-action.btn-call[_ngcontent-%COMP%] {\n  background: #f8fafc;\n  border: 1.5px solid #e2e8f0;\n  color: #0f172a;\n}\n.sticky-contact-footer[_ngcontent-%COMP%]   .footer-actions-grid[_ngcontent-%COMP%]   .btn-footer-action.btn-whatsapp[_ngcontent-%COMP%] {\n  background: #25d366;\n  border: none;\n  color: #ffffff;\n  box-shadow: 0 3px 10px rgba(37, 211, 102, 0.28);\n}\n.property-video-modal[_ngcontent-%COMP%] {\n  --background: transparent;\n  --box-shadow: none;\n  --backdrop-opacity: 0.85;\n  --width: min(94vw, 640px);\n  --max-width: 640px;\n  --height: auto;\n  --border-radius: 20px;\n}\n.property-video-modal[_ngcontent-%COMP%]::part(content) {\n  border-radius: 20px;\n  overflow: hidden;\n  background: #000000;\n  border: 1px solid rgba(255, 255, 255, 0.15);\n  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.85);\n  width: min(94vw, 640px);\n  max-width: 640px;\n  height: auto;\n  aspect-ratio: 16/9;\n  margin: auto;\n}\n.property-video-modal.is-reel[_ngcontent-%COMP%] {\n  --width: min(calc(88vh * (9 / 16)), 92vw, 420px);\n  --max-width: 92vw;\n  --height: min(88vh, calc(92vw * (16 / 9)));\n  --max-height: 88vh;\n  --border-radius: 24px;\n}\n.property-video-modal.is-reel[_ngcontent-%COMP%]::part(content) {\n  width: min(49.5vh, 92vw, 420px);\n  max-width: 92vw;\n  height: min(88vh, 163.5555555556vw);\n  max-height: 88vh;\n  aspect-ratio: 9/16;\n  border-radius: 24px;\n}\n.property-video-modal[_ngcontent-%COMP%]   .video-card-wrapper[_ngcontent-%COMP%] {\n  position: relative;\n  width: 100%;\n  height: 100%;\n  background: #000000;\n  overflow: hidden;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.property-video-modal[_ngcontent-%COMP%]   .video-card-wrapper[_ngcontent-%COMP%]   .video-overlay-close-btn[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 12px;\n  right: 12px;\n  z-index: 30;\n  width: 36px;\n  height: 36px;\n  border-radius: 50%;\n  background: rgba(15, 23, 42, 0.65);\n  backdrop-filter: blur(8px);\n  -webkit-backdrop-filter: blur(8px);\n  border: 1px solid rgba(255, 255, 255, 0.25);\n  color: #ffffff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 20px;\n  cursor: pointer;\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);\n  transition: transform 0.15s ease, background 0.15s ease;\n}\n.property-video-modal[_ngcontent-%COMP%]   .video-card-wrapper[_ngcontent-%COMP%]   .video-overlay-close-btn[_ngcontent-%COMP%]:active {\n  transform: scale(0.9);\n  background: rgba(15, 23, 42, 0.9);\n}\n.property-video-modal[_ngcontent-%COMP%]   .video-card-wrapper[_ngcontent-%COMP%]   .video-aspect-pill[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 12px;\n  left: 12px;\n  z-index: 30;\n  height: 30px;\n  padding: 0 10px;\n  border-radius: 999px;\n  background: rgba(15, 23, 42, 0.7);\n  backdrop-filter: blur(10px);\n  -webkit-backdrop-filter: blur(10px);\n  border: 1px solid rgba(255, 255, 255, 0.25);\n  color: #f8fafc;\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  cursor: pointer;\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);\n  transition: transform 0.15s ease, background 0.15s ease;\n}\n.property-video-modal[_ngcontent-%COMP%]   .video-card-wrapper[_ngcontent-%COMP%]   .video-aspect-pill[_ngcontent-%COMP%]   .res-tag[_ngcontent-%COMP%] {\n  font-size: 9px;\n  font-weight: 850;\n  letter-spacing: 0.6px;\n  background: #a000e2;\n  color: #ffffff;\n  padding: 2px 5px;\n  border-radius: 6px;\n}\n.property-video-modal[_ngcontent-%COMP%]   .video-card-wrapper[_ngcontent-%COMP%]   .video-aspect-pill[_ngcontent-%COMP%]   .res-value[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  font-weight: 750;\n  letter-spacing: 0.3px;\n  color: #f1f5f9;\n}\n.property-video-modal[_ngcontent-%COMP%]   .video-card-wrapper[_ngcontent-%COMP%]   .video-aspect-pill[_ngcontent-%COMP%]:active {\n  transform: scale(0.92);\n  background: rgba(15, 23, 42, 0.9);\n}\n.property-video-modal[_ngcontent-%COMP%]   .video-card-wrapper[_ngcontent-%COMP%]   .video-frame-box[_ngcontent-%COMP%] {\n  position: relative;\n  width: 100%;\n  height: 100%;\n  overflow: hidden;\n  background: #000000;\n  border-radius: inherit;\n}\n.property-video-modal[_ngcontent-%COMP%]   .video-card-wrapper[_ngcontent-%COMP%]   .video-frame-box[_ngcontent-%COMP%]   .video-iframe[_ngcontent-%COMP%] {\n  position: absolute;\n  top: -48px;\n  left: -2px;\n  width: calc(100% + 4px);\n  height: calc(100% + 54px);\n  border: 0;\n  display: block;\n}\n.property-video-modal[_ngcontent-%COMP%]   .video-card-wrapper[_ngcontent-%COMP%]   .video-frame-box.is-reel[_ngcontent-%COMP%]   .video-iframe[_ngcontent-%COMP%] {\n  top: -50px;\n  left: -2px;\n  width: calc(100% + 4px);\n  height: calc(100% + 58px);\n}\n.property-video-modal[_ngcontent-%COMP%]   .video-card-wrapper[_ngcontent-%COMP%]   .video-frame-box[_ngcontent-%COMP%]   .top-branding-blocker[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  height: 52px;\n  background:\n    linear-gradient(\n      to bottom,\n      rgba(0, 0, 0, 0.95) 0%,\n      rgba(0, 0, 0, 0.6) 45%,\n      rgba(0, 0, 0, 0) 100%);\n  pointer-events: none;\n  z-index: 10;\n}\n.property-video-modal[_ngcontent-%COMP%]   .video-card-wrapper[_ngcontent-%COMP%]   .video-frame-box[_ngcontent-%COMP%]   .iframe-touch-shield[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  z-index: 15;\n  background: transparent;\n  cursor: pointer;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.property-video-modal[_ngcontent-%COMP%]   .video-card-wrapper[_ngcontent-%COMP%]   .video-frame-box[_ngcontent-%COMP%]   .iframe-touch-shield[_ngcontent-%COMP%]   .play-pause-feedback[_ngcontent-%COMP%] {\n  width: 60px;\n  height: 60px;\n  border-radius: 50%;\n  background: rgba(15, 23, 42, 0.75);\n  backdrop-filter: blur(10px);\n  -webkit-backdrop-filter: blur(10px);\n  border: 1.5px solid rgba(255, 255, 255, 0.3);\n  color: #ffffff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 28px;\n  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.5);\n  pointer-events: none;\n}\n.property-video-modal[_ngcontent-%COMP%]   .video-card-wrapper[_ngcontent-%COMP%]   .video-frame-box[_ngcontent-%COMP%]   .no-video-box[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  padding: 20px;\n  text-align: center;\n  color: #94a3b8;\n  font-size: 14px;\n}\n/*# sourceMappingURL=property-details.page.css.map */"] });
var PropertyDetailsPage = _PropertyDetailsPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(PropertyDetailsPage, { className: "PropertyDetailsPage", filePath: "src/app/pages/property-details/property-details.page.ts", lineNumber: 70 });
})();
export {
  PropertyDetailsPage
};
//# sourceMappingURL=property-details.page-BRPSGJ66.js.map
