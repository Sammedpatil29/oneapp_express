import {
  ErrorComponent
} from "./chunk-WSTY3NBK.js";
import {
  ProductCardComponent
} from "./chunk-PCADZWYU.js";
import {
  GroceryService
} from "./chunk-UOJDERHI.js";
import {
  LocationService
} from "./chunk-4TQR4WSH.js";
import "./chunk-V444GY6B.js";
import "./chunk-QH3WR2OQ.js";
import {
  add,
  addIcons,
  caretForwardOutline,
  chevronDownOutline,
  homeOutline,
  remove,
  search,
  timeOutline
} from "./chunk-V2INQVNG.js";
import {
  AuthService
} from "./chunk-EB6T6TPT.js";
import "./chunk-OE5MTPUR.js";
import "./chunk-YJYUHAOC.js";
import "./chunk-XR3JUECC.js";
import {
  IonContent,
  IonHeader,
  IonIcon,
  IonSkeletonText,
  IonToolbar
} from "./chunk-CJE2NDTY.js";
import {
  ChangeDetectorRef,
  CommonModule,
  FormsModule,
  NavController,
  NgForOf,
  Router,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵstyleProp,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate
} from "./chunk-Z7XNNJSA.js";
import "./chunk-FH4NU4VH.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/grocery/grocery.page.ts
var _c0 = () => [1, 2, 3];
var _c1 = () => [1, 2, 3, 4, 5, 6, 7, 8];
var _c2 = () => [1, 2];
function GroceryPage_Conditional_17_div_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 22);
    \u0275\u0275element(1, "ion-skeleton-text", 23);
    \u0275\u0275elementEnd();
  }
}
function GroceryPage_Conditional_17_div_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 24)(1, "div", 25);
    \u0275\u0275element(2, "ion-skeleton-text", 26);
    \u0275\u0275elementEnd();
    \u0275\u0275element(3, "ion-skeleton-text", 27);
    \u0275\u0275elementEnd();
  }
}
function GroceryPage_Conditional_17_div_7_div_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 35);
    \u0275\u0275element(1, "ion-skeleton-text", 36)(2, "ion-skeleton-text", 37)(3, "ion-skeleton-text", 38);
    \u0275\u0275elementStart(4, "div", 39);
    \u0275\u0275element(5, "ion-skeleton-text", 40)(6, "ion-skeleton-text", 41);
    \u0275\u0275elementEnd()();
  }
}
function GroceryPage_Conditional_17_div_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 28)(1, "div", 29)(2, "div", 30);
    \u0275\u0275element(3, "ion-skeleton-text", 31)(4, "ion-skeleton-text", 32);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "div", 33);
    \u0275\u0275template(6, GroceryPage_Conditional_17_div_7_div_6_Template, 7, 0, "div", 34);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(6);
    \u0275\u0275property("ngForOf", \u0275\u0275pureFunction0(1, _c0));
  }
}
function GroceryPage_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div")(1, "div", 15);
    \u0275\u0275template(2, GroceryPage_Conditional_17_div_2_Template, 2, 0, "div", 16);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 17);
    \u0275\u0275element(4, "ion-skeleton-text", 18);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 19);
    \u0275\u0275template(6, GroceryPage_Conditional_17_div_6_Template, 4, 0, "div", 20);
    \u0275\u0275elementEnd();
    \u0275\u0275template(7, GroceryPage_Conditional_17_div_7_Template, 7, 2, "div", 21);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance(2);
    \u0275\u0275property("ngForOf", \u0275\u0275pureFunction0(3, _c0));
    \u0275\u0275advance(4);
    \u0275\u0275property("ngForOf", \u0275\u0275pureFunction0(4, _c1));
    \u0275\u0275advance();
    \u0275\u0275property("ngForOf", \u0275\u0275pureFunction0(5, _c2));
  }
}
function GroceryPage_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "app-error", 42);
    \u0275\u0275listener("reload", function GroceryPage_Conditional_18_Template_app_error_reload_0_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.getGroceryHomeData());
    });
    \u0275\u0275elementEnd();
  }
}
function GroceryPage_Conditional_19_div_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 46);
    \u0275\u0275listener("click", function GroceryPage_Conditional_19_div_2_Template_div_click_0_listener() {
      const banner_r4 = \u0275\u0275restoreView(_r3).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.goToSpecialCategory(banner_r4.term));
    });
    \u0275\u0275element(1, "img", 47);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const banner_r4 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275property("src", banner_r4.img, \u0275\u0275sanitizeUrl);
  }
}
function GroceryPage_Conditional_19_div_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 48);
    \u0275\u0275listener("click", function GroceryPage_Conditional_19_div_7_Template_div_click_0_listener() {
      const cat_r6 = \u0275\u0275restoreView(_r5).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.goToGrocerybyCategory(cat_r6.name));
    });
    \u0275\u0275elementStart(1, "div", 49);
    \u0275\u0275element(2, "img", 50);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const cat_r6 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275styleProp("background", cat_r6.bg);
    \u0275\u0275advance();
    \u0275\u0275property("src", cat_r6.img, \u0275\u0275sanitizeUrl);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(cat_r6.name);
  }
}
function GroceryPage_Conditional_19_div_8_app_product_card_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "app-product-card", 53);
    \u0275\u0275listener("increase", function GroceryPage_Conditional_19_div_8_app_product_card_10_Template_app_product_card_increase_0_listener($event) {
      \u0275\u0275restoreView(_r9);
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.increase($event));
    })("decrease", function GroceryPage_Conditional_19_div_8_app_product_card_10_Template_app_product_card_decrease_0_listener($event) {
      \u0275\u0275restoreView(_r9);
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.decrease($event));
    })("itemClicked", function GroceryPage_Conditional_19_div_8_app_product_card_10_Template_app_product_card_itemClicked_0_listener($event) {
      \u0275\u0275restoreView(_r9);
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.goToDetails($event));
    });
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const p_r10 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275property("product", p_r10)("qty", ctx_r1.getQty(p_r10.id));
  }
}
function GroceryPage_Conditional_19_div_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 28)(1, "div", 29)(2, "div")(3, "h4");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "small");
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "span", 51);
    \u0275\u0275listener("click", function GroceryPage_Conditional_19_div_8_Template_span_click_7_listener() {
      const section_r8 = \u0275\u0275restoreView(_r7).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.goToSpecialCategory(section_r8.term));
    });
    \u0275\u0275text(8, "See all");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "div", 33);
    \u0275\u0275template(10, GroceryPage_Conditional_19_div_8_app_product_card_10_Template, 1, 2, "app-product-card", 52);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const section_r8 = ctx.$implicit;
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(section_r8.title);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(section_r8.subtitle);
    \u0275\u0275advance(4);
    \u0275\u0275property("ngForOf", section_r8.products);
  }
}
function GroceryPage_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div")(1, "div", 15);
    \u0275\u0275template(2, GroceryPage_Conditional_19_div_2_Template, 2, 1, "div", 43);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 17)(4, "h4");
    \u0275\u0275text(5, "Explore by Category");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "div", 19);
    \u0275\u0275template(7, GroceryPage_Conditional_19_div_7_Template, 5, 4, "div", 44);
    \u0275\u0275elementEnd();
    \u0275\u0275template(8, GroceryPage_Conditional_19_div_8_Template, 11, 3, "div", 21);
    \u0275\u0275element(9, "div", 45);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(2);
    \u0275\u0275property("ngForOf", ctx_r1.corousalBanners);
    \u0275\u0275advance(5);
    \u0275\u0275property("ngForOf", ctx_r1.categories);
    \u0275\u0275advance();
    \u0275\u0275property("ngForOf", ctx_r1.productSections);
  }
}
var _GroceryPage = class _GroceryPage {
  constructor(router, cartService, authService, cdr, navCtrl, locationService) {
    this.router = router;
    this.cartService = cartService;
    this.authService = authService;
    this.cdr = cdr;
    this.navCtrl = navCtrl;
    this.locationService = locationService;
    this.deliveryTime = "Delivery Location";
    this.isLoading = false;
    this.isError = false;
    this.cartItems = [];
    this.banners = [
      {
        title: "50% OFF",
        subtitle: "On First Order",
        img: "https://cdn-icons-png.flaticon.com/512/3081/3081986.png",
        bg: "linear-gradient(to right, #6a11cb 0%, #2575fc 100%)",
        term: "under_100"
      },
      {
        title: "Fresh",
        subtitle: "Vegetables",
        img: "https://cdn-icons-png.flaticon.com/512/2909/2909808.png",
        bg: "linear-gradient(to right, #ff9966 0%, #ff5e62 100%)",
        term: "new_arrivals"
      }
    ];
    this.categories = [];
    this.productSections = [];
    this.corousalBanners = [];
    this.miniBanner = [];
    addIcons({
      chevronDownOutline,
      homeOutline,
      search,
      timeOutline,
      caretForwardOutline,
      add,
      remove
    });
  }
  ngOnInit() {
    return __async(this, null, function* () {
      this.token = yield this.authService.getToken();
      this.locationService.location$.subscribe((res) => {
        this.currentLocation = res;
      });
      this.cartService.cart$.subscribe((items) => {
        this.cartItems = items;
        console.log("\u{1F6D2} UI Cart Updated:", this.cartItems);
        this.cdr.detectChanges();
      });
      this.getGroceryHomeData();
    });
  }
  ngOnDestroy() {
  }
  // --- ACTIONS ---
  increase(productId) {
    this.cartService.increaseQty(productId, this.token).subscribe({
      next: () => console.log("Increase Success"),
      error: (err) => console.error("API Failed", err)
    });
  }
  decrease(productId) {
    var _a;
    (_a = this.cartService.decreaseQty(productId, this.token)) == null ? void 0 : _a.subscribe({
      next: () => console.log("Decrease Success"),
      error: (err) => console.error("API Failed", err)
    });
  }
  // --- HELPERS ---
  getQty(productId) {
    if (!this.cartItems || this.cartItems.length === 0)
      return 0;
    const item = this.cartItems.find((i) => String(i.productId) === String(productId));
    return item ? item.quantity : 0;
  }
  gotoSearch() {
    this.navCtrl.navigateForward("/layout/grocery-layout/grocery-search");
  }
  goToSpecialCategory(term) {
    this.navCtrl.navigateForward("/layout/grocery-layout/grocery-special", {
      state: { term }
    });
  }
  goToGrocerybyCategory(catName) {
    this.navCtrl.navigateForward("/layout/grocery-layout/grocery-by-category", {
      state: { category: catName }
    });
  }
  goToDetails(product) {
    this.navCtrl.navigateForward(`/layout/grocery-layout/grocery-item-details/${product == null ? void 0 : product.id}`, {
      state: { productId: product == null ? void 0 : product.id }
    });
  }
  goToCart() {
    this.navCtrl.navigateForward("/layout/grocery-layout/cart");
  }
  goToHome() {
    this.navCtrl.navigateForward("/layout/example/home");
  }
  getGroceryHomeData() {
    this.isLoading = true;
    this.isError = false;
    this.cartService.getCartItems(this.token).subscribe({
      next: (res) => {
        if (res.data) {
          this.categories = res.data.categories;
          this.productSections = res.data.productSections;
          this.corousalBanners = res.data.carouselBanners;
          this.miniBanner = res.data.miniBanner;
          this.cdr.detectChanges();
          this.isLoading = false;
        }
      },
      error: (err) => {
        console.error("API Failed", err);
        this.isLoading = false;
        this.isError = true;
      }
    });
  }
  openLocation() {
    this.navCtrl.navigateForward("/layout/address-list", {
      state: { data: "grocery" }
    });
  }
};
_GroceryPage.\u0275fac = function GroceryPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _GroceryPage)(\u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(GroceryService), \u0275\u0275directiveInject(AuthService), \u0275\u0275directiveInject(ChangeDetectorRef), \u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(LocationService));
};
_GroceryPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _GroceryPage, selectors: [["app-grocery"]], decls: 20, vars: 5, consts: [[1, "ion-no-border"], [1, "header-toolbar", "pt-5"], [1, "header-top"], [1, "location-box"], [1, "brand-time"], [1, "address-row", 3, "click"], ["name", "chevron-down-outline"], ["name", "home-outline", 1, "profile-icon", "pe-3", 3, "click"], [1, "search-container", 2, "display", "flex", "align-items", "stretch", "gap", "10px", "padding-right", "0", "margin-right", "0"], [1, "search-box", 2, "flex", "1", 3, "click"], ["name", "search"], ["type", "text", "placeholder", 'Search "milk"', "readonly", ""], [2, "width", "auto", "height", "50px", "border-radius", "8px 0px 0px 8px", "object-fit", "cover", 3, "click", "src"], [1, "bg-light", 3, "fullscreen"], ["title", "Oops! Home page failed to load"], [1, "banner-scroll"], ["style", "margin-right: 16px; flex-shrink: 0;", 4, "ngFor", "ngForOf"], [1, "section-title"], ["animated", "", 2, "width", "150px", "height", "24px", "border-radius", "4px"], [1, "category-grid"], ["class", "cat-item", 4, "ngFor", "ngForOf"], ["class", "product-section", 4, "ngFor", "ngForOf"], [2, "margin-right", "16px", "flex-shrink", "0"], ["animated", "", 2, "width", "320px", "height", "160px", "border-radius", "16px"], [1, "cat-item"], [1, "cat-img", 2, "background", "transparent"], ["animated", "", 2, "width", "100%", "height", "100%", "border-radius", "50%"], ["animated", "", 2, "width", "60px", "height", "12px", "margin-top", "8px", "border-radius", "4px"], [1, "product-section"], [1, "section-header"], [2, "width", "100%"], ["animated", "", 2, "width", "120px", "height", "20px", "border-radius", "4px", "margin-bottom", "4px"], ["animated", "", 2, "width", "80px", "height", "14px", "border-radius", "4px"], [1, "product-scroll"], ["style", "width: 150px; margin-right: 12px; flex-shrink: 0;", 4, "ngFor", "ngForOf"], [2, "width", "150px", "margin-right", "12px", "flex-shrink", "0"], ["animated", "", 2, "width", "100%", "height", "150px", "border-radius", "12px"], ["animated", "", 2, "width", "90%", "height", "14px", "margin-top", "8px", "border-radius", "4px"], ["animated", "", 2, "width", "60%", "height", "14px", "margin-top", "4px", "border-radius", "4px"], [1, "d-flex", "justify-content-between", "align-items-center", "mt-2"], ["animated", "", 2, "width", "40%", "height", "18px", "border-radius", "4px"], ["animated", "", 2, "width", "60px", "height", "30px", "border-radius", "6px"], ["title", "Oops! Home page failed to load", 3, "reload"], [3, "click", 4, "ngFor", "ngForOf"], ["class", "cat-item", 3, "click", 4, "ngFor", "ngForOf"], [2, "height", "100px"], [3, "click"], ["alt", "", 1, "banner", "p-0", 3, "src"], [1, "cat-item", 3, "click"], [1, "cat-img"], [3, "src"], [1, "see-all", 3, "click"], [3, "product", "qty", "increase", "decrease", "itemClicked", 4, "ngFor", "ngForOf"], [3, "increase", "decrease", "itemClicked", "product", "qty"]], template: function GroceryPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar", 1)(2, "div", 2)(3, "div", 3)(4, "h2", 4);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "div", 5);
    \u0275\u0275listener("click", function GroceryPage_Template_div_click_6_listener() {
      return ctx.openLocation();
    });
    \u0275\u0275elementStart(7, "small");
    \u0275\u0275text(8);
    \u0275\u0275elementEnd();
    \u0275\u0275element(9, "ion-icon", 6);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(10, "ion-icon", 7);
    \u0275\u0275listener("click", function GroceryPage_Template_ion_icon_click_10_listener() {
      return ctx.goToHome();
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(11, "div", 8)(12, "div", 9);
    \u0275\u0275listener("click", function GroceryPage_Template_div_click_12_listener() {
      return ctx.gotoSearch();
    });
    \u0275\u0275element(13, "ion-icon", 10)(14, "input", 11);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "img", 12);
    \u0275\u0275listener("click", function GroceryPage_Template_img_click_15_listener() {
      return ctx.goToSpecialCategory(ctx.miniBanner.term);
    });
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(16, "ion-content", 13);
    \u0275\u0275template(17, GroceryPage_Conditional_17_Template, 8, 6, "div")(18, GroceryPage_Conditional_18_Template, 1, 0, "app-error", 14)(19, GroceryPage_Conditional_19_Template, 10, 3, "div");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx.deliveryTime);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx.currentLocation == null ? null : ctx.currentLocation.address);
    \u0275\u0275advance(7);
    \u0275\u0275property("src", ctx.miniBanner == null ? null : ctx.miniBanner.img, \u0275\u0275sanitizeUrl);
    \u0275\u0275advance();
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.isLoading ? 17 : ctx.isError ? 18 : 19);
  }
}, dependencies: [
  IonSkeletonText,
  IonIcon,
  IonToolbar,
  IonHeader,
  IonContent,
  CommonModule,
  NgForOf,
  FormsModule,
  ProductCardComponent,
  ErrorComponent
], styles: ["\n\nion-content[_ngcontent-%COMP%] {\n  --background: #f5f7fd;\n}\n.header-toolbar[_ngcontent-%COMP%] {\n  --background: #fff;\n  padding: 10px 0px 15px 15px;\n  display: flex;\n  flex-direction: column;\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.03);\n}\n.header-toolbar[_ngcontent-%COMP%]   .header-top[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 15px;\n}\n.header-toolbar[_ngcontent-%COMP%]   .header-top[_ngcontent-%COMP%]   .brand-time[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 22px;\n  font-weight: 900;\n  color: #000;\n  letter-spacing: -0.5px;\n}\n.header-toolbar[_ngcontent-%COMP%]   .header-top[_ngcontent-%COMP%]   .address-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 5px;\n}\n.header-toolbar[_ngcontent-%COMP%]   .header-top[_ngcontent-%COMP%]   .address-row[_ngcontent-%COMP%]   small[_ngcontent-%COMP%] {\n  font-weight: 500;\n  color: #555;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  max-width: 200px;\n  font-size: 11px;\n}\n.header-toolbar[_ngcontent-%COMP%]   .header-top[_ngcontent-%COMP%]   .profile-icon[_ngcontent-%COMP%] {\n  font-size: 22px;\n  color: #333;\n}\n.header-toolbar[_ngcontent-%COMP%]   .search-container[_ngcontent-%COMP%]   .search-box[_ngcontent-%COMP%] {\n  background: #f1f2f6;\n  border-radius: 12px;\n  padding: 12px;\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  border: 1px solid #e1e1e1;\n}\n.header-toolbar[_ngcontent-%COMP%]   .search-container[_ngcontent-%COMP%]   .search-box[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  color: #a000e2;\n  font-size: 20px;\n}\n.header-toolbar[_ngcontent-%COMP%]   .search-container[_ngcontent-%COMP%]   .search-box[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  border: none;\n  background: transparent;\n  width: 100%;\n  outline: none;\n  font-size: 15px;\n  color: #333;\n}\n.header-toolbar[_ngcontent-%COMP%]   .search-container[_ngcontent-%COMP%]   .search-box[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]::placeholder {\n  color: #999;\n}\n.banner-scroll[_ngcontent-%COMP%] {\n  display: flex;\n  overflow-x: auto;\n  gap: 15px;\n  padding: 15px;\n}\n.banner-scroll[_ngcontent-%COMP%]::-webkit-scrollbar {\n  display: none;\n}\n.banner-scroll[_ngcontent-%COMP%]   .banner[_ngcontent-%COMP%] {\n  min-width: 280px;\n  height: 140px;\n  border-radius: 16px;\n  position: relative;\n  padding: 20px;\n  color: white;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n.banner-scroll[_ngcontent-%COMP%]   .banner[_ngcontent-%COMP%]   .text[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin: 0;\n  font-weight: 800;\n  font-size: 24px;\n  line-height: 1.1;\n}\n.banner-scroll[_ngcontent-%COMP%]   .banner[_ngcontent-%COMP%]   .text[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 5px 0 0;\n  opacity: 0.9;\n  font-size: 12px;\n}\n.section-title[_ngcontent-%COMP%] {\n  padding: 0 15px;\n  margin-top: 10px;\n}\n.section-title[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  font-weight: 800;\n  font-size: 18px;\n  margin: 0;\n  color: #222;\n}\n.category-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(4, 1fr);\n  gap: 15px;\n  padding: 15px;\n}\n.category-grid[_ngcontent-%COMP%]   .cat-item[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  gap: 6px;\n}\n.category-grid[_ngcontent-%COMP%]   .cat-item[_ngcontent-%COMP%]   .cat-img[_ngcontent-%COMP%] {\n  width: 100%;\n  aspect-ratio: 1;\n  border-radius: 14px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  background: white;\n}\n.category-grid[_ngcontent-%COMP%]   .cat-item[_ngcontent-%COMP%]   .cat-img[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 60%;\n}\n.category-grid[_ngcontent-%COMP%]   .cat-item[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 600;\n  color: #444;\n}\n.product-section[_ngcontent-%COMP%] {\n  padding-bottom: 20px;\n}\n.product-section[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 0 15px 15px;\n}\n.product-section[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  margin: 0;\n  font-weight: 700;\n  font-size: 17px;\n  color: #222;\n}\n.product-section[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]   small[_ngcontent-%COMP%] {\n  color: #888;\n  font-size: 12px;\n  display: block;\n  margin-top: 2px;\n}\n.product-section[_ngcontent-%COMP%]   .section-header[_ngcontent-%COMP%]   .see-all[_ngcontent-%COMP%] {\n  color: #a000e2;\n  font-weight: 700;\n  font-size: 13px;\n}\n.product-section[_ngcontent-%COMP%]   .product-scroll[_ngcontent-%COMP%] {\n  display: flex;\n  overflow-x: auto;\n  padding: 0 15px;\n  gap: 12px;\n  scroll-behavior: smooth;\n}\n.product-section[_ngcontent-%COMP%]   .product-scroll[_ngcontent-%COMP%]::-webkit-scrollbar {\n  display: none;\n}\n.product-section[_ngcontent-%COMP%]   .product-scroll[_ngcontent-%COMP%]   app-product-card[_ngcontent-%COMP%] {\n  flex: 0 0 145px;\n  width: 145px;\n}\n.product-card[_ngcontent-%COMP%] {\n  min-width: 140px;\n  max-width: 140px;\n  background: white;\n  border-radius: 16px;\n  padding: 10px;\n  border: 1px solid #f0f0f0;\n  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.02);\n}\n.product-card[_ngcontent-%COMP%]   .img-wrapper[_ngcontent-%COMP%] {\n  position: relative;\n  height: 90px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  margin-bottom: 5px;\n}\n.product-card[_ngcontent-%COMP%]   .img-wrapper[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  max-height: 80px;\n  max-width: 100%;\n  object-fit: contain;\n}\n.product-card[_ngcontent-%COMP%]   .img-wrapper[_ngcontent-%COMP%]   .discount[_ngcontent-%COMP%] {\n  position: absolute;\n  top: -5px;\n  left: -5px;\n  background: #5c6bc0;\n  color: white;\n  font-size: 9px;\n  padding: 3px 6px;\n  border-radius: 4px 0 6px 0;\n  font-weight: 700;\n}\n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   .time-tag[_ngcontent-%COMP%] {\n  background: #f5f5f5;\n  width: fit-content;\n  font-size: 9px;\n  padding: 2px 5px;\n  border-radius: 4px;\n  font-weight: 700;\n  color: #555;\n  display: flex;\n  align-items: center;\n  gap: 3px;\n}\n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   .time-tag[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 10px;\n}\n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-weight: 600;\n  margin: 6px 0 2px;\n  color: #222;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   small[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #888;\n  font-weight: 500;\n}\n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   .price-row[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-end;\n  margin-top: 10px;\n}\n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   .price-row[_ngcontent-%COMP%]   .prices[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   .price-row[_ngcontent-%COMP%]   .prices[_ngcontent-%COMP%]   .current[_ngcontent-%COMP%] {\n  font-weight: 700;\n  font-size: 13px;\n  color: #222;\n}\n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   .price-row[_ngcontent-%COMP%]   .prices[_ngcontent-%COMP%]   .original[_ngcontent-%COMP%] {\n  font-size: 10px;\n  color: #999;\n  text-decoration: line-through;\n}\n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   .price-row[_ngcontent-%COMP%]   .add-btn[_ngcontent-%COMP%] {\n  background: white;\n  color: #a000e2;\n  border: 1px solid #a000e2;\n  border-radius: 6px;\n  padding: 5px 12px;\n  font-weight: 800;\n  font-size: 12px;\n  box-shadow: 0 2px 5px rgba(255, 50, 105, 0.1);\n  text-transform: uppercase;\n}\n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   .price-row[_ngcontent-%COMP%]   .qty-counter[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  background: #a000e2;\n  border-radius: 6px;\n  height: 28px;\n  box-shadow: 0 2px 5px rgba(255, 50, 105, 0.3);\n}\n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   .price-row[_ngcontent-%COMP%]   .qty-counter[_ngcontent-%COMP%]   .minus[_ngcontent-%COMP%], \n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   .price-row[_ngcontent-%COMP%]   .qty-counter[_ngcontent-%COMP%]   .plus[_ngcontent-%COMP%] {\n  width: 25px;\n  height: 100%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  color: white;\n  font-weight: bold;\n  font-size: 16px;\n}\n.product-card[_ngcontent-%COMP%]   .p-details[_ngcontent-%COMP%]   .price-row[_ngcontent-%COMP%]   .qty-counter[_ngcontent-%COMP%]   .count[_ngcontent-%COMP%] {\n  color: white;\n  font-weight: 700;\n  font-size: 12px;\n  min-width: 15px;\n  text-align: center;\n}\n/*# sourceMappingURL=grocery.page.css.map */"] });
var GroceryPage = _GroceryPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(GroceryPage, { className: "GroceryPage", filePath: "src/app/grocery/grocery.page.ts", lineNumber: 30 });
})();
export {
  GroceryPage
};
//# sourceMappingURL=grocery.page-NQGQTRAL.js.map
