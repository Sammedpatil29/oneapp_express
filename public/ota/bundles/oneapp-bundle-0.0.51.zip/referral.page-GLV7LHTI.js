import {
  Share
} from "./chunk-XS4AIG4E.js";
import {
  ReferralService
} from "./chunk-A4U5EYAN.js";
import {
  addIcons,
  arrowBackOutline,
  cashOutline,
  checkmarkCircle,
  copyOutline,
  giftOutline,
  logoWhatsapp,
  peopleOutline,
  personAddOutline,
  refreshOutline,
  shareSocialOutline,
  sparklesOutline,
  timeOutline,
  walletOutline
} from "./chunk-V2INQVNG.js";
import "./chunk-OE5MTPUR.js";
import "./chunk-YJYUHAOC.js";
import "./chunk-XR3JUECC.js";
import {
  IonButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonIcon,
  IonSpinner,
  IonTitle,
  IonToolbar,
  ToastController
} from "./chunk-CJE2NDTY.js";
import {
  CommonModule,
  DatePipe,
  DecimalPipe,
  FormsModule,
  NavController,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1
} from "./chunk-Z7XNNJSA.js";
import "./chunk-FH4NU4VH.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/pages/referral/referral.page.ts
var _forTrack0 = ($index, $item) => $item.id;
function ReferralPage_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-spinner", 18);
  }
}
function ReferralPage_Conditional_75_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 45);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("", ctx_r0.referrals.length, " Friends");
  }
}
function ReferralPage_Conditional_76_For_2_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 65);
    \u0275\u0275element(1, "ion-icon", 39);
    \u0275\u0275text(2, " +\u20B950 Earned ");
    \u0275\u0275elementEnd();
  }
}
function ReferralPage_Conditional_76_For_2_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 66);
    \u0275\u0275element(1, "ion-icon", 67);
    \u0275\u0275text(2, " Joined ");
    \u0275\u0275elementEnd();
  }
}
function ReferralPage_Conditional_76_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 59)(1, "div", 60);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 61)(4, "h4", 62);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "p", 63);
    \u0275\u0275text(7);
    \u0275\u0275pipe(8, "date");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "div", 64);
    \u0275\u0275template(10, ReferralPage_Conditional_76_For_2_Conditional_10_Template, 3, 0, "span", 65)(11, ReferralPage_Conditional_76_For_2_Conditional_11_Template, 3, 0, "span", 66);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ref_r2 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" ", ref_r2.referee_name ? ref_r2.referee_name.charAt(0).toUpperCase() : "F", " ");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ref_r2.referee_name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("Joined ", \u0275\u0275pipeBind2(8, 4, ref_r2.signup_date, "mediumDate"), "");
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ref_r2.status === "COMPLETED" ? 10 : 11);
  }
}
function ReferralPage_Conditional_76_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 46);
    \u0275\u0275repeaterCreate(1, ReferralPage_Conditional_76_For_2_Template, 12, 7, "div", 59, _forTrack0);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r0.referrals);
  }
}
function ReferralPage_Conditional_77_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 47)(1, "div", 68);
    \u0275\u0275element(2, "ion-icon", 69);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "h4", 70);
    \u0275\u0275text(4, "No referrals yet");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p", 71);
    \u0275\u0275text(6, "Share your invite code with friends and family. Once they make their first order, you both get \u20B950!");
    \u0275\u0275elementEnd()();
  }
}
var _ReferralPage = class _ReferralPage {
  constructor(toastController, navCtrl, referralService) {
    this.toastController = toastController;
    this.navCtrl = navCtrl;
    this.referralService = referralService;
    this.referralCode = "...";
    this.isCopied = false;
    this.isLoading = true;
    this.stats = {
      total_invites: 0,
      completed_invites: 0,
      total_earnings: 0,
      reward_per_referral: 50
    };
    this.referrals = [];
    addIcons({
      copyOutline,
      checkmarkCircle,
      giftOutline,
      shareSocialOutline,
      walletOutline,
      personAddOutline,
      logoWhatsapp,
      arrowBackOutline,
      peopleOutline,
      timeOutline,
      sparklesOutline,
      refreshOutline,
      cashOutline
    });
  }
  ngOnInit() {
    this.loadReferralData();
  }
  ionViewWillEnter() {
    this.loadReferralData();
  }
  goBack() {
    this.navCtrl.back();
  }
  loadReferralData() {
    this.isLoading = true;
    this.referralService.getReferralDetails().subscribe({
      next: (res) => {
        this.isLoading = false;
        if (res == null ? void 0 : res.success) {
          this.referralCode = res.referral_code || "PINTU50";
          if (res.stats) {
            this.stats = res.stats;
          }
          this.referrals = res.referrals || [];
        }
      },
      error: (err) => {
        this.isLoading = false;
        console.warn("Failed to load live referral stats:", err == null ? void 0 : err.message);
        if (this.referralCode === "...") {
          this.referralCode = "PINTU50";
        }
      }
    });
  }
  copyCode() {
    return __async(this, null, function* () {
      try {
        if ((navigator == null ? void 0 : navigator.clipboard) && this.referralCode && this.referralCode !== "...") {
          yield navigator.clipboard.writeText(this.referralCode);
        }
        this.isCopied = true;
        const toast = yield this.toastController.create({
          message: `Referral code ${this.referralCode} copied to clipboard!`,
          duration: 2200,
          position: "bottom",
          color: "dark"
        });
        yield toast.present();
        setTimeout(() => {
          this.isCopied = false;
        }, 3e3);
      } catch (e) {
        this.isCopied = true;
        setTimeout(() => this.isCopied = false, 3e3);
      }
    });
  }
  share() {
    return __async(this, null, function* () {
      try {
        yield Share.share({
          title: "Join me on Pintu!",
          text: `I'm inviting you to try Pintu! Sign up with my referral code ${this.referralCode} and we'll both get \u20B950 in our wallet.`,
          url: "https://pintu.in/download",
          dialogTitle: "Share with friends"
        });
      } catch (e) {
        this.shareViaWhatsApp();
      }
    });
  }
  shareViaWhatsApp() {
    const text = encodeURIComponent(`Hey! Try Pintu for 10-15 min grocery delivery & zero surge rides. Use my invite code ${this.referralCode} to get \u20B950 off on your first order: https://pintu.in/download`);
    window.open(`https://wa.me/?text=${text}`, "_system");
  }
};
_ReferralPage.\u0275fac = function ReferralPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _ReferralPage)(\u0275\u0275directiveInject(ToastController), \u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(ReferralService));
};
_ReferralPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _ReferralPage, selectors: [["app-referral"]], decls: 107, vars: 15, consts: [[1, "ion-no-border", "bg-white", "pt-2"], ["slot", "start"], [3, "click"], ["name", "arrow-back-outline", "color", "dark"], [1, "fw-bold", "text-dark"], [1, "referral-page-content", 3, "fullscreen"], [1, "referral-body-container"], [1, "referral-hero-card"], [1, "hero-glow-orb"], [1, "hero-visual-col"], [1, "hero-gift-emoji"], [1, "hero-info-col"], [1, "hero-badge"], [1, "hero-headline"], [1, "hero-desc"], [1, "referral-code-card"], [1, "d-flex", "justify-content-between", "align-items-center", "mb-1"], [1, "code-eyebrow"], ["name", "crescent", 1, "spinner-code-loading"], ["role", "button", "tabindex", "0", 1, "code-action-box", 3, "click"], [1, "code-text"], ["type", "button", 1, "btn-copy-chip"], [3, "name"], [1, "share-actions-row"], ["type", "button", 1, "btn-share-primary", 3, "click"], ["name", "share-social-outline"], ["type", "button", "aria-label", "Share via WhatsApp", 1, "btn-whatsapp-action", 3, "click"], ["name", "logo-whatsapp"], [1, "referral-stats-card"], [1, "stats-header"], [1, "stats-title"], [1, "stats-rate-badge"], [1, "stats-grid"], [1, "stat-box"], [1, "stat-icon", "purple"], ["name", "people-outline"], [1, "stat-value"], [1, "stat-label"], [1, "stat-icon", "emerald"], ["name", "checkmark-circle"], [1, "stat-icon", "amber"], ["name", "wallet-outline"], [1, "referrals-activity-section"], [1, "activity-header"], [1, "section-title"], [1, "activity-count"], [1, "referrals-list"], [1, "empty-referrals-box"], [1, "how-it-works-section"], [1, "timeline-container"], [1, "timeline-step"], [1, "step-icon-box", "purple-bg"], [1, "step-text-col"], [1, "step-title"], [1, "step-desc"], [1, "step-icon-box", "blue-bg"], ["name", "person-add-outline"], [1, "step-icon-box", "emerald-bg"], [1, "bottom-nav-spacer"], [1, "friend-item-card"], [1, "friend-avatar"], [1, "friend-info"], [1, "friend-name"], [1, "friend-date"], [1, "friend-status"], [1, "status-pill", "status-completed"], [1, "status-pill", "status-pending"], ["name", "time-outline"], [1, "empty-icon-wrap"], ["name", "sparkles-outline"], [1, "empty-title"], [1, "empty-desc"]], template: function ReferralPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar")(2, "ion-buttons", 1)(3, "ion-button", 2);
    \u0275\u0275listener("click", function ReferralPage_Template_ion_button_click_3_listener() {
      return ctx.goBack();
    });
    \u0275\u0275element(4, "ion-icon", 3);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "ion-title", 4);
    \u0275\u0275text(6, "Refer & Earn");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(7, "ion-content", 5)(8, "main", 6)(9, "div", 7);
    \u0275\u0275element(10, "div", 8);
    \u0275\u0275elementStart(11, "div", 9)(12, "span", 10);
    \u0275\u0275text(13, "\u{1F381}");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(14, "div", 11)(15, "span", 12);
    \u0275\u0275text(16, "PINTU REWARDS");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "h2", 13);
    \u0275\u0275text(18, "Give \u20B950, Get \u20B950");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(19, "p", 14);
    \u0275\u0275text(20, "Invite friends to Pintu. Both of you receive \u20B950 wallet cash when they complete their 1st order.");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(21, "div", 15)(22, "div", 16)(23, "span", 17);
    \u0275\u0275text(24, "YOUR UNIQUE REFERRAL CODE");
    \u0275\u0275elementEnd();
    \u0275\u0275template(25, ReferralPage_Conditional_25_Template, 1, 0, "ion-spinner", 18);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(26, "div", 19);
    \u0275\u0275listener("click", function ReferralPage_Template_div_click_26_listener() {
      return ctx.copyCode();
    });
    \u0275\u0275elementStart(27, "span", 20);
    \u0275\u0275text(28);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(29, "button", 21);
    \u0275\u0275element(30, "ion-icon", 22);
    \u0275\u0275elementStart(31, "span");
    \u0275\u0275text(32);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(33, "div", 23)(34, "button", 24);
    \u0275\u0275listener("click", function ReferralPage_Template_button_click_34_listener() {
      return ctx.share();
    });
    \u0275\u0275element(35, "ion-icon", 25);
    \u0275\u0275elementStart(36, "span");
    \u0275\u0275text(37, "Share with Friends");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(38, "button", 26);
    \u0275\u0275listener("click", function ReferralPage_Template_button_click_38_listener() {
      return ctx.shareViaWhatsApp();
    });
    \u0275\u0275element(39, "ion-icon", 27);
    \u0275\u0275elementStart(40, "span");
    \u0275\u0275text(41, "WhatsApp");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(42, "div", 28)(43, "div", 29)(44, "h3", 30);
    \u0275\u0275text(45, "Your Referral Rewards");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(46, "span", 31);
    \u0275\u0275text(47, "\u20B950 / Friend");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(48, "div", 32)(49, "div", 33)(50, "div", 34);
    \u0275\u0275element(51, "ion-icon", 35);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(52, "span", 36);
    \u0275\u0275text(53);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(54, "span", 37);
    \u0275\u0275text(55, "Invited");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(56, "div", 33)(57, "div", 38);
    \u0275\u0275element(58, "ion-icon", 39);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(59, "span", 36);
    \u0275\u0275text(60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(61, "span", 37);
    \u0275\u0275text(62, "Completed");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(63, "div", 33)(64, "div", 40);
    \u0275\u0275element(65, "ion-icon", 41);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(66, "span", 36);
    \u0275\u0275text(67);
    \u0275\u0275pipe(68, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(69, "span", 37);
    \u0275\u0275text(70, "Total Earned");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(71, "section", 42)(72, "div", 43)(73, "h3", 44);
    \u0275\u0275text(74, "Referred Friends");
    \u0275\u0275elementEnd();
    \u0275\u0275template(75, ReferralPage_Conditional_75_Template, 2, 1, "span", 45);
    \u0275\u0275elementEnd();
    \u0275\u0275template(76, ReferralPage_Conditional_76_Template, 3, 0, "div", 46)(77, ReferralPage_Conditional_77_Template, 7, 0, "div", 47);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(78, "section", 48)(79, "h3", 44);
    \u0275\u0275text(80, "How It Works");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(81, "div", 49)(82, "div", 50)(83, "div", 51);
    \u0275\u0275element(84, "ion-icon", 25);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(85, "div", 52)(86, "h4", 53);
    \u0275\u0275text(87, "1. Share your code");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(88, "p", 54);
    \u0275\u0275text(89, "Send your referral invite code or link to your friends and contacts.");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(90, "div", 50)(91, "div", 55);
    \u0275\u0275element(92, "ion-icon", 56);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(93, "div", 52)(94, "h4", 53);
    \u0275\u0275text(95, "2. Friend signs up & orders");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(96, "p", 54);
    \u0275\u0275text(97, "They sign up with your code and get an instant \u20B950 welcome discount.");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(98, "div", 50)(99, "div", 57);
    \u0275\u0275element(100, "ion-icon", 41);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(101, "div", 52)(102, "h4", 53);
    \u0275\u0275text(103, "3. You get \u20B950 wallet cash");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(104, "p", 54);
    \u0275\u0275text(105, "\u20B950 is credited directly into your Pintu wallet when their order completes.");
    \u0275\u0275elementEnd()()()()();
    \u0275\u0275element(106, "div", 58);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(7);
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance(18);
    \u0275\u0275conditional(ctx.isLoading ? 25 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx.referralCode);
    \u0275\u0275advance();
    \u0275\u0275classProp("copied", ctx.isCopied);
    \u0275\u0275advance();
    \u0275\u0275property("name", ctx.isCopied ? "checkmark-circle" : "copy-outline");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx.isCopied ? "Copied!" : "Tap to Copy");
    \u0275\u0275advance(21);
    \u0275\u0275textInterpolate(ctx.stats.total_invites);
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate(ctx.stats.completed_invites);
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate1("\u20B9", \u0275\u0275pipeBind2(68, 12, ctx.stats.total_earnings, "1.0-0"), "");
    \u0275\u0275advance(8);
    \u0275\u0275conditional(ctx.referrals.length > 0 ? 75 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.referrals.length > 0 ? 76 : 77);
  }
}, dependencies: [
  IonHeader,
  IonToolbar,
  IonButtons,
  IonButton,
  IonTitle,
  IonContent,
  IonIcon,
  IonSpinner,
  CommonModule,
  DecimalPipe,
  DatePipe,
  FormsModule
], styles: ["\n\n.referral-page-content[_ngcontent-%COMP%] {\n  --background: #f8fafc;\n  --overflow: hidden auto;\n  overflow-x: hidden;\n  position: relative;\n}\nion-header[_ngcontent-%COMP%] {\n  --background: #ffffff;\n  background: #ffffff;\n  border-bottom: 1px solid #f1f5f9;\n}\nion-toolbar[_ngcontent-%COMP%] {\n  --background: #ffffff;\n}\n.referral-body-container[_ngcontent-%COMP%] {\n  padding: 16px;\n  display: flex;\n  flex-direction: column;\n  gap: 16px;\n  width: 100%;\n  max-width: 100%;\n  box-sizing: border-box;\n}\n.referral-hero-card[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #2e0854 0%,\n      #1e1b4b 60%,\n      #4a044e 100%);\n  border-radius: 24px;\n  padding: 20px 18px;\n  display: flex;\n  align-items: center;\n  gap: 16px;\n  position: relative;\n  overflow: hidden;\n  box-shadow: 0 8px 24px rgba(46, 8, 84, 0.25);\n}\n.referral-hero-card[_ngcontent-%COMP%]   .hero-glow-orb[_ngcontent-%COMP%] {\n  position: absolute;\n  width: 120px;\n  height: 120px;\n  border-radius: 50%;\n  background:\n    radial-gradient(\n      circle,\n      rgba(168, 85, 247, 0.4) 0%,\n      rgba(168, 85, 247, 0) 70%);\n  top: -30px;\n  right: -30px;\n}\n.referral-hero-card[_ngcontent-%COMP%]   .hero-visual-col[_ngcontent-%COMP%] {\n  width: 64px;\n  height: 64px;\n  border-radius: 20px;\n  background: rgba(255, 255, 255, 0.12);\n  -webkit-backdrop-filter: blur(8px);\n  backdrop-filter: blur(8px);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  flex-shrink: 0;\n  border: 1px solid rgba(255, 255, 255, 0.2);\n}\n.referral-hero-card[_ngcontent-%COMP%]   .hero-visual-col[_ngcontent-%COMP%]   .hero-gift-emoji[_ngcontent-%COMP%] {\n  font-size: 34px;\n  filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.3));\n}\n.referral-hero-card[_ngcontent-%COMP%]   .hero-info-col[_ngcontent-%COMP%] {\n  flex: 1;\n  display: flex;\n  flex-direction: column;\n  gap: 3px;\n  z-index: 2;\n}\n.referral-hero-card[_ngcontent-%COMP%]   .hero-info-col[_ngcontent-%COMP%]   .hero-badge[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  font-weight: 850;\n  color: #fef08a;\n  letter-spacing: 0.6px;\n}\n.referral-hero-card[_ngcontent-%COMP%]   .hero-info-col[_ngcontent-%COMP%]   .hero-headline[_ngcontent-%COMP%] {\n  font-size: 18px;\n  font-weight: 850;\n  color: #ffffff;\n  margin: 0;\n  letter-spacing: -0.2px;\n}\n.referral-hero-card[_ngcontent-%COMP%]   .hero-info-col[_ngcontent-%COMP%]   .hero-desc[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  font-weight: 450;\n  color: rgba(255, 255, 255, 0.8);\n  margin: 0;\n  line-height: 1.35;\n}\n.referral-code-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 20px;\n  padding: 16px;\n  border: 1px solid #f1f5f9;\n  box-shadow: 0 4px 14px rgba(15, 23, 42, 0.04);\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n.referral-code-card[_ngcontent-%COMP%]   .code-eyebrow[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 800;\n  color: #94a3b8;\n  letter-spacing: 0.6px;\n}\n.referral-code-card[_ngcontent-%COMP%]   .code-action-box[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  background: #f8fafc;\n  border: 2px dashed #cbd5e1;\n  border-radius: 14px;\n  padding: 10px 14px;\n  cursor: pointer;\n  transition: border-color 0.2s ease, background 0.2s ease;\n}\n.referral-code-card[_ngcontent-%COMP%]   .code-action-box[_ngcontent-%COMP%]:active {\n  border-color: #a000e2;\n  background: #faf5ff;\n}\n.referral-code-card[_ngcontent-%COMP%]   .code-action-box[_ngcontent-%COMP%]   .code-text[_ngcontent-%COMP%] {\n  font-size: 18px;\n  font-weight: 850;\n  color: #0f172a;\n  letter-spacing: 1.5px;\n  font-family: monospace;\n}\n.referral-code-card[_ngcontent-%COMP%]   .code-action-box[_ngcontent-%COMP%]   .btn-copy-chip[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border: 1px solid #e2e8f0;\n  border-radius: 99px;\n  padding: 6px 12px;\n  font-size: 11.5px;\n  font-weight: 750;\n  color: #a000e2;\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  cursor: pointer;\n  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04);\n  transition: all 0.2s ease;\n}\n.referral-code-card[_ngcontent-%COMP%]   .code-action-box[_ngcontent-%COMP%]   .btn-copy-chip.copied[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  border-color: #a7f3d0;\n  color: #059669;\n}\n.share-actions-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n}\n.share-actions-row[_ngcontent-%COMP%]   .btn-share-primary[_ngcontent-%COMP%] {\n  flex: 1;\n  background: #a000e2;\n  color: #ffffff;\n  border: none;\n  border-radius: 16px;\n  padding: 14px 16px;\n  font-size: 13.5px;\n  font-weight: 750;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 8px;\n  box-shadow: 0 4px 14px rgba(160, 0, 226, 0.3);\n  cursor: pointer;\n  transition: transform 0.15s ease;\n}\n.share-actions-row[_ngcontent-%COMP%]   .btn-share-primary[_ngcontent-%COMP%]:active {\n  transform: scale(0.98);\n}\n.share-actions-row[_ngcontent-%COMP%]   .btn-share-primary[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 17px;\n}\n.share-actions-row[_ngcontent-%COMP%]   .btn-whatsapp-action[_ngcontent-%COMP%] {\n  background: #25d366;\n  color: #ffffff;\n  border: none;\n  border-radius: 16px;\n  padding: 14px 18px;\n  font-size: 13.5px;\n  font-weight: 750;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 6px;\n  box-shadow: 0 4px 14px rgba(37, 211, 102, 0.25);\n  cursor: pointer;\n  transition: transform 0.15s ease;\n}\n.share-actions-row[_ngcontent-%COMP%]   .btn-whatsapp-action[_ngcontent-%COMP%]:active {\n  transform: scale(0.98);\n}\n.share-actions-row[_ngcontent-%COMP%]   .btn-whatsapp-action[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n}\n.spinner-code-loading[_ngcontent-%COMP%] {\n  width: 14px;\n  height: 14px;\n  --color: #a000e2;\n}\n.referral-stats-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 20px;\n  padding: 16px;\n  border: 1px solid #f1f5f9;\n  box-shadow: 0 4px 14px rgba(15, 23, 42, 0.04);\n  display: flex;\n  flex-direction: column;\n  gap: 14px;\n}\n.referral-stats-card[_ngcontent-%COMP%]   .stats-header[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n.referral-stats-card[_ngcontent-%COMP%]   .stats-header[_ngcontent-%COMP%]   .stats-title[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 800;\n  color: #0f172a;\n  margin: 0;\n}\n.referral-stats-card[_ngcontent-%COMP%]   .stats-header[_ngcontent-%COMP%]   .stats-rate-badge[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 700;\n  color: #a000e2;\n  background: #fdf4ff;\n  border: 1px solid #f5d0fe;\n  padding: 3px 8px;\n  border-radius: 999px;\n}\n.referral-stats-card[_ngcontent-%COMP%]   .stats-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  gap: 10px;\n}\n.referral-stats-card[_ngcontent-%COMP%]   .stats-grid[_ngcontent-%COMP%]   .stat-box[_ngcontent-%COMP%] {\n  background: #f8fafc;\n  border: 1px solid #f1f5f9;\n  border-radius: 16px;\n  padding: 12px 8px;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  text-align: center;\n  gap: 4px;\n}\n.referral-stats-card[_ngcontent-%COMP%]   .stats-grid[_ngcontent-%COMP%]   .stat-box[_ngcontent-%COMP%]   .stat-icon[_ngcontent-%COMP%] {\n  width: 32px;\n  height: 32px;\n  border-radius: 10px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 17px;\n  margin-bottom: 2px;\n}\n.referral-stats-card[_ngcontent-%COMP%]   .stats-grid[_ngcontent-%COMP%]   .stat-box[_ngcontent-%COMP%]   .stat-icon.purple[_ngcontent-%COMP%] {\n  background: #f3e8ff;\n  color: #a000e2;\n}\n.referral-stats-card[_ngcontent-%COMP%]   .stats-grid[_ngcontent-%COMP%]   .stat-box[_ngcontent-%COMP%]   .stat-icon.emerald[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  color: #10b981;\n}\n.referral-stats-card[_ngcontent-%COMP%]   .stats-grid[_ngcontent-%COMP%]   .stat-box[_ngcontent-%COMP%]   .stat-icon.amber[_ngcontent-%COMP%] {\n  background: #fef3c7;\n  color: #d97706;\n}\n.referral-stats-card[_ngcontent-%COMP%]   .stats-grid[_ngcontent-%COMP%]   .stat-box[_ngcontent-%COMP%]   .stat-value[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 850;\n  color: #0f172a;\n  line-height: 1.1;\n}\n.referral-stats-card[_ngcontent-%COMP%]   .stats-grid[_ngcontent-%COMP%]   .stat-box[_ngcontent-%COMP%]   .stat-label[_ngcontent-%COMP%] {\n  font-size: 10.5px;\n  font-weight: 600;\n  color: #64748b;\n  letter-spacing: -0.1px;\n}\n.referrals-activity-section[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 20px;\n  padding: 18px 16px;\n  border: 1px solid #f1f5f9;\n  box-shadow: 0 4px 14px rgba(15, 23, 42, 0.04);\n  display: flex;\n  flex-direction: column;\n  gap: 14px;\n}\n.referrals-activity-section[_ngcontent-%COMP%]   .activity-header[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n.referrals-activity-section[_ngcontent-%COMP%]   .activity-header[_ngcontent-%COMP%]   .section-title[_ngcontent-%COMP%] {\n  font-size: 15px;\n  font-weight: 850;\n  color: #0f172a;\n  margin: 0;\n  letter-spacing: -0.2px;\n}\n.referrals-activity-section[_ngcontent-%COMP%]   .activity-header[_ngcontent-%COMP%]   .activity-count[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  font-weight: 700;\n  color: #64748b;\n  background: #f1f5f9;\n  padding: 3px 8px;\n  border-radius: 8px;\n}\n.referrals-activity-section[_ngcontent-%COMP%]   .referrals-list[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n}\n.referrals-activity-section[_ngcontent-%COMP%]   .referrals-list[_ngcontent-%COMP%]   .friend-item-card[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  padding: 10px 12px;\n  background: #f8fafc;\n  border-radius: 14px;\n  border: 1px solid #f1f5f9;\n}\n.referrals-activity-section[_ngcontent-%COMP%]   .referrals-list[_ngcontent-%COMP%]   .friend-item-card[_ngcontent-%COMP%]   .friend-avatar[_ngcontent-%COMP%] {\n  width: 36px;\n  height: 36px;\n  border-radius: 50%;\n  background:\n    linear-gradient(\n      135deg,\n      #a000e2 0%,\n      #7c3aed 100%);\n  color: #ffffff;\n  font-weight: 800;\n  font-size: 14px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  flex-shrink: 0;\n}\n.referrals-activity-section[_ngcontent-%COMP%]   .referrals-list[_ngcontent-%COMP%]   .friend-item-card[_ngcontent-%COMP%]   .friend-info[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 0;\n}\n.referrals-activity-section[_ngcontent-%COMP%]   .referrals-list[_ngcontent-%COMP%]   .friend-item-card[_ngcontent-%COMP%]   .friend-info[_ngcontent-%COMP%]   .friend-name[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  font-weight: 750;\n  color: #0f172a;\n  margin: 0 0 2px;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.referrals-activity-section[_ngcontent-%COMP%]   .referrals-list[_ngcontent-%COMP%]   .friend-item-card[_ngcontent-%COMP%]   .friend-info[_ngcontent-%COMP%]   .friend-date[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #94a3b8;\n  margin: 0;\n}\n.referrals-activity-section[_ngcontent-%COMP%]   .referrals-list[_ngcontent-%COMP%]   .friend-item-card[_ngcontent-%COMP%]   .friend-status[_ngcontent-%COMP%] {\n  flex-shrink: 0;\n}\n.referrals-activity-section[_ngcontent-%COMP%]   .referrals-list[_ngcontent-%COMP%]   .friend-item-card[_ngcontent-%COMP%]   .friend-status[_ngcontent-%COMP%]   .status-pill[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  padding: 4px 9px;\n  border-radius: 999px;\n  font-size: 11px;\n  font-weight: 750;\n}\n.referrals-activity-section[_ngcontent-%COMP%]   .referrals-list[_ngcontent-%COMP%]   .friend-item-card[_ngcontent-%COMP%]   .friend-status[_ngcontent-%COMP%]   .status-pill.status-completed[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  color: #059669;\n  border: 1px solid #a7f3d0;\n}\n.referrals-activity-section[_ngcontent-%COMP%]   .referrals-list[_ngcontent-%COMP%]   .friend-item-card[_ngcontent-%COMP%]   .friend-status[_ngcontent-%COMP%]   .status-pill.status-pending[_ngcontent-%COMP%] {\n  background: #fffbeb;\n  color: #b45309;\n  border: 1px solid #fde68a;\n}\n.referrals-activity-section[_ngcontent-%COMP%]   .referrals-list[_ngcontent-%COMP%]   .friend-item-card[_ngcontent-%COMP%]   .friend-status[_ngcontent-%COMP%]   .status-pill[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 13px;\n}\n.referrals-activity-section[_ngcontent-%COMP%]   .empty-referrals-box[_ngcontent-%COMP%] {\n  text-align: center;\n  padding: 24px 16px 16px;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  gap: 8px;\n}\n.referrals-activity-section[_ngcontent-%COMP%]   .empty-referrals-box[_ngcontent-%COMP%]   .empty-icon-wrap[_ngcontent-%COMP%] {\n  width: 48px;\n  height: 48px;\n  border-radius: 50%;\n  background: #fdf4ff;\n  color: #a000e2;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 22px;\n  margin-bottom: 4px;\n}\n.referrals-activity-section[_ngcontent-%COMP%]   .empty-referrals-box[_ngcontent-%COMP%]   .empty-title[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 800;\n  color: #0f172a;\n  margin: 0;\n}\n.referrals-activity-section[_ngcontent-%COMP%]   .empty-referrals-box[_ngcontent-%COMP%]   .empty-desc[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #64748b;\n  margin: 0;\n  max-width: 260px;\n  line-height: 1.4;\n}\n.how-it-works-section[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 20px;\n  padding: 18px 16px;\n  border: 1px solid #f1f5f9;\n  box-shadow: 0 4px 14px rgba(15, 23, 42, 0.04);\n  display: flex;\n  flex-direction: column;\n  gap: 14px;\n}\n.how-it-works-section[_ngcontent-%COMP%]   .section-title[_ngcontent-%COMP%] {\n  font-size: 15px;\n  font-weight: 850;\n  color: #0f172a;\n  margin: 0;\n  letter-spacing: -0.2px;\n}\n.how-it-works-section[_ngcontent-%COMP%]   .timeline-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 14px;\n}\n.how-it-works-section[_ngcontent-%COMP%]   .timeline-container[_ngcontent-%COMP%]   .timeline-step[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-start;\n  gap: 12px;\n}\n.how-it-works-section[_ngcontent-%COMP%]   .timeline-container[_ngcontent-%COMP%]   .timeline-step[_ngcontent-%COMP%]   .step-icon-box[_ngcontent-%COMP%] {\n  width: 36px;\n  height: 36px;\n  border-radius: 12px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 17px;\n  flex-shrink: 0;\n}\n.how-it-works-section[_ngcontent-%COMP%]   .timeline-container[_ngcontent-%COMP%]   .timeline-step[_ngcontent-%COMP%]   .step-icon-box.purple-bg[_ngcontent-%COMP%] {\n  background: #f3e8ff;\n  color: #a000e2;\n}\n.how-it-works-section[_ngcontent-%COMP%]   .timeline-container[_ngcontent-%COMP%]   .timeline-step[_ngcontent-%COMP%]   .step-icon-box.blue-bg[_ngcontent-%COMP%] {\n  background: #eff6ff;\n  color: #2563eb;\n}\n.how-it-works-section[_ngcontent-%COMP%]   .timeline-container[_ngcontent-%COMP%]   .timeline-step[_ngcontent-%COMP%]   .step-icon-box.emerald-bg[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  color: #059669;\n}\n.how-it-works-section[_ngcontent-%COMP%]   .timeline-container[_ngcontent-%COMP%]   .timeline-step[_ngcontent-%COMP%]   .step-text-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 1px;\n}\n.how-it-works-section[_ngcontent-%COMP%]   .timeline-container[_ngcontent-%COMP%]   .timeline-step[_ngcontent-%COMP%]   .step-text-col[_ngcontent-%COMP%]   .step-title[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  font-weight: 750;\n  color: #0f172a;\n  margin: 0;\n}\n.how-it-works-section[_ngcontent-%COMP%]   .timeline-container[_ngcontent-%COMP%]   .timeline-step[_ngcontent-%COMP%]   .step-text-col[_ngcontent-%COMP%]   .step-desc[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  font-weight: 500;\n  color: #64748b;\n  margin: 0;\n  line-height: 1.35;\n}\n.bottom-nav-spacer[_ngcontent-%COMP%] {\n  min-height: calc(80px + env(safe-area-inset-bottom, 0px));\n  height: calc(80px + env(safe-area-inset-bottom, 0px));\n  width: 100%;\n}\n/*# sourceMappingURL=referral.page.css.map */"] });
var ReferralPage = _ReferralPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(ReferralPage, { className: "ReferralPage", filePath: "src/app/pages/referral/referral.page.ts", lineNumber: 53 });
})();
export {
  ReferralPage
};
//# sourceMappingURL=referral.page-GLV7LHTI.js.map
