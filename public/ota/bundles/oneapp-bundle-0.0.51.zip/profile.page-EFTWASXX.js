import {
  PintuPocketService
} from "./chunk-PF5HLQEL.js";
import {
  TranslatePipe
} from "./chunk-EAEIPGUF.js";
import {
  FooterComponent
} from "./chunk-BAXPXNKU.js";
import {
  ProfileService
} from "./chunk-HGHC2QOZ.js";
import {
  addIcons,
  arrowBackOutline,
  arrowUpCircle,
  bulbOutline,
  callOutline,
  checkmark,
  checkmarkCircle,
  chevronForward,
  cloudDownloadOutline,
  giftOutline,
  headsetOutline,
  informationCircleOutline,
  languageOutline,
  locationOutline,
  logOutOutline,
  mapOutline,
  personOutline,
  receiptOutline,
  refreshOutline,
  settingsOutline,
  shieldOutline,
  sparkles,
  walletOutline,
  warningOutline
} from "./chunk-V2INQVNG.js";
import {
  OtaService
} from "./chunk-DCTFUYU7.js";
import "./chunk-EBMCUG2R.js";
import {
  AppDialogService
} from "./chunk-W37RSO62.js";
import {
  AuthService
} from "./chunk-EB6T6TPT.js";
import "./chunk-OE5MTPUR.js";
import "./chunk-YJYUHAOC.js";
import "./chunk-XR3JUECC.js";
import {
  IonButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonIcon,
  IonSkeletonText,
  IonTitle,
  IonToolbar
} from "./chunk-CJE2NDTY.js";
import {
  AsyncPipe,
  CommonModule,
  DecimalPipe,
  FormsModule,
  NavController,
  Router,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind1,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2
} from "./chunk-Z7XNNJSA.js";
import "./chunk-FH4NU4VH.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/pages/profile/profile.page.ts
function ProfilePage_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "img", 60);
    \u0275\u0275listener("error", function ProfilePage_Conditional_14_Template_img_error_0_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.profileData.profile_image = "");
    });
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275property("src", ctx_r1.profileData.profile_image, \u0275\u0275sanitizeUrl);
  }
}
function ProfilePage_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 12);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r1.getUserInitials(), " ");
  }
}
function ProfilePage_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-skeleton-text", 61)(1, "ion-skeleton-text", 62);
  }
}
function ProfilePage_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "h2", 63);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "p", 64);
    \u0275\u0275element(3, "ion-icon", 65);
    \u0275\u0275elementStart(4, "span");
    \u0275\u0275text(5);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r1.getDisplayName(), " ");
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate((ctx_r1.profileData == null ? null : ctx_r1.profileData.phone) || "+91");
  }
}
function ProfilePage_Conditional_118_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 48);
    \u0275\u0275element(1, "ion-icon", 66);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3);
    \u0275\u0275pipe(4, "translate");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(4, 1, "up_to_date"));
  }
}
function ProfilePage_Conditional_119_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 49);
    \u0275\u0275element(1, "ion-icon", 67);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3);
    \u0275\u0275pipe(4, "translate");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate2("v", ctx_r1.latestOtaVersion, " ", \u0275\u0275pipeBind1(4, 2, "update_ready"), "");
  }
}
var _ProfilePage = class _ProfilePage {
  constructor(router, navCtrl, authService, profileService, dialogService, pocketService, otaService) {
    this.router = router;
    this.navCtrl = navCtrl;
    this.authService = authService;
    this.profileService = profileService;
    this.dialogService = dialogService;
    this.pocketService = pocketService;
    this.otaService = otaService;
    this.profileData = null;
    this.isLoading = false;
    this.token = "";
    this.currentAppVersion = "0.0.16";
    this.latestOtaVersion = "";
    this.isCheckingOta = false;
    this.isOtaUpToDate = true;
    this.hasOtaUpdateAvailable = false;
    this.pocketBalance$ = this.pocketService.balance$;
    addIcons({ arrowBackOutline, checkmark, callOutline, receiptOutline, locationOutline, walletOutline, headsetOutline, personOutline, chevronForward, mapOutline, giftOutline, settingsOutline, bulbOutline, cloudDownloadOutline, checkmarkCircle, arrowUpCircle, refreshOutline, informationCircleOutline, shieldOutline, logOutOutline, languageOutline, warningOutline, sparkles });
  }
  goBack() {
    this.navCtrl.back();
  }
  ngOnInit() {
    return __async(this, null, function* () {
      this.token = (yield this.authService.getToken()) || "";
      if (this.token) {
        this.getProfileData();
      }
      this.initAppVersionAndOta();
    });
  }
  initAppVersionAndOta() {
    return __async(this, null, function* () {
      this.currentAppVersion = yield this.otaService.getCurrentVersion();
      const res = yield this.otaService.checkUpdateDetails();
      if (res.success) {
        this.currentAppVersion = res.currentVersion;
        this.isOtaUpToDate = res.isUpToDate;
        this.hasOtaUpdateAvailable = res.updateAvailable;
        this.latestOtaVersion = res.latestVersion || "";
      }
    });
  }
  checkOtaUpdate(isUserClick = true) {
    return __async(this, null, function* () {
      if (this.isCheckingOta)
        return;
      this.isCheckingOta = true;
      const res = yield this.otaService.checkUpdateDetails();
      this.isCheckingOta = false;
      this.currentAppVersion = res.currentVersion;
      if (res.success) {
        this.isOtaUpToDate = res.isUpToDate;
        this.hasOtaUpdateAvailable = res.updateAvailable;
        this.latestOtaVersion = res.latestVersion || "";
        if (isUserClick) {
          if (res.isUpToDate) {
            yield this.dialogService.showAlert("Everything is Up to Date", `You are running the latest version (v${this.currentAppVersion}). 

Request URL: ${res.maskedUrl}`, "info", "OK");
          } else if (res.updateAvailable) {
            const proceed = yield this.dialogService.showConfirm({
              title: "New OTA Update Available",
              message: `Version v${res.latestVersion} is ready to download (current: v${this.currentAppVersion}).

Request URL: ${res.maskedUrl}`,
              confirmText: "Update Now",
              cancelText: "Later"
            });
            if (proceed) {
              this.dialogService.showToast("Downloading and applying update...", "success", 3e3);
              const applyRes = yield this.otaService.applyUpdateNow();
              if (!applyRes.success) {
                yield this.dialogService.showAlert("Update Failed", `${applyRes.message || "Could not apply update bundle."}

Request URL: ${res.maskedUrl}`, "warning", "Close");
              }
            }
          }
        }
      } else {
        this.isOtaUpToDate = false;
        if (isUserClick) {
          const debugDetails = [
            `Error: ${res.error || "Server error"}`,
            res.httpStatus ? `HTTP Status: ${res.httpStatus}` : "",
            res.errorDetails ? `Server Response: ${res.errorDetails}` : "",
            `Request URL: ${res.maskedUrl || res.manifestUrl}`
          ].filter(Boolean).join("\n\n");
          yield this.dialogService.showAlert("OTA Check Failed (Debug)", debugDetails, "warning", "Close");
        }
      }
    });
  }
  onRefreshOtaClick(event) {
    event.stopPropagation();
    this.checkOtaUpdate(true);
  }
  getProfileData() {
    this.isLoading = true;
    this.profileService.getProfileData(this.token).subscribe({
      next: (res) => {
        this.profileData = (res == null ? void 0 : res.user) || (res == null ? void 0 : res.data) || res || {};
        this.isLoading = false;
      },
      error: () => {
        this.isLoading = false;
      }
    });
  }
  getDisplayName() {
    if (!this.profileData)
      return "Pintu Customer";
    const first = this.profileData.first_name || this.profileData.name || "";
    const last = this.profileData.last_name || "";
    const full = `${first} ${last}`.trim();
    return full || "Pintu Customer";
  }
  getUserInitials() {
    const name = this.getDisplayName();
    return name.charAt(0).toUpperCase() || "P";
  }
  logOut() {
    return __async(this, null, function* () {
      const confirmed = yield this.dialogService.showDangerConfirm({
        title: "Log Out",
        message: "Are you sure you want to log out of your Pintu account?",
        confirmText: "Yes, Log Out",
        cancelText: "Cancel"
      });
      if (confirmed) {
        this.profileData = null;
        yield this.authService.logout();
      }
    });
  }
  goToSupport() {
    this.router.navigate(["/layout/support"]);
  }
  openReferral() {
    this.router.navigate(["/layout/referral"]);
  }
  openPintuPocket() {
    this.router.navigate(["/layout/pintu-pocket"]);
  }
  openDetails(option) {
    if (option === "Pintu Pocket" || option === "Wallet") {
      this.router.navigate(["/layout/pintu-pocket"]);
    } else if (option === "Personal Details") {
      this.router.navigate(["/layout/profile-details"]);
    } else if (option === "Saved Addresses") {
      this.router.navigate(["/layout/address-list"], {
        state: { data: "profile" }
      });
    } else if (option === "Orders History" || option === "Orders") {
      this.router.navigate(["/layout/history"]);
    } else if (option === "settings" || option === "language" || option === "App Settings") {
      this.router.navigate(["/layout/about"], {
        state: { data: "App Settings" }
      });
    } else {
      this.router.navigate(["/layout/about"], {
        state: { data: option }
      });
    }
  }
};
_ProfilePage.\u0275fac = function ProfilePage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _ProfilePage)(\u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(AuthService), \u0275\u0275directiveInject(ProfileService), \u0275\u0275directiveInject(AppDialogService), \u0275\u0275directiveInject(PintuPocketService), \u0275\u0275directiveInject(OtaService));
};
_ProfilePage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _ProfilePage, selectors: [["app-profile"]], decls: 152, vars: 49, consts: [[1, "ion-no-border", "bg-white", "pt-2"], ["slot", "start"], [3, "click"], ["name", "arrow-back-outline", "color", "dark"], [1, "fw-bold", "text-dark"], [1, "profile-content-page", 3, "fullscreen"], [1, "profile-body-container"], [1, "profile-hero-card"], [1, "hero-glow-orb"], [1, "profile-hero-inner"], [1, "profile-avatar-wrapper"], ["alt", "Profile", 1, "avatar-photo", 3, "src"], [1, "avatar-initials-badge"], ["title", "Verified Customer", 1, "verified-tick-badge"], ["name", "checkmark"], [1, "profile-identity-info"], [1, "quick-shortcuts-strip"], ["role", "button", "tabindex", "0", 1, "shortcut-box", 3, "click"], [1, "shortcut-icon-circle", "bg-purple-light"], ["name", "receipt-outline"], [1, "shortcut-label"], [1, "shortcut-icon-circle", "bg-emerald-light"], ["name", "wallet-outline"], [1, "pocket-pill-chip"], [1, "shortcut-icon-circle", "bg-amber-light"], ["name", "headset-outline"], [1, "menu-group-card"], [1, "group-header-label"], ["role", "button", "tabindex", "0", 1, "menu-row", 3, "click"], [1, "menu-icon-box", "bg-purple-tint"], ["name", "person-outline"], [1, "menu-text-col"], [1, "menu-title"], [1, "menu-subtitle"], ["name", "chevron-forward", 1, "menu-chevron"], [1, "menu-divider"], [1, "menu-icon-box", "bg-emerald-tint"], ["name", "map-outline"], [1, "menu-icon-box", "bg-amber-tint"], ["name", "gift-outline"], [1, "d-flex", "align-items-center", "gap-2"], [1, "reward-tag"], ["name", "settings-outline"], ["name", "bulb-outline"], ["role", "button", "tabindex", "0", 1, "menu-row", "ota-update-row", 3, "click"], ["name", "cloud-download-outline"], [1, "menu-subtitle", "ota-version-row"], [1, "version-num"], ["title", "App is up to date", 1, "ota-status-inline", "up-to-date"], ["title", "New update available", 1, "ota-status-inline", "update-ready"], ["type", "button", "title", "Check for updates now", "aria-label", "Check for OTA Updates", 1, "btn-ota-refresh", 3, "click"], ["name", "refresh-outline"], [1, "menu-icon-box", "bg-slate-tint"], ["name", "information-circle-outline"], ["name", "shield-outline"], ["role", "button", "tabindex", "0", 1, "logout-card-action", 3, "click"], [1, "logout-icon-box"], ["name", "log-out-outline"], [1, "logout-text"], [1, "bottom-nav-spacer"], ["alt", "Profile", 1, "avatar-photo", 3, "error", "src"], ["animated", "", 2, "width", "160px", "height", "22px", "border-radius", "6px", "margin", "0 auto 6px"], ["animated", "", 2, "width", "110px", "height", "14px", "border-radius", "4px", "margin", "0 auto 8px"], [1, "user-display-name"], [1, "user-display-phone"], ["name", "call-outline"], ["name", "checkmark-circle"], ["name", "arrow-up-circle"]], template: function ProfilePage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar")(2, "ion-buttons", 1)(3, "ion-button", 2);
    \u0275\u0275listener("click", function ProfilePage_Template_ion_button_click_3_listener() {
      return ctx.goBack();
    });
    \u0275\u0275element(4, "ion-icon", 3);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "ion-title", 4);
    \u0275\u0275text(6);
    \u0275\u0275pipe(7, "translate");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(8, "ion-content", 5)(9, "main", 6)(10, "section", 7);
    \u0275\u0275element(11, "div", 8);
    \u0275\u0275elementStart(12, "div", 9)(13, "div", 10);
    \u0275\u0275template(14, ProfilePage_Conditional_14_Template, 1, 1, "img", 11)(15, ProfilePage_Conditional_15_Template, 2, 1, "div", 12);
    \u0275\u0275elementStart(16, "div", 13);
    \u0275\u0275element(17, "ion-icon", 14);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(18, "div", 15);
    \u0275\u0275template(19, ProfilePage_Conditional_19_Template, 2, 0)(20, ProfilePage_Conditional_20_Template, 6, 2);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(21, "section", 16)(22, "div", 17);
    \u0275\u0275listener("click", function ProfilePage_Template_div_click_22_listener() {
      return ctx.openDetails("Orders");
    });
    \u0275\u0275elementStart(23, "div", 18);
    \u0275\u0275element(24, "ion-icon", 19);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(25, "span", 20);
    \u0275\u0275text(26);
    \u0275\u0275pipe(27, "translate");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(28, "div", 17);
    \u0275\u0275listener("click", function ProfilePage_Template_div_click_28_listener() {
      return ctx.openPintuPocket();
    });
    \u0275\u0275elementStart(29, "div", 21);
    \u0275\u0275element(30, "ion-icon", 22);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(31, "span", 20);
    \u0275\u0275text(32, "Pintu Pocket");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(33, "span", 23);
    \u0275\u0275text(34);
    \u0275\u0275pipe(35, "async");
    \u0275\u0275pipe(36, "number");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(37, "div", 17);
    \u0275\u0275listener("click", function ProfilePage_Template_div_click_37_listener() {
      return ctx.goToSupport();
    });
    \u0275\u0275elementStart(38, "div", 24);
    \u0275\u0275element(39, "ion-icon", 25);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(40, "span", 20);
    \u0275\u0275text(41);
    \u0275\u0275pipe(42, "translate");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(43, "section", 26)(44, "div", 27);
    \u0275\u0275text(45, "ACCOUNT & REWARDS");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(46, "div", 28);
    \u0275\u0275listener("click", function ProfilePage_Template_div_click_46_listener() {
      return ctx.openDetails("Personal Details");
    });
    \u0275\u0275elementStart(47, "div", 29);
    \u0275\u0275element(48, "ion-icon", 30);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(49, "div", 31)(50, "span", 32);
    \u0275\u0275text(51);
    \u0275\u0275pipe(52, "translate");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(53, "span", 33);
    \u0275\u0275text(54, "Name, email & mobile number");
    \u0275\u0275elementEnd()();
    \u0275\u0275element(55, "ion-icon", 34);
    \u0275\u0275elementEnd();
    \u0275\u0275element(56, "div", 35);
    \u0275\u0275elementStart(57, "div", 28);
    \u0275\u0275listener("click", function ProfilePage_Template_div_click_57_listener() {
      return ctx.openDetails("Saved Addresses");
    });
    \u0275\u0275elementStart(58, "div", 36);
    \u0275\u0275element(59, "ion-icon", 37);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(60, "div", 31)(61, "span", 32);
    \u0275\u0275text(62);
    \u0275\u0275pipe(63, "translate");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(64, "span", 33);
    \u0275\u0275text(65, "Home, work & other locations");
    \u0275\u0275elementEnd()();
    \u0275\u0275element(66, "ion-icon", 34);
    \u0275\u0275elementEnd();
    \u0275\u0275element(67, "div", 35);
    \u0275\u0275elementStart(68, "div", 28);
    \u0275\u0275listener("click", function ProfilePage_Template_div_click_68_listener() {
      return ctx.openReferral();
    });
    \u0275\u0275elementStart(69, "div", 38);
    \u0275\u0275element(70, "ion-icon", 39);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(71, "div", 31)(72, "div", 40)(73, "span", 32);
    \u0275\u0275text(74);
    \u0275\u0275pipe(75, "translate");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(76, "span", 41);
    \u0275\u0275text(77, "\u20B950 OFF");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(78, "span", 33);
    \u0275\u0275text(79, "Share Pintu with family & neighbours");
    \u0275\u0275elementEnd()();
    \u0275\u0275element(80, "ion-icon", 34);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(81, "section", 26)(82, "div", 27);
    \u0275\u0275text(83, "PREFERENCES");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(84, "div", 28);
    \u0275\u0275listener("click", function ProfilePage_Template_div_click_84_listener() {
      return ctx.openDetails("settings");
    });
    \u0275\u0275elementStart(85, "div", 29);
    \u0275\u0275element(86, "ion-icon", 42);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(87, "div", 31)(88, "span", 32);
    \u0275\u0275text(89);
    \u0275\u0275pipe(90, "translate");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(91, "span", 33);
    \u0275\u0275text(92, "Language, theme & display");
    \u0275\u0275elementEnd()();
    \u0275\u0275element(93, "ion-icon", 34);
    \u0275\u0275elementEnd();
    \u0275\u0275element(94, "div", 35);
    \u0275\u0275elementStart(95, "div", 28);
    \u0275\u0275listener("click", function ProfilePage_Template_div_click_95_listener() {
      return ctx.openDetails("suggestion");
    });
    \u0275\u0275elementStart(96, "div", 29);
    \u0275\u0275element(97, "ion-icon", 43);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(98, "div", 31)(99, "span", 32);
    \u0275\u0275text(100);
    \u0275\u0275pipe(101, "translate");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(102, "span", 33);
    \u0275\u0275text(103, "Tell us what you'd love on Pintu");
    \u0275\u0275elementEnd()();
    \u0275\u0275element(104, "ion-icon", 34);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(105, "section", 26)(106, "div", 27);
    \u0275\u0275text(107, "ABOUT & LEGAL");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(108, "div", 44);
    \u0275\u0275listener("click", function ProfilePage_Template_div_click_108_listener() {
      return ctx.checkOtaUpdate(true);
    });
    \u0275\u0275elementStart(109, "div", 29);
    \u0275\u0275element(110, "ion-icon", 45);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(111, "div", 31)(112, "span", 32);
    \u0275\u0275text(113);
    \u0275\u0275pipe(114, "translate");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(115, "div", 46)(116, "span", 47);
    \u0275\u0275text(117);
    \u0275\u0275elementEnd();
    \u0275\u0275template(118, ProfilePage_Conditional_118_Template, 5, 3, "span", 48)(119, ProfilePage_Conditional_119_Template, 5, 4, "span", 49);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(120, "button", 50);
    \u0275\u0275listener("click", function ProfilePage_Template_button_click_120_listener($event) {
      return ctx.onRefreshOtaClick($event);
    });
    \u0275\u0275element(121, "ion-icon", 51);
    \u0275\u0275elementEnd()();
    \u0275\u0275element(122, "div", 35);
    \u0275\u0275elementStart(123, "div", 28);
    \u0275\u0275listener("click", function ProfilePage_Template_div_click_123_listener() {
      return ctx.openDetails("About Pintu");
    });
    \u0275\u0275elementStart(124, "div", 52);
    \u0275\u0275element(125, "ion-icon", 53);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(126, "div", 31)(127, "span", 32);
    \u0275\u0275text(128);
    \u0275\u0275pipe(129, "translate");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(130, "span", 33);
    \u0275\u0275text(131, "Our mission, services & vision");
    \u0275\u0275elementEnd()();
    \u0275\u0275element(132, "ion-icon", 34);
    \u0275\u0275elementEnd();
    \u0275\u0275element(133, "div", 35);
    \u0275\u0275elementStart(134, "div", 28);
    \u0275\u0275listener("click", function ProfilePage_Template_div_click_134_listener() {
      return ctx.openDetails("Terms & Privacy");
    });
    \u0275\u0275elementStart(135, "div", 52);
    \u0275\u0275element(136, "ion-icon", 54);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(137, "div", 31)(138, "span", 32);
    \u0275\u0275text(139);
    \u0275\u0275pipe(140, "translate");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(141, "span", 33);
    \u0275\u0275text(142, "Customer protection & policies");
    \u0275\u0275elementEnd()();
    \u0275\u0275element(143, "ion-icon", 34);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(144, "div", 55);
    \u0275\u0275listener("click", function ProfilePage_Template_div_click_144_listener() {
      return ctx.logOut();
    });
    \u0275\u0275elementStart(145, "div", 56);
    \u0275\u0275element(146, "ion-icon", 57);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(147, "span", 58);
    \u0275\u0275text(148);
    \u0275\u0275pipe(149, "translate");
    \u0275\u0275elementEnd()();
    \u0275\u0275element(150, "app-footer")(151, "div", 59);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(7, 20, "profile"));
    \u0275\u0275advance(2);
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance(6);
    \u0275\u0275conditional((ctx.profileData == null ? null : ctx.profileData.profile_image) ? 14 : 15);
    \u0275\u0275advance(5);
    \u0275\u0275conditional(ctx.isLoading ? 19 : 20);
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(27, 22, "orders"));
    \u0275\u0275advance(8);
    \u0275\u0275textInterpolate1("\u20B9", \u0275\u0275pipeBind2(36, 26, \u0275\u0275pipeBind1(35, 24, ctx.pocketBalance$), "1.0-0"), "");
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(42, 29, "help_support"));
    \u0275\u0275advance(10);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(52, 31, "personal_details"));
    \u0275\u0275advance(11);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(63, 33, "saved_addresses"));
    \u0275\u0275advance(12);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(75, 35, "refer"));
    \u0275\u0275advance(15);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(90, 37, "settings"));
    \u0275\u0275advance(11);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(101, 39, "suggest_product_or_service"));
    \u0275\u0275advance(13);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(114, 41, "check_for_updates"));
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("v", ctx.currentAppVersion, "");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.isOtaUpToDate ? 118 : ctx.hasOtaUpdateAvailable ? 119 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275classProp("spinning", ctx.isCheckingOta);
    \u0275\u0275advance(8);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(129, 43, "about_pintu"));
    \u0275\u0275advance(11);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(140, 45, "terms_of_service_privacy"));
    \u0275\u0275advance(9);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(149, 47, "log_out_account"));
  }
}, dependencies: [
  CommonModule,
  AsyncPipe,
  DecimalPipe,
  FormsModule,
  IonHeader,
  IonToolbar,
  IonButtons,
  IonButton,
  IonTitle,
  IonContent,
  IonSkeletonText,
  IonIcon,
  FooterComponent,
  TranslatePipe
], styles: ["\n\n.profile-content-page[_ngcontent-%COMP%] {\n  --background: #f8fafc;\n  --overflow: auto;\n  position: relative;\n}\nion-header[_ngcontent-%COMP%] {\n  --background: #ffffff;\n  background: #ffffff;\n  border-bottom: 1px solid #f1f5f9;\n}\nion-toolbar[_ngcontent-%COMP%] {\n  --background: #ffffff;\n}\n.profile-body-container[_ngcontent-%COMP%] {\n  padding: 16px 16px 24px;\n  display: flex;\n  flex-direction: column;\n  gap: 16px;\n}\n.profile-hero-card[_ngcontent-%COMP%] {\n  position: relative;\n  border-radius: 24px;\n  background:\n    linear-gradient(\n      145deg,\n      #3b0764 0%,\n      #1e1b4b 100%);\n  padding: 24px 20px 20px;\n  box-shadow: 0 10px 30px rgba(59, 7, 100, 0.28);\n  border: 1px solid rgba(168, 85, 247, 0.25);\n  overflow: hidden;\n}\n.profile-hero-card[_ngcontent-%COMP%]   .hero-glow-orb[_ngcontent-%COMP%] {\n  position: absolute;\n  top: -50px;\n  right: -50px;\n  width: 150px;\n  height: 150px;\n  border-radius: 50%;\n  background:\n    radial-gradient(\n      circle,\n      rgba(160, 0, 226, 0.45) 0%,\n      transparent 70%);\n  filter: blur(25px);\n  pointer-events: none;\n}\n.profile-hero-card[_ngcontent-%COMP%]   .profile-hero-inner[_ngcontent-%COMP%] {\n  position: relative;\n  z-index: 2;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  text-align: center;\n}\n.profile-hero-card[_ngcontent-%COMP%]   .profile-avatar-wrapper[_ngcontent-%COMP%] {\n  position: relative;\n  width: 76px;\n  height: 76px;\n  margin-bottom: 12px;\n}\n.profile-hero-card[_ngcontent-%COMP%]   .profile-avatar-wrapper[_ngcontent-%COMP%]   .avatar-photo[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  border-radius: 50%;\n  object-fit: cover;\n  border: 2.5px solid #ffffff;\n  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.25);\n}\n.profile-hero-card[_ngcontent-%COMP%]   .profile-avatar-wrapper[_ngcontent-%COMP%]   .avatar-initials-badge[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  border-radius: 50%;\n  background:\n    linear-gradient(\n      135deg,\n      #facc15 0%,\n      #ca8a04 100%);\n  color: #0f172a;\n  font-size: 26px;\n  font-weight: 900;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  border: 2.5px solid #ffffff;\n  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.25);\n}\n.profile-hero-card[_ngcontent-%COMP%]   .profile-avatar-wrapper[_ngcontent-%COMP%]   .verified-tick-badge[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 0;\n  right: 0;\n  width: 22px;\n  height: 22px;\n  border-radius: 50%;\n  background: #10b981;\n  border: 2px solid #ffffff;\n  color: #ffffff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 13px;\n  font-weight: 900;\n}\n.profile-hero-card[_ngcontent-%COMP%]   .profile-identity-info[_ngcontent-%COMP%]   .user-display-name[_ngcontent-%COMP%] {\n  font-size: 20px;\n  font-weight: 850;\n  color: #ffffff;\n  margin: 0 0 4px;\n  letter-spacing: -0.3px;\n}\n.profile-hero-card[_ngcontent-%COMP%]   .profile-identity-info[_ngcontent-%COMP%]   .user-display-phone[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  font-size: 13px;\n  color: #e9d5ff;\n  margin: 0;\n}\n.profile-hero-card[_ngcontent-%COMP%]   .profile-identity-info[_ngcontent-%COMP%]   .user-display-phone[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 13px;\n}\n.quick-shortcuts-strip[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  gap: 10px;\n}\n.quick-shortcuts-strip[_ngcontent-%COMP%]   .shortcut-box[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 18px;\n  padding: 14px 8px;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  gap: 8px;\n  border: 1px solid #f1f5f9;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);\n  cursor: pointer;\n  transition: transform 0.15s ease, box-shadow 0.15s ease;\n}\n.quick-shortcuts-strip[_ngcontent-%COMP%]   .shortcut-box[_ngcontent-%COMP%]:active {\n  transform: scale(0.96);\n  background: #f8fafc;\n}\n.quick-shortcuts-strip[_ngcontent-%COMP%]   .shortcut-box[_ngcontent-%COMP%]   .shortcut-icon-circle[_ngcontent-%COMP%] {\n  width: 44px;\n  height: 44px;\n  border-radius: 14px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 20px;\n}\n.quick-shortcuts-strip[_ngcontent-%COMP%]   .shortcut-box[_ngcontent-%COMP%]   .shortcut-icon-circle.bg-purple-light[_ngcontent-%COMP%] {\n  background: #f5f3ff;\n  color: #7c3aed;\n}\n.quick-shortcuts-strip[_ngcontent-%COMP%]   .shortcut-box[_ngcontent-%COMP%]   .shortcut-icon-circle.bg-emerald-light[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  color: #059669;\n}\n.quick-shortcuts-strip[_ngcontent-%COMP%]   .shortcut-box[_ngcontent-%COMP%]   .shortcut-icon-circle.bg-amber-light[_ngcontent-%COMP%] {\n  background: #fffbeb;\n  color: #d97706;\n}\n.quick-shortcuts-strip[_ngcontent-%COMP%]   .shortcut-box[_ngcontent-%COMP%]   .shortcut-label[_ngcontent-%COMP%] {\n  font-size: 12.5px;\n  font-weight: 700;\n  color: #334155;\n}\n.quick-shortcuts-strip[_ngcontent-%COMP%]   .shortcut-box[_ngcontent-%COMP%]   .pocket-pill-chip[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 850;\n  color: #7c3aed;\n  background: #f3e8ff;\n  padding: 1px 7px;\n  border-radius: 99px;\n  margin-top: -2px;\n}\n.menu-group-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 20px;\n  border: 1px solid #f1f5f9;\n  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.03);\n  padding: 14px 16px;\n}\n.menu-group-card[_ngcontent-%COMP%]   .group-header-label[_ngcontent-%COMP%] {\n  font-size: 10.5px;\n  font-weight: 800;\n  color: #94a3b8;\n  letter-spacing: 0.8px;\n  margin-bottom: 12px;\n  text-transform: uppercase;\n}\n.menu-group-card[_ngcontent-%COMP%]   .menu-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  padding: 10px 0;\n  cursor: pointer;\n  transition: opacity 0.15s ease;\n}\n.menu-group-card[_ngcontent-%COMP%]   .menu-row[_ngcontent-%COMP%]:active {\n  opacity: 0.7;\n}\n.menu-group-card[_ngcontent-%COMP%]   .menu-row[_ngcontent-%COMP%]   .menu-icon-box[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 38px;\n  border-radius: 12px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 18px;\n  flex-shrink: 0;\n}\n.menu-group-card[_ngcontent-%COMP%]   .menu-row[_ngcontent-%COMP%]   .menu-icon-box.bg-purple-tint[_ngcontent-%COMP%] {\n  background: #f3e8ff;\n  color: #a000e2;\n}\n.menu-group-card[_ngcontent-%COMP%]   .menu-row[_ngcontent-%COMP%]   .menu-icon-box.bg-emerald-tint[_ngcontent-%COMP%] {\n  background: #d1fae5;\n  color: #059669;\n}\n.menu-group-card[_ngcontent-%COMP%]   .menu-row[_ngcontent-%COMP%]   .menu-icon-box.bg-amber-tint[_ngcontent-%COMP%] {\n  background: #fef3c7;\n  color: #b45309;\n}\n.menu-group-card[_ngcontent-%COMP%]   .menu-row[_ngcontent-%COMP%]   .menu-icon-box.bg-slate-tint[_ngcontent-%COMP%] {\n  background: #f1f5f9;\n  color: #475569;\n}\n.menu-group-card[_ngcontent-%COMP%]   .menu-row[_ngcontent-%COMP%]   .menu-text-col[_ngcontent-%COMP%] {\n  flex: 1;\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n  min-width: 0;\n}\n.menu-group-card[_ngcontent-%COMP%]   .menu-row[_ngcontent-%COMP%]   .menu-text-col[_ngcontent-%COMP%]   .menu-title[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 750;\n  color: #0f172a;\n}\n.menu-group-card[_ngcontent-%COMP%]   .menu-row[_ngcontent-%COMP%]   .menu-text-col[_ngcontent-%COMP%]   .menu-subtitle[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  font-weight: 500;\n  color: #64748b;\n}\n.menu-group-card[_ngcontent-%COMP%]   .menu-row[_ngcontent-%COMP%]   .menu-text-col[_ngcontent-%COMP%]   .reward-tag[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  font-weight: 800;\n  background: #fef08a;\n  color: #854d0e;\n  padding: 2px 7px;\n  border-radius: 6px;\n}\n.menu-group-card[_ngcontent-%COMP%]   .menu-row[_ngcontent-%COMP%]   .menu-chevron[_ngcontent-%COMP%] {\n  font-size: 16px;\n  color: #cbd5e1;\n  flex-shrink: 0;\n}\n.menu-group-card[_ngcontent-%COMP%]   .menu-row.ota-update-row[_ngcontent-%COMP%]   .ota-version-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  font-size: 12px;\n  color: #64748b;\n  font-weight: 500;\n  line-height: 1.2;\n}\n.menu-group-card[_ngcontent-%COMP%]   .menu-row.ota-update-row[_ngcontent-%COMP%]   .ota-version-row[_ngcontent-%COMP%]   .version-num[_ngcontent-%COMP%] {\n  font-weight: 600;\n  color: #475569;\n  font-size: 12px;\n}\n.menu-group-card[_ngcontent-%COMP%]   .menu-row.ota-update-row[_ngcontent-%COMP%]   .ota-version-row[_ngcontent-%COMP%]   .ota-status-inline[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 3px;\n  font-size: 12px;\n  font-weight: 600;\n  background: transparent;\n  border: none;\n  padding: 0;\n}\n.menu-group-card[_ngcontent-%COMP%]   .menu-row.ota-update-row[_ngcontent-%COMP%]   .ota-version-row[_ngcontent-%COMP%]   .ota-status-inline.up-to-date[_ngcontent-%COMP%] {\n  color: #059669;\n}\n.menu-group-card[_ngcontent-%COMP%]   .menu-row.ota-update-row[_ngcontent-%COMP%]   .ota-version-row[_ngcontent-%COMP%]   .ota-status-inline.up-to-date[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  color: #10b981;\n}\n.menu-group-card[_ngcontent-%COMP%]   .menu-row.ota-update-row[_ngcontent-%COMP%]   .ota-version-row[_ngcontent-%COMP%]   .ota-status-inline.update-ready[_ngcontent-%COMP%] {\n  color: #2563eb;\n}\n.menu-group-card[_ngcontent-%COMP%]   .menu-row.ota-update-row[_ngcontent-%COMP%]   .ota-version-row[_ngcontent-%COMP%]   .ota-status-inline.update-ready[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  color: #3b82f6;\n}\n.menu-group-card[_ngcontent-%COMP%]   .menu-row.ota-update-row[_ngcontent-%COMP%]   .btn-ota-refresh[_ngcontent-%COMP%] {\n  width: 36px;\n  height: 36px;\n  border-radius: 50%;\n  background: #f8fafc;\n  border: 1.5px solid #e2e8f0;\n  color: var(--app-theme-color, #a000e2);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 18px;\n  cursor: pointer;\n  flex-shrink: 0;\n  transition: all 0.2s ease;\n}\n.menu-group-card[_ngcontent-%COMP%]   .menu-row.ota-update-row[_ngcontent-%COMP%]   .btn-ota-refresh[_ngcontent-%COMP%]:hover {\n  background: #f3e8ff;\n  border-color: #d8b4fe;\n}\n.menu-group-card[_ngcontent-%COMP%]   .menu-row.ota-update-row[_ngcontent-%COMP%]   .btn-ota-refresh[_ngcontent-%COMP%]:active {\n  transform: scale(0.92);\n  background: #e9d5ff;\n}\n.menu-group-card[_ngcontent-%COMP%]   .menu-row.ota-update-row[_ngcontent-%COMP%]   .btn-ota-refresh.spinning[_ngcontent-%COMP%] {\n  animation: _ngcontent-%COMP%_otaSpin 1s linear infinite;\n  color: #a000e2;\n  pointer-events: none;\n}\n.menu-group-card[_ngcontent-%COMP%]   .menu-divider[_ngcontent-%COMP%] {\n  height: 1px;\n  background: #f8fafc;\n  margin: 2px 0 2px 50px;\n}\n@keyframes _ngcontent-%COMP%_otaSpin {\n  100% {\n    transform: rotate(360deg);\n  }\n}\n.logout-card-action[_ngcontent-%COMP%] {\n  background: #fff5f5;\n  border: 1px solid #fee2e2;\n  border-radius: 18px;\n  padding: 14px 18px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 10px;\n  cursor: pointer;\n  transition: background 0.15s ease, transform 0.15s ease;\n}\n.logout-card-action[_ngcontent-%COMP%]:active {\n  background: #fecaca;\n  transform: scale(0.98);\n}\n.logout-card-action[_ngcontent-%COMP%]   .logout-icon-box[_ngcontent-%COMP%] {\n  font-size: 19px;\n  color: #ef4444;\n  display: flex;\n  align-items: center;\n}\n.logout-card-action[_ngcontent-%COMP%]   .logout-text[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  font-weight: 800;\n  color: #dc2626;\n}\n.app-version-footer[_ngcontent-%COMP%] {\n  text-align: center;\n  padding: 8px 16px;\n}\n.app-version-footer[_ngcontent-%COMP%]   .brand-text[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 800;\n  color: #94a3b8;\n  letter-spacing: 0.8px;\n  margin: 0 0 3px;\n}\n.app-version-footer[_ngcontent-%COMP%]   .ver-text[_ngcontent-%COMP%] {\n  font-size: 10.5px;\n  color: #cbd5e1;\n  font-weight: 600;\n  margin: 0;\n}\n.bottom-nav-spacer[_ngcontent-%COMP%] {\n  min-height: calc(80px + env(safe-area-inset-bottom, 0px));\n  height: calc(80px + env(safe-area-inset-bottom, 0px));\n  width: 100%;\n}\n/*# sourceMappingURL=profile.page.css.map */"] });
var ProfilePage = _ProfilePage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(ProfilePage, { className: "ProfilePage", filePath: "src/app/pages/profile/profile.page.ts", lineNumber: 70 });
})();
export {
  ProfilePage
};
//# sourceMappingURL=profile.page-EFTWASXX.js.map
