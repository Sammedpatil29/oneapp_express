import {
  DUMMY_LAB_CATEGORIES,
  DUMMY_LAB_TESTS,
  DUMMY_MEDICINES,
  DUMMY_MEDICINE_CATEGORIES
} from "./chunk-GFPPLSVS.js";
import {
  PharmacyCartService
} from "./chunk-SFLHCKYK.js";
import {
  LocationService
} from "./chunk-4TQR4WSH.js";
import "./chunk-V444GY6B.js";
import "./chunk-QH3WR2OQ.js";
import {
  add,
  addIcons,
  arrowBack,
  arrowForward,
  arrowForwardOutline,
  bagHandleOutline,
  bandageOutline,
  bodyOutline,
  cameraOutline,
  cartOutline,
  checkmarkCircle,
  checkmarkCircleOutline,
  chevronDown,
  closeOutline,
  cloudUploadOutline,
  documentTextOutline,
  fitnessOutline,
  flashOutline,
  flaskOutline,
  happyOutline,
  heartOutline,
  location,
  locationOutline,
  medkitOutline,
  nutritionOutline,
  pulseOutline,
  receiptOutline,
  remove,
  roseOutline,
  searchOutline,
  shieldCheckmarkOutline,
  sparklesOutline,
  thermometerOutline,
  timeOutline,
  waterOutline
} from "./chunk-V2INQVNG.js";
import {
  ToastController
} from "./chunk-OE5MTPUR.js";
import "./chunk-YJYUHAOC.js";
import "./chunk-XR3JUECC.js";
import {
  IonContent,
  IonHeader,
  IonIcon,
  IonModal,
  IonRefresher,
  IonRefresherContent,
  IonToolbar
} from "./chunk-CJE2NDTY.js";
import {
  CommonModule,
  DefaultValueAccessor,
  FormsModule,
  NavController,
  NgControlStatus,
  NgModel,
  Router,
  Subscription,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIdentity,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵstyleProp,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-Z7XNNJSA.js";
import "./chunk-FH4NU4VH.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/components/pharmacy-footer/pharmacy-footer.component.ts
function PharmacyFooterComponent_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 9);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r0.subtitle);
  }
}
function PharmacyFooterComponent_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 10);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r0.address);
  }
}
function PharmacyFooterComponent_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 11);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r0.licenseInfo);
  }
}
var _PharmacyFooterComponent = class _PharmacyFooterComponent {
  constructor() {
    this.label = "Managed By";
    this.companyName = "MedPlus Pharmacy & Wellness";
    this.subtitle = "Licensed Chemist & Druggist \u2022 100% Genuine Medicines";
    this.address = "Main Road, Opp. Bus Stand, Athani - 591304";
    this.licenseInfo = "DL No: KA-BEL-2024-0987 \u2022 GSTIN: 29XXXXX0000X1ZX \u2022 Call: 8884950068";
    this.logoUrl = "assets/favicon_io/apple-touch-icon.png";
  }
  onImageError(event) {
    const target = event.target;
    if (target) {
      target.src = "assets/favicon_io/favicon-32x32.png";
    }
  }
};
_PharmacyFooterComponent.\u0275fac = function PharmacyFooterComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _PharmacyFooterComponent)();
};
_PharmacyFooterComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _PharmacyFooterComponent, selectors: [["app-pharmacy-footer"]], inputs: { label: "label", companyName: "companyName", subtitle: "subtitle", address: "address", licenseInfo: "licenseInfo", logoUrl: "logoUrl" }, decls: 14, vars: 7, consts: [[1, "pharmacy-brand-footer"], [1, "footer-divider-line"], [1, "footer-content-wrapper"], [1, "powered-by-label"], [1, "partner-card"], [1, "brand-logo-wrap"], [1, "brand-logo-img", 3, "error", "src", "alt"], [1, "brand-text-col"], [1, "brand-name", "text-center"], [1, "brand-sub", "text-center"], [1, "brand-address", "text-center"], [1, "brand-gst", "text-center"]], template: function PharmacyFooterComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "footer", 0);
    \u0275\u0275element(1, "div", 1);
    \u0275\u0275elementStart(2, "div", 2)(3, "div", 3);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 4)(6, "div", 5)(7, "img", 6);
    \u0275\u0275listener("error", function PharmacyFooterComponent_Template_img_error_7_listener($event) {
      return ctx.onImageError($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "div", 7)(9, "h4", 8);
    \u0275\u0275text(10);
    \u0275\u0275elementEnd();
    \u0275\u0275template(11, PharmacyFooterComponent_Conditional_11_Template, 2, 1, "span", 9)(12, PharmacyFooterComponent_Conditional_12_Template, 2, 1, "span", 10)(13, PharmacyFooterComponent_Conditional_13_Template, 2, 1, "span", 11);
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx.label);
    \u0275\u0275advance(3);
    \u0275\u0275property("src", ctx.logoUrl, \u0275\u0275sanitizeUrl)("alt", ctx.companyName);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx.companyName);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.subtitle ? 11 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.address ? 12 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.licenseInfo ? 13 : -1);
  }
}, dependencies: [CommonModule], styles: ["\n\n.pharmacy-brand-footer[_ngcontent-%COMP%] {\n  width: 100%;\n  max-width: 100%;\n  box-sizing: border-box;\n  margin-top: 20px;\n  margin-bottom: 24px;\n  position: relative;\n  overflow: hidden;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n}\n.pharmacy-brand-footer[_ngcontent-%COMP%]   .footer-divider-line[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 1px;\n  background:\n    linear-gradient(\n      90deg,\n      transparent 0%,\n      rgba(226, 232, 240, 0.9) 25%,\n      rgba(203, 213, 225, 0.9) 50%,\n      rgba(226, 232, 240, 0.9) 75%,\n      transparent 100%);\n  margin-bottom: 14px;\n}\n.pharmacy-brand-footer[_ngcontent-%COMP%]   .footer-content-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  text-align: center;\n  gap: 8px;\n  width: 100%;\n  padding: 0 16px;\n  box-sizing: border-box;\n}\n.pharmacy-brand-footer[_ngcontent-%COMP%]   .powered-by-label[_ngcontent-%COMP%] {\n  font-size: 10.5px;\n  font-weight: 700;\n  color: #94a3b8;\n  letter-spacing: 1.2px;\n  text-transform: uppercase;\n}\n.pharmacy-brand-footer[_ngcontent-%COMP%]   .partner-card[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  text-align: center;\n  gap: 8px;\n  background: transparent;\n  padding: 0px 0px 10px;\n  max-width: 100%;\n  transition: transform 0.2s ease, box-shadow 0.2s ease;\n}\n.pharmacy-brand-footer[_ngcontent-%COMP%]   .partner-card[_ngcontent-%COMP%]   .brand-logo-wrap[_ngcontent-%COMP%] {\n  width: 44px;\n  height: 44px;\n  min-width: 44px;\n  border-radius: 12px;\n  background: #f0fdf4;\n  border: 1px solid #bbf7d0;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  overflow: hidden;\n  flex-shrink: 0;\n  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);\n}\n.pharmacy-brand-footer[_ngcontent-%COMP%]   .partner-card[_ngcontent-%COMP%]   .brand-logo-wrap[_ngcontent-%COMP%]   .brand-logo-img[_ngcontent-%COMP%] {\n  width: 28px;\n  height: 28px;\n  object-fit: contain;\n  display: block;\n}\n.pharmacy-brand-footer[_ngcontent-%COMP%]   .partner-card[_ngcontent-%COMP%]   .brand-text-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  text-align: center;\n  gap: 3px;\n}\n.pharmacy-brand-footer[_ngcontent-%COMP%]   .partner-card[_ngcontent-%COMP%]   .brand-text-col[_ngcontent-%COMP%]   .brand-name[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 13px;\n  font-weight: 800;\n  color: #0f172a;\n  letter-spacing: -0.2px;\n  line-height: 1.25;\n  text-align: center;\n}\n.pharmacy-brand-footer[_ngcontent-%COMP%]   .partner-card[_ngcontent-%COMP%]   .brand-text-col[_ngcontent-%COMP%]   .brand-sub[_ngcontent-%COMP%] {\n  font-size: 10.5px;\n  font-weight: 600;\n  color: #059669;\n  letter-spacing: 0.2px;\n  line-height: 1.2;\n  text-align: center;\n}\n.pharmacy-brand-footer[_ngcontent-%COMP%]   .partner-card[_ngcontent-%COMP%]   .brand-text-col[_ngcontent-%COMP%]   .brand-address[_ngcontent-%COMP%] {\n  font-size: 10.5px;\n  font-weight: 600;\n  color: #64748b;\n  letter-spacing: 0.2px;\n  line-height: 1.25;\n  text-align: center;\n}\n.pharmacy-brand-footer[_ngcontent-%COMP%]   .partner-card[_ngcontent-%COMP%]   .brand-text-col[_ngcontent-%COMP%]   .brand-gst[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 600;\n  color: #94a3b8;\n  letter-spacing: 0.3px;\n  line-height: 1.2;\n  text-align: center;\n}\n/*# sourceMappingURL=pharmacy-footer.component.css.map */"] });
var PharmacyFooterComponent = _PharmacyFooterComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(PharmacyFooterComponent, { className: "PharmacyFooterComponent", filePath: "src/app/components/pharmacy-footer/pharmacy-footer.component.ts", lineNumber: 11 });
})();

// src/app/pages/pharmacy/pharmacy.page.ts
var _c0 = () => [0, 0.7, 0.95];
var _forTrack0 = ($index, $item) => $item.id;
function PharmacyPage_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "span", 11);
  }
}
function PharmacyPage_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "span", 12);
  }
}
function PharmacyPage_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "span", 13);
  }
}
function PharmacyPage_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 15)(1, "span", 33);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r0.displayFullAddress);
  }
}
function PharmacyPage_Conditional_26_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 23);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r0.medSummary.itemCount);
  }
}
function PharmacyPage_Conditional_32_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 25);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r0.labSummary.itemCount);
  }
}
function PharmacyPage_Conditional_37_For_62_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 78);
    \u0275\u0275text(1, "Rx");
    \u0275\u0275elementEnd();
  }
}
function PharmacyPage_Conditional_37_For_62_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 81);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const med_r4 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("", med_r4.discountPercent, "% OFF");
  }
}
function PharmacyPage_Conditional_37_For_62_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 89);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const med_r4 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("\u20B9", med_r4.mrp, "");
  }
}
function PharmacyPage_Conditional_37_For_62_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 93);
    \u0275\u0275listener("click", function PharmacyPage_Conditional_37_For_62_Conditional_18_Template_button_click_0_listener($event) {
      \u0275\u0275restoreView(_r5);
      const med_r4 = \u0275\u0275nextContext().$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.addMedicineToCart(med_r4, $event));
    });
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2, "ADD");
    \u0275\u0275elementEnd();
    \u0275\u0275element(3, "ion-icon", 94);
    \u0275\u0275elementEnd();
  }
}
function PharmacyPage_Conditional_37_For_62_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 92)(1, "button", 95);
    \u0275\u0275listener("click", function PharmacyPage_Conditional_37_For_62_Conditional_19_Template_button_click_1_listener($event) {
      \u0275\u0275restoreView(_r6);
      const med_r4 = \u0275\u0275nextContext().$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.decrementMedicine(med_r4, $event));
    });
    \u0275\u0275element(2, "ion-icon", 96);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 97);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "button", 95);
    \u0275\u0275listener("click", function PharmacyPage_Conditional_37_For_62_Conditional_19_Template_button_click_5_listener($event) {
      \u0275\u0275restoreView(_r6);
      const med_r4 = \u0275\u0275nextContext().$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.incrementMedicine(med_r4, $event));
    });
    \u0275\u0275element(6, "ion-icon", 94);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const med_r4 = \u0275\u0275nextContext().$implicit;
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r0.getMedicineQty(med_r4.id));
  }
}
function PharmacyPage_Conditional_37_For_62_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 77);
    \u0275\u0275listener("click", function PharmacyPage_Conditional_37_For_62_Template_div_click_0_listener() {
      const med_r4 = \u0275\u0275restoreView(_r3).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.openMedicineDetails(med_r4.id));
    });
    \u0275\u0275template(1, PharmacyPage_Conditional_37_For_62_Conditional_1_Template, 2, 0, "span", 78);
    \u0275\u0275elementStart(2, "div", 79);
    \u0275\u0275element(3, "img", 80);
    \u0275\u0275template(4, PharmacyPage_Conditional_37_For_62_Conditional_4_Template, 2, 1, "span", 81);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 82)(6, "span", 83);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "h5", 84);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "span", 85);
    \u0275\u0275text(11);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "div", 86)(13, "div", 87)(14, "span", 88);
    \u0275\u0275text(15);
    \u0275\u0275elementEnd();
    \u0275\u0275template(16, PharmacyPage_Conditional_37_For_62_Conditional_16_Template, 2, 1, "span", 89);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "div", 90);
    \u0275\u0275template(18, PharmacyPage_Conditional_37_For_62_Conditional_18_Template, 4, 0, "button", 91)(19, PharmacyPage_Conditional_37_For_62_Conditional_19_Template, 7, 1, "div", 92);
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const med_r4 = ctx.$implicit;
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275conditional(med_r4.prescriptionRequired ? 1 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275property("src", med_r4.image, \u0275\u0275sanitizeUrl)("alt", med_r4.name);
    \u0275\u0275advance();
    \u0275\u0275conditional(med_r4.discountPercent > 0 ? 4 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(med_r4.brand);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(med_r4.name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(med_r4.packSize);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("\u20B9", med_r4.price, "");
    \u0275\u0275advance();
    \u0275\u0275conditional(med_r4.mrp > med_r4.price ? 16 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r0.getMedicineQty(med_r4.id) === 0 ? 18 : 19);
  }
}
function PharmacyPage_Conditional_37_For_75_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 72);
    \u0275\u0275listener("click", function PharmacyPage_Conditional_37_For_75_Template_button_click_0_listener() {
      const cat_r8 = \u0275\u0275restoreView(_r7).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.filterMedCategory(cat_r8.id));
    });
    \u0275\u0275element(1, "ion-icon", 98);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const cat_r8 = ctx.$implicit;
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275classProp("active", ctx_r0.selectedMedCategory === cat_r8.id);
    \u0275\u0275advance();
    \u0275\u0275styleProp("color", cat_r8.color);
    \u0275\u0275property("name", cat_r8.icon);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(cat_r8.name);
  }
}
function PharmacyPage_Conditional_37_For_78_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 78);
    \u0275\u0275text(1, "Rx");
    \u0275\u0275elementEnd();
  }
}
function PharmacyPage_Conditional_37_For_78_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 81);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const med_r10 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("", med_r10.discountPercent, "% OFF");
  }
}
function PharmacyPage_Conditional_37_For_78_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 109);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const med_r10 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("\u20B9", med_r10.mrp, "");
  }
}
function PharmacyPage_Conditional_37_For_78_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 93);
    \u0275\u0275listener("click", function PharmacyPage_Conditional_37_For_78_Conditional_20_Template_button_click_0_listener($event) {
      \u0275\u0275restoreView(_r11);
      const med_r10 = \u0275\u0275nextContext().$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.addMedicineToCart(med_r10, $event));
    });
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2, "ADD");
    \u0275\u0275elementEnd();
    \u0275\u0275element(3, "ion-icon", 94);
    \u0275\u0275elementEnd();
  }
}
function PharmacyPage_Conditional_37_For_78_Conditional_21_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 92)(1, "button", 95);
    \u0275\u0275listener("click", function PharmacyPage_Conditional_37_For_78_Conditional_21_Template_button_click_1_listener($event) {
      \u0275\u0275restoreView(_r12);
      const med_r10 = \u0275\u0275nextContext().$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.decrementMedicine(med_r10, $event));
    });
    \u0275\u0275element(2, "ion-icon", 96);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 97);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "button", 95);
    \u0275\u0275listener("click", function PharmacyPage_Conditional_37_For_78_Conditional_21_Template_button_click_5_listener($event) {
      \u0275\u0275restoreView(_r12);
      const med_r10 = \u0275\u0275nextContext().$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.incrementMedicine(med_r10, $event));
    });
    \u0275\u0275element(6, "ion-icon", 94);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const med_r10 = \u0275\u0275nextContext().$implicit;
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r0.getMedicineQty(med_r10.id));
  }
}
function PharmacyPage_Conditional_37_For_78_Conditional_22_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "div", 111);
    \u0275\u0275elementStart(1, "div", 112)(2, "span", 113);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "span", 114);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const med_r10 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(med_r10.seller.type);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(med_r10.seller.name);
  }
}
function PharmacyPage_Conditional_37_For_78_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 99);
    \u0275\u0275listener("click", function PharmacyPage_Conditional_37_For_78_Template_div_click_0_listener() {
      const med_r10 = \u0275\u0275restoreView(_r9).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.openMedicineDetails(med_r10.id));
    });
    \u0275\u0275template(1, PharmacyPage_Conditional_37_For_78_Conditional_1_Template, 2, 0, "span", 78);
    \u0275\u0275elementStart(2, "div", 100);
    \u0275\u0275element(3, "img", 80);
    \u0275\u0275template(4, PharmacyPage_Conditional_37_For_78_Conditional_4_Template, 2, 1, "span", 81);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 101)(6, "span", 102);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "h5", 103);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "span", 104);
    \u0275\u0275text(11);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "p", 105);
    \u0275\u0275text(13);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "div", 106)(15, "div", 107)(16, "span", 108);
    \u0275\u0275text(17);
    \u0275\u0275elementEnd();
    \u0275\u0275template(18, PharmacyPage_Conditional_37_For_78_Conditional_18_Template, 2, 1, "span", 109);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(19, "div", 110);
    \u0275\u0275template(20, PharmacyPage_Conditional_37_For_78_Conditional_20_Template, 4, 0, "button", 91)(21, PharmacyPage_Conditional_37_For_78_Conditional_21_Template, 7, 1, "div", 92);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(22, PharmacyPage_Conditional_37_For_78_Conditional_22_Template, 6, 2);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const med_r10 = ctx.$implicit;
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275conditional(med_r10.prescriptionRequired ? 1 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275property("src", med_r10.image, \u0275\u0275sanitizeUrl)("alt", med_r10.name);
    \u0275\u0275advance();
    \u0275\u0275conditional(med_r10.discountPercent > 0 ? 4 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(med_r10.brand);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(med_r10.name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", med_r10.dosageForm, " \u2022 ", med_r10.packSize, "");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(med_r10.description);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("\u20B9", med_r10.price, "");
    \u0275\u0275advance();
    \u0275\u0275conditional(med_r10.mrp > med_r10.price ? 18 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r0.getMedicineQty(med_r10.id) === 0 ? 20 : 21);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(med_r10.seller ? 22 : -1);
  }
}
function PharmacyPage_Conditional_37_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "section", 34)(1, "div", 35);
    \u0275\u0275element(2, "div", 36)(3, "div", 37);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "div", 38)(5, "div", 39);
    \u0275\u0275element(6, "ion-icon", 40);
    \u0275\u0275elementStart(7, "span");
    \u0275\u0275text(8, "QUICK PRESCRIPTION ORDER");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "h3", 41);
    \u0275\u0275text(10, "Order Medicines via Prescription");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "p", 42);
    \u0275\u0275text(12, " Upload your doctor's prescription. Our licensed pharmacist will verify and arrange your complete order. ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "div", 43)(14, "div", 44);
    \u0275\u0275element(15, "ion-icon", 45);
    \u0275\u0275elementStart(16, "span");
    \u0275\u0275text(17, "100% Genuine");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(18, "div", 44);
    \u0275\u0275element(19, "ion-icon", 46);
    \u0275\u0275elementStart(20, "span");
    \u0275\u0275text(21, "Free Verification");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(22, "div", 44);
    \u0275\u0275element(23, "ion-icon", 47);
    \u0275\u0275elementStart(24, "span");
    \u0275\u0275text(25, "Instant Dispatch");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(26, "button", 48);
    \u0275\u0275listener("click", function PharmacyPage_Conditional_37_Template_button_click_26_listener() {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.openPrescriptionModal("medicine"));
    });
    \u0275\u0275element(27, "ion-icon", 49);
    \u0275\u0275elementStart(28, "span");
    \u0275\u0275text(29, "UPLOAD PRESCRIPTION");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(30, "section", 50);
    \u0275\u0275element(31, "div", 51);
    \u0275\u0275elementStart(32, "div", 52)(33, "div", 53)(34, "div", 54);
    \u0275\u0275element(35, "ion-icon", 55);
    \u0275\u0275elementStart(36, "span");
    \u0275\u0275text(37, "SUPERFAST 15-MIN DELIVERY");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(38, "h4", 56);
    \u0275\u0275text(39, "Flat 15% OFF on Medicines");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(40, "p", 57);
    \u0275\u0275text(41, "Use coupon code ");
    \u0275\u0275elementStart(42, "strong", 58);
    \u0275\u0275text(43, "HEALTH15");
    \u0275\u0275elementEnd();
    \u0275\u0275text(44, " at checkout. 100% genuine medicines from licensed pharmacies.");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(45, "div", 59)(46, "div", 60)(47, "span", 61);
    \u0275\u0275text(48, "15%");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(49, "span", 62);
    \u0275\u0275text(50, "OFF");
    \u0275\u0275elementEnd()()()()();
    \u0275\u0275elementStart(51, "section", 63)(52, "div", 64)(53, "div", 65)(54, "h4", 66);
    \u0275\u0275text(55, "You May Need");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(56, "span", 67);
    \u0275\u0275text(57, "Everyday medicines & health essentials");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(58, "span", 68);
    \u0275\u0275text(59, "POPULAR");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(60, "div", 69);
    \u0275\u0275repeaterCreate(61, PharmacyPage_Conditional_37_For_62_Template, 20, 10, "div", 70, _forTrack0);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(63, "section", 63)(64, "div", 64)(65, "div", 65)(66, "h4", 66);
    \u0275\u0275text(67, "Shop by Category");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(68, "span", 67);
    \u0275\u0275text(69, "Find medicines for specific health needs");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(70, "div", 71)(71, "button", 72);
    \u0275\u0275listener("click", function PharmacyPage_Conditional_37_Template_button_click_71_listener() {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.filterMedCategory("all"));
    });
    \u0275\u0275elementStart(72, "span");
    \u0275\u0275text(73, "All Medicines");
    \u0275\u0275elementEnd()();
    \u0275\u0275repeaterCreate(74, PharmacyPage_Conditional_37_For_75_Template, 4, 6, "button", 73, _forTrack0);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(76, "div", 74);
    \u0275\u0275repeaterCreate(77, PharmacyPage_Conditional_37_For_78_Template, 23, 13, "div", 75, _forTrack0);
    \u0275\u0275elementEnd()();
    \u0275\u0275element(79, "app-pharmacy-footer", 76);
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(61);
    \u0275\u0275repeater(ctx_r0.allMedicines.slice(0, 6));
    \u0275\u0275advance(10);
    \u0275\u0275classProp("active", ctx_r0.selectedMedCategory === "all");
    \u0275\u0275advance(3);
    \u0275\u0275repeater(ctx_r0.medicineCategories);
    \u0275\u0275advance(3);
    \u0275\u0275repeater(ctx_r0.displayedMedicines);
  }
}
function PharmacyPage_Conditional_38_For_63_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 72);
    \u0275\u0275listener("click", function PharmacyPage_Conditional_38_For_63_Template_button_click_0_listener() {
      const cat_r15 = \u0275\u0275restoreView(_r14).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.filterLabCategory(cat_r15.id));
    });
    \u0275\u0275element(1, "ion-icon", 98);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const cat_r15 = ctx.$implicit;
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275classProp("active", ctx_r0.selectedLabCategory === cat_r15.id);
    \u0275\u0275advance();
    \u0275\u0275styleProp("color", cat_r15.color);
    \u0275\u0275property("name", cat_r15.icon);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(cat_r15.name);
  }
}
function PharmacyPage_Conditional_38_For_75_For_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 137);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const tag_r18 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(tag_r18);
  }
}
function PharmacyPage_Conditional_38_For_75_For_32_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 147);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const param_r19 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("\u2022 ", param_r19, "");
  }
}
function PharmacyPage_Conditional_38_For_75_Conditional_33_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 148);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const test_r17 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("+", test_r17.parameters.length - 4, " more");
  }
}
function PharmacyPage_Conditional_38_For_75_Conditional_39_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 155);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "span", 156);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const test_r17 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("\u20B9", test_r17.mrp, "");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("", test_r17.discountPercent, "% OFF");
  }
}
function PharmacyPage_Conditional_38_For_75_Conditional_43_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 45);
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2, "ADDED");
    \u0275\u0275elementEnd();
  }
}
function PharmacyPage_Conditional_38_For_75_Conditional_44_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 94);
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2, "BOOK TEST");
    \u0275\u0275elementEnd();
  }
}
function PharmacyPage_Conditional_38_For_75_Conditional_45_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "div", 111);
    \u0275\u0275elementStart(1, "div", 112)(2, "span", 113);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "span", 114);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const test_r17 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(test_r17.labPartner.type);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(test_r17.labPartner.name);
  }
}
function PharmacyPage_Conditional_38_For_75_Template(rf, ctx) {
  if (rf & 1) {
    const _r16 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 133);
    \u0275\u0275listener("click", function PharmacyPage_Conditional_38_For_75_Template_div_click_0_listener() {
      const test_r17 = \u0275\u0275restoreView(_r16).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.openLabTestDetails(test_r17.id));
    });
    \u0275\u0275elementStart(1, "div", 134)(2, "div", 135)(3, "div", 136);
    \u0275\u0275repeaterCreate(4, PharmacyPage_Conditional_38_For_75_For_5_Template, 2, 1, "span", 137, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "h4", 138);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "p", 139);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(10, "div", 140)(11, "div", 141);
    \u0275\u0275element(12, "ion-icon", 24);
    \u0275\u0275elementStart(13, "span");
    \u0275\u0275text(14);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "div", 141);
    \u0275\u0275element(16, "ion-icon", 47);
    \u0275\u0275elementStart(17, "span");
    \u0275\u0275text(18);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(19, "div", 141);
    \u0275\u0275element(20, "ion-icon", 142);
    \u0275\u0275elementStart(21, "span");
    \u0275\u0275text(22);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(23, "div", 141);
    \u0275\u0275element(24, "ion-icon", 143);
    \u0275\u0275elementStart(25, "span");
    \u0275\u0275text(26);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(27, "div", 144)(28, "span", 145);
    \u0275\u0275text(29, "Key Parameters:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(30, "div", 146);
    \u0275\u0275repeaterCreate(31, PharmacyPage_Conditional_38_For_75_For_32_Template, 2, 1, "span", 147, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275template(33, PharmacyPage_Conditional_38_For_75_Conditional_33_Template, 2, 1, "span", 148);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(34, "div", 149)(35, "div", 150)(36, "div", 151)(37, "span", 152);
    \u0275\u0275text(38);
    \u0275\u0275elementEnd();
    \u0275\u0275template(39, PharmacyPage_Conditional_38_For_75_Conditional_39_Template, 4, 2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(40, "span", 153);
    \u0275\u0275text(41, "Free sample pickup on orders > \u20B9499");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(42, "button", 154);
    \u0275\u0275listener("click", function PharmacyPage_Conditional_38_For_75_Template_button_click_42_listener($event) {
      const test_r17 = \u0275\u0275restoreView(_r16).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.toggleLabTestBooking(test_r17, $event));
    });
    \u0275\u0275template(43, PharmacyPage_Conditional_38_For_75_Conditional_43_Template, 3, 0)(44, PharmacyPage_Conditional_38_For_75_Conditional_44_Template, 3, 0);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(45, PharmacyPage_Conditional_38_For_75_Conditional_45_Template, 6, 2);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const test_r17 = ctx.$implicit;
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275classProp("booked", ctx_r0.isLabTestBooked(test_r17.id));
    \u0275\u0275advance(4);
    \u0275\u0275repeater(test_r17.tags);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(test_r17.name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(test_r17.description);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate1("", test_r17.testCount, " Tests Included");
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(test_r17.fastingRequirement);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("Reports in ", test_r17.reportTimeHours, " hrs");
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(test_r17.sampleType);
    \u0275\u0275advance(5);
    \u0275\u0275repeater(test_r17.parameters.slice(0, 4));
    \u0275\u0275advance(2);
    \u0275\u0275conditional(test_r17.parameters.length > 4 ? 33 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate1("\u20B9", test_r17.price, "");
    \u0275\u0275advance();
    \u0275\u0275conditional(test_r17.mrp > test_r17.price ? 39 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275classProp("booked", ctx_r0.isLabTestBooked(test_r17.id));
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.isLabTestBooked(test_r17.id) ? 43 : 44);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(test_r17.labPartner ? 45 : -1);
  }
}
function PharmacyPage_Conditional_38_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "section", 115)(1, "div", 35);
    \u0275\u0275element(2, "div", 36)(3, "div", 37);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "div", 38)(5, "div", 116);
    \u0275\u0275element(6, "ion-icon", 24);
    \u0275\u0275elementStart(7, "span");
    \u0275\u0275text(8, "DOCTOR'S LAB ADVICE");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "h3", 41);
    \u0275\u0275text(10, "Book Tests via Doctor's Note");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "p", 42);
    \u0275\u0275text(12, " Not sure which health package or blood tests to book? Upload your prescription and our medical team will schedule the exact required tests. ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "div", 43)(14, "div", 44);
    \u0275\u0275element(15, "ion-icon", 46);
    \u0275\u0275elementStart(16, "span");
    \u0275\u0275text(17, "NABL Accredited");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(18, "div", 44);
    \u0275\u0275element(19, "ion-icon", 117);
    \u0275\u0275elementStart(20, "span");
    \u0275\u0275text(21, "Home Sample Pickup");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(22, "div", 44);
    \u0275\u0275element(23, "ion-icon", 47);
    \u0275\u0275elementStart(24, "span");
    \u0275\u0275text(25, "Digital Reports");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(26, "button", 118);
    \u0275\u0275listener("click", function PharmacyPage_Conditional_38_Template_button_click_26_listener() {
      \u0275\u0275restoreView(_r13);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.openPrescriptionModal("lab"));
    });
    \u0275\u0275element(27, "ion-icon", 49);
    \u0275\u0275elementStart(28, "span");
    \u0275\u0275text(29, "UPLOAD & CONSULT LAB");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(30, "section", 119);
    \u0275\u0275element(31, "div", 120);
    \u0275\u0275elementStart(32, "div", 52)(33, "div", 53)(34, "div", 121);
    \u0275\u0275element(35, "ion-icon", 46);
    \u0275\u0275elementStart(36, "span");
    \u0275\u0275text(37, "NABL & ICMR CERTIFIED LABS");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(38, "h4", 56);
    \u0275\u0275text(39, "Full Body Health Checkups");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(40, "p", 57);
    \u0275\u0275text(41, "Up to ");
    \u0275\u0275elementStart(42, "strong");
    \u0275\u0275text(43, "50% OFF");
    \u0275\u0275elementEnd();
    \u0275\u0275text(44, " on comprehensive health packages with free home sample collection.");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(45, "div", 59)(46, "div", 122)(47, "span", 61);
    \u0275\u0275text(48, "50%");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(49, "span", 62);
    \u0275\u0275text(50, "OFF");
    \u0275\u0275elementEnd()()()()();
    \u0275\u0275elementStart(51, "section", 63)(52, "div", 64)(53, "div", 65)(54, "h4", 66);
    \u0275\u0275text(55, "Checkups by Health Concern");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(56, "span", 67);
    \u0275\u0275text(57, "Targeted diagnostic screenings");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(58, "div", 71)(59, "button", 72);
    \u0275\u0275listener("click", function PharmacyPage_Conditional_38_Template_button_click_59_listener() {
      \u0275\u0275restoreView(_r13);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.filterLabCategory("all"));
    });
    \u0275\u0275elementStart(60, "span");
    \u0275\u0275text(61, "All Packages");
    \u0275\u0275elementEnd()();
    \u0275\u0275repeaterCreate(62, PharmacyPage_Conditional_38_For_63_Template, 4, 6, "button", 73, _forTrack0);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(64, "section", 63)(65, "div", 64)(66, "div", 65)(67, "h4", 66);
    \u0275\u0275text(68, "Recommended Health Packages");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(69, "span", 67);
    \u0275\u0275text(70, "Certified labs & free home sample pickup");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(71, "span", 123);
    \u0275\u0275text(72, "TOP RATED");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(73, "div", 124);
    \u0275\u0275repeaterCreate(74, PharmacyPage_Conditional_38_For_75_Template, 46, 15, "div", 125, _forTrack0);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(76, "section", 126)(77, "h5", 127);
    \u0275\u0275text(78, "Why Book Lab Tests with Pintu?");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(79, "div", 128)(80, "div", 129)(81, "div", 130);
    \u0275\u0275element(82, "ion-icon", 46);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(83, "h6");
    \u0275\u0275text(84, "NABL / ICMR Accredited");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(85, "p");
    \u0275\u0275text(86, "100% accurate results from certified diagnostic partner labs.");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(87, "div", 129)(88, "div", 130);
    \u0275\u0275element(89, "ion-icon", 131);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(90, "h6");
    \u0275\u0275text(91, "Sterile Home Collection");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(92, "p");
    \u0275\u0275text(93, "Trained phlebotomists using single-use vacuum collection tubes.");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(94, "div", 129)(95, "div", 130);
    \u0275\u0275element(96, "ion-icon", 47);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(97, "h6");
    \u0275\u0275text(98, "Smart Digital Reports");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(99, "p");
    \u0275\u0275text(100, "Get verified PDF reports delivered directly on App and WhatsApp.");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275element(101, "app-pharmacy-footer", 132);
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(59);
    \u0275\u0275classProp("active", ctx_r0.selectedLabCategory === "all");
    \u0275\u0275advance(3);
    \u0275\u0275repeater(ctx_r0.labCategories);
    \u0275\u0275advance(12);
    \u0275\u0275repeater(ctx_r0.displayedLabTests);
  }
}
function PharmacyPage_Conditional_40_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 167);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("Saved \u20B9", ctx_r0.medSummary.savings, "");
  }
}
function PharmacyPage_Conditional_40_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "aside", 30)(1, "div", 157);
    \u0275\u0275listener("click", function PharmacyPage_Conditional_40_Template_div_click_1_listener() {
      \u0275\u0275restoreView(_r20);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.goToCart("medicine"));
    });
    \u0275\u0275elementStart(2, "div", 158)(3, "div", 159);
    \u0275\u0275element(4, "ion-icon", 160);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 161)(6, "div", 162)(7, "span", 163);
    \u0275\u0275text(8, "MEDICINE CART");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "span", 164);
    \u0275\u0275text(10);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(11, "div", 165)(12, "span", 166);
    \u0275\u0275text(13);
    \u0275\u0275elementEnd();
    \u0275\u0275template(14, PharmacyPage_Conditional_40_Conditional_14_Template, 2, 1, "span", 167);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(15, "div", 168)(16, "button", 169);
    \u0275\u0275listener("click", function PharmacyPage_Conditional_40_Template_button_click_16_listener($event) {
      \u0275\u0275restoreView(_r20);
      const ctx_r0 = \u0275\u0275nextContext();
      ctx_r0.goToCart("medicine");
      return \u0275\u0275resetView($event.stopPropagation());
    });
    \u0275\u0275elementStart(17, "span");
    \u0275\u0275text(18, "View Cart");
    \u0275\u0275elementEnd();
    \u0275\u0275element(19, "ion-icon", 170);
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(10);
    \u0275\u0275textInterpolate2("", ctx_r0.medSummary.itemCount, " ", ctx_r0.medSummary.itemCount === 1 ? "ITEM" : "ITEMS", "");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r0.medSummary.grandTotal, "");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.medSummary.savings > 0 ? 14 : -1);
  }
}
function PharmacyPage_Conditional_41_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 174);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("Saved \u20B9", ctx_r0.labSummary.savings, "");
  }
}
function PharmacyPage_Conditional_41_Template(rf, ctx) {
  if (rf & 1) {
    const _r21 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "aside", 31)(1, "div", 157);
    \u0275\u0275listener("click", function PharmacyPage_Conditional_41_Template_div_click_1_listener() {
      \u0275\u0275restoreView(_r21);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.goToCart("lab"));
    });
    \u0275\u0275elementStart(2, "div", 158)(3, "div", 171);
    \u0275\u0275element(4, "ion-icon", 24);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 161)(6, "div", 162)(7, "span", 172);
    \u0275\u0275text(8, "LAB TESTS CART");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "span", 173);
    \u0275\u0275text(10);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(11, "div", 165)(12, "span", 166);
    \u0275\u0275text(13);
    \u0275\u0275elementEnd();
    \u0275\u0275template(14, PharmacyPage_Conditional_41_Conditional_14_Template, 2, 1, "span", 174);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(15, "div", 168)(16, "button", 175);
    \u0275\u0275listener("click", function PharmacyPage_Conditional_41_Template_button_click_16_listener($event) {
      \u0275\u0275restoreView(_r21);
      const ctx_r0 = \u0275\u0275nextContext();
      ctx_r0.goToCart("lab");
      return \u0275\u0275resetView($event.stopPropagation());
    });
    \u0275\u0275elementStart(17, "span");
    \u0275\u0275text(18, "View Cart");
    \u0275\u0275elementEnd();
    \u0275\u0275element(19, "ion-icon", 170);
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(10);
    \u0275\u0275textInterpolate2("", ctx_r0.labSummary.itemCount, " ", ctx_r0.labSummary.itemCount === 1 ? "PACKAGE" : "PACKAGES", "");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r0.labSummary.grandTotal, "");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.labSummary.savings > 0 ? 14 : -1);
  }
}
function PharmacyPage_ng_template_43_Conditional_34_Template(rf, ctx) {
  if (rf & 1) {
    const _r23 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 190);
    \u0275\u0275element(1, "ion-icon", 196);
    \u0275\u0275elementStart(2, "div", 197)(3, "span", 198);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "span", 199);
    \u0275\u0275text(6, "Ready to attach");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "button", 200);
    \u0275\u0275listener("click", function PharmacyPage_ng_template_43_Conditional_34_Template_button_click_7_listener() {
      \u0275\u0275restoreView(_r23);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.prescriptionFileName = "");
    });
    \u0275\u0275element(8, "ion-icon", 182);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r0.prescriptionFileName);
  }
}
function PharmacyPage_ng_template_43_Conditional_44_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1, "Verifying & Uploading...");
    \u0275\u0275elementEnd();
  }
}
function PharmacyPage_ng_template_43_Conditional_45_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 201);
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2, "SUBMIT PRESCRIPTION");
    \u0275\u0275elementEnd();
  }
}
function PharmacyPage_ng_template_43_Template(rf, ctx) {
  if (rf & 1) {
    const _r22 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 176)(1, "div", 177);
    \u0275\u0275element(2, "div", 178);
    \u0275\u0275elementStart(3, "div", 179)(4, "div", 180)(5, "h4");
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "p");
    \u0275\u0275text(8, "Our healthcare team will inspect and verify your order");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "button", 181);
    \u0275\u0275listener("click", function PharmacyPage_ng_template_43_Template_button_click_9_listener() {
      \u0275\u0275restoreView(_r22);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.closePrescriptionModal());
    });
    \u0275\u0275element(10, "ion-icon", 182);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(11, "div", 183)(12, "div", 184)(13, "div", 185);
    \u0275\u0275listener("click", function PharmacyPage_ng_template_43_Template_div_click_13_listener() {
      \u0275\u0275restoreView(_r22);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.simulateFilePick("camera"));
    });
    \u0275\u0275elementStart(14, "div", 186);
    \u0275\u0275element(15, "ion-icon", 187);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "span", 188);
    \u0275\u0275text(17, "Camera");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "span", 189);
    \u0275\u0275text(19, "Take clear photo");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(20, "div", 185);
    \u0275\u0275listener("click", function PharmacyPage_ng_template_43_Template_div_click_20_listener() {
      \u0275\u0275restoreView(_r22);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.simulateFilePick("gallery"));
    });
    \u0275\u0275elementStart(21, "div", 186);
    \u0275\u0275element(22, "ion-icon", 49);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(23, "span", 188);
    \u0275\u0275text(24, "Gallery");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(25, "span", 189);
    \u0275\u0275text(26, "Choose image");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(27, "div", 185);
    \u0275\u0275listener("click", function PharmacyPage_ng_template_43_Template_div_click_27_listener() {
      \u0275\u0275restoreView(_r22);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.simulateFilePick("doc"));
    });
    \u0275\u0275elementStart(28, "div", 186);
    \u0275\u0275element(29, "ion-icon", 40);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(30, "span", 188);
    \u0275\u0275text(31, "PDF Document");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(32, "span", 189);
    \u0275\u0275text(33, "Attach file");
    \u0275\u0275elementEnd()()();
    \u0275\u0275template(34, PharmacyPage_ng_template_43_Conditional_34_Template, 9, 1, "div", 190);
    \u0275\u0275elementStart(35, "div", 191)(36, "label", 192);
    \u0275\u0275text(37, "Patient Instructions (Optional):");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(38, "textarea", 193);
    \u0275\u0275twoWayListener("ngModelChange", function PharmacyPage_ng_template_43_Template_textarea_ngModelChange_38_listener($event) {
      \u0275\u0275restoreView(_r22);
      const ctx_r0 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r0.prescriptionNotes, $event) || (ctx_r0.prescriptionNotes = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(39, "div", 194);
    \u0275\u0275element(40, "ion-icon", 46);
    \u0275\u0275elementStart(41, "p");
    \u0275\u0275text(42, "Your medical prescription is stored securely under medical confidentiality guidelines.");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(43, "button", 195);
    \u0275\u0275listener("click", function PharmacyPage_ng_template_43_Template_button_click_43_listener() {
      \u0275\u0275restoreView(_r22);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.submitPrescription());
    });
    \u0275\u0275template(44, PharmacyPage_ng_template_43_Conditional_44_Template, 2, 0, "span")(45, PharmacyPage_ng_template_43_Conditional_45_Template, 3, 0);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(ctx_r0.prescriptionUploadType === "medicine" ? "Upload Medicine Prescription" : "Upload Lab Test Prescription");
    \u0275\u0275advance(28);
    \u0275\u0275conditional(ctx_r0.prescriptionFileName ? 34 : -1);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r0.prescriptionNotes);
    \u0275\u0275advance(5);
    \u0275\u0275property("disabled", ctx_r0.isUploadingPrescription);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.isUploadingPrescription ? 44 : 45);
  }
}
var _PharmacyPage = class _PharmacyPage {
  constructor(router, navCtrl, locationService, cartService, toastCtrl) {
    this.router = router;
    this.navCtrl = navCtrl;
    this.locationService = locationService;
    this.cartService = cartService;
    this.toastCtrl = toastCtrl;
    this.activeTab = "medicines";
    this.displayLocationName = "Select Location";
    this.displayFullAddress = "";
    this.isSavedAddress = false;
    this.isOutOfServiceArea = false;
    this.allMedicines = DUMMY_MEDICINES;
    this.displayedMedicines = DUMMY_MEDICINES;
    this.medicineCategories = DUMMY_MEDICINE_CATEGORIES;
    this.selectedMedCategory = "all";
    this.allLabTests = DUMMY_LAB_TESTS;
    this.displayedLabTests = DUMMY_LAB_TESTS;
    this.labCategories = DUMMY_LAB_CATEGORIES;
    this.selectedLabCategory = "all";
    this.medSummary = { itemCount: 0, subtotal: 0, totalMrp: 0, savings: 0, fee: 0, grandTotal: 0 };
    this.labSummary = { itemCount: 0, subtotal: 0, totalMrp: 0, savings: 0, fee: 0, grandTotal: 0 };
    this.isPrescriptionModalOpen = false;
    this.prescriptionUploadType = "medicine";
    this.prescriptionFileName = "";
    this.prescriptionNotes = "";
    this.isUploadingPrescription = false;
    this.subs = new Subscription();
    addIcons({ arrowBack, location, chevronDown, searchOutline, medkitOutline, flaskOutline, documentTextOutline, checkmarkCircle, shieldCheckmarkOutline, timeOutline, cloudUploadOutline, flashOutline, add, remove, heartOutline, receiptOutline, waterOutline, fitnessOutline, bagHandleOutline, arrowForward, closeOutline, cameraOutline, checkmarkCircleOutline, locationOutline, cartOutline, sparklesOutline, thermometerOutline, nutritionOutline, bandageOutline, happyOutline, pulseOutline, roseOutline, bodyOutline, arrowForwardOutline });
  }
  ngOnInit() {
    const savedLoc = localStorage.getItem("location");
    if (savedLoc) {
      try {
        const parsed = JSON.parse(savedLoc);
        this.applyLocation(parsed);
      } catch (e) {
      }
    }
    this.subs.add(this.locationService.location$.subscribe((loc) => {
      if (loc) {
        this.applyLocation(loc);
      }
    }));
    this.subs.add(this.locationService.address$.subscribe((addr) => {
      if (addr && addr.trim()) {
        this.displayFullAddress = addr.trim();
        if (this.displayLocationName === "Select Location" || !this.displayLocationName) {
          this.displayLocationName = addr.split(",")[0].trim();
        }
      }
    }));
    this.subs.add(this.cartService.medicineSummary$.subscribe((summary) => {
      this.medSummary = summary;
    }));
    this.subs.add(this.cartService.labSummary$.subscribe((summary) => {
      this.labSummary = summary;
    }));
  }
  ngOnDestroy() {
    this.subs.unsubscribe();
  }
  applyLocation(loc) {
    if (!loc)
      return;
    this.displayLocationName = loc.area || loc.name || loc.city || "Home";
    this.displayFullAddress = loc.formatted_address || loc.fullAddress || loc.address || "";
    this.isSavedAddress = Boolean(loc.id || loc.is_saved || loc.tag);
  }
  goBack() {
    this.navCtrl.navigateRoot("/layout/home");
  }
  openLocation() {
    this.router.navigate(["/layout/address-list"], {
      state: { data: "pharmacy" }
    });
  }
  // ─── TAB NAVIGATION ────────────────────────────────────────────────────────
  switchTab(tab) {
    this.activeTab = tab;
  }
  // ─── SEARCH TRIGGER ────────────────────────────────────────────────────────
  goToSearch() {
    const type = this.activeTab === "medicines" ? "medicine" : "lab";
    this.router.navigate(["/layout/pharmacy/search"], {
      queryParams: { type }
    });
  }
  // ─── CART NAVIGATION ───────────────────────────────────────────────────────
  goToCart(preferredType) {
    const type = preferredType || (this.activeTab === "medicines" ? "medicine" : "lab");
    this.router.navigate(["/layout/pharmacy/cart"], {
      queryParams: { type }
    });
  }
  proceedToCheckout(preferredType) {
    const type = preferredType || (this.activeTab === "medicines" ? "medicine" : "lab");
    this.router.navigate(["/layout/pharmacy/cart"], {
      queryParams: { type, action: "pay" }
    });
  }
  openMedicineDetails(id) {
    this.navCtrl.navigateForward(`/layout/pharmacy/medicine/${id}`);
  }
  openLabTestDetails(id) {
    this.navCtrl.navigateForward(`/layout/pharmacy/test/${id}`);
  }
  // ─── MEDICINE FILTERING & ACTIONS ──────────────────────────────────────────
  filterMedCategory(catId) {
    this.selectedMedCategory = catId;
    if (catId === "all") {
      this.displayedMedicines = this.allMedicines;
    } else {
      this.displayedMedicines = this.allMedicines.filter((m) => m.category === catId);
    }
  }
  getMedicineQty(itemId) {
    return this.cartService.getMedicineQuantity(itemId);
  }
  addMedicineToCart(item, event) {
    if (event)
      event.stopPropagation();
    this.cartService.addMedicine(item, 1);
  }
  incrementMedicine(item, event) {
    if (event)
      event.stopPropagation();
    const current = this.getMedicineQty(item.id);
    this.cartService.updateMedicineQuantity(item.id, current + 1);
  }
  decrementMedicine(item, event) {
    if (event)
      event.stopPropagation();
    const current = this.getMedicineQty(item.id);
    this.cartService.updateMedicineQuantity(item.id, current - 1);
  }
  // ─── LAB TEST FILTERING & ACTIONS ──────────────────────────────────────────
  filterLabCategory(catId) {
    this.selectedLabCategory = catId;
    if (catId === "all") {
      this.displayedLabTests = this.allLabTests;
    } else {
      this.displayedLabTests = this.allLabTests.filter((t) => t.category === catId);
    }
  }
  isLabTestBooked(testId) {
    return this.cartService.isLabTestInCart(testId);
  }
  toggleLabTestBooking(test, event) {
    if (event)
      event.stopPropagation();
    this.cartService.toggleLabTest(test);
  }
  // ─── PRESCRIPTION MODAL ────────────────────────────────────────────────────
  openPrescriptionModal(type) {
    this.prescriptionUploadType = type;
    this.prescriptionFileName = "";
    this.prescriptionNotes = "";
    this.isPrescriptionModalOpen = true;
  }
  closePrescriptionModal() {
    this.isPrescriptionModalOpen = false;
  }
  simulateFilePick(source) {
    const timestamp = (/* @__PURE__ */ new Date()).getTime().toString().slice(-4);
    if (source === "camera") {
      this.prescriptionFileName = `Rx_Photo_${timestamp}.jpg`;
    } else if (source === "gallery") {
      this.prescriptionFileName = `Prescription_Scan_${timestamp}.png`;
    } else {
      this.prescriptionFileName = `Doctor_Prescription_${timestamp}.pdf`;
    }
  }
  submitPrescription() {
    return __async(this, null, function* () {
      if (!this.prescriptionFileName) {
        this.prescriptionFileName = `Prescription_${Date.now().toString().slice(-4)}.jpg`;
      }
      this.isUploadingPrescription = true;
      setTimeout(() => __async(this, null, function* () {
        this.cartService.uploadPrescription({
          fileName: this.prescriptionFileName,
          notes: this.prescriptionNotes,
          type: this.prescriptionUploadType
        });
        this.isUploadingPrescription = false;
        this.isPrescriptionModalOpen = false;
        const toast = yield this.toastCtrl.create({
          message: this.prescriptionUploadType === "medicine" ? "Prescription uploaded! Our pharmacist will review and verify your medicines shortly." : "Prescription uploaded! Our lab doctor will recommend the required tests.",
          duration: 3500,
          color: "success",
          position: "top",
          icon: "checkmark-circle"
        });
        yield toast.present();
      }), 900);
    });
  }
  handleRefresh(event) {
    setTimeout(() => {
      event.target.complete();
    }, 600);
  }
};
_PharmacyPage.\u0275fac = function PharmacyPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _PharmacyPage)(\u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(LocationService), \u0275\u0275directiveInject(PharmacyCartService), \u0275\u0275directiveInject(ToastController));
};
_PharmacyPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _PharmacyPage, selectors: [["app-pharmacy"]], decls: 44, vars: 17, consts: [[1, "pharmacy-header", "ion-no-border"], [1, "main-toolbar"], [1, "header-top-row"], ["type", "button", "aria-label", "Go Back", 1, "btn-back-nav", 3, "click"], ["name", "arrow-back"], ["role", "button", "tabindex", "0", 1, "location-pill-btn", 3, "click"], [1, "location-icon-box"], ["name", "location"], [1, "location-text-col"], [1, "location-title-row"], [1, "location-name"], ["title", "Location Not Serviceable", 1, "location-status-dot", "red"], ["title", "Saved Address", 1, "location-status-dot", "green"], ["title", "Current Location", 1, "location-status-dot", "orange"], ["name", "chevron-down", 1, "chevron-icon"], [1, "location-sub-row"], ["role", "button", "tabindex", "0", "title", "Search", 1, "header-right-search", 3, "click"], [1, "search-icon-btn"], ["name", "search-outline"], [1, "service-segmented-bar"], ["type", "button", 1, "service-tab-btn", 3, "click"], [1, "tab-icon-wrap"], ["name", "medkit-outline"], [1, "tab-badge"], ["name", "flask-outline"], [1, "tab-badge", "lab"], [1, "pharmacy-content"], ["slot", "fixed", 3, "ionRefresh"], [1, "pharmacy-body-container"], [1, "bottom-nav-spacer"], ["slot", "fixed", 1, "docked-cart-banner", "medicine", "animate__animated", "animate__fadeInUp"], ["slot", "fixed", 1, "docked-cart-banner", "lab", "animate__animated", "animate__fadeInUp"], [1, "prescription-upload-modal", 3, "didDismiss", "isOpen", "initialBreakpoint", "breakpoints"], [1, "location-full-address", "text-truncate"], [1, "rx-upload-hero-card", "animate__animated", "animate__fadeIn"], [1, "rx-card-decor"], [1, "decor-circle", "c1"], [1, "decor-circle", "c2"], [1, "rx-card-content"], [1, "rx-badge-pill"], ["name", "document-text-outline"], [1, "rx-title"], [1, "rx-desc"], [1, "rx-features-row"], [1, "feature-chip"], ["name", "checkmark-circle"], ["name", "shield-checkmark-outline"], ["name", "time-outline"], ["type", "button", 1, "btn-upload-rx", 3, "click"], ["name", "cloud-upload-outline"], [1, "pharmacy-promo-banner-card", "medicine", "animate__animated", "animate__fadeIn"], [1, "banner-decor-glow"], [1, "banner-inner"], [1, "banner-text-col"], [1, "banner-badge-pill"], ["name", "flash-outline"], [1, "banner-title"], [1, "banner-desc"], [1, "coupon-code"], [1, "banner-art-col"], [1, "banner-discount-tag"], [1, "pct"], [1, "off"], [1, "section-block"], [1, "section-header-row"], [1, "section-title-col"], [1, "section-title"], [1, "section-subtitle"], [1, "section-tag-pill"], [1, "products-horizontal-scroll"], ["role", "button", "tabindex", "0", 1, "product-card-pill"], [1, "category-chips-scroll"], ["type", "button", 1, "cat-chip", 3, "click"], ["type", "button", 1, "cat-chip", 3, "active"], [1, "medicines-catalog-grid"], ["role", "button", "tabindex", "0", 1, "med-catalog-card"], ["label", "Dispensed & Fulfilled By", "companyName", "MedPlus Pharmacy & Wellness", "subtitle", "Licensed Chemist & Druggist \u2022 100% Genuine Medicines", "address", "Main Road, Near Bus Stand, Athani - 591304", "licenseInfo", "DL No: KA-BEL-2024-0987 \u2022 GSTIN: 29XXXXX0000X1ZX \u2022 Call: +91 8884950068"], ["role", "button", "tabindex", "0", 1, "product-card-pill", 3, "click"], [1, "rx-required-tag"], [1, "product-img-box"], ["loading", "lazy", 3, "src", "alt"], [1, "discount-chip"], [1, "product-info-wrap"], [1, "product-brand"], [1, "product-name", "text-truncate-2"], [1, "product-pack"], [1, "product-pricing-row"], [1, "price-col"], [1, "current-price"], [1, "mrp-price"], [1, "cart-action-col"], ["type", "button", 1, "btn-add-item"], [1, "stepper-box"], ["type", "button", 1, "btn-add-item", 3, "click"], ["name", "add"], ["type", "button", 1, "btn-step", 3, "click"], ["name", "remove"], [1, "step-count"], [3, "name"], ["role", "button", "tabindex", "0", 1, "med-catalog-card", 3, "click"], [1, "catalog-img-wrap"], [1, "catalog-body"], [1, "catalog-brand"], [1, "catalog-title"], [1, "catalog-dosage"], [1, "catalog-desc", "text-truncate-2"], [1, "catalog-footer"], [1, "price-stack"], [1, "main-price"], [1, "strike-mrp"], [1, "action-wrap"], [1, "vendor-divider"], [1, "vendor-brief"], [1, "vendor-role"], [1, "vendor-name"], [1, "rx-upload-hero-card", "lab-card", "animate__animated", "animate__fadeIn"], [1, "rx-badge-pill", "lab"], ["name", "heart-outline"], ["type", "button", 1, "btn-upload-rx", "lab", 3, "click"], [1, "pharmacy-promo-banner-card", "lab", "animate__animated", "animate__fadeIn"], [1, "banner-decor-glow", "lab"], [1, "banner-badge-pill", "lab"], [1, "banner-discount-tag", "lab"], [1, "section-tag-pill", "lab"], [1, "lab-tests-list"], ["role", "button", "tabindex", "0", 1, "lab-test-card", 3, "booked"], [1, "lab-trust-section"], [1, "trust-heading"], [1, "trust-cards-grid"], [1, "trust-card"], [1, "trust-icon-wrap"], ["name", "fitness-outline"], ["label", "Accredited Diagnostic Partner", "companyName", "Dr. Lal PathLabs & Metropolis Health", "subtitle", "NABL & ICMR Certified Diagnostics Network", "address", "Miraj Road, Opp. Civil Hospital, Athani - 591304", "licenseInfo", "NABL Reg: MC-5421 \u2022 Fast 12-24h Digital Reports \u2022 Call: +91 8884950068"], ["role", "button", "tabindex", "0", 1, "lab-test-card", 3, "click"], [1, "test-header-row"], [1, "test-title-col"], [1, "test-tags-wrap"], [1, "test-tag"], [1, "test-name"], [1, "test-desc"], [1, "test-meta-pills-row"], [1, "meta-pill"], ["name", "receipt-outline"], ["name", "water-outline"], [1, "test-params-box"], [1, "params-label"], [1, "params-chips-wrap"], [1, "param-chip"], [1, "param-chip", "more"], [1, "test-footer-row"], [1, "test-price-col"], [1, "test-price-main"], [1, "test-price"], [1, "test-footnote"], ["type", "button", 1, "btn-book-test", 3, "click"], [1, "test-mrp"], [1, "test-save-badge"], ["role", "button", "tabindex", "0", 1, "cart-banner-card", 3, "click"], [1, "banner-left"], [1, "cart-icon-circle"], ["name", "bag-handle-outline"], [1, "cart-text-col"], [1, "cart-badge-row"], [1, "badge-text"], [1, "item-count-chip"], [1, "cart-price-row"], [1, "cart-grand-total"], [1, "cart-savings-chip"], [1, "banner-actions-right"], ["type", "button", "aria-label", "View Medicine Cart", 1, "btn-view-cart", 3, "click"], ["name", "arrow-forward"], [1, "cart-icon-circle", "lab"], [1, "badge-text", "lab"], [1, "item-count-chip", "lab"], [1, "cart-savings-chip", "lab"], ["type", "button", "aria-label", "View Lab Cart", 1, "btn-view-cart", "lab", 3, "click"], [1, "rx-modal-container"], [1, "rx-modal-header"], [1, "sheet-handle"], [1, "rx-header-title-row"], [1, "rx-modal-title-col"], ["type", "button", 1, "btn-modal-close", 3, "click"], ["name", "close-outline"], [1, "rx-modal-body"], [1, "upload-options-grid"], ["role", "button", "tabindex", "0", 1, "upload-opt-card", 3, "click"], [1, "opt-icon-circle"], ["name", "camera-outline"], [1, "opt-title"], [1, "opt-sub"], [1, "selected-file-chip", "animate__animated", "animate__fadeIn"], [1, "notes-field-wrap"], ["for", "rxNotes"], ["id", "rxNotes", "rows", "3", "placeholder", "e.g. Please send 1 month supply, or call before dispatching...", 3, "ngModelChange", "ngModel"], [1, "rx-safety-note"], ["type", "button", 1, "btn-submit-rx", 3, "click", "disabled"], ["name", "checkmark-circle", 1, "check-icon"], [1, "file-info-col"], [1, "file-name"], [1, "file-status"], ["type", "button", 1, "btn-remove-file", 3, "click"], ["name", "checkmark-circle-outline"]], template: function PharmacyPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar", 1)(2, "div", 2)(3, "button", 3);
    \u0275\u0275listener("click", function PharmacyPage_Template_button_click_3_listener() {
      return ctx.goBack();
    });
    \u0275\u0275element(4, "ion-icon", 4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 5);
    \u0275\u0275listener("click", function PharmacyPage_Template_div_click_5_listener() {
      return ctx.openLocation();
    });
    \u0275\u0275elementStart(6, "div", 6);
    \u0275\u0275element(7, "ion-icon", 7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "div", 8)(9, "div", 9)(10, "span", 10);
    \u0275\u0275text(11);
    \u0275\u0275elementEnd();
    \u0275\u0275template(12, PharmacyPage_Conditional_12_Template, 1, 0, "span", 11)(13, PharmacyPage_Conditional_13_Template, 1, 0, "span", 12)(14, PharmacyPage_Conditional_14_Template, 1, 0, "span", 13);
    \u0275\u0275element(15, "ion-icon", 14);
    \u0275\u0275elementEnd();
    \u0275\u0275template(16, PharmacyPage_Conditional_16_Template, 3, 1, "div", 15);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(17, "div", 16);
    \u0275\u0275listener("click", function PharmacyPage_Template_div_click_17_listener() {
      return ctx.goToSearch();
    });
    \u0275\u0275elementStart(18, "div", 17);
    \u0275\u0275element(19, "ion-icon", 18);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(20, "div", 19)(21, "button", 20);
    \u0275\u0275listener("click", function PharmacyPage_Template_button_click_21_listener() {
      return ctx.switchTab("medicines");
    });
    \u0275\u0275elementStart(22, "div", 21);
    \u0275\u0275element(23, "ion-icon", 22);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(24, "span");
    \u0275\u0275text(25, "Medicines");
    \u0275\u0275elementEnd();
    \u0275\u0275template(26, PharmacyPage_Conditional_26_Template, 2, 1, "span", 23);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(27, "button", 20);
    \u0275\u0275listener("click", function PharmacyPage_Template_button_click_27_listener() {
      return ctx.switchTab("lab_tests");
    });
    \u0275\u0275elementStart(28, "div", 21);
    \u0275\u0275element(29, "ion-icon", 24);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(30, "span");
    \u0275\u0275text(31, "Lab Tests");
    \u0275\u0275elementEnd();
    \u0275\u0275template(32, PharmacyPage_Conditional_32_Template, 2, 1, "span", 25);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(33, "ion-content", 26)(34, "ion-refresher", 27);
    \u0275\u0275listener("ionRefresh", function PharmacyPage_Template_ion_refresher_ionRefresh_34_listener($event) {
      return ctx.handleRefresh($event);
    });
    \u0275\u0275element(35, "ion-refresher-content");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(36, "main", 28);
    \u0275\u0275template(37, PharmacyPage_Conditional_37_Template, 80, 2)(38, PharmacyPage_Conditional_38_Template, 102, 2);
    \u0275\u0275element(39, "div", 29);
    \u0275\u0275elementEnd();
    \u0275\u0275template(40, PharmacyPage_Conditional_40_Template, 20, 4, "aside", 30)(41, PharmacyPage_Conditional_41_Template, 20, 4, "aside", 31);
    \u0275\u0275elementStart(42, "ion-modal", 32);
    \u0275\u0275listener("didDismiss", function PharmacyPage_Template_ion_modal_didDismiss_42_listener() {
      return ctx.closePrescriptionModal();
    });
    \u0275\u0275template(43, PharmacyPage_ng_template_43_Template, 46, 5, "ng-template");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(11);
    \u0275\u0275textInterpolate(ctx.displayLocationName);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.isOutOfServiceArea ? 12 : ctx.isSavedAddress ? 13 : 14);
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx.displayFullAddress ? 16 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275classProp("active", ctx.activeTab === "medicines");
    \u0275\u0275advance(5);
    \u0275\u0275conditional(ctx.medSummary.itemCount > 0 ? 26 : -1);
    \u0275\u0275advance();
    \u0275\u0275classProp("active", ctx.activeTab === "lab_tests");
    \u0275\u0275advance(5);
    \u0275\u0275conditional(ctx.labSummary.itemCount > 0 ? 32 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275conditional(ctx.activeTab === "medicines" ? 37 : ctx.activeTab === "lab_tests" ? 38 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275classProp("has-cart", ctx.activeTab === "medicines" && ctx.medSummary.itemCount > 0 || ctx.activeTab === "lab_tests" && ctx.labSummary.itemCount > 0);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.activeTab === "medicines" && ctx.medSummary.itemCount > 0 ? 40 : ctx.activeTab === "lab_tests" && ctx.labSummary.itemCount > 0 ? 41 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275property("isOpen", ctx.isPrescriptionModalOpen)("initialBreakpoint", 0.7)("breakpoints", \u0275\u0275pureFunction0(16, _c0));
  }
}, dependencies: [
  CommonModule,
  FormsModule,
  DefaultValueAccessor,
  NgControlStatus,
  NgModel,
  IonContent,
  IonHeader,
  IonToolbar,
  IonIcon,
  IonModal,
  IonRefresher,
  IonRefresherContent,
  PharmacyFooterComponent
], styles: ["\n\n[_nghost-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  width: 100%;\n  height: 100%;\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  overflow: hidden;\n}\n.pharmacy-content[_ngcontent-%COMP%] {\n  --background: #f8fafc;\n  flex: 1;\n  width: 100%;\n  height: 100%;\n  position: relative;\n}\n.pharmacy-header[_ngcontent-%COMP%] {\n  --background: #ffffff;\n  background: #ffffff;\n  border-bottom: 1px solid #f1f5f9;\n  box-shadow: 0 2px 10px rgba(15, 23, 42, 0.04);\n  z-index: 100;\n  padding: 0 !important;\n  margin: 0 !important;\n  --ion-safe-area-top: 0px;\n  flex-shrink: 0;\n}\n.pharmacy-header[_ngcontent-%COMP%]   .main-toolbar[_ngcontent-%COMP%] {\n  --background: #ffffff;\n  background: #ffffff;\n  --padding-start: 12px;\n  --padding-end: 12px;\n  --padding-top: env(safe-area-inset-top, 0px);\n  --padding-bottom: 8px;\n  --min-height: 48px;\n  --border-width: 0;\n  padding: 0;\n}\n.pharmacy-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  width: 100%;\n  margin-bottom: 10px;\n}\n.pharmacy-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .btn-back-nav[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 38px;\n  border-radius: 50%;\n  background: #f1f5f9;\n  border: none;\n  color: #0f172a;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 20px;\n  cursor: pointer;\n  flex-shrink: 0;\n  transition: background 0.15s ease;\n}\n.pharmacy-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .btn-back-nav[_ngcontent-%COMP%]:active {\n  background: #e2e8f0;\n}\n.pharmacy-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .location-pill-btn[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 0;\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n  border-radius: 14px;\n  padding: 6px 10px;\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n.pharmacy-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .location-pill-btn[_ngcontent-%COMP%]:active {\n  background: #f1f5f9;\n  border-color: #cbd5e1;\n}\n.pharmacy-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .location-pill-btn[_ngcontent-%COMP%]   .location-icon-box[_ngcontent-%COMP%] {\n  width: 28px;\n  height: 28px;\n  border-radius: 8px;\n  background: #ecfdf5;\n  color: #059669;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 16px;\n  flex-shrink: 0;\n}\n.pharmacy-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .location-pill-btn[_ngcontent-%COMP%]   .location-text-col[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 0;\n  display: flex;\n  flex-direction: column;\n}\n.pharmacy-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .location-pill-btn[_ngcontent-%COMP%]   .location-text-col[_ngcontent-%COMP%]   .location-title-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 5px;\n}\n.pharmacy-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .location-pill-btn[_ngcontent-%COMP%]   .location-text-col[_ngcontent-%COMP%]   .location-title-row[_ngcontent-%COMP%]   .location-name[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-weight: 800;\n  color: #0f172a;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  max-width: 120px;\n}\n.pharmacy-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .location-pill-btn[_ngcontent-%COMP%]   .location-text-col[_ngcontent-%COMP%]   .location-title-row[_ngcontent-%COMP%]   .location-status-dot[_ngcontent-%COMP%] {\n  width: 7px;\n  height: 7px;\n  border-radius: 50%;\n  flex-shrink: 0;\n}\n.pharmacy-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .location-pill-btn[_ngcontent-%COMP%]   .location-text-col[_ngcontent-%COMP%]   .location-title-row[_ngcontent-%COMP%]   .location-status-dot.green[_ngcontent-%COMP%] {\n  background: #10b981;\n}\n.pharmacy-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .location-pill-btn[_ngcontent-%COMP%]   .location-text-col[_ngcontent-%COMP%]   .location-title-row[_ngcontent-%COMP%]   .location-status-dot.orange[_ngcontent-%COMP%] {\n  background: #f59e0b;\n}\n.pharmacy-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .location-pill-btn[_ngcontent-%COMP%]   .location-text-col[_ngcontent-%COMP%]   .location-title-row[_ngcontent-%COMP%]   .location-status-dot.red[_ngcontent-%COMP%] {\n  background: #ef4444;\n}\n.pharmacy-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .location-pill-btn[_ngcontent-%COMP%]   .location-text-col[_ngcontent-%COMP%]   .location-title-row[_ngcontent-%COMP%]   .chevron-icon[_ngcontent-%COMP%] {\n  font-size: 13px;\n  color: #64748b;\n}\n.pharmacy-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .location-pill-btn[_ngcontent-%COMP%]   .location-text-col[_ngcontent-%COMP%]   .location-sub-row[_ngcontent-%COMP%]   .location-full-address[_ngcontent-%COMP%] {\n  font-size: 10.5px;\n  color: #64748b;\n  font-weight: 500;\n  display: block;\n}\n.pharmacy-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .header-right-search[_ngcontent-%COMP%] {\n  flex-shrink: 0;\n  cursor: pointer;\n}\n.pharmacy-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .header-right-search[_ngcontent-%COMP%]   .search-icon-btn[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n  border-radius: 12px;\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  color: #0f172a;\n  font-size: 20px;\n  transition: all 0.15s ease;\n}\n.pharmacy-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .header-right-search[_ngcontent-%COMP%]   .search-icon-btn[_ngcontent-%COMP%]:active {\n  background: #f1f5f9;\n  transform: scale(0.95);\n}\n.pharmacy-header[_ngcontent-%COMP%]   .service-segmented-bar[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  background: #f1f5f9;\n  padding: 4px;\n  border-radius: 14px;\n  margin-bottom: 0;\n}\n.pharmacy-header[_ngcontent-%COMP%]   .service-segmented-bar[_ngcontent-%COMP%]   .service-tab-btn[_ngcontent-%COMP%] {\n  flex: 1;\n  height: 40px;\n  border: none;\n  border-radius: 10px;\n  background: transparent;\n  color: #64748b;\n  font-size: 13.5px;\n  font-weight: 750;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 7px;\n  cursor: pointer;\n  transition: all 0.2s ease;\n}\n.pharmacy-header[_ngcontent-%COMP%]   .service-segmented-bar[_ngcontent-%COMP%]   .service-tab-btn[_ngcontent-%COMP%]   .tab-icon-wrap[_ngcontent-%COMP%] {\n  font-size: 17px;\n  display: flex;\n  align-items: center;\n}\n.pharmacy-header[_ngcontent-%COMP%]   .service-segmented-bar[_ngcontent-%COMP%]   .service-tab-btn[_ngcontent-%COMP%]   .tab-badge[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 800;\n  background: #ecfdf5;\n  color: #059669;\n  padding: 1px 6px;\n  border-radius: 99px;\n}\n.pharmacy-header[_ngcontent-%COMP%]   .service-segmented-bar[_ngcontent-%COMP%]   .service-tab-btn[_ngcontent-%COMP%]   .tab-badge.lab[_ngcontent-%COMP%] {\n  background: #f3e8ff;\n  color: #7c3aed;\n}\n.pharmacy-header[_ngcontent-%COMP%]   .service-segmented-bar[_ngcontent-%COMP%]   .service-tab-btn.active[_ngcontent-%COMP%] {\n  background: #ffffff;\n  color: #0f172a;\n  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.08);\n}\n.pharmacy-header[_ngcontent-%COMP%]   .service-segmented-bar[_ngcontent-%COMP%]   .service-tab-btn.active[_ngcontent-%COMP%]   .tab-icon-wrap[_ngcontent-%COMP%] {\n  color: #059669;\n}\n.pharmacy-header[_ngcontent-%COMP%]   .service-segmented-bar[_ngcontent-%COMP%]   .service-tab-btn.active[_ngcontent-%COMP%]:nth-child(2)   .tab-icon-wrap[_ngcontent-%COMP%] {\n  color: #7c3aed;\n}\n.pharmacy-body-container[_ngcontent-%COMP%] {\n  padding: 14px 14px 20px;\n  display: flex;\n  flex-direction: column;\n  gap: 18px;\n}\n.rx-upload-hero-card[_ngcontent-%COMP%] {\n  position: relative;\n  border-radius: 20px;\n  padding: 18px 18px 20px;\n  background:\n    linear-gradient(\n      135deg,\n      #064e3b 0%,\n      #065f46 50%,\n      #047857 100%);\n  color: #ffffff;\n  overflow: hidden;\n  box-shadow: 0 10px 25px -5px rgba(5, 150, 105, 0.3);\n}\n.rx-upload-hero-card.lab-card[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #311042 0%,\n      #4c1d95 50%,\n      #6d28d9 100%);\n  box-shadow: 0 10px 25px -5px rgba(109, 40, 217, 0.3);\n}\n.rx-upload-hero-card[_ngcontent-%COMP%]   .rx-card-decor[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  pointer-events: none;\n}\n.rx-upload-hero-card[_ngcontent-%COMP%]   .rx-card-decor[_ngcontent-%COMP%]   .decor-circle[_ngcontent-%COMP%] {\n  position: absolute;\n  border-radius: 50%;\n  background: rgba(255, 255, 255, 0.08);\n}\n.rx-upload-hero-card[_ngcontent-%COMP%]   .rx-card-decor[_ngcontent-%COMP%]   .decor-circle.c1[_ngcontent-%COMP%] {\n  width: 140px;\n  height: 140px;\n  top: -40px;\n  right: -30px;\n}\n.rx-upload-hero-card[_ngcontent-%COMP%]   .rx-card-decor[_ngcontent-%COMP%]   .decor-circle.c2[_ngcontent-%COMP%] {\n  width: 90px;\n  height: 90px;\n  bottom: -20px;\n  left: 20%;\n}\n.rx-upload-hero-card[_ngcontent-%COMP%]   .rx-card-content[_ngcontent-%COMP%] {\n  position: relative;\n  z-index: 2;\n  display: flex;\n  flex-direction: column;\n}\n.rx-upload-hero-card[_ngcontent-%COMP%]   .rx-card-content[_ngcontent-%COMP%]   .rx-badge-pill[_ngcontent-%COMP%] {\n  align-self: flex-start;\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  font-size: 10px;\n  font-weight: 850;\n  letter-spacing: 0.6px;\n  background: rgba(255, 255, 255, 0.18);\n  -webkit-backdrop-filter: blur(8px);\n  backdrop-filter: blur(8px);\n  padding: 3px 10px;\n  border-radius: 99px;\n  margin-bottom: 8px;\n  color: #a7f3d0;\n}\n.rx-upload-hero-card[_ngcontent-%COMP%]   .rx-card-content[_ngcontent-%COMP%]   .rx-badge-pill.lab[_ngcontent-%COMP%] {\n  color: #e9d5ff;\n}\n.rx-upload-hero-card[_ngcontent-%COMP%]   .rx-card-content[_ngcontent-%COMP%]   .rx-title[_ngcontent-%COMP%] {\n  font-size: 18px;\n  font-weight: 850;\n  color: #ffffff;\n  margin: 0 0 6px;\n  line-height: 1.25;\n}\n.rx-upload-hero-card[_ngcontent-%COMP%]   .rx-card-content[_ngcontent-%COMP%]   .rx-desc[_ngcontent-%COMP%] {\n  font-size: 12.5px;\n  color: rgba(255, 255, 255, 0.9);\n  margin: 0 0 14px;\n  line-height: 1.45;\n}\n.rx-upload-hero-card[_ngcontent-%COMP%]   .rx-card-content[_ngcontent-%COMP%]   .rx-features-row[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 6px;\n  margin-bottom: 16px;\n}\n.rx-upload-hero-card[_ngcontent-%COMP%]   .rx-card-content[_ngcontent-%COMP%]   .rx-features-row[_ngcontent-%COMP%]   .feature-chip[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  font-size: 11px;\n  font-weight: 700;\n  background: rgba(0, 0, 0, 0.2);\n  padding: 4px 10px;\n  border-radius: 8px;\n  color: #ffffff;\n}\n.rx-upload-hero-card[_ngcontent-%COMP%]   .rx-card-content[_ngcontent-%COMP%]   .rx-features-row[_ngcontent-%COMP%]   .feature-chip[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #34d399;\n}\n.rx-upload-hero-card[_ngcontent-%COMP%]   .rx-card-content[_ngcontent-%COMP%]   .btn-upload-rx[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 44px;\n  border-radius: 12px;\n  background: #ffffff;\n  color: #065f46;\n  border: none;\n  font-size: 13px;\n  font-weight: 850;\n  letter-spacing: 0.4px;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  gap: 7px;\n  cursor: pointer;\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);\n  transition: transform 0.15s ease;\n}\n.rx-upload-hero-card[_ngcontent-%COMP%]   .rx-card-content[_ngcontent-%COMP%]   .btn-upload-rx[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 17px;\n}\n.rx-upload-hero-card[_ngcontent-%COMP%]   .rx-card-content[_ngcontent-%COMP%]   .btn-upload-rx[_ngcontent-%COMP%]:active {\n  transform: scale(0.98);\n}\n.rx-upload-hero-card[_ngcontent-%COMP%]   .rx-card-content[_ngcontent-%COMP%]   .btn-upload-rx.lab[_ngcontent-%COMP%] {\n  color: #5b21b6;\n}\n.pharmacy-promo-banner-card[_ngcontent-%COMP%] {\n  position: relative;\n  border-radius: 18px;\n  padding: 14px 16px;\n  background:\n    linear-gradient(\n      135deg,\n      #064e3b 0%,\n      #065f46 60%,\n      #047857 100%);\n  color: #ffffff;\n  overflow: hidden;\n  box-shadow: 0 4px 18px rgba(6, 78, 59, 0.22);\n}\n.pharmacy-promo-banner-card.lab[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #0c4a6e 0%,\n      #0369a1 60%,\n      #0284c7 100%);\n  box-shadow: 0 4px 18px rgba(12, 74, 110, 0.22);\n}\n.pharmacy-promo-banner-card[_ngcontent-%COMP%]   .banner-decor-glow[_ngcontent-%COMP%] {\n  position: absolute;\n  width: 120px;\n  height: 120px;\n  border-radius: 50%;\n  background: rgba(255, 255, 255, 0.1);\n  top: -40px;\n  right: -20px;\n  filter: blur(24px);\n  pointer-events: none;\n}\n.pharmacy-promo-banner-card[_ngcontent-%COMP%]   .banner-decor-glow.lab[_ngcontent-%COMP%] {\n  background: rgba(56, 189, 248, 0.15);\n}\n.pharmacy-promo-banner-card[_ngcontent-%COMP%]   .banner-inner[_ngcontent-%COMP%] {\n  position: relative;\n  z-index: 2;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 12px;\n}\n.pharmacy-promo-banner-card[_ngcontent-%COMP%]   .banner-inner[_ngcontent-%COMP%]   .banner-text-col[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 0;\n}\n.pharmacy-promo-banner-card[_ngcontent-%COMP%]   .banner-inner[_ngcontent-%COMP%]   .banner-text-col[_ngcontent-%COMP%]   .banner-badge-pill[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  font-size: 9px;\n  font-weight: 850;\n  letter-spacing: 0.6px;\n  background: rgba(255, 255, 255, 0.18);\n  color: #a7f3d0;\n  padding: 2px 8px;\n  border-radius: 99px;\n  margin-bottom: 4px;\n}\n.pharmacy-promo-banner-card[_ngcontent-%COMP%]   .banner-inner[_ngcontent-%COMP%]   .banner-text-col[_ngcontent-%COMP%]   .banner-badge-pill[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 11px;\n}\n.pharmacy-promo-banner-card[_ngcontent-%COMP%]   .banner-inner[_ngcontent-%COMP%]   .banner-text-col[_ngcontent-%COMP%]   .banner-badge-pill.lab[_ngcontent-%COMP%] {\n  color: #bae6fd;\n}\n.pharmacy-promo-banner-card[_ngcontent-%COMP%]   .banner-inner[_ngcontent-%COMP%]   .banner-text-col[_ngcontent-%COMP%]   .banner-title[_ngcontent-%COMP%] {\n  margin: 0 0 3px 0;\n  font-size: 15px;\n  font-weight: 850;\n  color: #ffffff;\n  letter-spacing: -0.2px;\n}\n.pharmacy-promo-banner-card[_ngcontent-%COMP%]   .banner-inner[_ngcontent-%COMP%]   .banner-text-col[_ngcontent-%COMP%]   .banner-desc[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 11px;\n  color: rgba(255, 255, 255, 0.88);\n  line-height: 1.35;\n}\n.pharmacy-promo-banner-card[_ngcontent-%COMP%]   .banner-inner[_ngcontent-%COMP%]   .banner-text-col[_ngcontent-%COMP%]   .banner-desc[_ngcontent-%COMP%]   .coupon-code[_ngcontent-%COMP%] {\n  color: #fef08a;\n  letter-spacing: 0.4px;\n}\n.pharmacy-promo-banner-card[_ngcontent-%COMP%]   .banner-inner[_ngcontent-%COMP%]   .banner-art-col[_ngcontent-%COMP%] {\n  flex-shrink: 0;\n}\n.pharmacy-promo-banner-card[_ngcontent-%COMP%]   .banner-inner[_ngcontent-%COMP%]   .banner-art-col[_ngcontent-%COMP%]   .banner-discount-tag[_ngcontent-%COMP%] {\n  width: 52px;\n  height: 52px;\n  border-radius: 14px;\n  background: rgba(255, 255, 255, 0.18);\n  border: 1px solid rgba(255, 255, 255, 0.25);\n  -webkit-backdrop-filter: blur(8px);\n  backdrop-filter: blur(8px);\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  color: #ffffff;\n  line-height: 1;\n}\n.pharmacy-promo-banner-card[_ngcontent-%COMP%]   .banner-inner[_ngcontent-%COMP%]   .banner-art-col[_ngcontent-%COMP%]   .banner-discount-tag[_ngcontent-%COMP%]   .pct[_ngcontent-%COMP%] {\n  font-size: 15px;\n  font-weight: 900;\n}\n.pharmacy-promo-banner-card[_ngcontent-%COMP%]   .banner-inner[_ngcontent-%COMP%]   .banner-art-col[_ngcontent-%COMP%]   .banner-discount-tag[_ngcontent-%COMP%]   .off[_ngcontent-%COMP%] {\n  font-size: 9px;\n  font-weight: 800;\n  letter-spacing: 0.5px;\n  margin-top: 2px;\n  opacity: 0.9;\n}\n.pharmacy-promo-banner-card[_ngcontent-%COMP%]   .banner-inner[_ngcontent-%COMP%]   .banner-art-col[_ngcontent-%COMP%]   .banner-discount-tag.lab[_ngcontent-%COMP%] {\n  background: rgba(255, 255, 255, 0.2);\n}\n.section-block[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n}\n.section-block[_ngcontent-%COMP%]   .section-header-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-end;\n  justify-content: space-between;\n}\n.section-block[_ngcontent-%COMP%]   .section-header-row[_ngcontent-%COMP%]   .section-title-col[_ngcontent-%COMP%]   .section-title[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 16.5px;\n  font-weight: 850;\n  color: #0f172a;\n  line-height: 1.2;\n}\n.section-block[_ngcontent-%COMP%]   .section-header-row[_ngcontent-%COMP%]   .section-title-col[_ngcontent-%COMP%]   .section-subtitle[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  color: #64748b;\n  font-weight: 500;\n}\n.section-block[_ngcontent-%COMP%]   .section-header-row[_ngcontent-%COMP%]   .section-tag-pill[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  font-weight: 850;\n  letter-spacing: 0.5px;\n  color: #059669;\n  background: #ecfdf5;\n  padding: 3px 8px;\n  border-radius: 99px;\n}\n.section-block[_ngcontent-%COMP%]   .section-header-row[_ngcontent-%COMP%]   .section-tag-pill.lab[_ngcontent-%COMP%] {\n  color: #7c3aed;\n  background: #f3e8ff;\n}\n.products-horizontal-scroll[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 12px;\n  overflow-x: auto;\n  padding-bottom: 6px;\n  margin: 0 -14px;\n  padding-left: 14px;\n  padding-right: 14px;\n  scroll-snap-type: x mandatory;\n  -webkit-overflow-scrolling: touch;\n}\n.products-horizontal-scroll[_ngcontent-%COMP%]::-webkit-scrollbar {\n  display: none;\n}\n.products-horizontal-scroll[_ngcontent-%COMP%]   .product-card-pill[_ngcontent-%COMP%] {\n  flex: 0 0 160px;\n  scroll-snap-align: start;\n  background: #ffffff;\n  border: 1px solid #e2e8f0;\n  border-radius: 16px;\n  padding: 10px;\n  position: relative;\n  display: flex;\n  flex-direction: column;\n  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.03);\n}\n.products-horizontal-scroll[_ngcontent-%COMP%]   .product-card-pill[_ngcontent-%COMP%]   .rx-required-tag[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 8px;\n  left: 8px;\n  z-index: 5;\n  font-size: 9px;\n  font-weight: 850;\n  background: #ef4444;\n  color: #ffffff;\n  padding: 1px 5px;\n  border-radius: 4px;\n}\n.products-horizontal-scroll[_ngcontent-%COMP%]   .product-card-pill[_ngcontent-%COMP%]   .product-img-box[_ngcontent-%COMP%] {\n  position: relative;\n  width: 100%;\n  height: 110px;\n  border-radius: 10px;\n  background: #f8fafc;\n  overflow: hidden;\n  margin-bottom: 8px;\n}\n.products-horizontal-scroll[_ngcontent-%COMP%]   .product-card-pill[_ngcontent-%COMP%]   .product-img-box[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n.products-horizontal-scroll[_ngcontent-%COMP%]   .product-card-pill[_ngcontent-%COMP%]   .product-img-box[_ngcontent-%COMP%]   .discount-chip[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 6px;\n  left: 6px;\n  font-size: 9px;\n  font-weight: 850;\n  background: #059669;\n  color: #ffffff;\n  padding: 2px 5px;\n  border-radius: 4px;\n}\n.products-horizontal-scroll[_ngcontent-%COMP%]   .product-card-pill[_ngcontent-%COMP%]   .product-info-wrap[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  flex: 1;\n}\n.products-horizontal-scroll[_ngcontent-%COMP%]   .product-card-pill[_ngcontent-%COMP%]   .product-info-wrap[_ngcontent-%COMP%]   .product-brand[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  font-weight: 700;\n  color: #94a3b8;\n  text-transform: uppercase;\n}\n.products-horizontal-scroll[_ngcontent-%COMP%]   .product-card-pill[_ngcontent-%COMP%]   .product-info-wrap[_ngcontent-%COMP%]   .product-name[_ngcontent-%COMP%] {\n  margin: 2px 0 4px;\n  font-size: 12.5px;\n  font-weight: 800;\n  color: #0f172a;\n  line-height: 1.25;\n  min-height: 32px;\n}\n.products-horizontal-scroll[_ngcontent-%COMP%]   .product-card-pill[_ngcontent-%COMP%]   .product-info-wrap[_ngcontent-%COMP%]   .product-pack[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #64748b;\n  margin-bottom: 8px;\n}\n.products-horizontal-scroll[_ngcontent-%COMP%]   .product-card-pill[_ngcontent-%COMP%]   .product-info-wrap[_ngcontent-%COMP%]   .product-pricing-row[_ngcontent-%COMP%] {\n  margin-top: auto;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n.products-horizontal-scroll[_ngcontent-%COMP%]   .product-card-pill[_ngcontent-%COMP%]   .product-info-wrap[_ngcontent-%COMP%]   .product-pricing-row[_ngcontent-%COMP%]   .price-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n.products-horizontal-scroll[_ngcontent-%COMP%]   .product-card-pill[_ngcontent-%COMP%]   .product-info-wrap[_ngcontent-%COMP%]   .product-pricing-row[_ngcontent-%COMP%]   .price-col[_ngcontent-%COMP%]   .current-price[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  font-weight: 850;\n  color: #0f172a;\n}\n.products-horizontal-scroll[_ngcontent-%COMP%]   .product-card-pill[_ngcontent-%COMP%]   .product-info-wrap[_ngcontent-%COMP%]   .product-pricing-row[_ngcontent-%COMP%]   .price-col[_ngcontent-%COMP%]   .mrp-price[_ngcontent-%COMP%] {\n  font-size: 10px;\n  color: #94a3b8;\n  text-decoration: line-through;\n}\n.products-horizontal-scroll[_ngcontent-%COMP%]   .product-card-pill[_ngcontent-%COMP%]   .product-info-wrap[_ngcontent-%COMP%]   .product-pricing-row[_ngcontent-%COMP%]   .btn-add-item[_ngcontent-%COMP%] {\n  height: 28px;\n  padding: 0 10px;\n  border-radius: 8px;\n  background: #ecfdf5;\n  border: 1px solid #a7f3d0;\n  color: #059669;\n  font-size: 11px;\n  font-weight: 800;\n  display: inline-flex;\n  align-items: center;\n  gap: 2px;\n  cursor: pointer;\n}\n.products-horizontal-scroll[_ngcontent-%COMP%]   .product-card-pill[_ngcontent-%COMP%]   .product-info-wrap[_ngcontent-%COMP%]   .product-pricing-row[_ngcontent-%COMP%]   .btn-add-item[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 13px;\n}\n.products-horizontal-scroll[_ngcontent-%COMP%]   .product-card-pill[_ngcontent-%COMP%]   .product-info-wrap[_ngcontent-%COMP%]   .product-pricing-row[_ngcontent-%COMP%]   .btn-add-item[_ngcontent-%COMP%]:active {\n  background: #d1fae5;\n}\n.products-horizontal-scroll[_ngcontent-%COMP%]   .product-card-pill[_ngcontent-%COMP%]   .product-info-wrap[_ngcontent-%COMP%]   .product-pricing-row[_ngcontent-%COMP%]   .stepper-box[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  background: #059669;\n  border-radius: 8px;\n  height: 28px;\n  padding: 0 2px;\n}\n.products-horizontal-scroll[_ngcontent-%COMP%]   .product-card-pill[_ngcontent-%COMP%]   .product-info-wrap[_ngcontent-%COMP%]   .product-pricing-row[_ngcontent-%COMP%]   .stepper-box[_ngcontent-%COMP%]   .btn-step[_ngcontent-%COMP%] {\n  width: 24px;\n  height: 24px;\n  border: none;\n  background: transparent;\n  color: #ffffff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 13px;\n  cursor: pointer;\n}\n.products-horizontal-scroll[_ngcontent-%COMP%]   .product-card-pill[_ngcontent-%COMP%]   .product-info-wrap[_ngcontent-%COMP%]   .product-pricing-row[_ngcontent-%COMP%]   .stepper-box[_ngcontent-%COMP%]   .step-count[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  font-weight: 800;\n  color: #ffffff;\n  min-width: 16px;\n  text-align: center;\n}\n.category-chips-scroll[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 8px;\n  overflow-x: auto;\n  margin: 0 -14px;\n  padding: 0 14px 4px;\n  -webkit-overflow-scrolling: touch;\n}\n.category-chips-scroll[_ngcontent-%COMP%]::-webkit-scrollbar {\n  display: none;\n}\n.category-chips-scroll[_ngcontent-%COMP%]   .cat-chip[_ngcontent-%COMP%] {\n  flex: 0 0 auto;\n  height: 34px;\n  padding: 0 12px;\n  border-radius: 999px;\n  background: #ffffff;\n  border: 1px solid #e2e8f0;\n  color: #475569;\n  font-size: 12px;\n  font-weight: 750;\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n.category-chips-scroll[_ngcontent-%COMP%]   .cat-chip[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 15px;\n}\n.category-chips-scroll[_ngcontent-%COMP%]   .cat-chip.active[_ngcontent-%COMP%] {\n  background: #0f172a;\n  color: #ffffff;\n  border-color: #0f172a;\n}\n.category-chips-scroll[_ngcontent-%COMP%]   .cat-chip.active[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  color: #ffffff !important;\n}\n.medicines-catalog-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 12px;\n}\n.medicines-catalog-grid[_ngcontent-%COMP%]   .med-catalog-card[_ngcontent-%COMP%] {\n  position: relative;\n  background: #ffffff;\n  border: 1px solid #e2e8f0;\n  border-radius: 16px;\n  padding: 10px;\n  display: flex;\n  flex-direction: column;\n  box-shadow: 0 2px 6px rgba(15, 23, 42, 0.03);\n}\n.medicines-catalog-grid[_ngcontent-%COMP%]   .med-catalog-card[_ngcontent-%COMP%]   .rx-required-tag[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 8px;\n  left: 8px;\n  z-index: 5;\n  font-size: 9px;\n  font-weight: 850;\n  background: #ef4444;\n  color: #ffffff;\n  padding: 1px 5px;\n  border-radius: 4px;\n}\n.medicines-catalog-grid[_ngcontent-%COMP%]   .med-catalog-card[_ngcontent-%COMP%]   .catalog-img-wrap[_ngcontent-%COMP%] {\n  position: relative;\n  width: 100%;\n  height: 120px;\n  border-radius: 10px;\n  background: #f8fafc;\n  overflow: hidden;\n  margin-bottom: 8px;\n}\n.medicines-catalog-grid[_ngcontent-%COMP%]   .med-catalog-card[_ngcontent-%COMP%]   .catalog-img-wrap[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n.medicines-catalog-grid[_ngcontent-%COMP%]   .med-catalog-card[_ngcontent-%COMP%]   .catalog-img-wrap[_ngcontent-%COMP%]   .discount-chip[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 6px;\n  left: 6px;\n  font-size: 9px;\n  font-weight: 850;\n  background: #059669;\n  color: #ffffff;\n  padding: 2px 5px;\n  border-radius: 4px;\n}\n.medicines-catalog-grid[_ngcontent-%COMP%]   .med-catalog-card[_ngcontent-%COMP%]   .catalog-body[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  flex: 1;\n}\n.medicines-catalog-grid[_ngcontent-%COMP%]   .med-catalog-card[_ngcontent-%COMP%]   .catalog-body[_ngcontent-%COMP%]   .catalog-brand[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  font-weight: 700;\n  color: #94a3b8;\n  text-transform: uppercase;\n}\n.medicines-catalog-grid[_ngcontent-%COMP%]   .med-catalog-card[_ngcontent-%COMP%]   .catalog-body[_ngcontent-%COMP%]   .catalog-title[_ngcontent-%COMP%] {\n  margin: 2px 0;\n  font-size: 13px;\n  font-weight: 800;\n  color: #0f172a;\n  line-height: 1.25;\n}\n.medicines-catalog-grid[_ngcontent-%COMP%]   .med-catalog-card[_ngcontent-%COMP%]   .catalog-body[_ngcontent-%COMP%]   .catalog-dosage[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #64748b;\n  font-weight: 600;\n}\n.medicines-catalog-grid[_ngcontent-%COMP%]   .med-catalog-card[_ngcontent-%COMP%]   .catalog-body[_ngcontent-%COMP%]   .catalog-desc[_ngcontent-%COMP%] {\n  margin: 4px 0 8px;\n  font-size: 11px;\n  color: #64748b;\n  line-height: 1.35;\n}\n.medicines-catalog-grid[_ngcontent-%COMP%]   .med-catalog-card[_ngcontent-%COMP%]   .catalog-body[_ngcontent-%COMP%]   .catalog-footer[_ngcontent-%COMP%] {\n  margin-top: auto;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n.medicines-catalog-grid[_ngcontent-%COMP%]   .med-catalog-card[_ngcontent-%COMP%]   .catalog-body[_ngcontent-%COMP%]   .catalog-footer[_ngcontent-%COMP%]   .price-stack[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n.medicines-catalog-grid[_ngcontent-%COMP%]   .med-catalog-card[_ngcontent-%COMP%]   .catalog-body[_ngcontent-%COMP%]   .catalog-footer[_ngcontent-%COMP%]   .price-stack[_ngcontent-%COMP%]   .main-price[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 850;\n  color: #0f172a;\n}\n.medicines-catalog-grid[_ngcontent-%COMP%]   .med-catalog-card[_ngcontent-%COMP%]   .catalog-body[_ngcontent-%COMP%]   .catalog-footer[_ngcontent-%COMP%]   .price-stack[_ngcontent-%COMP%]   .strike-mrp[_ngcontent-%COMP%] {\n  font-size: 10px;\n  color: #94a3b8;\n  text-decoration: line-through;\n}\n.medicines-catalog-grid[_ngcontent-%COMP%]   .med-catalog-card[_ngcontent-%COMP%]   .catalog-body[_ngcontent-%COMP%]   .catalog-footer[_ngcontent-%COMP%]   .btn-add-item[_ngcontent-%COMP%] {\n  height: 30px;\n  padding: 0 12px;\n  border-radius: 8px;\n  background: #ecfdf5;\n  border: 1px solid #a7f3d0;\n  color: #059669;\n  font-size: 11.5px;\n  font-weight: 800;\n  display: inline-flex;\n  align-items: center;\n  gap: 3px;\n  cursor: pointer;\n}\n.medicines-catalog-grid[_ngcontent-%COMP%]   .med-catalog-card[_ngcontent-%COMP%]   .catalog-body[_ngcontent-%COMP%]   .catalog-footer[_ngcontent-%COMP%]   .btn-add-item[_ngcontent-%COMP%]:active {\n  background: #d1fae5;\n}\n.medicines-catalog-grid[_ngcontent-%COMP%]   .med-catalog-card[_ngcontent-%COMP%]   .catalog-body[_ngcontent-%COMP%]   .catalog-footer[_ngcontent-%COMP%]   .stepper-box[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  background: #059669;\n  border-radius: 8px;\n  height: 30px;\n  padding: 0 2px;\n}\n.medicines-catalog-grid[_ngcontent-%COMP%]   .med-catalog-card[_ngcontent-%COMP%]   .catalog-body[_ngcontent-%COMP%]   .catalog-footer[_ngcontent-%COMP%]   .stepper-box[_ngcontent-%COMP%]   .btn-step[_ngcontent-%COMP%] {\n  width: 26px;\n  height: 26px;\n  border: none;\n  background: transparent;\n  color: #ffffff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 14px;\n  cursor: pointer;\n}\n.medicines-catalog-grid[_ngcontent-%COMP%]   .med-catalog-card[_ngcontent-%COMP%]   .catalog-body[_ngcontent-%COMP%]   .catalog-footer[_ngcontent-%COMP%]   .stepper-box[_ngcontent-%COMP%]   .step-count[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 800;\n  color: #ffffff;\n  min-width: 18px;\n  text-align: center;\n}\n.medicines-catalog-grid[_ngcontent-%COMP%]   .med-catalog-card[_ngcontent-%COMP%]   .catalog-body[_ngcontent-%COMP%]   .vendor-divider[_ngcontent-%COMP%] {\n  height: 1px;\n  background: #f1f5f9;\n  margin: 6px 0 4px;\n}\n.medicines-catalog-grid[_ngcontent-%COMP%]   .med-catalog-card[_ngcontent-%COMP%]   .catalog-body[_ngcontent-%COMP%]   .vendor-brief[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  line-height: 1.2;\n}\n.medicines-catalog-grid[_ngcontent-%COMP%]   .med-catalog-card[_ngcontent-%COMP%]   .catalog-body[_ngcontent-%COMP%]   .vendor-brief[_ngcontent-%COMP%]   .vendor-role[_ngcontent-%COMP%] {\n  font-size: 8.5px;\n  font-weight: 750;\n  color: #94a3b8;\n  text-transform: uppercase;\n  letter-spacing: 0.3px;\n}\n.medicines-catalog-grid[_ngcontent-%COMP%]   .med-catalog-card[_ngcontent-%COMP%]   .catalog-body[_ngcontent-%COMP%]   .vendor-brief[_ngcontent-%COMP%]   .vendor-name[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 750;\n  color: #1e293b;\n}\n.lab-tests-list[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 14px;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border: 1.5px solid #e2e8f0;\n  border-radius: 18px;\n  padding: 16px;\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n  box-shadow: 0 4px 12px rgba(15, 23, 42, 0.03);\n  transition: all 0.2s ease;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card.booked[_ngcontent-%COMP%] {\n  border-color: #7c3aed;\n  background: #fcfaff;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .test-header-row[_ngcontent-%COMP%]   .test-title-col[_ngcontent-%COMP%]   .test-tags-wrap[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 6px;\n  margin-bottom: 6px;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .test-header-row[_ngcontent-%COMP%]   .test-title-col[_ngcontent-%COMP%]   .test-tags-wrap[_ngcontent-%COMP%]   .test-tag[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  font-weight: 800;\n  color: #7c3aed;\n  background: #f3e8ff;\n  padding: 2px 7px;\n  border-radius: 6px;\n  text-transform: uppercase;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .test-header-row[_ngcontent-%COMP%]   .test-title-col[_ngcontent-%COMP%]   .test-name[_ngcontent-%COMP%] {\n  margin: 0 0 4px;\n  font-size: 15px;\n  font-weight: 850;\n  color: #0f172a;\n  line-height: 1.3;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .test-header-row[_ngcontent-%COMP%]   .test-title-col[_ngcontent-%COMP%]   .test-desc[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 12px;\n  color: #64748b;\n  line-height: 1.4;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .test-meta-pills-row[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 6px;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .test-meta-pills-row[_ngcontent-%COMP%]   .meta-pill[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  font-size: 11px;\n  font-weight: 650;\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n  padding: 4px 8px;\n  border-radius: 6px;\n  color: #334155;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .test-meta-pills-row[_ngcontent-%COMP%]   .meta-pill[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 13px;\n  color: #7c3aed;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .test-params-box[_ngcontent-%COMP%] {\n  background: #f8fafc;\n  border-radius: 10px;\n  padding: 8px 10px;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .test-params-box[_ngcontent-%COMP%]   .params-label[_ngcontent-%COMP%] {\n  font-size: 10.5px;\n  font-weight: 750;\n  color: #64748b;\n  text-transform: uppercase;\n  display: block;\n  margin-bottom: 4px;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .test-params-box[_ngcontent-%COMP%]   .params-chips-wrap[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 5px;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .test-params-box[_ngcontent-%COMP%]   .params-chips-wrap[_ngcontent-%COMP%]   .param-chip[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #1e293b;\n  font-weight: 500;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .test-params-box[_ngcontent-%COMP%]   .params-chips-wrap[_ngcontent-%COMP%]   .param-chip.more[_ngcontent-%COMP%] {\n  color: #7c3aed;\n  font-weight: 700;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .test-footer-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  border-top: 1px solid #f1f5f9;\n  padding-top: 10px;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .test-footer-row[_ngcontent-%COMP%]   .test-price-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .test-footer-row[_ngcontent-%COMP%]   .test-price-col[_ngcontent-%COMP%]   .test-price-main[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .test-footer-row[_ngcontent-%COMP%]   .test-price-col[_ngcontent-%COMP%]   .test-price-main[_ngcontent-%COMP%]   .test-price[_ngcontent-%COMP%] {\n  font-size: 17px;\n  font-weight: 850;\n  color: #0f172a;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .test-footer-row[_ngcontent-%COMP%]   .test-price-col[_ngcontent-%COMP%]   .test-price-main[_ngcontent-%COMP%]   .test-mrp[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #94a3b8;\n  text-decoration: line-through;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .test-footer-row[_ngcontent-%COMP%]   .test-price-col[_ngcontent-%COMP%]   .test-price-main[_ngcontent-%COMP%]   .test-save-badge[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  font-weight: 850;\n  background: #dcfce7;\n  color: #15803d;\n  padding: 1px 5px;\n  border-radius: 4px;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .test-footer-row[_ngcontent-%COMP%]   .test-price-col[_ngcontent-%COMP%]   .test-footnote[_ngcontent-%COMP%] {\n  font-size: 10px;\n  color: #64748b;\n  font-weight: 500;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .test-footer-row[_ngcontent-%COMP%]   .btn-book-test[_ngcontent-%COMP%] {\n  height: 38px;\n  padding: 0 16px;\n  border-radius: 12px;\n  background: #7c3aed;\n  color: #ffffff;\n  border: none;\n  font-size: 12.5px;\n  font-weight: 800;\n  letter-spacing: 0.3px;\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .test-footer-row[_ngcontent-%COMP%]   .btn-book-test[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 15px;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .test-footer-row[_ngcontent-%COMP%]   .btn-book-test.booked[_ngcontent-%COMP%] {\n  background: #10b981;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .test-footer-row[_ngcontent-%COMP%]   .btn-book-test[_ngcontent-%COMP%]:active {\n  transform: scale(0.96);\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .vendor-divider[_ngcontent-%COMP%] {\n  height: 1px;\n  background: #f1f5f9;\n  margin: 8px 0 6px;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .vendor-brief[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  line-height: 1.2;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .vendor-brief[_ngcontent-%COMP%]   .vendor-role[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  font-weight: 750;\n  color: #94a3b8;\n  text-transform: uppercase;\n  letter-spacing: 0.3px;\n}\n.lab-tests-list[_ngcontent-%COMP%]   .lab-test-card[_ngcontent-%COMP%]   .vendor-brief[_ngcontent-%COMP%]   .vendor-name[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 750;\n  color: #1e293b;\n}\n.lab-trust-section[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 18px;\n  border: 1px solid #e2e8f0;\n  padding: 16px;\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n}\n.lab-trust-section[_ngcontent-%COMP%]   .trust-heading[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 14px;\n  font-weight: 800;\n  color: #0f172a;\n}\n.lab-trust-section[_ngcontent-%COMP%]   .trust-cards-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  gap: 8px;\n}\n.lab-trust-section[_ngcontent-%COMP%]   .trust-cards-grid[_ngcontent-%COMP%]   .trust-card[_ngcontent-%COMP%] {\n  background: #f8fafc;\n  border-radius: 12px;\n  padding: 10px 8px;\n  text-align: center;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n}\n.lab-trust-section[_ngcontent-%COMP%]   .trust-cards-grid[_ngcontent-%COMP%]   .trust-card[_ngcontent-%COMP%]   .trust-icon-wrap[_ngcontent-%COMP%] {\n  width: 32px;\n  height: 32px;\n  border-radius: 50%;\n  background: #f3e8ff;\n  color: #7c3aed;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 16px;\n  margin-bottom: 6px;\n}\n.lab-trust-section[_ngcontent-%COMP%]   .trust-cards-grid[_ngcontent-%COMP%]   .trust-card[_ngcontent-%COMP%]   h6[_ngcontent-%COMP%] {\n  margin: 0 0 2px;\n  font-size: 11px;\n  font-weight: 750;\n  color: #0f172a;\n  line-height: 1.25;\n}\n.lab-trust-section[_ngcontent-%COMP%]   .trust-cards-grid[_ngcontent-%COMP%]   .trust-card[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 9.5px;\n  color: #64748b;\n  line-height: 1.35;\n}\n.docked-cart-banner[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  width: 100%;\n  padding: 8px 14px calc(env(safe-area-inset-bottom, 0px) + 14px);\n  background:\n    linear-gradient(\n      to top,\n      rgb(248, 250, 252) 75%,\n      rgba(248, 250, 252, 0.9) 50%,\n      rgba(248, 250, 252, 0) 100%);\n  z-index: 99;\n  pointer-events: auto;\n  box-sizing: border-box;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #064e3b 0%,\n      #022c22 100%);\n  border: 1px solid rgba(52, 211, 153, 0.35);\n  border-radius: 16px;\n  padding: 10px 14px;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 10px;\n  box-shadow: 0 6px 20px rgba(6, 78, 59, 0.35);\n  cursor: pointer;\n  transition: transform 0.15s ease, box-shadow 0.15s ease;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]:active {\n  transform: scale(0.985);\n  box-shadow: 0 3px 12px rgba(6, 78, 59, 0.25);\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  min-width: 0;\n  flex: 1;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-icon-circle[_ngcontent-%COMP%] {\n  width: 34px;\n  height: 34px;\n  border-radius: 10px;\n  background: rgba(255, 255, 255, 0.15);\n  color: #ffffff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 18px;\n  flex-shrink: 0;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-icon-circle.lab[_ngcontent-%COMP%] {\n  background: rgba(255, 255, 255, 0.18);\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-text-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  min-width: 0;\n  gap: 2px;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-text-col[_ngcontent-%COMP%]   .cart-badge-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  flex-wrap: wrap;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-text-col[_ngcontent-%COMP%]   .cart-badge-row[_ngcontent-%COMP%]   .badge-text[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  font-weight: 850;\n  color: #34d399;\n  letter-spacing: 0.5px;\n  text-transform: uppercase;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-text-col[_ngcontent-%COMP%]   .cart-badge-row[_ngcontent-%COMP%]   .badge-text.lab[_ngcontent-%COMP%] {\n  color: #38bdf8;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-text-col[_ngcontent-%COMP%]   .cart-badge-row[_ngcontent-%COMP%]   .item-count-chip[_ngcontent-%COMP%] {\n  font-size: 9px;\n  font-weight: 800;\n  background: rgba(255, 255, 255, 0.18);\n  color: #ffffff;\n  padding: 1px 5px;\n  border-radius: 4px;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-text-col[_ngcontent-%COMP%]   .cart-badge-row[_ngcontent-%COMP%]   .item-count-chip.lab[_ngcontent-%COMP%] {\n  background: rgba(255, 255, 255, 0.2);\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-text-col[_ngcontent-%COMP%]   .cart-price-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: baseline;\n  gap: 6px;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-text-col[_ngcontent-%COMP%]   .cart-price-row[_ngcontent-%COMP%]   .cart-grand-total[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 900;\n  color: #ffffff;\n  letter-spacing: -0.2px;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-text-col[_ngcontent-%COMP%]   .cart-price-row[_ngcontent-%COMP%]   .cart-savings-chip[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  font-weight: 800;\n  background: rgba(16, 185, 129, 0.25);\n  color: #a7f3d0;\n  padding: 1px 5px;\n  border-radius: 4px;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-text-col[_ngcontent-%COMP%]   .cart-price-row[_ngcontent-%COMP%]   .cart-savings-chip.lab[_ngcontent-%COMP%] {\n  background: rgba(56, 189, 248, 0.25);\n  color: #bae6fd;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-text-col[_ngcontent-%COMP%]   .cart-price-row[_ngcontent-%COMP%]   .cart-tap-note[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #94a3b8;\n  font-weight: 500;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-actions-right[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  flex-shrink: 0;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-actions-right[_ngcontent-%COMP%]   .btn-view-cart[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #10b981 0%,\n      #059669 100%);\n  color: #ffffff;\n  border: none;\n  border-radius: 99px;\n  padding: 8px 16px;\n  font-size: 12.5px;\n  font-weight: 850;\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  box-shadow: 0 3px 12px rgba(16, 185, 129, 0.4);\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-actions-right[_ngcontent-%COMP%]   .btn-view-cart[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-actions-right[_ngcontent-%COMP%]   .btn-view-cart.lab[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #0284c7 0%,\n      #0369a1 100%);\n  box-shadow: 0 3px 12px rgba(2, 132, 199, 0.4);\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-actions-right[_ngcontent-%COMP%]   .btn-view-cart[_ngcontent-%COMP%]:active {\n  transform: scale(0.95);\n}\n.docked-cart-banner.lab[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #0c4a6e 0%,\n      #082f49 100%);\n  border: 1px solid rgba(56, 189, 248, 0.35);\n  box-shadow: 0 6px 20px rgba(12, 74, 110, 0.35);\n}\n.docked-cart-banner.lab[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]:active {\n  box-shadow: 0 3px 12px rgba(12, 74, 110, 0.25);\n}\n@keyframes _ngcontent-%COMP%_pulseGlow {\n  0% {\n    box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7);\n  }\n  70% {\n    box-shadow: 0 0 0 8px rgba(16, 185, 129, 0);\n  }\n  100% {\n    box-shadow: 0 0 0 0 rgba(16, 185, 129, 0);\n  }\n}\n.bottom-nav-spacer[_ngcontent-%COMP%] {\n  height: 24px;\n  width: 100%;\n  transition: height 0.2s ease;\n}\n.bottom-nav-spacer.has-cart[_ngcontent-%COMP%] {\n  height: 120px;\n}\n.prescription-upload-modal[_ngcontent-%COMP%] {\n  --border-radius: 24px 24px 0 0;\n  --background: #ffffff;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]::part(content) {\n  border-radius: 24px 24px 0 0;\n  background: #ffffff;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  padding-bottom: max(env(safe-area-inset-bottom, 0px), 16px);\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-header[_ngcontent-%COMP%] {\n  padding: 12px 18px;\n  border-bottom: 1px solid #f1f5f9;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-header[_ngcontent-%COMP%]   .sheet-handle[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 4px;\n  border-radius: 99px;\n  background: #cbd5e1;\n  margin: 0 auto 12px;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-header[_ngcontent-%COMP%]   .rx-header-title-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-header[_ngcontent-%COMP%]   .rx-header-title-row[_ngcontent-%COMP%]   .rx-modal-title-col[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 16.5px;\n  font-weight: 850;\n  color: #0f172a;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-header[_ngcontent-%COMP%]   .rx-header-title-row[_ngcontent-%COMP%]   .rx-modal-title-col[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 2px 0 0;\n  font-size: 12px;\n  color: #64748b;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-header[_ngcontent-%COMP%]   .rx-header-title-row[_ngcontent-%COMP%]   .btn-modal-close[_ngcontent-%COMP%] {\n  width: 32px;\n  height: 32px;\n  border-radius: 50%;\n  background: #f1f5f9;\n  border: none;\n  color: #475569;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 18px;\n  cursor: pointer;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-body[_ngcontent-%COMP%] {\n  padding: 16px;\n  display: flex;\n  flex-direction: column;\n  gap: 14px;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-body[_ngcontent-%COMP%]   .upload-options-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  gap: 10px;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-body[_ngcontent-%COMP%]   .upload-options-grid[_ngcontent-%COMP%]   .upload-opt-card[_ngcontent-%COMP%] {\n  background: #f8fafc;\n  border: 1.5px dashed #cbd5e1;\n  border-radius: 14px;\n  padding: 14px 8px;\n  text-align: center;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-body[_ngcontent-%COMP%]   .upload-options-grid[_ngcontent-%COMP%]   .upload-opt-card[_ngcontent-%COMP%]:active {\n  border-color: #059669;\n  background: #ecfdf5;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-body[_ngcontent-%COMP%]   .upload-options-grid[_ngcontent-%COMP%]   .upload-opt-card[_ngcontent-%COMP%]   .opt-icon-circle[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 38px;\n  border-radius: 50%;\n  background: #ffffff;\n  color: #059669;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 20px;\n  margin-bottom: 6px;\n  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-body[_ngcontent-%COMP%]   .upload-options-grid[_ngcontent-%COMP%]   .upload-opt-card[_ngcontent-%COMP%]   .opt-title[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 800;\n  color: #0f172a;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-body[_ngcontent-%COMP%]   .upload-options-grid[_ngcontent-%COMP%]   .upload-opt-card[_ngcontent-%COMP%]   .opt-sub[_ngcontent-%COMP%] {\n  font-size: 10px;\n  color: #64748b;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-body[_ngcontent-%COMP%]   .selected-file-chip[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  background: #ecfdf5;\n  border: 1px solid #a7f3d0;\n  border-radius: 12px;\n  padding: 10px 12px;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-body[_ngcontent-%COMP%]   .selected-file-chip[_ngcontent-%COMP%]   .check-icon[_ngcontent-%COMP%] {\n  font-size: 20px;\n  color: #059669;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-body[_ngcontent-%COMP%]   .selected-file-chip[_ngcontent-%COMP%]   .file-info-col[_ngcontent-%COMP%] {\n  flex: 1;\n  display: flex;\n  flex-direction: column;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-body[_ngcontent-%COMP%]   .selected-file-chip[_ngcontent-%COMP%]   .file-info-col[_ngcontent-%COMP%]   .file-name[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 750;\n  color: #065f46;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-body[_ngcontent-%COMP%]   .selected-file-chip[_ngcontent-%COMP%]   .file-info-col[_ngcontent-%COMP%]   .file-status[_ngcontent-%COMP%] {\n  font-size: 10px;\n  color: #059669;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-body[_ngcontent-%COMP%]   .selected-file-chip[_ngcontent-%COMP%]   .btn-remove-file[_ngcontent-%COMP%] {\n  border: none;\n  background: transparent;\n  color: #ef4444;\n  font-size: 18px;\n  cursor: pointer;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-body[_ngcontent-%COMP%]   .notes-field-wrap[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 6px;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-body[_ngcontent-%COMP%]   .notes-field-wrap[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 750;\n  color: #334155;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-body[_ngcontent-%COMP%]   .notes-field-wrap[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%] {\n  width: 100%;\n  border-radius: 12px;\n  border: 1px solid #cbd5e1;\n  padding: 10px;\n  font-size: 12.5px;\n  color: #0f172a;\n  background: #ffffff;\n  resize: none;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-body[_ngcontent-%COMP%]   .notes-field-wrap[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%]:focus {\n  outline: none;\n  border-color: #059669;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-body[_ngcontent-%COMP%]   .rx-safety-note[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  background: #f8fafc;\n  border-radius: 10px;\n  padding: 8px 10px;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-body[_ngcontent-%COMP%]   .rx-safety-note[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n  color: #059669;\n  flex-shrink: 0;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-body[_ngcontent-%COMP%]   .rx-safety-note[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 11px;\n  color: #64748b;\n  line-height: 1.35;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-body[_ngcontent-%COMP%]   .btn-submit-rx[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 48px;\n  border-radius: 14px;\n  background: #059669;\n  color: #ffffff;\n  border: none;\n  font-size: 13.5px;\n  font-weight: 850;\n  letter-spacing: 0.3px;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  gap: 6px;\n  cursor: pointer;\n  box-shadow: 0 4px 14px rgba(5, 150, 105, 0.35);\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-body[_ngcontent-%COMP%]   .btn-submit-rx[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n}\n.prescription-upload-modal[_ngcontent-%COMP%]   .rx-modal-container[_ngcontent-%COMP%]   .rx-modal-body[_ngcontent-%COMP%]   .btn-submit-rx[_ngcontent-%COMP%]:disabled {\n  opacity: 0.6;\n}\n/*# sourceMappingURL=pharmacy.page.css.map */"] });
var PharmacyPage = _PharmacyPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(PharmacyPage, { className: "PharmacyPage", filePath: "src/app/pages/pharmacy/pharmacy.page.ts", lineNumber: 89 });
})();
export {
  PharmacyPage
};
//# sourceMappingURL=pharmacy.page-TRM7CUGA.js.map
