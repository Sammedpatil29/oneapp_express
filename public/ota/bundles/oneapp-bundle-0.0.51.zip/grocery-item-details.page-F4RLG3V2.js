import {
  ErrorComponent
} from "./chunk-WSTY3NBK.js";
import {
  ProductCardComponent
} from "./chunk-PCADZWYU.js";
import {
  GroceryService
} from "./chunk-UOJDERHI.js";
import {
  addIcons,
  alertCircleOutline,
  arrowBack,
  arrowBackOutline,
  globeOutline,
  heartOutline,
  hourglassOutline,
  leafOutline,
  shareSocialOutline,
  shieldCheckmarkOutline,
  star,
  timeOutline
} from "./chunk-V2INQVNG.js";
import {
  AuthService
} from "./chunk-EB6T6TPT.js";
import "./chunk-OE5MTPUR.js";
import "./chunk-YJYUHAOC.js";
import "./chunk-XR3JUECC.js";
import {
  IonButton,
  IonButtons,
  IonContent,
  IonFooter,
  IonHeader,
  IonIcon,
  IonSkeletonText,
  IonTitle,
  IonToolbar
} from "./chunk-CJE2NDTY.js";
import {
  ChangeDetectorRef,
  CommonModule,
  DecimalPipe,
  FormsModule,
  NavController,
  NgForOf,
  NgIf,
  Router,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵpropertyInterpolate,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2
} from "./chunk-Z7XNNJSA.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/pages/grocery-item-details/grocery-item-details.page.ts
function GroceryItemDetailsPage_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div")(1, "div", 8);
    \u0275\u0275element(2, "ion-skeleton-text", 9);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 10);
    \u0275\u0275element(4, "ion-skeleton-text", 11)(5, "ion-skeleton-text", 12);
    \u0275\u0275elementStart(6, "div", 13);
    \u0275\u0275element(7, "ion-skeleton-text", 14)(8, "ion-skeleton-text", 15);
    \u0275\u0275elementEnd()();
    \u0275\u0275element(9, "hr", 16);
    \u0275\u0275elementStart(10, "div", 10);
    \u0275\u0275element(11, "ion-skeleton-text", 17)(12, "ion-skeleton-text", 18)(13, "ion-skeleton-text", 19);
    \u0275\u0275elementEnd()();
  }
}
function GroceryItemDetailsPage_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "app-error", 20);
    \u0275\u0275listener("reload", function GroceryItemDetailsPage_Conditional_9_Template_app_error_reload_0_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.getDetails());
    });
    \u0275\u0275elementEnd();
  }
}
function GroceryItemDetailsPage_Conditional_10_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 43);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "span", 44);
    \u0275\u0275text(3);
    \u0275\u0275pipe(4, "number");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("\u20B9", ctx_r1.product.price, "");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("", \u0275\u0275pipeBind2(4, 2, ctx_r1.product.discount / ctx_r1.product.price * 100, "1.0-0"), "% OFF");
  }
}
function GroceryItemDetailsPage_Conditional_10_app_product_card_50_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "app-product-card", 45);
    \u0275\u0275listener("increase", function GroceryItemDetailsPage_Conditional_10_app_product_card_50_Template_app_product_card_increase_0_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.increase($event));
    })("decrease", function GroceryItemDetailsPage_Conditional_10_app_product_card_50_Template_app_product_card_decrease_0_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.decrease($event));
    })("itemClicked", function GroceryItemDetailsPage_Conditional_10_app_product_card_50_Template_app_product_card_itemClicked_0_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.goToDetails($event));
    });
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const p_r5 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275property("product", p_r5)("qty", ctx_r1.getQty(p_r5.id));
  }
}
function GroceryItemDetailsPage_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div")(1, "div", 21)(2, "div", 22);
    \u0275\u0275element(3, "img", 23);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(4, "div", 24)(5, "div", 25)(6, "div")(7, "small", 26);
    \u0275\u0275text(8);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "h1");
    \u0275\u0275text(10);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(11, "div", 27);
    \u0275\u0275text(12);
    \u0275\u0275pipe(13, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "div", 28)(15, "span", 29);
    \u0275\u0275text(16);
    \u0275\u0275elementEnd();
    \u0275\u0275template(17, GroceryItemDetailsPage_Conditional_10_Conditional_17_Template, 5, 5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "p", 30);
    \u0275\u0275text(19, "(Inclusive of all taxes)");
    \u0275\u0275elementEnd()();
    \u0275\u0275element(20, "hr", 16);
    \u0275\u0275elementStart(21, "div", 31)(22, "h4");
    \u0275\u0275text(23, "Product Details");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(24, "p");
    \u0275\u0275text(25);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(26, "span", 32);
    \u0275\u0275listener("click", function GroceryItemDetailsPage_Conditional_10_Template_span_click_26_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.isExpanded = !ctx_r1.isExpanded);
    });
    \u0275\u0275text(27);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(28, "div", 33)(29, "div", 34);
    \u0275\u0275element(30, "ion-icon", 35);
    \u0275\u0275elementStart(31, "strong");
    \u0275\u0275text(32, "Hybrid");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(33, "div", 34);
    \u0275\u0275element(34, "ion-icon", 36);
    \u0275\u0275elementStart(35, "strong");
    \u0275\u0275text(36, "3 Days");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(37, "div", 34);
    \u0275\u0275element(38, "ion-icon", 37);
    \u0275\u0275elementStart(39, "strong");
    \u0275\u0275text(40, "Indian");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(41, "div", 34);
    \u0275\u0275element(42, "ion-icon", 38);
    \u0275\u0275elementStart(43, "strong");
    \u0275\u0275text(44, "No Return");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275element(45, "hr", 16);
    \u0275\u0275elementStart(46, "div", 39)(47, "h4");
    \u0275\u0275text(48, "You might also like");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(49, "div", 40);
    \u0275\u0275template(50, GroceryItemDetailsPage_Conditional_10_app_product_card_50_Template, 1, 2, "app-product-card", 41);
    \u0275\u0275elementEnd()();
    \u0275\u0275element(51, "div", 42);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(3);
    \u0275\u0275propertyInterpolate("alt", ctx_r1.product.name);
    \u0275\u0275property("src", ctx_r1.product.image_url, \u0275\u0275sanitizeUrl);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r1.product.brand);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.product.name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", \u0275\u0275pipeBind2(13, 13, ctx_r1.product.unit_value, "1.0-0"), " ", ctx_r1.product.unit, "");
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r1.product.price - ctx_r1.product.discount, "");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.product.discount > 0 ? 17 : -1);
    \u0275\u0275advance(7);
    \u0275\u0275classProp("collapsed", !ctx_r1.isExpanded);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r1.product.description, " ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" ", ctx_r1.isExpanded ? "Read Less" : "Read More", " ");
    \u0275\u0275advance(23);
    \u0275\u0275property("ngForOf", ctx_r1.similarProducts);
  }
}
function GroceryItemDetailsPage_Conditional_11_button_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "button", 51);
    \u0275\u0275text(1, " OUT OF STOCK ");
    \u0275\u0275elementEnd();
  }
}
function GroceryItemDetailsPage_Conditional_11_button_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 52);
    \u0275\u0275listener("click", function GroceryItemDetailsPage_Conditional_11_button_9_Template_button_click_0_listener($event) {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext(2);
      $event.stopPropagation();
      return \u0275\u0275resetView(ctx_r1.increase(ctx_r1.product.id));
    });
    \u0275\u0275text(1, " ADD TO CART ");
    \u0275\u0275elementEnd();
  }
}
function GroceryItemDetailsPage_Conditional_11_div_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 53)(1, "div", 54);
    \u0275\u0275listener("click", function GroceryItemDetailsPage_Conditional_11_div_10_Template_div_click_1_listener($event) {
      \u0275\u0275restoreView(_r7);
      const ctx_r1 = \u0275\u0275nextContext(2);
      $event.stopPropagation();
      return \u0275\u0275resetView(ctx_r1.decrease(ctx_r1.product.id));
    });
    \u0275\u0275text(2, "-");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 55);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 54);
    \u0275\u0275listener("click", function GroceryItemDetailsPage_Conditional_11_div_10_Template_div_click_5_listener($event) {
      \u0275\u0275restoreView(_r7);
      const ctx_r1 = \u0275\u0275nextContext(2);
      $event.stopPropagation();
      return \u0275\u0275resetView(ctx_r1.increase(ctx_r1.product.id));
    });
    \u0275\u0275text(6, "+");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r1.getQty(ctx_r1.product.id));
  }
}
function GroceryItemDetailsPage_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-footer", 7)(1, "div", 46)(2, "div", 47)(3, "span");
    \u0275\u0275text(4);
    \u0275\u0275pipe(5, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "small");
    \u0275\u0275text(7);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(8, GroceryItemDetailsPage_Conditional_11_button_8_Template, 2, 0, "button", 48)(9, GroceryItemDetailsPage_Conditional_11_button_9_Template, 2, 0, "button", 49)(10, GroceryItemDetailsPage_Conditional_11_div_10_Template, 7, 1, "div", 50);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate2("", \u0275\u0275pipeBind2(5, 6, ctx_r1.product.unit_value, "1.0-0"), " ", ctx_r1.product.unit, "");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r1.product.price - ctx_r1.product.discount, "");
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", ctx_r1.product.stock === 0);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", ctx_r1.product.stock !== 0 && ctx_r1.getQty(ctx_r1.product.id) === 0);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", ctx_r1.product.stock !== 0 && ctx_r1.getQty(ctx_r1.product.id) > 0);
  }
}
var _GroceryItemDetailsPage = class _GroceryItemDetailsPage {
  // [
  //   { name: 'Red Onion', weight: '1kg', price: 45, img: 'https://cdn-icons-png.flaticon.com/512/765/765580.png' },
  //   { name: 'Potato', weight: '1kg', price: 35, img: 'https://cdn-icons-png.flaticon.com/512/765/765544.png' },
  //   { name: 'Cucumber', weight: '500g', price: 18, img: 'https://cdn-icons-png.flaticon.com/512/2329/2329921.png' },
  // ];
  constructor(router, groceryService, authService, cdr, navCtrl) {
    this.router = router;
    this.groceryService = groceryService;
    this.authService = authService;
    this.cdr = cdr;
    this.navCtrl = navCtrl;
    this.qty = 0;
    this.isExpanded = false;
    this.product = {};
    this.cartItems = [];
    this.isLoading = false;
    this.isError = false;
    this.similarProducts = [];
    addIcons({ shareSocialOutline, heartOutline, leafOutline, hourglassOutline, globeOutline, alertCircleOutline, arrowBack, arrowBackOutline, timeOutline, shieldCheckmarkOutline, star });
  }
  ngOnInit() {
    return __async(this, null, function* () {
      var _a, _b;
      const navigation = this.router.getCurrentNavigation();
      if ((_b = (_a = navigation == null ? void 0 : navigation.extras) == null ? void 0 : _a.state) == null ? void 0 : _b["productId"]) {
        this.productId = navigation.extras.state["productId"];
        console.log("Product ID:", this.productId);
      }
      this.token = yield this.authService.getToken();
      this.groceryService.cart$.subscribe((items) => {
        console.log("\u{1F6D2} UI Cart Updated:", items);
        this.cartItems = items;
        this.cdr.detectChanges();
      });
      this.getDetails();
    });
  }
  increase(productId) {
    this.groceryService.increaseQty(productId, this.token).subscribe({
      next: () => console.log("Increase Success"),
      error: (err) => console.error("API Failed", err)
    });
  }
  decrease(productId) {
    var _a;
    (_a = this.groceryService.decreaseQty(productId, this.token)) == null ? void 0 : _a.subscribe({
      next: () => console.log("Decrease Success"),
      error: (err) => console.error("API Failed", err)
    });
  }
  // --- HELPERS ---
  getQty(productId) {
    if (!this.cartItems || this.cartItems.length === 0)
      return 0;
    const item = this.cartItems.find((i) => String(i.productId) === String(productId));
    return item ? item.quantity : 0;
  }
  getDetails() {
    this.isLoading = true;
    this.isError = false;
    this.groceryService.getItemDetails(this.productId).subscribe((res) => {
      this.product = res.data;
      this.similarProducts = res.suggestions;
      this.cdr.detectChanges();
      this.isLoading = false;
    }, (error) => {
      this.isLoading = false;
      this.isError = true;
    });
  }
  goBack() {
    this.navCtrl.back();
  }
  goToDetails(product) {
    console.log("clicked product:", product);
    this.navCtrl.navigateForward([`/layout/grocery-layout/grocery-item-details/${product == null ? void 0 : product.id}`], {
      state: { productId: product == null ? void 0 : product.id }
    });
  }
};
_GroceryItemDetailsPage.\u0275fac = function GroceryItemDetailsPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _GroceryItemDetailsPage)(\u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(GroceryService), \u0275\u0275directiveInject(AuthService), \u0275\u0275directiveInject(ChangeDetectorRef), \u0275\u0275directiveInject(NavController));
};
_GroceryItemDetailsPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _GroceryItemDetailsPage, selectors: [["app-grocery-item-details"]], decls: 12, vars: 4, consts: [[1, "ion-no-border", "bg-white", "pt-2"], ["slot", "start"], [3, "click"], ["name", "arrow-back-outline", "color", "dark"], [1, "fw-bold", "text-dark"], [1, "bg-white", 3, "fullscreen"], ["title", "Oops! Item details failed to load"], [1, "sticky-footer"], [2, "height", "45vh", "width", "100%", "background", "#f4f4f4"], ["animated", "", 2, "width", "100%", "height", "100%", "margin", "0"], [2, "padding", "16px"], ["animated", "", 2, "width", "30%", "height", "14px", "border-radius", "4px"], ["animated", "", 2, "width", "80%", "height", "28px", "margin-top", "8px", "border-radius", "4px"], [2, "margin-top", "16px", "display", "flex", "align-items", "center", "gap", "10px"], ["animated", "", 2, "width", "80px", "height", "24px", "border-radius", "4px"], ["animated", "", 2, "width", "60px", "height", "18px", "border-radius", "4px"], [1, "divider"], ["animated", "", 2, "width", "40%", "height", "20px", "margin-bottom", "12px", "border-radius", "4px"], ["animated", "", 2, "width", "100%", "height", "14px", "margin-bottom", "6px", "border-radius", "4px"], ["animated", "", 2, "width", "70%", "height", "14px", "margin-bottom", "6px", "border-radius", "4px"], ["title", "Oops! Item details failed to load", 3, "reload"], [1, "image-container"], [1, "main-img"], [3, "src", "alt"], [1, "info-section"], [1, "d-flex", "justify-content-between", "align-items-start"], [1, "brand", "text-muted"], [1, "weight-row"], [1, "price-block"], [1, "curr"], [1, "tax-note"], [1, "details-section"], [1, "read-more", 3, "click"], [1, "highlights"], [1, "hl-item"], ["name", "leaf-outline", 1, "hl-icon", "text-success"], ["name", "hourglass-outline", 1, "hl-icon", "text-warning"], ["name", "globe-outline", 1, "hl-icon", "text-primary"], ["name", "alert-circle-outline", 1, "hl-icon", "text-danger"], [1, "similar-section"], [1, "product-scroll"], [3, "product", "qty", "increase", "decrease", "itemClicked", 4, "ngFor", "ngForOf"], [2, "height", "100px"], [1, "old"], [1, "disc-tag"], [3, "increase", "decrease", "itemClicked", "product", "qty"], [1, "action-container"], [1, "unit-toggle"], ["class", "big-add-btn", "disabled", "", "style", "opacity: 0.7; background-color: #dcdcdc; color: #555; border: none;", 4, "ngIf"], ["class", "big-add-btn", 3, "click", 4, "ngIf"], ["class", "big-counter", 4, "ngIf"], ["disabled", "", 1, "big-add-btn", 2, "opacity", "0.7", "background-color", "#dcdcdc", "color", "#555", "border", "none"], [1, "big-add-btn", 3, "click"], [1, "big-counter"], [1, "btn", 3, "click"], [1, "val"]], template: function GroceryItemDetailsPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar")(2, "ion-buttons", 1)(3, "ion-button", 2);
    \u0275\u0275listener("click", function GroceryItemDetailsPage_Template_ion_button_click_3_listener() {
      return ctx.goBack();
    });
    \u0275\u0275element(4, "ion-icon", 3);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "ion-title", 4);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(7, "ion-content", 5);
    \u0275\u0275template(8, GroceryItemDetailsPage_Conditional_8_Template, 14, 0, "div")(9, GroceryItemDetailsPage_Conditional_9_Template, 1, 0, "app-error", 6)(10, GroceryItemDetailsPage_Conditional_10_Template, 52, 16, "div");
    \u0275\u0275elementEnd();
    \u0275\u0275template(11, GroceryItemDetailsPage_Conditional_11_Template, 11, 9, "ion-footer", 7);
  }
  if (rf & 2) {
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate((ctx.product == null ? null : ctx.product.name) || "Product Details");
    \u0275\u0275advance();
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.isLoading ? 8 : ctx.isError ? 9 : 10);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(!ctx.isLoading && !ctx.isError && ctx.product ? 11 : -1);
  }
}, dependencies: [IonSkeletonText, IonFooter, IonIcon, IonButtons, IonButton, IonTitle, IonContent, IonHeader, IonToolbar, CommonModule, NgForOf, NgIf, DecimalPipe, FormsModule, ErrorComponent, ProductCardComponent], styles: ['\n\nion-header[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  z-index: 10;\n}\nion-header[_ngcontent-%COMP%]   ion-toolbar[_ngcontent-%COMP%] {\n  --background: transparent;\n  --border-width: 0;\n  padding-top: var(--ion-safe-area-top);\n}\nion-header[_ngcontent-%COMP%]   ion-toolbar[_ngcontent-%COMP%]   ion-buttons[_ngcontent-%COMP%]   ion-button[_ngcontent-%COMP%], \nion-header[_ngcontent-%COMP%]   ion-toolbar[_ngcontent-%COMP%]   ion-buttons[_ngcontent-%COMP%]   ion-back-button[_ngcontent-%COMP%] {\n  --background: rgb(255, 255, 255);\n  --color: #000;\n  --padding-start: 0;\n  --padding-end: 0;\n  border-radius: 50%;\n  width: 40px;\n  height: 40px;\n  margin: 0 5px;\n}\n.bg-white[_ngcontent-%COMP%] {\n  --background: #fff;\n}\n.divider[_ngcontent-%COMP%] {\n  border: 0;\n  height: 8px;\n  background: #f9f9f9;\n  margin: 0;\n}\n.image-container[_ngcontent-%COMP%] {\n  height: 45vh;\n  min-height: 320px;\n  width: 100%;\n  padding: 0;\n  margin: 0;\n  background: #eff6ff;\n  position: relative;\n  border-radius: 0 0 0px 0px;\n  overflow: hidden;\n}\n.image-container[_ngcontent-%COMP%]   .main-img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n}\n.image-container[_ngcontent-%COMP%]   .main-img[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n  display: block;\n}\n.image-container[_ngcontent-%COMP%]   .trust-badges[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 20px;\n  left: 20px;\n  z-index: 5;\n}\n.info-section[_ngcontent-%COMP%] {\n  padding: 20px 15px;\n}\n.info-section[_ngcontent-%COMP%]   .brand[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 600;\n  text-transform: uppercase;\n  letter-spacing: 0.5px;\n}\n.info-section[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%] {\n  margin: 4px 0;\n  font-size: 22px;\n  font-weight: 800;\n  color: #222;\n  line-height: 1.3;\n}\n.info-section[_ngcontent-%COMP%]   .weight-row[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: #777;\n  font-weight: 500;\n  margin-bottom: 12px;\n}\n.info-section[_ngcontent-%COMP%]   .price-block[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.info-section[_ngcontent-%COMP%]   .price-block[_ngcontent-%COMP%]   .curr[_ngcontent-%COMP%] {\n  font-size: 24px;\n  font-weight: 800;\n  color: #222;\n}\n.info-section[_ngcontent-%COMP%]   .price-block[_ngcontent-%COMP%]   .old[_ngcontent-%COMP%] {\n  font-size: 14px;\n  text-decoration: line-through;\n  color: #999;\n}\n.info-section[_ngcontent-%COMP%]   .price-block[_ngcontent-%COMP%]   .disc-tag[_ngcontent-%COMP%] {\n  background: #a000e2;\n  color: white;\n  font-size: 10px;\n  padding: 2px 6px;\n  border-radius: 4px;\n  font-weight: 700;\n}\n.info-section[_ngcontent-%COMP%]   .tax-note[_ngcontent-%COMP%] {\n  font-size: 10px;\n  color: #999;\n  margin: 2px 0 0;\n}\n.details-section[_ngcontent-%COMP%] {\n  padding: 15px;\n}\n.details-section[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  margin: 0 0 10px;\n  font-size: 16px;\n  font-weight: 700;\n  color: #222;\n}\n.details-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 13px;\n  color: #555;\n  line-height: 1.5;\n  margin: 0;\n}\n.details-section[_ngcontent-%COMP%]   p.collapsed[_ngcontent-%COMP%] {\n  display: -webkit-box;\n  -webkit-line-clamp: 3;\n  -webkit-box-orient: vertical;\n  overflow: hidden;\n}\n.details-section[_ngcontent-%COMP%]   .read-more[_ngcontent-%COMP%] {\n  color: #a000e2;\n  font-size: 12px;\n  font-weight: 700;\n  display: block;\n  margin-top: 5px;\n  cursor: pointer;\n}\n.details-section[_ngcontent-%COMP%]   .highlights[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-around;\n  background: #fff;\n  padding: 15px 10px;\n  border-radius: 12px;\n  border: 1px solid #f0f0f0;\n  margin-top: 20px;\n}\n.details-section[_ngcontent-%COMP%]   .highlights[_ngcontent-%COMP%]   .hl-item[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  gap: 6px;\n  width: 25%;\n  position: relative;\n}\n.details-section[_ngcontent-%COMP%]   .highlights[_ngcontent-%COMP%]   .hl-item[_ngcontent-%COMP%]:not(:last-child)::after {\n  content: "";\n  position: absolute;\n  right: 0;\n  top: 15%;\n  height: 70%;\n  width: 1px;\n  background: #eee;\n}\n.details-section[_ngcontent-%COMP%]   .highlights[_ngcontent-%COMP%]   .hl-item[_ngcontent-%COMP%]   .hl-icon[_ngcontent-%COMP%] {\n  font-size: 22px;\n}\n.details-section[_ngcontent-%COMP%]   .highlights[_ngcontent-%COMP%]   .hl-item[_ngcontent-%COMP%]   .text-success[_ngcontent-%COMP%] {\n  color: #2dd36f;\n}\n.details-section[_ngcontent-%COMP%]   .highlights[_ngcontent-%COMP%]   .hl-item[_ngcontent-%COMP%]   .text-warning[_ngcontent-%COMP%] {\n  color: #ffc409;\n}\n.details-section[_ngcontent-%COMP%]   .highlights[_ngcontent-%COMP%]   .hl-item[_ngcontent-%COMP%]   .text-primary[_ngcontent-%COMP%] {\n  color: #3880ff;\n}\n.details-section[_ngcontent-%COMP%]   .highlights[_ngcontent-%COMP%]   .hl-item[_ngcontent-%COMP%]   .text-danger[_ngcontent-%COMP%] {\n  color: #eb445a;\n}\n.details-section[_ngcontent-%COMP%]   .highlights[_ngcontent-%COMP%]   .hl-item[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #333;\n  text-align: center;\n}\n.similar-section[_ngcontent-%COMP%] {\n  padding: 15px 0 15px 15px;\n}\n.similar-section[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  margin: 0 0 15px;\n  font-size: 16px;\n  font-weight: 700;\n  color: #222;\n}\n.similar-section[_ngcontent-%COMP%]   .product-scroll[_ngcontent-%COMP%] {\n  display: flex;\n  overflow-x: auto;\n  padding-right: 15px;\n  padding-bottom: 10px;\n  gap: 12px;\n  scroll-behavior: smooth;\n}\n.similar-section[_ngcontent-%COMP%]   .product-scroll[_ngcontent-%COMP%]::-webkit-scrollbar {\n  display: none;\n}\n.similar-section[_ngcontent-%COMP%]   .product-scroll[_ngcontent-%COMP%]   app-product-card[_ngcontent-%COMP%] {\n  flex: 0 0 145px;\n  width: 145px;\n}\n.sticky-footer[_ngcontent-%COMP%] {\n  background: white;\n  padding: 10px 15px 20px;\n  box-shadow: 0 -4px 15px rgba(0, 0, 0, 0.05);\n  border-top: 1px solid #f0f0f0;\n}\n.sticky-footer[_ngcontent-%COMP%]   .action-container[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n.sticky-footer[_ngcontent-%COMP%]   .action-container[_ngcontent-%COMP%]   .unit-toggle[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n.sticky-footer[_ngcontent-%COMP%]   .action-container[_ngcontent-%COMP%]   .unit-toggle[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 600;\n  color: #222;\n}\n.sticky-footer[_ngcontent-%COMP%]   .action-container[_ngcontent-%COMP%]   .unit-toggle[_ngcontent-%COMP%]   small[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #777;\n}\n.sticky-footer[_ngcontent-%COMP%]   .action-container[_ngcontent-%COMP%]   .big-add-btn[_ngcontent-%COMP%] {\n  background: var(--grocery-theme-color);\n  color: white;\n  border: none;\n  padding: 12px 30px;\n  border-radius: 12px;\n  font-weight: 700;\n  font-size: 14px;\n  letter-spacing: 0.5px;\n  box-shadow: 0 4px 10px rgba(255, 50, 105, 0.3);\n}\n.sticky-footer[_ngcontent-%COMP%]   .action-container[_ngcontent-%COMP%]   .big-add-btn[_ngcontent-%COMP%]:active {\n  transform: scale(0.98);\n}\n.sticky-footer[_ngcontent-%COMP%]   .action-container[_ngcontent-%COMP%]   .big-counter[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  background: #a000e2;\n  color: white;\n  border-radius: 12px;\n  height: 44px;\n  min-width: 120px;\n  justify-content: space-between;\n  padding: 0 5px;\n  box-shadow: 0 4px 10px rgba(255, 50, 105, 0.3);\n}\n.sticky-footer[_ngcontent-%COMP%]   .action-container[_ngcontent-%COMP%]   .big-counter[_ngcontent-%COMP%]   .btn[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 100%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 20px;\n  font-weight: bold;\n  color: white;\n}\n.sticky-footer[_ngcontent-%COMP%]   .action-container[_ngcontent-%COMP%]   .big-counter[_ngcontent-%COMP%]   .val[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 700;\n}\n/*# sourceMappingURL=grocery-item-details.page.css.map */'] });
var GroceryItemDetailsPage = _GroceryItemDetailsPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(GroceryItemDetailsPage, { className: "GroceryItemDetailsPage", filePath: "src/app/pages/grocery-item-details/grocery-item-details.page.ts", lineNumber: 21 });
})();
export {
  GroceryItemDetailsPage
};
//# sourceMappingURL=grocery-item-details.page-F4RLG3V2.js.map
