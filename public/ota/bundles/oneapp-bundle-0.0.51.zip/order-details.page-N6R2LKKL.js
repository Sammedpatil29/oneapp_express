import {
  EventsService
} from "./chunk-GKNTDGNO.js";
import {
  addIcons,
  alertCircleOutline,
  arrowBack,
  arrowBackOutline,
  calendarOutline,
  checkmarkCircle,
  downloadOutline,
  homeOutline,
  locationOutline,
  mapOutline,
  shareSocialOutline,
  timeOutline
} from "./chunk-V2INQVNG.js";
import {
  AuthService
} from "./chunk-EB6T6TPT.js";
import "./chunk-OE5MTPUR.js";
import "./chunk-YJYUHAOC.js";
import "./chunk-XR3JUECC.js";
import {
  IonButton,
  IonButtons,
  IonCardSubtitle,
  IonContent,
  IonHeader,
  IonIcon,
  IonInput,
  IonItem,
  IonRange,
  IonSelect,
  IonSelectOption,
  IonSpinner,
  IonTitle,
  IonToast,
  IonToolbar
} from "./chunk-CJE2NDTY.js";
import {
  CommonModule,
  CurrencyPipe,
  DatePipe,
  FormsModule,
  MaxLengthValidator,
  NavController,
  NgControlStatus,
  NgForOf,
  NgIf,
  NgModel,
  NgZone,
  Platform,
  Router,
  TitleCasePipe,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind1,
  ɵɵpipeBind2,
  ɵɵpipeBind4,
  ɵɵproperty,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-Z7XNNJSA.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/pages/order-details/order-details.page.ts
function OrderDetailsPage_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 6);
    \u0275\u0275element(1, "ion-spinner", 8);
    \u0275\u0275elementEnd();
  }
}
function OrderDetailsPage_Conditional_9_div_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 33);
    \u0275\u0275text(1);
    \u0275\u0275pipe(2, "titlecase");
    \u0275\u0275elementStart(3, "span", 4);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", \u0275\u0275pipeBind1(2, 2, ctx_r1.selectedOption.name), " Ticket ");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r1.unitPrice, "");
  }
}
function OrderDetailsPage_Conditional_9_Conditional_15_ion_select_option_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-select-option", 37);
    \u0275\u0275text(1);
    \u0275\u0275pipe(2, "titlecase");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const opt_r4 = ctx.$implicit;
    \u0275\u0275property("value", opt_r4);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate2(" ", \u0275\u0275pipeBind1(2, 3, opt_r4.name), " - \u20B9", opt_r4.price, " ");
  }
}
function OrderDetailsPage_Conditional_9_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-card-subtitle", 17);
    \u0275\u0275text(1, "Select Ticket Class");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "ion-item", 34)(3, "ion-select", 35);
    \u0275\u0275listener("ionChange", function OrderDetailsPage_Conditional_9_Conditional_15_Template_ion_select_ionChange_3_listener($event) {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.onTicketSelect($event.detail.value));
    });
    \u0275\u0275template(4, OrderDetailsPage_Conditional_9_Conditional_15_ion_select_option_4_Template, 3, 5, "ion-select-option", 36);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(3);
    \u0275\u0275property("value", ctx_r1.selectedOption);
    \u0275\u0275advance();
    \u0275\u0275property("ngForOf", ctx_r1.ticketOptions);
  }
}
function OrderDetailsPage_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 9)(1, "div")(2, "div", 10);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275template(4, OrderDetailsPage_Conditional_9_div_4_Template, 5, 4, "div", 11);
    \u0275\u0275elementStart(5, "div", 12);
    \u0275\u0275text(6);
    \u0275\u0275pipe(7, "date");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "div", 13)(9, "span", 14);
    \u0275\u0275listener("click", function OrderDetailsPage_Conditional_9_Template_span_click_9_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.count("-"));
    });
    \u0275\u0275text(10, "-");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "span", 15);
    \u0275\u0275text(12);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "span", 16);
    \u0275\u0275listener("click", function OrderDetailsPage_Conditional_9_Template_span_click_13_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.count("+"));
    });
    \u0275\u0275text(14, "+");
    \u0275\u0275elementEnd()()();
    \u0275\u0275template(15, OrderDetailsPage_Conditional_9_Conditional_15_Template, 5, 2);
    \u0275\u0275elementStart(16, "ion-card-subtitle", 17);
    \u0275\u0275text(17, "Personal Details");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "ion-item", 18)(19, "ion-input", 19);
    \u0275\u0275twoWayListener("ngModelChange", function OrderDetailsPage_Conditional_9_Template_ion_input_ngModelChange_19_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.customerName, $event) || (ctx_r1.customerName = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(20, "ion-item", 18)(21, "ion-input", 20);
    \u0275\u0275twoWayListener("ngModelChange", function OrderDetailsPage_Conditional_9_Template_ion_input_ngModelChange_21_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.mobileNumber, $event) || (ctx_r1.mobileNumber = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(22, "ion-item", 18)(23, "ion-input", 21);
    \u0275\u0275twoWayListener("ngModelChange", function OrderDetailsPage_Conditional_9_Template_ion_input_ngModelChange_23_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.email, $event) || (ctx_r1.email = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(24, "ion-card-subtitle", 17);
    \u0275\u0275text(25, "Price Details");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(26, "div", 22)(27, "div", 23)(28, "span");
    \u0275\u0275text(29);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(30, "span", 24);
    \u0275\u0275text(31);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(32, "div", 25)(33, "span");
    \u0275\u0275text(34, "Platform Charges (7%)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(35, "span");
    \u0275\u0275text(36);
    \u0275\u0275elementEnd()();
    \u0275\u0275element(37, "hr", 26);
    \u0275\u0275elementStart(38, "div", 27)(39, "span");
    \u0275\u0275text(40, "Total Pay");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(41, "span");
    \u0275\u0275text(42);
    \u0275\u0275elementEnd()()();
    \u0275\u0275element(43, "div", 28);
    \u0275\u0275elementStart(44, "div", 29)(45, "div", 30)(46, "div", 31);
    \u0275\u0275text(47);
    \u0275\u0275pipe(48, "currency");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(49, "ion-range", 32);
    \u0275\u0275listener("ionChange", function OrderDetailsPage_Conditional_9_Template_ion_range_ionChange_49_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView($event.detail.value == 100 ? ctx_r1.PayNow() : $event.target.value = 0);
    });
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx_r1.eventData == null ? null : ctx_r1.eventData.eventName);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", ctx_r1.selectedOption);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" ", \u0275\u0275pipeBind2(7, 14, ctx_r1.eventData == null ? null : ctx_r1.eventData.eventDate, "mediumDate"), " ");
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(ctx_r1.ticketCount);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx_r1.ticketOptions.length > 1 ? 15 : -1);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.customerName);
    \u0275\u0275advance(2);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.mobileNumber);
    \u0275\u0275advance(2);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.email);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate2("Base Price (", ctx_r1.ticketCount, " x \u20B9", ctx_r1.unitPrice, ")");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r1.basePrice, "");
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r1.charges, "");
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r1.finalCost, "");
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate1(" Slide to Pay ", \u0275\u0275pipeBind4(48, 17, ctx_r1.finalCost, "INR", "symbol", "1.0-0"), " ");
  }
}
var _OrderDetailsPage = class _OrderDetailsPage {
  constructor(navCtrl, router, authService, eventService, zone, platform) {
    this.navCtrl = navCtrl;
    this.router = router;
    this.authService = authService;
    this.eventService = eventService;
    this.zone = zone;
    this.platform = platform;
    this.ticketCount = 1;
    this.unitPrice = 0;
    this.basePrice = 0;
    this.charges = 0;
    this.finalCost = 0;
    this.ticketOptions = [];
    this.selectedOption = null;
    this.customerName = "";
    this.mobileNumber = "";
    this.email = "";
    this.isLoading = true;
    this.isToastOpen = false;
    this.toastMessage = "";
    this.pendingOrderId = null;
    this.pollingInterval = null;
    this.isPaymentDetected = false;
    addIcons({ arrowBack, arrowBackOutline, homeOutline, checkmarkCircle, calendarOutline, timeOutline, locationOutline, alertCircleOutline, downloadOutline, shareSocialOutline, mapOutline });
  }
  ngOnInit() {
    return __async(this, null, function* () {
      var _a;
      this.eventId = history.state.eventId;
      if (!this.eventId) {
        const nav = this.router.getCurrentNavigation();
        if ((_a = nav == null ? void 0 : nav.extras) == null ? void 0 : _a.state) {
          this.eventId = nav.extras.state["eventId"];
        }
      }
      this.authService.getToken().then((res) => {
        this.token = res;
        if (this.eventId) {
          this.fetchEventDetails(this.eventId);
        } else {
          console.error("No Event ID provided!");
          this.isLoading = false;
        }
      });
      this.checkPendingOrder();
    });
  }
  fetchEventDetails(id) {
    this.isLoading = true;
    let params = { "eventId": id };
    this.eventService.getEventDetails(params, this.token).subscribe({
      next: (res) => {
        if (res.success) {
          this.eventData = res.event;
          if (res.user) {
            this.customerName = res.user.name || "";
            this.mobileNumber = res.user.phone || "";
            this.email = res.user.email || "";
          }
          this.processTicketOptions(this.eventData.ticketOptions);
        }
        this.isLoading = false;
      },
      error: (err) => {
        console.error("API Error", err);
        this.isLoading = false;
      }
    });
  }
  checkPendingOrder() {
    return __async(this, null, function* () {
      const value = localStorage.getItem("pending_order_id");
      if (value) {
        this.pendingOrderId = value;
        this.startPolling(this.pendingOrderId);
      }
    });
  }
  // ... [Ticket Processing and Calculation Methods remain same] ...
  processTicketOptions(options) {
    if (options && options.length > 0) {
      this.ticketOptions = options.map((opt) => ({
        name: opt.class,
        price: Number(opt.price),
        stock: opt.tickets
      }));
      this.onTicketSelect(this.ticketOptions[0]);
    } else {
      this.ticketOptions = [];
      this.unitPrice = 0;
    }
  }
  onTicketSelect(option) {
    this.selectedOption = option;
    this.unitPrice = option.price;
    this.calculateTotal();
  }
  calculateTotal() {
    this.basePrice = this.ticketCount * this.unitPrice;
    this.charges = Math.round(this.basePrice * 0.07);
    this.finalCost = this.basePrice + this.charges;
  }
  count(action) {
    if (action === "+") {
      if (this.ticketCount < this.eventData.maxSelection)
        this.ticketCount++;
      else
        this.showToast(`Max ${this.eventData.maxSelection} Quantity allowed`);
    } else if (action === "-") {
      if (this.ticketCount > 1)
        this.ticketCount--;
    }
    this.calculateTotal();
  }
  // ✅ 1. Check Availability First
  PayNow() {
    if (!this.customerName || !this.mobileNumber || !this.email) {
      this.showToast("Please fill all details");
      return;
    }
    this.isLoading = true;
    let params = {
      "eventId": this.eventId,
      "class": this.selectedOption.name,
      "tickets": this.ticketCount
    };
    this.eventService.checkAvailability(params).subscribe({
      next: (res) => {
        if (res.success === true) {
          this.createOrderOnBackend();
        } else {
          this.isLoading = false;
          this.showToast(res.message || "Tickets not available");
        }
      },
      error: (err) => {
        this.isLoading = false;
        this.showToast("Server error checking availability");
      }
    });
  }
  // ✅ 2. Acquire Order ID from Backend
  createOrderOnBackend() {
    const orderData = {
      eventId: this.eventId,
      tickets: this.ticketCount,
      class: this.selectedOption.name
    };
    this.eventService.createRazorpayOrder(orderData, this.token).subscribe({
      next: (res) => __async(this, null, function* () {
        if (res.success) {
          this.pendingOrderId = res.internal_order_id;
          localStorage.setItem("pending_order_id", res.internal_order_id);
          this.initiateRazorpay(res.razorpay_order_id);
        } else {
          this.isLoading = false;
          this.showToast("Failed to create order");
        }
      }),
      error: (err) => {
        this.isLoading = false;
        this.showToast("Server error creating order");
      }
    });
  }
  // ✅ 3. Initiate Razorpay & START POLLING
  initiateRazorpay(rzpOrderId) {
    const options = {
      key: "rzp_test_S5RLYqr6y2I6xs",
      amount: (this.finalCost * 100).toString(),
      currency: "INR",
      name: "Pintu Events",
      description: `${this.selectedOption.name} Ticket x${this.ticketCount}`,
      image: "https://your-logo-url.com/logo.png",
      order_id: rzpOrderId,
      prefill: {
        name: this.customerName,
        email: this.email,
        contact: this.mobileNumber
      },
      theme: { color: "#121212" }
    };
    this.platform.ready().then(() => {
      if (typeof window.RazorpayCheckout !== "undefined") {
        window.RazorpayCheckout.open(options);
        this.startPolling(this.pendingOrderId);
      } else {
        this.isLoading = false;
        this.showToast("Razorpay Plugin not installed");
      }
    });
  }
  // ✅ 4. The Polling Logic
  startPolling(internalOrderId) {
    console.log("Started polling for:", internalOrderId);
    this.stopPolling();
    this.pollingInterval = setInterval(() => {
      this.checkStatusFromBackend(internalOrderId);
    }, 3e3);
    setTimeout(() => {
      if (!this.isPaymentDetected) {
        this.stopPolling();
        this.isLoading = false;
      }
    }, 12e4);
  }
  checkStatusFromBackend(internalOrderId) {
    const verifyData = { orderId: internalOrderId };
    this.eventService.verifyPayment(verifyData).subscribe({
      next: (res) => __async(this, null, function* () {
        console.log("veerified");
        if (res.success && res.status === "paid") {
          this.handleSuccess(res);
        } else if (res.status === "failed") {
          this.stopPolling();
          this.isLoading = false;
          this.showToast("Payment Failed.");
        }
      }),
      error: (err) => {
        console.log("Poll error", err);
      }
    });
  }
  stopPolling() {
    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
      this.pollingInterval = null;
    }
  }
  handleSuccess(res) {
    return __async(this, null, function* () {
      var _a;
      this.isPaymentDetected = true;
      console.log("Payment Success:", res);
      this.stopPolling();
      this.isLoading = false;
      localStorage.removeItem("pending_order_id");
      this.showToast("Booking Confirmed! \u{1F680}");
      const idToPass = ((_a = res.booking) == null ? void 0 : _a.id) || res.orderId || res.id || this.pendingOrderId;
      this.navCtrl.navigateRoot(["/layout/track-order"], {
        animated: true,
        animationDirection: "forward",
        state: {
          orderId: res.booking.id,
          from: "order-details"
          // Required for the 'Back' button logic in TrackOrderPage
        }
      });
    });
  }
  dummycall() {
    this.navCtrl.navigateRoot(["/layout/track-order"], {
      animated: true,
      animationDirection: "forward",
      state: {
        orderId: "14",
        from: "order-details"
        // Required for the 'Back' button logic in TrackOrderPage
      }
    });
  }
  ngOnDestroy() {
    this.stopPolling();
  }
  showToast(msg) {
    this.isToastOpen = true;
    this.toastMessage = msg;
    setTimeout(() => {
      this.isToastOpen = false;
    }, 2e3);
  }
  goBack() {
    this.navCtrl.back();
  }
};
_OrderDetailsPage.\u0275fac = function OrderDetailsPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _OrderDetailsPage)(\u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(AuthService), \u0275\u0275directiveInject(EventsService), \u0275\u0275directiveInject(NgZone), \u0275\u0275directiveInject(Platform));
};
_OrderDetailsPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _OrderDetailsPage, selectors: [["app-order-details"]], decls: 11, vars: 5, consts: [[1, "ion-no-border", "bg-white", "pt-2"], ["slot", "start"], [3, "click"], ["name", "arrow-back-outline", "color", "dark"], [1, "fw-bold", "text-dark"], [1, "ion-padding-horizontal", 3, "fullscreen"], [1, "d-flex", "justify-content-center", "align-items-center", "h-100"], [3, "isOpen", "message", "duration"], ["name", "crescent"], [1, "p-3", "mt-3", "border", "rounded-4", "d-flex", "justify-content-between", "align-items-center", "bg-light"], [1, "fw-bold", "fs-5"], ["class", "text-muted small", 4, "ngIf"], [1, "text-muted", "small", 2, "font-size", "11px"], [1, "d-flex", "align-items-center", "bg-white", "border", "rounded-pill", "px-2", "py-1", "shadow-sm"], [1, "px-2", "fw-bold", "fs-4", "text-secondary", 3, "click"], [1, "px-2", "fw-bold", "fs-6"], [1, "px-2", "fw-bold", "fs-4", "text-primary", 3, "click"], [1, "mt-4", "ms-1", "fw-bold", "text-dark"], ["lines", "none", 1, "border", "rounded-4", "mt-2", "bg-light"], ["placeholder", "Full Name", 3, "ngModelChange", "ngModel"], ["placeholder", "Phone Number", "type", "tel", "maxlength", "10", 3, "ngModelChange", "ngModel"], ["placeholder", "Email Address", "type", "email", 3, "ngModelChange", "ngModel"], [1, "border", "rounded-4", "mt-2", "p-3", "mb-5", "bg-white", "shadow-sm"], [1, "d-flex", "justify-content-between", "mb-2"], [1, "fw-medium"], [1, "d-flex", "justify-content-between", "mb-2", "text-muted"], [1, "my-2", "dashed"], [1, "d-flex", "justify-content-between", "fw-bold", "fs-5", "text-dark"], [2, "height", "100px"], [1, "fixed-bottom", "bg-white", "p-3"], [2, "position", "relative", "width", "100%", "height", "60px", "background-color", "#222428", "border-radius", "16px", "display", "flex", "align-items", "center", "justify-content", "center", "overflow", "hidden"], [2, "position", "absolute", "color", "white", "font-weight", "600", "font-size", "16px", "pointer-events", "none", "z-index", "1"], ["min", "0", "max", "100", "value", "0", "mode", "ios", 2, "width", "100%", "padding", "0", "margin", "0", "height", "100%", "z-index", "2", "--bar-background", "transparent", "--bar-background-active", "transparent", "--knob-background", "#ffffff url('data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 512 512%22%3E%3Cpath fill=%22none%22 stroke=%22black%22 stroke-linecap=%22round%22 stroke-linejoin=%22round%22 stroke-width=%2248%22 d=%22M184 112l144 144-144 144%22/%3E%3C/svg%3E') no-repeat center center", "--knob-background-size", "24px", "--knob-size", "52px", "--knob-border-radius", "14px", "--knob-box-shadow", "0 2px 6px rgba(0,0,0,0.3)", "padding-inline-start", "30px", "padding-inline-end", "30px", 3, "ionChange"], [1, "text-muted", "small"], ["lines", "none", 1, "border", "rounded-4", "mt-2"], ["interface", "action-sheet", "placeholder", "Select Class", 1, "w-100", "fw-bold", 3, "ionChange", "value"], [3, "value", 4, "ngFor", "ngForOf"], [3, "value"]], template: function OrderDetailsPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar")(2, "ion-buttons", 1)(3, "ion-button", 2);
    \u0275\u0275listener("click", function OrderDetailsPage_Template_ion_button_click_3_listener() {
      return ctx.goBack();
    });
    \u0275\u0275element(4, "ion-icon", 3);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "ion-title", 4);
    \u0275\u0275text(6, "Order Details");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(7, "ion-content", 5);
    \u0275\u0275template(8, OrderDetailsPage_Conditional_8_Template, 2, 0, "div", 6)(9, OrderDetailsPage_Conditional_9_Template, 50, 22);
    \u0275\u0275element(10, "ion-toast", 7);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance(7);
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.isLoading ? 8 : 9);
    \u0275\u0275advance(2);
    \u0275\u0275property("isOpen", ctx.isToastOpen)("message", ctx.toastMessage)("duration", 3e3);
  }
}, dependencies: [IonRange, IonToast, IonSelect, IonSelectOption, IonSpinner, IonItem, IonInput, IonCardSubtitle, IonIcon, IonButton, IonButtons, IonContent, IonHeader, IonTitle, IonToolbar, CommonModule, NgForOf, NgIf, TitleCasePipe, CurrencyPipe, DatePipe, FormsModule, NgControlStatus, MaxLengthValidator, NgModel], styles: ["\n\n.addressField[_ngcontent-%COMP%] {\n  border-radius: 15px;\n  border: 1px solid gray;\n}\n.image[_ngcontent-%COMP%] {\n  width: 100px;\n  height: 100px;\n}\n/*# sourceMappingURL=order-details.page.css.map */"] });
var OrderDetailsPage = _OrderDetailsPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(OrderDetailsPage, { className: "OrderDetailsPage", filePath: "src/app/pages/order-details/order-details.page.ts", lineNumber: 23 });
})();
export {
  OrderDetailsPage
};
//# sourceMappingURL=order-details.page-N6R2LKKL.js.map
