import {
  PharmacyCartService
} from "./chunk-SFLHCKYK.js";
import {
  LocationService
} from "./chunk-4TQR4WSH.js";
import "./chunk-V444GY6B.js";
import "./chunk-QH3WR2OQ.js";
import {
  add,
  addIcons,
  arrowBack,
  bagHandleOutline,
  calendarOutline,
  cameraOutline,
  checkmarkCircle,
  checkmarkCircleOutline,
  chevronForward,
  closeOutline,
  cloudUploadOutline,
  documentTextOutline,
  flaskOutline,
  locationOutline,
  personOutline,
  pricetagOutline,
  receiptOutline,
  remove,
  shieldCheckmarkOutline,
  timeOutline,
  trashOutline
} from "./chunk-V2INQVNG.js";
import {
  AlertController,
  ToastController
} from "./chunk-OE5MTPUR.js";
import "./chunk-YJYUHAOC.js";
import "./chunk-XR3JUECC.js";
import {
  IonContent,
  IonHeader,
  IonIcon,
  IonModal,
  IonToolbar
} from "./chunk-CJE2NDTY.js";
import {
  ActivatedRoute,
  CommonModule,
  DefaultValueAccessor,
  FormsModule,
  NavController,
  NgControlStatus,
  NgModel,
  NumberValueAccessor,
  Router,
  Subscription,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIdentity,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-Z7XNNJSA.js";
import "./chunk-FH4NU4VH.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/pages/pharmacy-cart/pharmacy-cart.page.ts
var _c0 = () => [0, 0.68, 0.95];
var _forTrack0 = ($index, $item) => $item.item.id;
var _forTrack1 = ($index, $item) => $item.test.id;
function PharmacyCartPage_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 11);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r0.medSummary.itemCount);
  }
}
function PharmacyCartPage_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 13);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r0.labSummary.itemCount);
  }
}
function PharmacyCartPage_Conditional_39_Conditional_0_Conditional_0_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 62);
  }
}
function PharmacyCartPage_Conditional_39_Conditional_0_Conditional_0_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 63);
  }
}
function PharmacyCartPage_Conditional_39_Conditional_0_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "section", 59)(1, "div", 60)(2, "div", 61);
    \u0275\u0275template(3, PharmacyCartPage_Conditional_39_Conditional_0_Conditional_0_Conditional_3_Template, 1, 0, "ion-icon", 62)(4, PharmacyCartPage_Conditional_39_Conditional_0_Conditional_0_Conditional_4_Template, 1, 0, "ion-icon", 63);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 64)(6, "span", 65);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "p", 66);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(10, "button", 67);
    \u0275\u0275listener("click", function PharmacyCartPage_Conditional_39_Conditional_0_Conditional_0_Template_button_click_10_listener() {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.openPrescriptionSheet());
    });
    \u0275\u0275text(11);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275classProp("rx-attached", ctx_r0.latestPrescription);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx_r0.latestPrescription ? 3 : 4);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1(" ", ctx_r0.latestPrescription ? "Prescription Attached" : "Prescription Required", " ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" ", ctx_r0.latestPrescription ? ctx_r0.latestPrescription.fileName : "Some medicines in your cart need doctor verification.", " ");
    \u0275\u0275advance();
    \u0275\u0275classProp("btn-edit", ctx_r0.latestPrescription);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r0.latestPrescription ? "Change" : "Upload Rx", " ");
  }
}
function PharmacyCartPage_Conditional_39_Conditional_0_For_7_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 70);
    \u0275\u0275text(1, "Rx");
    \u0275\u0275elementEnd();
  }
}
function PharmacyCartPage_Conditional_39_Conditional_0_For_7_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 80);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ci_r4 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("\u20B9", ci_r4.item.mrp * ci_r4.quantity, "");
  }
}
function PharmacyCartPage_Conditional_39_Conditional_0_For_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 37)(1, "div", 68);
    \u0275\u0275element(2, "img", 69);
    \u0275\u0275template(3, PharmacyCartPage_Conditional_39_Conditional_0_For_7_Conditional_3_Template, 2, 0, "span", 70);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "div", 71)(5, "div", 72)(6, "h5", 73);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "button", 74);
    \u0275\u0275listener("click", function PharmacyCartPage_Conditional_39_Conditional_0_For_7_Template_button_click_8_listener() {
      const ci_r4 = \u0275\u0275restoreView(_r3).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.removeMedicine(ci_r4.item.id));
    });
    \u0275\u0275element(9, "ion-icon", 75);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(10, "span", 76);
    \u0275\u0275text(11);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "div", 77)(13, "div", 78)(14, "span", 79);
    \u0275\u0275text(15);
    \u0275\u0275elementEnd();
    \u0275\u0275template(16, PharmacyCartPage_Conditional_39_Conditional_0_For_7_Conditional_16_Template, 2, 1, "span", 80);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "div", 81)(18, "button", 82);
    \u0275\u0275listener("click", function PharmacyCartPage_Conditional_39_Conditional_0_For_7_Template_button_click_18_listener() {
      const ci_r4 = \u0275\u0275restoreView(_r3).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.updateMedQty(ci_r4.item.id, ci_r4.quantity - 1));
    });
    \u0275\u0275element(19, "ion-icon", 83);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "span", 84);
    \u0275\u0275text(21);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(22, "button", 82);
    \u0275\u0275listener("click", function PharmacyCartPage_Conditional_39_Conditional_0_For_7_Template_button_click_22_listener() {
      const ci_r4 = \u0275\u0275restoreView(_r3).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.updateMedQty(ci_r4.item.id, ci_r4.quantity + 1));
    });
    \u0275\u0275element(23, "ion-icon", 85);
    \u0275\u0275elementEnd()()()()();
  }
  if (rf & 2) {
    const ci_r4 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275property("src", ci_r4.item.image, \u0275\u0275sanitizeUrl)("alt", ci_r4.item.name);
    \u0275\u0275advance();
    \u0275\u0275conditional(ci_r4.item.prescriptionRequired ? 3 : -1);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ci_r4.item.name);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate2("", ci_r4.item.packSize, " \u2022 ", ci_r4.item.brand, "");
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("\u20B9", ci_r4.item.price * ci_r4.quantity, "");
    \u0275\u0275advance();
    \u0275\u0275conditional(ci_r4.item.mrp > ci_r4.item.price ? 16 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ci_r4.quantity);
  }
}
function PharmacyCartPage_Conditional_39_Conditional_0_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 42)(1, "div", 86)(2, "span", 87);
    \u0275\u0275text(3, "HEALTH15");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "span", 88);
    \u0275\u0275text(5, "Flat 15% discount on medicines order");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "button", 89);
    \u0275\u0275listener("click", function PharmacyCartPage_Conditional_39_Conditional_0_Conditional_13_Template_button_click_6_listener() {
      \u0275\u0275restoreView(_r5);
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.applyCouponCode("HEALTH15"));
    });
    \u0275\u0275text(7, " Apply ");
    \u0275\u0275elementEnd()();
  }
}
function PharmacyCartPage_Conditional_39_Conditional_0_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 43)(1, "div", 90);
    \u0275\u0275element(2, "ion-icon", 62);
    \u0275\u0275elementStart(3, "span");
    \u0275\u0275text(4, "Coupon ");
    \u0275\u0275elementStart(5, "strong");
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275text(7);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "button", 91);
    \u0275\u0275listener("click", function PharmacyCartPage_Conditional_39_Conditional_0_Conditional_14_Template_button_click_8_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.removeCoupon());
    });
    \u0275\u0275text(9, " Remove ");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1("'", ctx_r0.appliedCoupon, "'");
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" applied (Saved \u20B9", ctx_r0.couponDiscount, ")");
  }
}
function PharmacyCartPage_Conditional_39_Conditional_0_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 49)(1, "span", 47);
    \u0275\u0275text(2, "Product Discounts");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 48);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("-\u20B9", ctx_r0.medSummary.savings, "");
  }
}
function PharmacyCartPage_Conditional_39_Conditional_0_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 49)(1, "span", 47);
    \u0275\u0275text(2, "Coupon Discount (HEALTH15)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 48);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("-\u20B9", ctx_r0.couponDiscount, "");
  }
}
function PharmacyCartPage_Conditional_39_Conditional_0_Conditional_28_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 50);
    \u0275\u0275text(1, "FREE");
    \u0275\u0275elementEnd();
  }
}
function PharmacyCartPage_Conditional_39_Conditional_0_Conditional_29_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 48);
    \u0275\u0275text(1, "\u20B925");
    \u0275\u0275elementEnd();
  }
}
function PharmacyCartPage_Conditional_39_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275template(0, PharmacyCartPage_Conditional_39_Conditional_0_Conditional_0_Template, 12, 8, "section", 32);
    \u0275\u0275elementStart(1, "section", 33)(2, "div", 34)(3, "h4", 35);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "div", 36);
    \u0275\u0275repeaterCreate(6, PharmacyCartPage_Conditional_39_Conditional_0_For_7_Template, 24, 9, "div", 37, _forTrack0);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "section", 38)(9, "div", 39);
    \u0275\u0275element(10, "ion-icon", 40);
    \u0275\u0275elementStart(11, "span", 41);
    \u0275\u0275text(12, "Apply Coupons & Offers");
    \u0275\u0275elementEnd()();
    \u0275\u0275template(13, PharmacyCartPage_Conditional_39_Conditional_0_Conditional_13_Template, 8, 0, "div", 42)(14, PharmacyCartPage_Conditional_39_Conditional_0_Conditional_14_Template, 10, 2, "div", 43);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "section", 44)(16, "h4", 45);
    \u0275\u0275text(17, "Bill Summary");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "div", 46)(19, "span", 47);
    \u0275\u0275text(20, "Item Total (MRP)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(21, "span", 48);
    \u0275\u0275text(22);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(23, PharmacyCartPage_Conditional_39_Conditional_0_Conditional_23_Template, 5, 1, "div", 49)(24, PharmacyCartPage_Conditional_39_Conditional_0_Conditional_24_Template, 5, 1, "div", 49);
    \u0275\u0275elementStart(25, "div", 46)(26, "span", 47);
    \u0275\u0275text(27, "Delivery Fee");
    \u0275\u0275elementEnd();
    \u0275\u0275template(28, PharmacyCartPage_Conditional_39_Conditional_0_Conditional_28_Template, 2, 0, "span", 50)(29, PharmacyCartPage_Conditional_39_Conditional_0_Conditional_29_Template, 2, 0, "span", 48);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(30, "div", 46)(31, "span", 47);
    \u0275\u0275text(32, "Handling & Packaging");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(33, "span", 48);
    \u0275\u0275text(34, "\u20B95");
    \u0275\u0275elementEnd()();
    \u0275\u0275element(35, "div", 51);
    \u0275\u0275elementStart(36, "div", 52)(37, "div", 53)(38, "span", 54);
    \u0275\u0275text(39, "To Pay");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(40, "span", 55);
    \u0275\u0275text(41);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(42, "span", 56);
    \u0275\u0275text(43);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(44, "div", 57);
    \u0275\u0275element(45, "ion-icon", 58);
    \u0275\u0275elementStart(46, "p");
    \u0275\u0275text(47, "100% genuine medications sourced directly from licensed wholesale distributors.");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275conditional(ctx_r0.hasPrescriptionRequiredItems ? 0 : -1);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("Items in Cart (", ctx_r0.medSummary.itemCount, ")");
    \u0275\u0275advance(2);
    \u0275\u0275repeater(ctx_r0.medicineItems);
    \u0275\u0275advance(7);
    \u0275\u0275conditional(!ctx_r0.appliedCoupon ? 13 : 14);
    \u0275\u0275advance(9);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r0.medSummary.totalMrp, "");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.medSummary.savings > 0 ? 23 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.couponDiscount > 0 ? 24 : -1);
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx_r0.medSummary.subtotal >= 199 ? 28 : 29);
    \u0275\u0275advance(13);
    \u0275\u0275textInterpolate1("You are saving \u20B9", ctx_r0.medSummary.savings + ctx_r0.couponDiscount, " on this order");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r0.finalMedicineTotal, "");
  }
}
function PharmacyCartPage_Conditional_39_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "section", 31)(1, "div", 92);
    \u0275\u0275element(2, "ion-icon", 10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "h4");
    \u0275\u0275text(4, "Your Medicine Cart is Empty");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p");
    \u0275\u0275text(6, "Browse from our wide catalog of genuine medicines, daily healthcare essentials, and vitamins.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "button", 93);
    \u0275\u0275listener("click", function PharmacyCartPage_Conditional_39_Conditional_1_Template_button_click_7_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.browsePharmacy());
    });
    \u0275\u0275text(8, " Explore Medicines ");
    \u0275\u0275elementEnd()();
  }
}
function PharmacyCartPage_Conditional_39_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275template(0, PharmacyCartPage_Conditional_39_Conditional_0_Template, 48, 9)(1, PharmacyCartPage_Conditional_39_Conditional_1_Template, 9, 0, "section", 31);
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275conditional(ctx_r0.medicineItems.length > 0 ? 0 : 1);
  }
}
function PharmacyCartPage_Conditional_40_Conditional_0_For_42_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 113);
    \u0275\u0275listener("click", function PharmacyCartPage_Conditional_40_Conditional_0_For_42_Template_button_click_0_listener() {
      const slot_r10 = \u0275\u0275restoreView(_r9).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.selectTimeSlot(slot_r10));
    });
    \u0275\u0275element(1, "ion-icon", 114);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const slot_r10 = ctx.$implicit;
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275classProp("active", ctx_r0.selectedTimeSlot === slot_r10);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(slot_r10);
  }
}
function PharmacyCartPage_Conditional_40_Conditional_0_For_49_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 80);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "span", 125);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ci_r12 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("\u20B9", ci_r12.test.mrp, "");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("", ci_r12.test.discountPercent, "% OFF");
  }
}
function PharmacyCartPage_Conditional_40_Conditional_0_For_49_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 111)(1, "div", 115)(2, "div", 116)(3, "h5", 117);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "span", 118);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "button", 119);
    \u0275\u0275listener("click", function PharmacyCartPage_Conditional_40_Conditional_0_For_49_Template_button_click_7_listener() {
      const ci_r12 = \u0275\u0275restoreView(_r11).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.removeLabTest(ci_r12.test.id));
    });
    \u0275\u0275element(8, "ion-icon", 75);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "div", 120)(10, "span", 121);
    \u0275\u0275element(11, "ion-icon", 114);
    \u0275\u0275text(12);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "span", 121);
    \u0275\u0275element(14, "ion-icon", 122);
    \u0275\u0275text(15);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(16, "div", 123)(17, "div", 78)(18, "span", 79);
    \u0275\u0275text(19);
    \u0275\u0275elementEnd();
    \u0275\u0275template(20, PharmacyCartPage_Conditional_40_Conditional_0_For_49_Conditional_20_Template, 4, 2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(21, "span", 124);
    \u0275\u0275text(22, "Home Sample Pickup");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ci_r12 = ctx.$implicit;
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ci_r12.test.name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", ci_r12.test.testCount, " Tests Included \u2022 ", ci_r12.test.sampleType, "");
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1(" ", ci_r12.test.fastingRequirement, " ");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" Report in ", ci_r12.test.reportTimeHours, " hrs ");
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("\u20B9", ci_r12.test.price, "");
    \u0275\u0275advance();
    \u0275\u0275conditional(ci_r12.test.mrp > ci_r12.test.price ? 20 : -1);
  }
}
function PharmacyCartPage_Conditional_40_Conditional_0_Conditional_58_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 49)(1, "span", 47);
    \u0275\u0275text(2, "Package Savings");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 48);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1("-\u20B9", ctx_r0.labSummary.savings, "");
  }
}
function PharmacyCartPage_Conditional_40_Conditional_0_Conditional_62_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 50);
    \u0275\u0275text(1, "FREE");
    \u0275\u0275elementEnd();
  }
}
function PharmacyCartPage_Conditional_40_Conditional_0_Conditional_63_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 48);
    \u0275\u0275text(1, "\u20B950");
    \u0275\u0275elementEnd();
  }
}
function PharmacyCartPage_Conditional_40_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "section", 94)(1, "div", 34);
    \u0275\u0275element(2, "ion-icon", 95);
    \u0275\u0275elementStart(3, "h4", 35);
    \u0275\u0275text(4, "Patient Details");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "div", 96)(6, "div", 97)(7, "label", 98);
    \u0275\u0275text(8, "Patient Full Name *");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "input", 99);
    \u0275\u0275twoWayListener("ngModelChange", function PharmacyCartPage_Conditional_40_Conditional_0_Template_input_ngModelChange_9_listener($event) {
      \u0275\u0275restoreView(_r8);
      const ctx_r0 = \u0275\u0275nextContext(2);
      \u0275\u0275twoWayBindingSet(ctx_r0.patientName, $event) || (ctx_r0.patientName = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(10, "div", 100)(11, "div", 97)(12, "label", 101);
    \u0275\u0275text(13, "Age");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "input", 102);
    \u0275\u0275twoWayListener("ngModelChange", function PharmacyCartPage_Conditional_40_Conditional_0_Template_input_ngModelChange_14_listener($event) {
      \u0275\u0275restoreView(_r8);
      const ctx_r0 = \u0275\u0275nextContext(2);
      \u0275\u0275twoWayBindingSet(ctx_r0.patientAge, $event) || (ctx_r0.patientAge = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "div", 97)(16, "label");
    \u0275\u0275text(17, "Gender");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "div", 103)(19, "button", 104);
    \u0275\u0275listener("click", function PharmacyCartPage_Conditional_40_Conditional_0_Template_button_click_19_listener() {
      \u0275\u0275restoreView(_r8);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.patientGender = "Male");
    });
    \u0275\u0275text(20, " Male ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(21, "button", 104);
    \u0275\u0275listener("click", function PharmacyCartPage_Conditional_40_Conditional_0_Template_button_click_21_listener() {
      \u0275\u0275restoreView(_r8);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.patientGender = "Female");
    });
    \u0275\u0275text(22, " Female ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(23, "button", 104);
    \u0275\u0275listener("click", function PharmacyCartPage_Conditional_40_Conditional_0_Template_button_click_23_listener() {
      \u0275\u0275restoreView(_r8);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.patientGender = "Other");
    });
    \u0275\u0275text(24, " Other ");
    \u0275\u0275elementEnd()()()()()();
    \u0275\u0275elementStart(25, "section", 105)(26, "div", 34);
    \u0275\u0275element(27, "ion-icon", 106);
    \u0275\u0275elementStart(28, "h4", 35);
    \u0275\u0275text(29, "Select Home Pickup Slot");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(30, "div", 107)(31, "button", 108);
    \u0275\u0275listener("click", function PharmacyCartPage_Conditional_40_Conditional_0_Template_button_click_31_listener() {
      \u0275\u0275restoreView(_r8);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.selectDateOption("Today"));
    });
    \u0275\u0275elementStart(32, "span");
    \u0275\u0275text(33, "Today");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(34, "button", 108);
    \u0275\u0275listener("click", function PharmacyCartPage_Conditional_40_Conditional_0_Template_button_click_34_listener() {
      \u0275\u0275restoreView(_r8);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.selectDateOption("Tomorrow"));
    });
    \u0275\u0275elementStart(35, "span");
    \u0275\u0275text(36, "Tomorrow (Recommended)");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(37, "button", 108);
    \u0275\u0275listener("click", function PharmacyCartPage_Conditional_40_Conditional_0_Template_button_click_37_listener() {
      \u0275\u0275restoreView(_r8);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.selectDateOption("Day After"));
    });
    \u0275\u0275elementStart(38, "span");
    \u0275\u0275text(39, "Day After");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(40, "div", 109);
    \u0275\u0275repeaterCreate(41, PharmacyCartPage_Conditional_40_Conditional_0_For_42_Template, 4, 3, "button", 110, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(43, "section", 33)(44, "div", 34)(45, "h4", 35);
    \u0275\u0275text(46);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(47, "div", 36);
    \u0275\u0275repeaterCreate(48, PharmacyCartPage_Conditional_40_Conditional_0_For_49_Template, 23, 7, "div", 111, _forTrack1);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(50, "section", 44)(51, "h4", 45);
    \u0275\u0275text(52, "Lab Test Summary");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(53, "div", 46)(54, "span", 47);
    \u0275\u0275text(55, "Total Tests MRP");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(56, "span", 48);
    \u0275\u0275text(57);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(58, PharmacyCartPage_Conditional_40_Conditional_0_Conditional_58_Template, 5, 1, "div", 49);
    \u0275\u0275elementStart(59, "div", 46)(60, "span", 47);
    \u0275\u0275text(61, "Home Sample Collection");
    \u0275\u0275elementEnd();
    \u0275\u0275template(62, PharmacyCartPage_Conditional_40_Conditional_0_Conditional_62_Template, 2, 0, "span", 50)(63, PharmacyCartPage_Conditional_40_Conditional_0_Conditional_63_Template, 2, 0, "span", 48);
    \u0275\u0275elementEnd();
    \u0275\u0275element(64, "div", 51);
    \u0275\u0275elementStart(65, "div", 52)(66, "div", 53)(67, "span", 54);
    \u0275\u0275text(68, "Total Payable");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(69, "span", 55);
    \u0275\u0275text(70);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(71, "span", 56);
    \u0275\u0275text(72);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(73, "div", 112);
    \u0275\u0275element(74, "ion-icon", 58);
    \u0275\u0275elementStart(75, "p");
    \u0275\u0275text(76, "NABL & ICMR accredited partner laboratories with certified phlebotomists.");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(9);
    \u0275\u0275twoWayProperty("ngModel", ctx_r0.patientName);
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx_r0.patientAge);
    \u0275\u0275advance(5);
    \u0275\u0275classProp("active", ctx_r0.patientGender === "Male");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r0.patientGender === "Female");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r0.patientGender === "Other");
    \u0275\u0275advance(8);
    \u0275\u0275classProp("active", ctx_r0.selectedDateOption === "Today");
    \u0275\u0275advance(3);
    \u0275\u0275classProp("active", ctx_r0.selectedDateOption === "Tomorrow");
    \u0275\u0275advance(3);
    \u0275\u0275classProp("active", ctx_r0.selectedDateOption === "Day After");
    \u0275\u0275advance(4);
    \u0275\u0275repeater(ctx_r0.availableTimeSlots);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate1("Selected Tests & Packages (", ctx_r0.labSummary.itemCount, ")");
    \u0275\u0275advance(2);
    \u0275\u0275repeater(ctx_r0.labItems);
    \u0275\u0275advance(9);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r0.labSummary.totalMrp, "");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.labSummary.savings > 0 ? 58 : -1);
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx_r0.labSummary.subtotal >= 499 ? 62 : 63);
    \u0275\u0275advance(8);
    \u0275\u0275textInterpolate1("You are saving \u20B9", ctx_r0.labSummary.savings, " with Pintu Health");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r0.labSummary.grandTotal, "");
  }
}
function PharmacyCartPage_Conditional_40_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "section", 31)(1, "div", 126);
    \u0275\u0275element(2, "ion-icon", 12);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "h4");
    \u0275\u0275text(4, "No Lab Tests Booked");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p");
    \u0275\u0275text(6, "Book comprehensive health checkups, blood tests, or specialized profiles with free home sample collection.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "button", 127);
    \u0275\u0275listener("click", function PharmacyCartPage_Conditional_40_Conditional_1_Template_button_click_7_listener() {
      \u0275\u0275restoreView(_r13);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.browsePharmacy());
    });
    \u0275\u0275text(8, " Browse Health Packages ");
    \u0275\u0275elementEnd()();
  }
}
function PharmacyCartPage_Conditional_40_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275template(0, PharmacyCartPage_Conditional_40_Conditional_0_Template, 77, 20)(1, PharmacyCartPage_Conditional_40_Conditional_1_Template, 9, 0, "section", 31);
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275conditional(ctx_r0.labItems.length > 0 ? 0 : 1);
  }
}
function PharmacyCartPage_Conditional_42_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1, "Placing Order...");
    \u0275\u0275elementEnd();
  }
}
function PharmacyCartPage_Conditional_42_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1, "Place Medicine Order");
    \u0275\u0275elementEnd();
    \u0275\u0275element(2, "ion-icon", 26);
  }
}
function PharmacyCartPage_Conditional_42_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "footer", 28)(1, "div", 128)(2, "div", 129)(3, "span", 130);
    \u0275\u0275text(4, "Total to Pay");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "span", 131);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "button", 132);
    \u0275\u0275listener("click", function PharmacyCartPage_Conditional_42_Template_button_click_7_listener() {
      \u0275\u0275restoreView(_r14);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.placeMedicineOrder());
    });
    \u0275\u0275template(8, PharmacyCartPage_Conditional_42_Conditional_8_Template, 2, 0, "span")(9, PharmacyCartPage_Conditional_42_Conditional_9_Template, 3, 0);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r0.finalMedicineTotal, "");
    \u0275\u0275advance();
    \u0275\u0275property("disabled", ctx_r0.isProcessingCheckout);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.isProcessingCheckout ? 8 : 9);
  }
}
function PharmacyCartPage_Conditional_43_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1, "Scheduling Pickup...");
    \u0275\u0275elementEnd();
  }
}
function PharmacyCartPage_Conditional_43_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1, "Confirm Lab Booking");
    \u0275\u0275elementEnd();
    \u0275\u0275element(2, "ion-icon", 26);
  }
}
function PharmacyCartPage_Conditional_43_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "footer", 29)(1, "div", 128)(2, "div", 129)(3, "span", 130);
    \u0275\u0275text(4, "Total to Pay");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "span", 133);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "button", 134);
    \u0275\u0275listener("click", function PharmacyCartPage_Conditional_43_Template_button_click_7_listener() {
      \u0275\u0275restoreView(_r15);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.bookLabTests());
    });
    \u0275\u0275template(8, PharmacyCartPage_Conditional_43_Conditional_8_Template, 2, 0, "span")(9, PharmacyCartPage_Conditional_43_Conditional_9_Template, 3, 0);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r0.labSummary.grandTotal, "");
    \u0275\u0275advance();
    \u0275\u0275property("disabled", ctx_r0.isProcessingCheckout);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.isProcessingCheckout ? 8 : 9);
  }
}
function PharmacyCartPage_ng_template_45_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 145);
    \u0275\u0275element(1, "ion-icon", 62);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx_r0.prescriptionFileName);
  }
}
function PharmacyCartPage_ng_template_45_Template(rf, ctx) {
  if (rf & 1) {
    const _r16 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 135);
    \u0275\u0275element(1, "div", 136);
    \u0275\u0275elementStart(2, "div", 137)(3, "div")(4, "h4");
    \u0275\u0275text(5, "Upload Doctor's Prescription");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "p");
    \u0275\u0275text(7, "Required for verifying prescription-controlled medications");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "button", 138);
    \u0275\u0275listener("click", function PharmacyCartPage_ng_template_45_Template_button_click_8_listener() {
      \u0275\u0275restoreView(_r16);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.closePrescriptionSheet());
    });
    \u0275\u0275element(9, "ion-icon", 139);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(10, "div", 140)(11, "div", 141)(12, "div", 142);
    \u0275\u0275listener("click", function PharmacyCartPage_ng_template_45_Template_div_click_12_listener() {
      \u0275\u0275restoreView(_r16);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.simulateFilePick("camera"));
    });
    \u0275\u0275element(13, "ion-icon", 143);
    \u0275\u0275elementStart(14, "span");
    \u0275\u0275text(15, "Camera");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(16, "div", 142);
    \u0275\u0275listener("click", function PharmacyCartPage_ng_template_45_Template_div_click_16_listener() {
      \u0275\u0275restoreView(_r16);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.simulateFilePick("gallery"));
    });
    \u0275\u0275element(17, "ion-icon", 144);
    \u0275\u0275elementStart(18, "span");
    \u0275\u0275text(19, "Gallery");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(20, "div", 142);
    \u0275\u0275listener("click", function PharmacyCartPage_ng_template_45_Template_div_click_20_listener() {
      \u0275\u0275restoreView(_r16);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.simulateFilePick("doc"));
    });
    \u0275\u0275element(21, "ion-icon", 63);
    \u0275\u0275elementStart(22, "span");
    \u0275\u0275text(23, "PDF Doc");
    \u0275\u0275elementEnd()()();
    \u0275\u0275template(24, PharmacyCartPage_ng_template_45_Conditional_24_Template, 4, 1, "div", 145);
    \u0275\u0275elementStart(25, "div", 146)(26, "label", 147);
    \u0275\u0275text(27, "Instructions for Pharmacist (Optional):");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(28, "input", 148);
    \u0275\u0275twoWayListener("ngModelChange", function PharmacyCartPage_ng_template_45_Template_input_ngModelChange_28_listener($event) {
      \u0275\u0275restoreView(_r16);
      const ctx_r0 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r0.prescriptionNotes, $event) || (ctx_r0.prescriptionNotes = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(29, "button", 149);
    \u0275\u0275listener("click", function PharmacyCartPage_ng_template_45_Template_button_click_29_listener() {
      \u0275\u0275restoreView(_r16);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.submitPrescription());
    });
    \u0275\u0275text(30);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(24);
    \u0275\u0275conditional(ctx_r0.prescriptionFileName ? 24 : -1);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r0.prescriptionNotes);
    \u0275\u0275advance();
    \u0275\u0275property("disabled", ctx_r0.isUploadingPrescription);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r0.isUploadingPrescription ? "Attaching Prescription..." : "Attach Prescription", " ");
  }
}
var _PharmacyCartPage = class _PharmacyCartPage {
  constructor(route, router, navCtrl, locationService, cartService, toastCtrl, alertCtrl) {
    this.route = route;
    this.router = router;
    this.navCtrl = navCtrl;
    this.locationService = locationService;
    this.cartService = cartService;
    this.toastCtrl = toastCtrl;
    this.alertCtrl = alertCtrl;
    this.activeCartType = "medicine";
    this.displayLocationName = "Home";
    this.displayFullAddress = "";
    this.medicineItems = [];
    this.medSummary = { itemCount: 0, subtotal: 0, totalMrp: 0, savings: 0, fee: 0, grandTotal: 0 };
    this.hasPrescriptionRequiredItems = false;
    this.latestPrescription = null;
    this.appliedCoupon = "";
    this.couponDiscount = 0;
    this.labItems = [];
    this.labSummary = { itemCount: 0, subtotal: 0, totalMrp: 0, savings: 0, fee: 0, grandTotal: 0 };
    this.patientName = "";
    this.patientAge = "";
    this.patientGender = "Male";
    this.selectedDateOption = "Tomorrow";
    this.selectedTimeSlot = "06:30 AM - 08:30 AM (Fasting)";
    this.availableTimeSlots = [
      "06:30 AM - 08:30 AM (Fasting)",
      "08:30 AM - 10:30 AM",
      "10:30 AM - 12:30 PM",
      "04:30 PM - 06:30 PM"
    ];
    this.isPrescriptionModalOpen = false;
    this.prescriptionFileName = "";
    this.prescriptionNotes = "";
    this.isUploadingPrescription = false;
    this.isProcessingCheckout = false;
    this.subs = new Subscription();
    addIcons({
      arrowBack,
      bagHandleOutline,
      flaskOutline,
      trashOutline,
      add,
      remove,
      locationOutline,
      chevronForward,
      documentTextOutline,
      cloudUploadOutline,
      shieldCheckmarkOutline,
      timeOutline,
      receiptOutline,
      checkmarkCircle,
      checkmarkCircleOutline,
      pricetagOutline,
      closeOutline,
      cameraOutline,
      personOutline,
      calendarOutline
    });
  }
  ngOnInit() {
    this.subs.add(this.route.queryParams.subscribe((params) => {
      if (params["type"] === "lab" || params["type"] === "lab_tests") {
        this.activeCartType = "lab";
      } else {
        this.activeCartType = "medicine";
      }
    }));
    const savedLoc = localStorage.getItem("location");
    if (savedLoc) {
      try {
        const parsed = JSON.parse(savedLoc);
        this.applyLocation(parsed);
      } catch (e) {
      }
    }
    this.subs.add(this.locationService.location$.subscribe((loc) => {
      if (loc)
        this.applyLocation(loc);
    }));
    this.subs.add(this.locationService.address$.subscribe((addr) => {
      if (addr && addr.trim()) {
        this.displayFullAddress = addr.trim();
      }
    }));
    this.subs.add(this.cartService.medicineCart$.subscribe((items) => {
      this.medicineItems = items;
      this.hasPrescriptionRequiredItems = items.some((i) => i.item.prescriptionRequired);
    }));
    this.subs.add(this.cartService.medicineSummary$.subscribe((sum) => {
      this.medSummary = sum;
    }));
    this.subs.add(this.cartService.labCart$.subscribe((items) => {
      this.labItems = items;
    }));
    this.subs.add(this.cartService.labSummary$.subscribe((sum) => {
      this.labSummary = sum;
    }));
    this.subs.add(this.cartService.prescriptions$.subscribe((rxList) => {
      if (rxList && rxList.length > 0) {
        this.latestPrescription = rxList[0];
      } else {
        this.latestPrescription = null;
      }
    }));
  }
  ngOnDestroy() {
    this.subs.unsubscribe();
  }
  applyLocation(loc) {
    if (!loc)
      return;
    this.displayLocationName = loc.area || loc.name || loc.city || "Home";
    this.displayFullAddress = loc.formatted_address || loc.fullAddress || loc.address || "";
  }
  goBack() {
    this.navCtrl.navigateBack("/layout/pharmacy");
  }
  switchCartType(type) {
    this.activeCartType = type;
  }
  openLocation() {
    this.router.navigate(["/layout/address-list"], {
      state: { data: "pharmacy" }
    });
  }
  // ─── MEDICINE CART ACTIONS ────────────────────────────────────────────────
  updateMedQty(itemId, newQty) {
    this.cartService.updateMedicineQuantity(itemId, newQty);
  }
  removeMedicine(itemId) {
    this.cartService.removeMedicine(itemId);
  }
  applyCouponCode(code) {
    if (code === "HEALTH15") {
      this.appliedCoupon = "HEALTH15";
      this.couponDiscount = Math.round(this.medSummary.subtotal * 0.15);
      this.showToast("Coupon HEALTH15 applied! 15% extra discount.", "success");
    }
  }
  removeCoupon() {
    this.appliedCoupon = "";
    this.couponDiscount = 0;
  }
  get finalMedicineTotal() {
    return Math.max(0, this.medSummary.grandTotal - this.couponDiscount);
  }
  // ─── LAB CART ACTIONS ─────────────────────────────────────────────────────
  removeLabTest(testId) {
    this.cartService.removeLabTest(testId);
  }
  selectDateOption(date) {
    this.selectedDateOption = date;
  }
  selectTimeSlot(slot) {
    this.selectedTimeSlot = slot;
  }
  // ─── PRESCRIPTION MODAL ───────────────────────────────────────────────────
  openPrescriptionSheet() {
    this.prescriptionFileName = "";
    this.prescriptionNotes = "";
    this.isPrescriptionModalOpen = true;
  }
  closePrescriptionSheet() {
    this.isPrescriptionModalOpen = false;
  }
  simulateFilePick(source) {
    const timestamp = (/* @__PURE__ */ new Date()).getTime().toString().slice(-4);
    if (source === "camera") {
      this.prescriptionFileName = `Rx_Photo_${timestamp}.jpg`;
    } else if (source === "gallery") {
      this.prescriptionFileName = `Prescription_${timestamp}.png`;
    } else {
      this.prescriptionFileName = `Doctor_Prescription_${timestamp}.pdf`;
    }
  }
  submitPrescription() {
    if (!this.prescriptionFileName) {
      this.prescriptionFileName = `Prescription_${Date.now().toString().slice(-4)}.jpg`;
    }
    this.isUploadingPrescription = true;
    setTimeout(() => {
      this.latestPrescription = this.cartService.uploadPrescription({
        fileName: this.prescriptionFileName,
        notes: this.prescriptionNotes,
        type: "medicine"
      });
      this.isUploadingPrescription = false;
      this.isPrescriptionModalOpen = false;
      this.showToast("Prescription attached to your order!", "success");
    }, 800);
  }
  // ─── CHECKOUT / ORDER PLACEMENT ───────────────────────────────────────────
  placeMedicineOrder() {
    return __async(this, null, function* () {
      if (this.medicineItems.length === 0)
        return;
      if (this.hasPrescriptionRequiredItems && !this.latestPrescription) {
        const alert = yield this.alertCtrl.create({
          header: "Prescription Required",
          message: "One or more medicines in your cart require a valid doctor prescription. Please attach your prescription before proceeding.",
          buttons: [
            { text: "Cancel", role: "cancel" },
            {
              text: "Upload Now",
              handler: () => {
                this.openPrescriptionSheet();
              }
            }
          ]
        });
        yield alert.present();
        return;
      }
      this.isProcessingCheckout = true;
      setTimeout(() => __async(this, null, function* () {
        this.isProcessingCheckout = false;
        const orderId = `MED-${Math.floor(1e5 + Math.random() * 9e5)}`;
        this.cartService.clearMedicineCart();
        this.removeCoupon();
        const alert = yield this.alertCtrl.create({
          header: "Order Placed Successfully! \u{1F389}",
          subHeader: `Order ID: #${orderId}`,
          message: `Your medicines order of \u20B9${this.finalMedicineTotal} is confirmed and scheduled for delivery to ${this.displayLocationName}.`,
          backdropDismiss: false,
          buttons: [
            {
              text: "Back to Pharmacy",
              handler: () => {
                this.router.navigate(["/layout/pharmacy"]);
              }
            }
          ]
        });
        yield alert.present();
      }), 1200);
    });
  }
  bookLabTests() {
    return __async(this, null, function* () {
      if (this.labItems.length === 0)
        return;
      if (!this.patientName.trim()) {
        this.showToast("Please enter the patient name for lab sample collection.", "warning");
        return;
      }
      this.isProcessingCheckout = true;
      setTimeout(() => __async(this, null, function* () {
        this.isProcessingCheckout = false;
        const bookingId = `LAB-${Math.floor(1e5 + Math.random() * 9e5)}`;
        this.cartService.clearLabCart();
        const alert = yield this.alertCtrl.create({
          header: "Lab Test Booked! \u{1F9EA}",
          subHeader: `Booking Ref: #${bookingId}`,
          message: `Home sample pickup scheduled for ${this.patientName} on ${this.selectedDateOption}, ${this.selectedTimeSlot}. Certified phlebotomist will visit ${this.displayLocationName}.`,
          backdropDismiss: false,
          buttons: [
            {
              text: "Done",
              handler: () => {
                this.router.navigate(["/layout/pharmacy"]);
              }
            }
          ]
        });
        yield alert.present();
      }), 1200);
    });
  }
  browsePharmacy() {
    this.router.navigate(["/layout/pharmacy"]);
  }
  showToast(message, color = "success") {
    return __async(this, null, function* () {
      const toast = yield this.toastCtrl.create({
        message,
        duration: 3e3,
        color,
        position: "top"
      });
      yield toast.present();
    });
  }
};
_PharmacyCartPage.\u0275fac = function PharmacyCartPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _PharmacyCartPage)(\u0275\u0275directiveInject(ActivatedRoute), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(LocationService), \u0275\u0275directiveInject(PharmacyCartService), \u0275\u0275directiveInject(ToastController), \u0275\u0275directiveInject(AlertController));
};
_PharmacyCartPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _PharmacyCartPage, selectors: [["app-pharmacy-cart"]], decls: 46, vars: 17, consts: [[1, "cart-header", "ion-no-border"], [1, "cart-toolbar"], [1, "cart-top-row"], ["type", "button", "aria-label", "Go Back", 1, "btn-back", 3, "click"], ["name", "arrow-back"], [1, "header-title-col"], [1, "page-title"], [1, "page-sub"], [1, "cart-switcher-bar"], ["type", "button", 1, "switch-btn", 3, "click"], ["name", "bag-handle-outline"], [1, "cart-count-chip"], ["name", "flask-outline"], [1, "cart-count-chip", "lab"], [1, "cart-content"], [1, "cart-container"], ["role", "button", "tabindex", "0", 1, "delivery-address-card", 3, "click"], [1, "address-left"], [1, "address-icon-box"], ["name", "location-outline"], [1, "address-text-col"], [1, "address-tag-row"], [1, "tag-title"], [1, "location-name"], [1, "address-line", "text-truncate-2"], ["type", "button", "aria-label", "Change Address", 1, "btn-change-address"], ["name", "chevron-forward"], [1, "bottom-spacer"], ["slot", "fixed", 1, "cart-sticky-footer", "medicine", "animate__animated", "animate__fadeInUp"], ["slot", "fixed", 1, "cart-sticky-footer", "lab", "animate__animated", "animate__fadeInUp"], [1, "prescription-cart-modal", 3, "didDismiss", "isOpen", "initialBreakpoint", "breakpoints"], [1, "empty-cart-view", "animate__animated", "animate__fadeIn"], [1, "rx-status-banner", "animate__animated", "animate__fadeIn", 3, "rx-attached"], [1, "cart-items-card"], [1, "card-header-row"], [1, "card-header-title"], [1, "items-list"], [1, "cart-item-row"], [1, "coupon-section-card"], [1, "coupon-header"], ["name", "pricetag-outline"], [1, "coupon-title"], [1, "coupon-offer-box"], [1, "applied-coupon-row", "animate__animated", "animate__fadeIn"], [1, "bill-summary-card"], [1, "bill-title"], [1, "bill-row"], [1, "bill-label"], [1, "bill-val"], [1, "bill-row", "green"], [1, "bill-val", "free"], [1, "bill-divider"], [1, "bill-total-row"], [1, "total-label-col"], [1, "total-title"], [1, "savings-note"], [1, "final-total"], [1, "trust-notice-card"], ["name", "shield-checkmark-outline"], [1, "rx-status-banner", "animate__animated", "animate__fadeIn"], [1, "rx-banner-left"], [1, "rx-icon-box"], ["name", "checkmark-circle"], ["name", "document-text-outline"], [1, "rx-text-col"], [1, "rx-banner-title"], [1, "rx-banner-desc"], ["type", "button", 1, "btn-rx-action", 3, "click"], [1, "item-img-wrap"], ["loading", "lazy", 3, "src", "alt"], [1, "rx-tag"], [1, "item-info-col"], [1, "item-title-row"], [1, "item-name"], ["type", "button", "title", "Remove item", 1, "btn-delete", 3, "click"], ["name", "trash-outline"], [1, "item-pack"], [1, "item-pricing-stepper-row"], [1, "price-stack"], [1, "unit-price"], [1, "strike-mrp"], [1, "stepper-box"], ["type", "button", 1, "btn-step", 3, "click"], ["name", "remove"], [1, "qty-num"], ["name", "add"], [1, "offer-left"], [1, "offer-code"], [1, "offer-desc"], ["type", "button", 1, "btn-apply-coupon", 3, "click"], [1, "applied-left"], ["type", "button", 1, "btn-remove-coupon", 3, "click"], [1, "empty-icon-circle"], ["type", "button", 1, "btn-browse-action", 3, "click"], [1, "patient-details-card", "animate__animated", "animate__fadeIn"], ["name", "person-outline"], [1, "form-grid"], [1, "input-group"], ["for", "ptName"], ["id", "ptName", "type", "text", "placeholder", "e.g. Ramesh Kumar", 1, "cart-input", 3, "ngModelChange", "ngModel"], [1, "input-row-half"], ["for", "ptAge"], ["id", "ptAge", "type", "number", "placeholder", "e.g. 32", 1, "cart-input", 3, "ngModelChange", "ngModel"], [1, "gender-pill-row"], ["type", "button", 1, "btn-gender", 3, "click"], [1, "slot-picker-card"], ["name", "calendar-outline"], [1, "date-chips-row"], ["type", "button", 1, "date-chip", 3, "click"], [1, "time-slots-grid"], ["type", "button", 1, "time-slot-btn", 3, "active"], [1, "lab-cart-item-row"], [1, "trust-notice-card", "lab"], ["type", "button", 1, "time-slot-btn", 3, "click"], ["name", "time-outline"], [1, "lab-item-header"], [1, "lab-item-title-col"], [1, "lab-item-name"], [1, "lab-item-meta"], ["type", "button", "title", "Remove test", 1, "btn-delete", 3, "click"], [1, "lab-item-specs"], [1, "spec-pill"], ["name", "receipt-outline"], [1, "lab-item-pricing-row"], [1, "collection-tag"], [1, "discount-pill"], [1, "empty-icon-circle", "lab"], ["type", "button", 1, "btn-browse-action", "lab", 3, "click"], [1, "footer-inner"], [1, "footer-total-col"], [1, "to-pay-label"], [1, "to-pay-amount"], ["type", "button", 1, "btn-checkout", "medicine", 3, "click", "disabled"], [1, "to-pay-amount", "lab"], ["type", "button", 1, "btn-checkout", "lab", 3, "click", "disabled"], [1, "rx-sheet-content"], [1, "sheet-handle-bar"], [1, "sheet-header"], ["type", "button", 1, "btn-sheet-close", 3, "click"], ["name", "close-outline"], [1, "sheet-body"], [1, "upload-options-grid"], ["role", "button", "tabindex", "0", 1, "opt-box", 3, "click"], ["name", "camera-outline"], ["name", "cloud-upload-outline"], [1, "selected-rx-preview"], [1, "rx-note-wrap"], ["for", "cartRxNotes"], ["id", "cartRxNotes", "type", "text", "placeholder", "e.g. Dispense generic equivalents if available", 1, "cart-input", 3, "ngModelChange", "ngModel"], ["type", "button", 1, "btn-confirm-rx", 3, "click", "disabled"]], template: function PharmacyCartPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar", 1)(2, "div", 2)(3, "button", 3);
    \u0275\u0275listener("click", function PharmacyCartPage_Template_button_click_3_listener() {
      return ctx.goBack();
    });
    \u0275\u0275element(4, "ion-icon", 4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 5)(6, "h3", 6);
    \u0275\u0275text(7, "My Health Cart");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "span", 7);
    \u0275\u0275text(9, "Independent carts for Meds & Tests");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(10, "div", 8)(11, "button", 9);
    \u0275\u0275listener("click", function PharmacyCartPage_Template_button_click_11_listener() {
      return ctx.switchCartType("medicine");
    });
    \u0275\u0275element(12, "ion-icon", 10);
    \u0275\u0275elementStart(13, "span");
    \u0275\u0275text(14, "Medicines Cart");
    \u0275\u0275elementEnd();
    \u0275\u0275template(15, PharmacyCartPage_Conditional_15_Template, 2, 1, "span", 11);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "button", 9);
    \u0275\u0275listener("click", function PharmacyCartPage_Template_button_click_16_listener() {
      return ctx.switchCartType("lab");
    });
    \u0275\u0275element(17, "ion-icon", 12);
    \u0275\u0275elementStart(18, "span");
    \u0275\u0275text(19, "Lab Tests Cart");
    \u0275\u0275elementEnd();
    \u0275\u0275template(20, PharmacyCartPage_Conditional_20_Template, 2, 1, "span", 13);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(21, "ion-content", 14)(22, "main", 15)(23, "section", 16);
    \u0275\u0275listener("click", function PharmacyCartPage_Template_section_click_23_listener() {
      return ctx.openLocation();
    });
    \u0275\u0275elementStart(24, "div", 17)(25, "div", 18);
    \u0275\u0275element(26, "ion-icon", 19);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(27, "div", 20)(28, "div", 21)(29, "span", 22);
    \u0275\u0275text(30);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(31, "span", 23);
    \u0275\u0275text(32);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(33, "p", 24);
    \u0275\u0275text(34);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(35, "button", 25)(36, "span");
    \u0275\u0275text(37, "Change");
    \u0275\u0275elementEnd();
    \u0275\u0275element(38, "ion-icon", 26);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(39, PharmacyCartPage_Conditional_39_Template, 2, 1)(40, PharmacyCartPage_Conditional_40_Template, 2, 1);
    \u0275\u0275element(41, "div", 27);
    \u0275\u0275elementEnd();
    \u0275\u0275template(42, PharmacyCartPage_Conditional_42_Template, 10, 3, "footer", 28)(43, PharmacyCartPage_Conditional_43_Template, 10, 3, "footer", 29);
    \u0275\u0275elementStart(44, "ion-modal", 30);
    \u0275\u0275listener("didDismiss", function PharmacyCartPage_Template_ion_modal_didDismiss_44_listener() {
      return ctx.closePrescriptionSheet();
    });
    \u0275\u0275template(45, PharmacyCartPage_ng_template_45_Template, 31, 4, "ng-template");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(11);
    \u0275\u0275classProp("active", ctx.activeCartType === "medicine");
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx.medSummary.itemCount > 0 ? 15 : -1);
    \u0275\u0275advance();
    \u0275\u0275classProp("active", ctx.activeCartType === "lab");
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx.labSummary.itemCount > 0 ? 20 : -1);
    \u0275\u0275advance(10);
    \u0275\u0275textInterpolate(ctx.activeCartType === "medicine" ? "Delivering to:" : "Sample Collection at:");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx.displayLocationName);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" ", ctx.displayFullAddress || "Select delivery address to proceed", " ");
    \u0275\u0275advance(5);
    \u0275\u0275conditional(ctx.activeCartType === "medicine" ? 39 : ctx.activeCartType === "lab" ? 40 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275classProp("has-cart", ctx.activeCartType === "medicine" && ctx.medicineItems.length > 0 || ctx.activeCartType === "lab" && ctx.labItems.length > 0);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.activeCartType === "medicine" && ctx.medicineItems.length > 0 ? 42 : ctx.activeCartType === "lab" && ctx.labItems.length > 0 ? 43 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275property("isOpen", ctx.isPrescriptionModalOpen)("initialBreakpoint", 0.68)("breakpoints", \u0275\u0275pureFunction0(16, _c0));
  }
}, dependencies: [
  CommonModule,
  FormsModule,
  DefaultValueAccessor,
  NumberValueAccessor,
  NgControlStatus,
  NgModel,
  IonContent,
  IonHeader,
  IonToolbar,
  IonIcon,
  IonModal
], styles: ['@charset "UTF-8";\n\n\n\n[_nghost-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  width: 100%;\n  height: 100%;\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  overflow: hidden;\n  --theme-med: #059669;\n  --theme-med-light: #ecfdf5;\n  --theme-lab: #0284c7;\n  --theme-lab-light: #f0f9ff;\n  --border-color: #e2e8f0;\n  --bg-color: #f8fafc;\n}\n.cart-content[_ngcontent-%COMP%] {\n  flex: 1;\n  width: 100%;\n  height: 100%;\n  position: relative;\n}\n.cart-header[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-bottom: 1px solid var(--border-color);\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);\n  padding: 0 !important;\n  margin: 0 !important;\n  --ion-safe-area-top: 0px;\n  flex-shrink: 0;\n}\n.cart-toolbar[_ngcontent-%COMP%] {\n  --background: #ffffff;\n  --padding-top: env(safe-area-inset-top, 0px);\n  --padding-bottom: 8px;\n  --padding-start: 14px;\n  --padding-end: 14px;\n}\n.cart-top-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  margin-bottom: 12px;\n}\n.btn-back[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 38px;\n  border-radius: 10px;\n  background: #f1f5f9;\n  border: 1px solid #e2e8f0;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  color: #1e293b;\n  font-size: 20px;\n  cursor: pointer;\n  flex-shrink: 0;\n}\n.btn-back[_ngcontent-%COMP%]:active {\n  transform: scale(0.95);\n}\n.header-title-col[_ngcontent-%COMP%]   .page-title[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 17px;\n  font-weight: 800;\n  color: #0f172a;\n  letter-spacing: -0.3px;\n}\n.header-title-col[_ngcontent-%COMP%]   .page-sub[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #64748b;\n  font-weight: 500;\n}\n.cart-switcher-bar[_ngcontent-%COMP%] {\n  display: flex;\n  background: #f1f5f9;\n  border-radius: 12px;\n  padding: 3px;\n  gap: 4px;\n}\n.switch-btn[_ngcontent-%COMP%] {\n  flex: 1;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 6px;\n  padding: 8px 10px;\n  border-radius: 9px;\n  border: none;\n  background: transparent;\n  font-size: 13px;\n  font-weight: 700;\n  color: #64748b;\n  cursor: pointer;\n  transition: all 0.2s ease;\n}\n.switch-btn[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 16px;\n}\n.switch-btn.active[_ngcontent-%COMP%] {\n  background: #ffffff;\n  color: #059669;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);\n}\n.switch-btn.active[_ngcontent-%COMP%]:last-child {\n  color: #0284c7;\n}\n.switch-btn[_ngcontent-%COMP%]   .cart-count-chip[_ngcontent-%COMP%] {\n  background: #059669;\n  color: #ffffff;\n  font-size: 10px;\n  font-weight: 800;\n  padding: 1px 6px;\n  border-radius: 10px;\n}\n.switch-btn[_ngcontent-%COMP%]   .cart-count-chip.lab[_ngcontent-%COMP%] {\n  background: #0284c7;\n}\n.cart-content[_ngcontent-%COMP%] {\n  --background: #f8fafc;\n}\n.cart-container[_ngcontent-%COMP%] {\n  padding: 14px;\n  display: flex;\n  flex-direction: column;\n  gap: 14px;\n}\n.delivery-address-card[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  background: #ffffff;\n  border-radius: 14px;\n  padding: 12px 14px;\n  border: 1px solid #e2e8f0;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.02);\n  cursor: pointer;\n}\n.delivery-address-card[_ngcontent-%COMP%]   .address-left[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  flex: 1;\n  min-width: 0;\n}\n.delivery-address-card[_ngcontent-%COMP%]   .address-icon-box[_ngcontent-%COMP%] {\n  width: 36px;\n  height: 36px;\n  border-radius: 10px;\n  background: #ecfdf5;\n  color: #059669;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 18px;\n  flex-shrink: 0;\n}\n.delivery-address-card[_ngcontent-%COMP%]   .address-text-col[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 0;\n}\n.delivery-address-card[_ngcontent-%COMP%]   .address-tag-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: baseline;\n  gap: 6px;\n  margin-bottom: 2px;\n}\n.delivery-address-card[_ngcontent-%COMP%]   .address-tag-row[_ngcontent-%COMP%]   .tag-title[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #64748b;\n  font-weight: 500;\n}\n.delivery-address-card[_ngcontent-%COMP%]   .address-tag-row[_ngcontent-%COMP%]   .location-name[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-weight: 700;\n  color: #0f172a;\n}\n.delivery-address-card[_ngcontent-%COMP%]   .address-line[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 11px;\n  color: #64748b;\n  line-height: 1.3;\n}\n.delivery-address-card[_ngcontent-%COMP%]   .btn-change-address[_ngcontent-%COMP%] {\n  background: transparent;\n  border: none;\n  color: #059669;\n  font-size: 12px;\n  font-weight: 700;\n  display: flex;\n  align-items: center;\n  gap: 2px;\n  padding: 6px 4px;\n  cursor: pointer;\n  flex-shrink: 0;\n}\n.rx-status-banner[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  background: #fef2f2;\n  border: 1.5px dashed #fca5a5;\n  border-radius: 14px;\n  padding: 12px;\n  gap: 10px;\n}\n.rx-status-banner.rx-attached[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  border-color: #6ee7b7;\n}\n.rx-status-banner.rx-attached[_ngcontent-%COMP%]   .rx-icon-box[_ngcontent-%COMP%] {\n  color: #059669;\n}\n.rx-status-banner.rx-attached[_ngcontent-%COMP%]   .rx-banner-title[_ngcontent-%COMP%] {\n  color: #047857;\n}\n.rx-status-banner[_ngcontent-%COMP%]   .rx-banner-left[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  flex: 1;\n  min-width: 0;\n}\n.rx-status-banner[_ngcontent-%COMP%]   .rx-icon-box[_ngcontent-%COMP%] {\n  font-size: 22px;\n  color: #dc2626;\n  flex-shrink: 0;\n}\n.rx-status-banner[_ngcontent-%COMP%]   .rx-text-col[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 0;\n}\n.rx-status-banner[_ngcontent-%COMP%]   .rx-banner-title[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-weight: 700;\n  color: #991b1b;\n  display: block;\n  margin-bottom: 2px;\n}\n.rx-status-banner[_ngcontent-%COMP%]   .rx-banner-desc[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 11px;\n  color: #64748b;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.rx-status-banner[_ngcontent-%COMP%]   .btn-rx-action[_ngcontent-%COMP%] {\n  background: #dc2626;\n  color: #ffffff;\n  border: none;\n  padding: 6px 12px;\n  border-radius: 8px;\n  font-size: 12px;\n  font-weight: 700;\n  cursor: pointer;\n  white-space: nowrap;\n  flex-shrink: 0;\n}\n.rx-status-banner[_ngcontent-%COMP%]   .btn-rx-action.btn-edit[_ngcontent-%COMP%] {\n  background: #059669;\n}\n.rx-status-banner[_ngcontent-%COMP%]   .btn-rx-action[_ngcontent-%COMP%]:active {\n  transform: scale(0.95);\n}\n.cart-items-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 14px;\n  padding: 14px;\n  border: 1px solid #e2e8f0;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.02);\n}\n.cart-items-card[_ngcontent-%COMP%]   .card-header-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  margin-bottom: 12px;\n  padding-bottom: 8px;\n  border-bottom: 1px solid #f1f5f9;\n}\n.cart-items-card[_ngcontent-%COMP%]   .card-header-row[_ngcontent-%COMP%]   .card-header-title[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 14px;\n  font-weight: 700;\n  color: #0f172a;\n}\n.cart-items-card[_ngcontent-%COMP%]   .items-list[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n}\n.cart-item-row[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 12px;\n  padding-bottom: 12px;\n  border-bottom: 1px solid #f1f5f9;\n}\n.cart-item-row[_ngcontent-%COMP%]:last-child {\n  padding-bottom: 0;\n  border-bottom: none;\n}\n.cart-item-row[_ngcontent-%COMP%]   .item-img-wrap[_ngcontent-%COMP%] {\n  position: relative;\n  width: 64px;\n  height: 64px;\n  border-radius: 8px;\n  overflow: hidden;\n  background: #f8fafc;\n  flex-shrink: 0;\n}\n.cart-item-row[_ngcontent-%COMP%]   .item-img-wrap[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n.cart-item-row[_ngcontent-%COMP%]   .item-img-wrap[_ngcontent-%COMP%]   .rx-tag[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 3px;\n  left: 3px;\n  background: #ef4444;\n  color: #ffffff;\n  font-size: 8px;\n  font-weight: 800;\n  padding: 1px 4px;\n  border-radius: 3px;\n}\n.cart-item-row[_ngcontent-%COMP%]   .item-info-col[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 0;\n  display: flex;\n  flex-direction: column;\n}\n.cart-item-row[_ngcontent-%COMP%]   .item-title-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-start;\n  justify-content: space-between;\n  gap: 8px;\n}\n.cart-item-row[_ngcontent-%COMP%]   .item-title-row[_ngcontent-%COMP%]   .item-name[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 13px;\n  font-weight: 700;\n  color: #0f172a;\n  line-height: 1.3;\n}\n.cart-item-row[_ngcontent-%COMP%]   .item-title-row[_ngcontent-%COMP%]   .btn-delete[_ngcontent-%COMP%] {\n  background: transparent;\n  border: none;\n  color: #94a3b8;\n  font-size: 16px;\n  cursor: pointer;\n  padding: 0;\n}\n.cart-item-row[_ngcontent-%COMP%]   .item-title-row[_ngcontent-%COMP%]   .btn-delete[_ngcontent-%COMP%]:hover {\n  color: #ef4444;\n}\n.cart-item-row[_ngcontent-%COMP%]   .item-pack[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #64748b;\n  margin: 2px 0 8px 0;\n}\n.cart-item-row[_ngcontent-%COMP%]   .item-pricing-stepper-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin-top: auto;\n}\n.cart-item-row[_ngcontent-%COMP%]   .price-stack[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: baseline;\n  gap: 6px;\n}\n.cart-item-row[_ngcontent-%COMP%]   .price-stack[_ngcontent-%COMP%]   .unit-price[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 800;\n  color: #0f172a;\n}\n.cart-item-row[_ngcontent-%COMP%]   .price-stack[_ngcontent-%COMP%]   .strike-mrp[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #94a3b8;\n  text-decoration: line-through;\n}\n.cart-item-row[_ngcontent-%COMP%]   .stepper-box[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  background: #ecfdf5;\n  border: 1px solid #10b981;\n  border-radius: 8px;\n  overflow: hidden;\n}\n.cart-item-row[_ngcontent-%COMP%]   .stepper-box[_ngcontent-%COMP%]   .btn-step[_ngcontent-%COMP%] {\n  background: transparent;\n  border: none;\n  color: #059669;\n  width: 26px;\n  height: 26px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  cursor: pointer;\n  font-size: 13px;\n}\n.cart-item-row[_ngcontent-%COMP%]   .stepper-box[_ngcontent-%COMP%]   .btn-step[_ngcontent-%COMP%]:active {\n  background: #10b981;\n  color: #ffffff;\n}\n.cart-item-row[_ngcontent-%COMP%]   .stepper-box[_ngcontent-%COMP%]   .qty-num[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 700;\n  color: #059669;\n  padding: 0 4px;\n  min-width: 18px;\n  text-align: center;\n}\n.lab-cart-item-row[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n  padding-bottom: 12px;\n  border-bottom: 1px solid #f1f5f9;\n}\n.lab-cart-item-row[_ngcontent-%COMP%]:last-child {\n  padding-bottom: 0;\n  border-bottom: none;\n}\n.lab-cart-item-row[_ngcontent-%COMP%]   .lab-item-header[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-start;\n  gap: 8px;\n}\n.lab-cart-item-row[_ngcontent-%COMP%]   .lab-item-header[_ngcontent-%COMP%]   .lab-item-name[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 14px;\n  font-weight: 700;\n  color: #0f172a;\n  line-height: 1.3;\n}\n.lab-cart-item-row[_ngcontent-%COMP%]   .lab-item-header[_ngcontent-%COMP%]   .lab-item-meta[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #64748b;\n  display: block;\n  margin-top: 2px;\n}\n.lab-cart-item-row[_ngcontent-%COMP%]   .lab-item-header[_ngcontent-%COMP%]   .btn-delete[_ngcontent-%COMP%] {\n  background: transparent;\n  border: none;\n  color: #94a3b8;\n  font-size: 16px;\n  cursor: pointer;\n}\n.lab-cart-item-row[_ngcontent-%COMP%]   .lab-item-header[_ngcontent-%COMP%]   .btn-delete[_ngcontent-%COMP%]:hover {\n  color: #ef4444;\n}\n.lab-cart-item-row[_ngcontent-%COMP%]   .lab-item-specs[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 6px;\n}\n.lab-cart-item-row[_ngcontent-%COMP%]   .lab-item-specs[_ngcontent-%COMP%]   .spec-pill[_ngcontent-%COMP%] {\n  background: #f1f5f9;\n  color: #334155;\n  font-size: 10px;\n  font-weight: 500;\n  padding: 3px 8px;\n  border-radius: 6px;\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n}\n.lab-cart-item-row[_ngcontent-%COMP%]   .lab-item-specs[_ngcontent-%COMP%]   .spec-pill[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  color: #0284c7;\n  font-size: 12px;\n}\n.lab-cart-item-row[_ngcontent-%COMP%]   .lab-item-pricing-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n.lab-cart-item-row[_ngcontent-%COMP%]   .lab-item-pricing-row[_ngcontent-%COMP%]   .price-stack[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: baseline;\n  gap: 6px;\n}\n.lab-cart-item-row[_ngcontent-%COMP%]   .lab-item-pricing-row[_ngcontent-%COMP%]   .price-stack[_ngcontent-%COMP%]   .unit-price[_ngcontent-%COMP%] {\n  font-size: 15px;\n  font-weight: 800;\n  color: #0f172a;\n}\n.lab-cart-item-row[_ngcontent-%COMP%]   .lab-item-pricing-row[_ngcontent-%COMP%]   .price-stack[_ngcontent-%COMP%]   .strike-mrp[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #94a3b8;\n  text-decoration: line-through;\n}\n.lab-cart-item-row[_ngcontent-%COMP%]   .lab-item-pricing-row[_ngcontent-%COMP%]   .price-stack[_ngcontent-%COMP%]   .discount-pill[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 700;\n  background: #fee2e2;\n  color: #dc2626;\n  padding: 1px 5px;\n  border-radius: 4px;\n}\n.lab-cart-item-row[_ngcontent-%COMP%]   .lab-item-pricing-row[_ngcontent-%COMP%]   .collection-tag[_ngcontent-%COMP%] {\n  font-size: 10px;\n  color: #059669;\n  font-weight: 600;\n}\n.coupon-section-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 14px;\n  padding: 12px 14px;\n  border: 1px solid #e2e8f0;\n}\n.coupon-section-card[_ngcontent-%COMP%]   .coupon-header[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  font-size: 13px;\n  font-weight: 700;\n  color: #0f172a;\n  margin-bottom: 10px;\n}\n.coupon-section-card[_ngcontent-%COMP%]   .coupon-header[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  color: #059669;\n  font-size: 16px;\n}\n.coupon-section-card[_ngcontent-%COMP%]   .coupon-offer-box[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  background: #f8fafc;\n  border: 1px dashed #cbd5e1;\n  border-radius: 10px;\n  padding: 10px 12px;\n}\n.coupon-section-card[_ngcontent-%COMP%]   .coupon-offer-box[_ngcontent-%COMP%]   .offer-code[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-weight: 800;\n  color: #059669;\n  letter-spacing: 0.5px;\n  display: block;\n}\n.coupon-section-card[_ngcontent-%COMP%]   .coupon-offer-box[_ngcontent-%COMP%]   .offer-desc[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #64748b;\n}\n.coupon-section-card[_ngcontent-%COMP%]   .coupon-offer-box[_ngcontent-%COMP%]   .btn-apply-coupon[_ngcontent-%COMP%] {\n  background: #059669;\n  color: #ffffff;\n  border: none;\n  padding: 6px 14px;\n  border-radius: 6px;\n  font-size: 12px;\n  font-weight: 700;\n  cursor: pointer;\n}\n.coupon-section-card[_ngcontent-%COMP%]   .applied-coupon-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  background: #ecfdf5;\n  border: 1px solid #6ee7b7;\n  border-radius: 10px;\n  padding: 8px 12px;\n}\n.coupon-section-card[_ngcontent-%COMP%]   .applied-coupon-row[_ngcontent-%COMP%]   .applied-left[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  font-size: 12px;\n  color: #047857;\n}\n.coupon-section-card[_ngcontent-%COMP%]   .applied-coupon-row[_ngcontent-%COMP%]   .applied-left[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 16px;\n}\n.coupon-section-card[_ngcontent-%COMP%]   .applied-coupon-row[_ngcontent-%COMP%]   .btn-remove-coupon[_ngcontent-%COMP%] {\n  background: transparent;\n  border: none;\n  color: #ef4444;\n  font-size: 12px;\n  font-weight: 700;\n  cursor: pointer;\n}\n.bill-summary-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 14px;\n  padding: 14px;\n  border: 1px solid #e2e8f0;\n}\n.bill-summary-card[_ngcontent-%COMP%]   .bill-title[_ngcontent-%COMP%] {\n  margin: 0 0 12px 0;\n  font-size: 14px;\n  font-weight: 700;\n  color: #0f172a;\n}\n.bill-summary-card[_ngcontent-%COMP%]   .bill-row[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  font-size: 13px;\n  color: #475569;\n  margin-bottom: 8px;\n}\n.bill-summary-card[_ngcontent-%COMP%]   .bill-row[_ngcontent-%COMP%]   .bill-val[_ngcontent-%COMP%] {\n  font-weight: 600;\n  color: #0f172a;\n}\n.bill-summary-card[_ngcontent-%COMP%]   .bill-row[_ngcontent-%COMP%]   .bill-val.free[_ngcontent-%COMP%] {\n  color: #059669;\n  font-weight: 700;\n}\n.bill-summary-card[_ngcontent-%COMP%]   .bill-row.green[_ngcontent-%COMP%] {\n  color: #059669;\n}\n.bill-summary-card[_ngcontent-%COMP%]   .bill-row.green[_ngcontent-%COMP%]   .bill-val[_ngcontent-%COMP%] {\n  color: #059669;\n}\n.bill-summary-card[_ngcontent-%COMP%]   .bill-divider[_ngcontent-%COMP%] {\n  height: 1px;\n  background: #e2e8f0;\n  margin: 10px 0;\n}\n.bill-summary-card[_ngcontent-%COMP%]   .bill-total-row[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n.bill-summary-card[_ngcontent-%COMP%]   .bill-total-row[_ngcontent-%COMP%]   .total-title[_ngcontent-%COMP%] {\n  font-size: 15px;\n  font-weight: 800;\n  color: #0f172a;\n  display: block;\n}\n.bill-summary-card[_ngcontent-%COMP%]   .bill-total-row[_ngcontent-%COMP%]   .savings-note[_ngcontent-%COMP%] {\n  font-size: 10px;\n  color: #059669;\n  font-weight: 600;\n}\n.bill-summary-card[_ngcontent-%COMP%]   .bill-total-row[_ngcontent-%COMP%]   .final-total[_ngcontent-%COMP%] {\n  font-size: 18px;\n  font-weight: 800;\n  color: #0f172a;\n}\n.patient-details-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 14px;\n  padding: 14px;\n  border: 1px solid #e2e8f0;\n}\n.patient-details-card[_ngcontent-%COMP%]   .card-header-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  margin-bottom: 12px;\n  color: #0284c7;\n}\n.patient-details-card[_ngcontent-%COMP%]   .card-header-row[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n}\n.patient-details-card[_ngcontent-%COMP%]   .card-header-row[_ngcontent-%COMP%]   .card-header-title[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 14px;\n  font-weight: 700;\n  color: #0f172a;\n}\n.patient-details-card[_ngcontent-%COMP%]   .form-grid[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n}\n.patient-details-card[_ngcontent-%COMP%]   .input-group[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n}\n.patient-details-card[_ngcontent-%COMP%]   .input-group[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 600;\n  color: #475569;\n}\n.patient-details-card[_ngcontent-%COMP%]   .input-row-half[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: 1fr 2fr;\n  gap: 10px;\n}\n.patient-details-card[_ngcontent-%COMP%]   .cart-input[_ngcontent-%COMP%] {\n  background: #f8fafc;\n  border: 1px solid #cbd5e1;\n  border-radius: 8px;\n  padding: 8px 10px;\n  font-size: 13px;\n  color: #0f172a;\n  outline: none;\n}\n.patient-details-card[_ngcontent-%COMP%]   .cart-input[_ngcontent-%COMP%]:focus {\n  border-color: #0284c7;\n  background: #ffffff;\n}\n.patient-details-card[_ngcontent-%COMP%]   .gender-pill-row[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 4px;\n}\n.patient-details-card[_ngcontent-%COMP%]   .gender-pill-row[_ngcontent-%COMP%]   .btn-gender[_ngcontent-%COMP%] {\n  flex: 1;\n  border: 1px solid #cbd5e1;\n  background: #f8fafc;\n  border-radius: 8px;\n  padding: 8px 4px;\n  font-size: 12px;\n  font-weight: 600;\n  color: #475569;\n  cursor: pointer;\n}\n.patient-details-card[_ngcontent-%COMP%]   .gender-pill-row[_ngcontent-%COMP%]   .btn-gender.active[_ngcontent-%COMP%] {\n  background: #f0f9ff;\n  border-color: #0284c7;\n  color: #0284c7;\n}\n.slot-picker-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 14px;\n  padding: 14px;\n  border: 1px solid #e2e8f0;\n}\n.slot-picker-card[_ngcontent-%COMP%]   .card-header-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  margin-bottom: 12px;\n  color: #0284c7;\n}\n.slot-picker-card[_ngcontent-%COMP%]   .card-header-row[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n}\n.slot-picker-card[_ngcontent-%COMP%]   .card-header-row[_ngcontent-%COMP%]   .card-header-title[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 14px;\n  font-weight: 700;\n  color: #0f172a;\n}\n.slot-picker-card[_ngcontent-%COMP%]   .date-chips-row[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 6px;\n  margin-bottom: 12px;\n}\n.slot-picker-card[_ngcontent-%COMP%]   .date-chips-row[_ngcontent-%COMP%]   .date-chip[_ngcontent-%COMP%] {\n  flex: 1;\n  background: #f8fafc;\n  border: 1px solid #cbd5e1;\n  border-radius: 8px;\n  padding: 8px 6px;\n  font-size: 11px;\n  font-weight: 600;\n  color: #475569;\n  cursor: pointer;\n  text-align: center;\n}\n.slot-picker-card[_ngcontent-%COMP%]   .date-chips-row[_ngcontent-%COMP%]   .date-chip.active[_ngcontent-%COMP%] {\n  background: #f0f9ff;\n  border-color: #0284c7;\n  color: #0284c7;\n  font-weight: 700;\n}\n.slot-picker-card[_ngcontent-%COMP%]   .time-slots-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 6px;\n}\n.slot-picker-card[_ngcontent-%COMP%]   .time-slots-grid[_ngcontent-%COMP%]   .time-slot-btn[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 4px;\n  background: #f8fafc;\n  border: 1px solid #cbd5e1;\n  border-radius: 8px;\n  padding: 8px 8px;\n  font-size: 11px;\n  font-weight: 500;\n  color: #334155;\n  cursor: pointer;\n}\n.slot-picker-card[_ngcontent-%COMP%]   .time-slots-grid[_ngcontent-%COMP%]   .time-slot-btn[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: #0284c7;\n}\n.slot-picker-card[_ngcontent-%COMP%]   .time-slots-grid[_ngcontent-%COMP%]   .time-slot-btn.active[_ngcontent-%COMP%] {\n  background: #f0f9ff;\n  border-color: #0284c7;\n  color: #0284c7;\n  font-weight: 700;\n}\n.trust-notice-card[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  background: #ecfdf5;\n  border-radius: 12px;\n  padding: 10px 14px;\n}\n.trust-notice-card[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 20px;\n  color: #059669;\n  flex-shrink: 0;\n}\n.trust-notice-card[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 11px;\n  color: #065f46;\n  line-height: 1.4;\n}\n.trust-notice-card.lab[_ngcontent-%COMP%] {\n  background: #f0f9ff;\n}\n.trust-notice-card.lab[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  color: #0284c7;\n}\n.trust-notice-card.lab[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  color: #0369a1;\n}\n.empty-cart-view[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  text-align: center;\n  padding: 50px 20px;\n  background: #ffffff;\n  border-radius: 16px;\n  border: 1px solid #e2e8f0;\n}\n.empty-cart-view[_ngcontent-%COMP%]   .empty-icon-circle[_ngcontent-%COMP%] {\n  width: 64px;\n  height: 64px;\n  border-radius: 50%;\n  background: #ecfdf5;\n  color: #059669;\n  font-size: 30px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin-bottom: 14px;\n}\n.empty-cart-view[_ngcontent-%COMP%]   .empty-icon-circle.lab[_ngcontent-%COMP%] {\n  background: #f0f9ff;\n  color: #0284c7;\n}\n.empty-cart-view[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 16px;\n  font-weight: 700;\n  color: #0f172a;\n}\n.empty-cart-view[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 4px 0 20px 0;\n  font-size: 13px;\n  color: #64748b;\n  line-height: 1.5;\n  max-width: 280px;\n}\n.empty-cart-view[_ngcontent-%COMP%]   .btn-browse-action[_ngcontent-%COMP%] {\n  background: #059669;\n  color: #ffffff;\n  border: none;\n  padding: 10px 24px;\n  border-radius: 10px;\n  font-size: 14px;\n  font-weight: 700;\n  cursor: pointer;\n}\n.empty-cart-view[_ngcontent-%COMP%]   .btn-browse-action.lab[_ngcontent-%COMP%] {\n  background: #0284c7;\n}\n.bottom-spacer[_ngcontent-%COMP%] {\n  height: 20px;\n}\n.bottom-spacer.has-cart[_ngcontent-%COMP%] {\n  height: 90px;\n}\n.cart-sticky-footer[_ngcontent-%COMP%] {\n  bottom: 0;\n  left: 0;\n  right: 0;\n  background: #ffffff;\n  border-top: 1px solid #e2e8f0;\n  box-shadow: 0 -4px 16px rgba(0, 0, 0, 0.06);\n  z-index: 100;\n  padding: 12px 16px calc(env(safe-area-inset-bottom, 0px) + 12px) 16px;\n}\n.cart-sticky-footer[_ngcontent-%COMP%]   .footer-inner[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 14px;\n}\n.cart-sticky-footer[_ngcontent-%COMP%]   .footer-total-col[_ngcontent-%COMP%]   .to-pay-label[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #64748b;\n  font-weight: 500;\n  display: block;\n}\n.cart-sticky-footer[_ngcontent-%COMP%]   .footer-total-col[_ngcontent-%COMP%]   .to-pay-amount[_ngcontent-%COMP%] {\n  font-size: 19px;\n  font-weight: 800;\n  color: #059669;\n}\n.cart-sticky-footer[_ngcontent-%COMP%]   .footer-total-col[_ngcontent-%COMP%]   .to-pay-amount.lab[_ngcontent-%COMP%] {\n  color: #0284c7;\n}\n.cart-sticky-footer[_ngcontent-%COMP%]   .btn-checkout[_ngcontent-%COMP%] {\n  flex: 1;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 6px;\n  background: #059669;\n  color: #ffffff;\n  border: none;\n  padding: 12px 18px;\n  border-radius: 12px;\n  font-size: 14px;\n  font-weight: 700;\n  cursor: pointer;\n  box-shadow: 0 4px 12px rgba(5, 150, 105, 0.3);\n}\n.cart-sticky-footer[_ngcontent-%COMP%]   .btn-checkout.lab[_ngcontent-%COMP%] {\n  background: #0284c7;\n  box-shadow: 0 4px 12px rgba(2, 132, 199, 0.3);\n}\n.cart-sticky-footer[_ngcontent-%COMP%]   .btn-checkout[_ngcontent-%COMP%]:active {\n  transform: scale(0.98);\n}\n.cart-sticky-footer[_ngcontent-%COMP%]   .btn-checkout[_ngcontent-%COMP%]:disabled {\n  opacity: 0.6;\n  cursor: not-allowed;\n}\n.prescription-cart-modal[_ngcontent-%COMP%]   .rx-sheet-content[_ngcontent-%COMP%] {\n  padding: 16px;\n}\n.prescription-cart-modal[_ngcontent-%COMP%]   .sheet-handle-bar[_ngcontent-%COMP%] {\n  width: 36px;\n  height: 4px;\n  background: #cbd5e1;\n  border-radius: 2px;\n  margin: 0 auto 12px auto;\n}\n.prescription-cart-modal[_ngcontent-%COMP%]   .sheet-header[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-start;\n  justify-content: space-between;\n  margin-bottom: 16px;\n}\n.prescription-cart-modal[_ngcontent-%COMP%]   .sheet-header[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 16px;\n  font-weight: 800;\n  color: #0f172a;\n}\n.prescription-cart-modal[_ngcontent-%COMP%]   .sheet-header[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 2px 0 0 0;\n  font-size: 12px;\n  color: #64748b;\n}\n.prescription-cart-modal[_ngcontent-%COMP%]   .sheet-header[_ngcontent-%COMP%]   .btn-sheet-close[_ngcontent-%COMP%] {\n  background: transparent;\n  border: none;\n  font-size: 20px;\n  color: #64748b;\n  cursor: pointer;\n}\n.prescription-cart-modal[_ngcontent-%COMP%]   .upload-options-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  gap: 10px;\n  margin-bottom: 14px;\n}\n.prescription-cart-modal[_ngcontent-%COMP%]   .upload-options-grid[_ngcontent-%COMP%]   .opt-box[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  gap: 6px;\n  background: #f8fafc;\n  border: 1px solid #cbd5e1;\n  border-radius: 10px;\n  padding: 12px 8px;\n  cursor: pointer;\n}\n.prescription-cart-modal[_ngcontent-%COMP%]   .upload-options-grid[_ngcontent-%COMP%]   .opt-box[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 22px;\n  color: #059669;\n}\n.prescription-cart-modal[_ngcontent-%COMP%]   .upload-options-grid[_ngcontent-%COMP%]   .opt-box[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 600;\n  color: #1e293b;\n}\n.prescription-cart-modal[_ngcontent-%COMP%]   .selected-rx-preview[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  background: #ecfdf5;\n  border: 1px solid #6ee7b7;\n  border-radius: 8px;\n  padding: 8px 12px;\n  margin-bottom: 12px;\n  font-size: 12px;\n  font-weight: 600;\n  color: #047857;\n}\n.prescription-cart-modal[_ngcontent-%COMP%]   .selected-rx-preview[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n}\n.prescription-cart-modal[_ngcontent-%COMP%]   .rx-note-wrap[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n  margin-bottom: 16px;\n}\n.prescription-cart-modal[_ngcontent-%COMP%]   .rx-note-wrap[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 600;\n  color: #475569;\n}\n.prescription-cart-modal[_ngcontent-%COMP%]   .btn-confirm-rx[_ngcontent-%COMP%] {\n  width: 100%;\n  background: #059669;\n  color: #ffffff;\n  border: none;\n  padding: 12px;\n  border-radius: 10px;\n  font-size: 14px;\n  font-weight: 700;\n  cursor: pointer;\n}\n.prescription-cart-modal[_ngcontent-%COMP%]   .btn-confirm-rx[_ngcontent-%COMP%]:disabled {\n  opacity: 0.6;\n}\n/*# sourceMappingURL=pharmacy-cart.page.css.map */'] });
var PharmacyCartPage = _PharmacyCartPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(PharmacyCartPage, { className: "PharmacyCartPage", filePath: "src/app/pages/pharmacy-cart/pharmacy-cart.page.ts", lineNumber: 63 });
})();
export {
  PharmacyCartPage
};
//# sourceMappingURL=pharmacy-cart.page-J6NEHEWE.js.map
