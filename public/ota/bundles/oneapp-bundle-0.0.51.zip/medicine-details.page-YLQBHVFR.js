import {
  DUMMY_MEDICINES
} from "./chunk-GFPPLSVS.js";
import {
  PharmacyCartService
} from "./chunk-SFLHCKYK.js";
import {
  add,
  addIcons,
  arrowBack,
  arrowForward,
  bagHandleOutline,
  cartOutline,
  checkmarkCircle,
  chevronForward,
  flashOutline,
  informationCircleOutline,
  medkitOutline,
  remove,
  shareSocialOutline,
  shieldCheckmarkOutline,
  sparklesOutline,
  timeOutline,
  warningOutline
} from "./chunk-V2INQVNG.js";
import {
  IonContent,
  IonHeader,
  IonIcon,
  IonToolbar,
  ToastController
} from "./chunk-CJE2NDTY.js";
import {
  ActivatedRoute,
  CommonModule,
  FormsModule,
  NavController,
  Router,
  inject,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIdentity,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2
} from "./chunk-Z7XNNJSA.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/pages/medicine-details/medicine-details.page.ts
function MedicineDetailsPage_Conditional_12_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 14);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("", ctx_r0.medicine.discountPercent, "% OFF");
  }
}
function MedicineDetailsPage_Conditional_12_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 15);
    \u0275\u0275text(1, "Rx Prescription Required");
    \u0275\u0275elementEnd();
  }
}
function MedicineDetailsPage_Conditional_12_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 21);
    \u0275\u0275element(1, "ion-icon", 59);
    \u0275\u0275text(2, " In Stock ");
    \u0275\u0275elementEnd();
  }
}
function MedicineDetailsPage_Conditional_12_Conditional_33_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 60);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "span", 61);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("MRP \u20B9", ctx_r0.medicine.mrp, "");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("Save \u20B9", ctx_r0.medicine.mrp - ctx_r0.medicine.price, "");
  }
}
function MedicineDetailsPage_Conditional_12_Conditional_37_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 62);
    \u0275\u0275listener("click", function MedicineDetailsPage_Conditional_12_Conditional_37_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.addToCart());
    });
    \u0275\u0275element(1, "ion-icon", 63);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3, "ADD TO CART");
    \u0275\u0275elementEnd()();
  }
}
function MedicineDetailsPage_Conditional_12_Conditional_38_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 36)(1, "button", 64);
    \u0275\u0275listener("click", function MedicineDetailsPage_Conditional_12_Conditional_38_Template_button_click_1_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.decrement());
    });
    \u0275\u0275element(2, "ion-icon", 65);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 66);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "button", 67);
    \u0275\u0275listener("click", function MedicineDetailsPage_Conditional_12_Conditional_38_Template_button_click_5_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.increment());
    });
    \u0275\u0275element(6, "ion-icon", 63);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r0.medQty);
  }
}
function MedicineDetailsPage_Conditional_12_Conditional_54_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 68);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const use_r4 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("\u2022 ", use_r4, "");
  }
}
function MedicineDetailsPage_Conditional_12_Conditional_54_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 47);
    \u0275\u0275repeaterCreate(1, MedicineDetailsPage_Conditional_12_Conditional_54_For_2_Template, 2, 1, "span", 68, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r0.medicine.uses);
  }
}
function MedicineDetailsPage_Conditional_12_Conditional_97_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 79);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("Saved \u20B9", ctx_r0.medSummary.savings, "");
  }
}
function MedicineDetailsPage_Conditional_12_Conditional_97_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "aside", 58)(1, "div", 69);
    \u0275\u0275listener("click", function MedicineDetailsPage_Conditional_12_Conditional_97_Template_div_click_1_listener() {
      \u0275\u0275restoreView(_r5);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.goToCart());
    });
    \u0275\u0275elementStart(2, "div", 70)(3, "div", 71);
    \u0275\u0275element(4, "ion-icon", 72);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 73)(6, "div", 74)(7, "span", 75);
    \u0275\u0275text(8, "MEDICINE CART");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "span", 76);
    \u0275\u0275text(10);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(11, "div", 77)(12, "span", 78);
    \u0275\u0275text(13);
    \u0275\u0275elementEnd();
    \u0275\u0275template(14, MedicineDetailsPage_Conditional_12_Conditional_97_Conditional_14_Template, 2, 1, "span", 79);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(15, "div", 80)(16, "button", 81);
    \u0275\u0275listener("click", function MedicineDetailsPage_Conditional_12_Conditional_97_Template_button_click_16_listener($event) {
      \u0275\u0275restoreView(_r5);
      const ctx_r0 = \u0275\u0275nextContext(2);
      ctx_r0.goToCart();
      return \u0275\u0275resetView($event.stopPropagation());
    });
    \u0275\u0275elementStart(17, "span");
    \u0275\u0275text(18, "View Cart");
    \u0275\u0275elementEnd();
    \u0275\u0275element(19, "ion-icon", 82);
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(10);
    \u0275\u0275textInterpolate2("", ctx_r0.medSummary.itemCount, " ", ctx_r0.medSummary.itemCount === 1 ? "ITEM" : "ITEMS", "");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r0.medSummary.grandTotal, "");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.medSummary.savings > 0 ? 14 : -1);
  }
}
function MedicineDetailsPage_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "main", 10)(1, "section", 11)(2, "div", 12);
    \u0275\u0275element(3, "img", 13);
    \u0275\u0275template(4, MedicineDetailsPage_Conditional_12_Conditional_4_Template, 2, 1, "span", 14)(5, MedicineDetailsPage_Conditional_12_Conditional_5_Template, 2, 0, "span", 15);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "section", 16)(7, "span", 17);
    \u0275\u0275text(8);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "h2", 18);
    \u0275\u0275text(10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "div", 19)(12, "span", 20);
    \u0275\u0275text(13);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "span", 20);
    \u0275\u0275text(15);
    \u0275\u0275elementEnd();
    \u0275\u0275template(16, MedicineDetailsPage_Conditional_12_Conditional_16_Template, 3, 0, "span", 21);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "div", 22)(18, "span", 23);
    \u0275\u0275text(19, "Composition:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "span", 24);
    \u0275\u0275text(21);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(22, "div", 25)(23, "span", 26);
    \u0275\u0275text(24, "Marketer:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(25, "span", 27);
    \u0275\u0275text(26);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(27, "section", 28)(28, "div", 29)(29, "div", 30)(30, "div", 31)(31, "span", 32);
    \u0275\u0275text(32);
    \u0275\u0275elementEnd();
    \u0275\u0275template(33, MedicineDetailsPage_Conditional_12_Conditional_33_Template, 4, 2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(34, "span", 33);
    \u0275\u0275text(35, "Inclusive of all applicable taxes");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(36, "div", 34);
    \u0275\u0275template(37, MedicineDetailsPage_Conditional_12_Conditional_37_Template, 4, 0, "button", 35)(38, MedicineDetailsPage_Conditional_12_Conditional_38_Template, 7, 1, "div", 36);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(39, "div", 37)(40, "div", 38);
    \u0275\u0275element(41, "ion-icon", 39);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(42, "div", 40)(43, "span", 41);
    \u0275\u0275text(44, "\u26A1 Instant 15-Minute Delivery");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(45, "span", 42);
    \u0275\u0275text(46, "Verified & packed by licensed pharmacists");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(47, "section", 43)(48, "h4", 44);
    \u0275\u0275element(49, "ion-icon", 45);
    \u0275\u0275elementStart(50, "span");
    \u0275\u0275text(51, "What is it used for?");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(52, "p", 46);
    \u0275\u0275text(53);
    \u0275\u0275elementEnd();
    \u0275\u0275template(54, MedicineDetailsPage_Conditional_12_Conditional_54_Template, 3, 0, "div", 47);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(55, "section", 43)(56, "h4", 44);
    \u0275\u0275element(57, "ion-icon", 48);
    \u0275\u0275elementStart(58, "span");
    \u0275\u0275text(59, "Directions for Use & Dosage");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(60, "p", 46);
    \u0275\u0275text(61);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(62, "section", 43)(63, "h4", 44);
    \u0275\u0275element(64, "ion-icon", 49);
    \u0275\u0275elementStart(65, "span");
    \u0275\u0275text(66, "Safety Advice & Warnings");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(67, "div", 50)(68, "div", 51)(69, "span", 52);
    \u0275\u0275text(70, "Alcohol");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(71, "span", 53);
    \u0275\u0275text(72, "Avoid or consult doctor. May increase risk of stomach upset or drowsiness.");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(73, "div", 51)(74, "span", 52);
    \u0275\u0275text(75, "Pregnancy & Breastfeeding");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(76, "span", 53);
    \u0275\u0275text(77, "Consult your physician before taking this medication during pregnancy.");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(78, "div", 51)(79, "span", 52);
    \u0275\u0275text(80, "Driving");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(81, "span", 53);
    \u0275\u0275text(82, "Generally safe, but avoid driving if you experience dizziness or drowsiness.");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(83, "div", 51)(84, "span", 52);
    \u0275\u0275text(85, "Kidney & Liver");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(86, "span", 53);
    \u0275\u0275text(87, "Dose adjustment may be needed for patients with active kidney or liver conditions.");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(88, "section", 54)(89, "div", 55);
    \u0275\u0275element(90, "ion-icon", 49);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(91, "div", 56)(92, "h5");
    \u0275\u0275text(93, "100% Genuine Medicine Guarantee");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(94, "p");
    \u0275\u0275text(95, "Sourced directly from authorized pharmaceutical distributors under strict temperature and storage compliance.");
    \u0275\u0275elementEnd()()();
    \u0275\u0275element(96, "div", 57);
    \u0275\u0275elementEnd();
    \u0275\u0275template(97, MedicineDetailsPage_Conditional_12_Conditional_97_Template, 20, 4, "aside", 58);
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(3);
    \u0275\u0275property("src", ctx_r0.medicine.image, \u0275\u0275sanitizeUrl)("alt", ctx_r0.medicine.name);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.medicine.discountPercent > 0 ? 4 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.medicine.prescriptionRequired ? 5 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx_r0.medicine.brand);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r0.medicine.name);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx_r0.medicine.dosageForm);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r0.medicine.packSize);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.medicine.inStock ? 16 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r0.medicine.composition || ctx_r0.medicine.name + " \u2022 Standard USP Formulation");
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r0.medicine.manufacturer || ctx_r0.medicine.brand + " Pharmaceuticals Ltd.");
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r0.medicine.price, "");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.medicine.mrp > ctx_r0.medicine.price ? 33 : -1);
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx_r0.medQty === 0 ? 37 : 38);
    \u0275\u0275advance(16);
    \u0275\u0275textInterpolate(ctx_r0.medicine.description);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.medicine.uses && ctx_r0.medicine.uses.length > 0 ? 54 : -1);
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate1(" ", ctx_r0.medicine.directionsForUse || "Take this medicine in the dose and duration as advised by your physician. Swallow it as a whole with water. Do not chew, crush or break the tablet.", " ");
    \u0275\u0275advance(35);
    \u0275\u0275classProp("has-cart", ctx_r0.medSummary.itemCount > 0);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.medSummary.itemCount > 0 ? 97 : -1);
  }
}
var _MedicineDetailsPage = class _MedicineDetailsPage {
  constructor() {
    this.route = inject(ActivatedRoute);
    this.router = inject(Router);
    this.navCtrl = inject(NavController);
    this.toastCtrl = inject(ToastController);
    this.cartService = inject(PharmacyCartService);
    this.medicine = null;
    this.medQty = 0;
    this.medSummary = {
      itemCount: 0,
      subtotal: 0,
      totalMrp: 0,
      savings: 0,
      fee: 0,
      grandTotal: 0
    };
    addIcons({
      arrowBack,
      shareSocialOutline,
      cartOutline,
      add,
      remove,
      shieldCheckmarkOutline,
      flashOutline,
      checkmarkCircle,
      informationCircleOutline,
      warningOutline,
      chevronForward,
      arrowForward,
      medkitOutline,
      bagHandleOutline,
      sparklesOutline,
      timeOutline
    });
  }
  ngOnInit() {
    const id = this.route.snapshot.paramMap.get("id");
    if (id) {
      this.medicine = DUMMY_MEDICINES.find((m) => m.id === id) || null;
    }
    if (!this.medicine) {
      this.medicine = DUMMY_MEDICINES[0];
    }
    this.cartSub = this.cartService.medicineCart$.subscribe((items) => {
      if (this.medicine) {
        const found = items.find((i) => i.item.id === this.medicine.id);
        this.medQty = found ? found.quantity : 0;
      }
    });
    this.summarySub = this.cartService.medicineSummary$.subscribe((summary) => {
      this.medSummary = summary;
    });
  }
  ngOnDestroy() {
    var _a, _b;
    (_a = this.cartSub) == null ? void 0 : _a.unsubscribe();
    (_b = this.summarySub) == null ? void 0 : _b.unsubscribe();
  }
  goBack() {
    this.navCtrl.navigateBack("/layout/pharmacy");
  }
  goToCart() {
    this.router.navigate(["/layout/pharmacy/cart"], {
      queryParams: { type: "medicine" }
    });
  }
  addToCart() {
    if (!this.medicine)
      return;
    this.cartService.addMedicine(this.medicine, 1);
  }
  increment() {
    if (!this.medicine)
      return;
    this.cartService.updateMedicineQuantity(this.medicine.id, this.medQty + 1);
  }
  decrement() {
    if (!this.medicine)
      return;
    this.cartService.updateMedicineQuantity(this.medicine.id, this.medQty - 1);
  }
  shareProduct() {
    return __async(this, null, function* () {
      if (!this.medicine)
        return;
      if (navigator.share) {
        try {
          yield navigator.share({
            title: this.medicine.name,
            text: `Buy ${this.medicine.name} (${this.medicine.packSize}) on Pintu at \u20B9${this.medicine.price}!`,
            url: window.location.href
          });
        } catch (e) {
        }
      } else {
        const toast = yield this.toastCtrl.create({
          message: "Link copied to clipboard!",
          duration: 1800,
          position: "bottom",
          color: "dark"
        });
        yield toast.present();
      }
    });
  }
};
_MedicineDetailsPage.\u0275fac = function MedicineDetailsPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _MedicineDetailsPage)();
};
_MedicineDetailsPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _MedicineDetailsPage, selectors: [["app-medicine-details"]], decls: 13, vars: 1, consts: [[1, "med-details-header", "ion-no-border"], [1, "med-details-toolbar"], [1, "header-top-row"], ["type", "button", "aria-label", "Go Back", 1, "btn-nav-back", 3, "click"], ["name", "arrow-back"], [1, "header-center-title"], [1, "header-actions-right"], ["type", "button", "aria-label", "Share", 1, "btn-share-nav", 3, "click"], ["name", "share-social-outline"], [1, "med-details-content"], [1, "med-details-container"], [1, "product-gallery-card"], [1, "gallery-image-box"], [3, "src", "alt"], [1, "discount-badge-ribbon"], [1, "rx-pill-badge"], [1, "product-header-card"], [1, "product-brand"], [1, "product-title"], [1, "product-specs-row"], [1, "spec-pill"], [1, "spec-pill", "in-stock"], [1, "composition-info-row"], [1, "comp-label"], [1, "comp-val"], [1, "manufacturer-info-row"], [1, "mfg-label"], [1, "mfg-val"], [1, "product-pricing-card"], [1, "pricing-main-row"], [1, "price-col"], [1, "price-line"], [1, "selling-price"], [1, "tax-footnote"], [1, "cta-col"], ["type", "button", 1, "btn-primary-add"], [1, "qty-stepper"], [1, "fast-delivery-strip"], [1, "delivery-icon-box"], ["name", "flash-outline"], [1, "delivery-text-col"], [1, "delivery-title"], [1, "delivery-sub"], [1, "info-card"], [1, "card-section-title"], ["name", "medkit-outline"], [1, "section-para"], [1, "uses-chips-wrap"], ["name", "information-circle-outline"], ["name", "shield-checkmark-outline"], [1, "safety-advice-grid"], [1, "safety-item"], [1, "safety-topic"], [1, "safety-detail"], [1, "trust-guarantee-card"], [1, "shield-circle"], [1, "trust-text-col"], [1, "bottom-nav-spacer"], ["slot", "fixed", 1, "docked-cart-banner", "medicine", "animate__animated", "animate__fadeInUp"], ["name", "checkmark-circle"], [1, "mrp-strike"], [1, "savings-tag"], ["type", "button", 1, "btn-primary-add", 3, "click"], ["name", "add"], ["type", "button", "aria-label", "Decrease Quantity", 1, "btn-stepper", 3, "click"], ["name", "remove"], [1, "qty-number"], ["type", "button", "aria-label", "Increase Quantity", 1, "btn-stepper", 3, "click"], [1, "use-chip"], ["role", "button", "tabindex", "0", 1, "cart-banner-card", 3, "click"], [1, "banner-left"], [1, "cart-icon-circle"], ["name", "bag-handle-outline"], [1, "cart-text-col"], [1, "cart-badge-row"], [1, "badge-text"], [1, "item-count-chip"], [1, "cart-price-row"], [1, "cart-grand-total"], [1, "cart-savings-chip"], [1, "banner-actions-right"], ["type", "button", "aria-label", "View Medicine Cart", 1, "btn-view-cart", 3, "click"], ["name", "arrow-forward"]], template: function MedicineDetailsPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar", 1)(2, "div", 2)(3, "button", 3);
    \u0275\u0275listener("click", function MedicineDetailsPage_Template_button_click_3_listener() {
      return ctx.goBack();
    });
    \u0275\u0275element(4, "ion-icon", 4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 5)(6, "h4");
    \u0275\u0275text(7, "Product Details");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "div", 6)(9, "button", 7);
    \u0275\u0275listener("click", function MedicineDetailsPage_Template_button_click_9_listener() {
      return ctx.shareProduct();
    });
    \u0275\u0275element(10, "ion-icon", 8);
    \u0275\u0275elementEnd()()()()();
    \u0275\u0275elementStart(11, "ion-content", 9);
    \u0275\u0275template(12, MedicineDetailsPage_Conditional_12_Template, 98, 20);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance(12);
    \u0275\u0275conditional(ctx.medicine ? 12 : -1);
  }
}, dependencies: [
  CommonModule,
  FormsModule,
  IonHeader,
  IonToolbar,
  IonContent,
  IonIcon
], styles: ["\n\n[_nghost-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  width: 100%;\n  height: 100%;\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  overflow: hidden;\n}\n.med-details-header[_ngcontent-%COMP%] {\n  --background: #ffffff;\n  background: #ffffff;\n  border-bottom: 1px solid #f1f5f9;\n  box-shadow: 0 1px 4px rgba(15, 23, 42, 0.04);\n  z-index: 100;\n  padding: 0 !important;\n  margin: 0 !important;\n  --ion-safe-area-top: 0px;\n  flex-shrink: 0;\n}\n.med-details-header[_ngcontent-%COMP%]   .med-details-toolbar[_ngcontent-%COMP%] {\n  --background: #ffffff;\n  background: #ffffff;\n  --padding-start: 12px;\n  --padding-end: 12px;\n  --padding-top: env(safe-area-inset-top, 0px);\n  --padding-bottom: 8px;\n  --min-height: 48px;\n  --border-width: 0;\n}\n.med-details-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  width: 100%;\n}\n.med-details-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .btn-nav-back[_ngcontent-%COMP%], \n.med-details-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .btn-share-nav[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 38px;\n  border-radius: 50%;\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n  color: #0f172a;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 20px;\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n.med-details-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .btn-nav-back[_ngcontent-%COMP%]:active, \n.med-details-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .btn-share-nav[_ngcontent-%COMP%]:active {\n  background: #e2e8f0;\n  transform: scale(0.95);\n}\n.med-details-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .header-center-title[_ngcontent-%COMP%] {\n  flex: 1;\n  text-align: center;\n}\n.med-details-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .header-center-title[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 15px;\n  font-weight: 800;\n  color: #0f172a;\n  letter-spacing: -0.2px;\n}\n.med-details-content[_ngcontent-%COMP%] {\n  --background: #f8fafc;\n  flex: 1;\n  width: 100%;\n  height: 100%;\n  position: relative;\n}\n.med-details-container[_ngcontent-%COMP%] {\n  padding: 14px 14px 20px;\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n}\n.product-gallery-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 20px;\n  border: 1px solid #e2e8f0;\n  overflow: hidden;\n  box-shadow: 0 2px 10px rgba(15, 23, 42, 0.04);\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  padding: 20px 16px;\n}\n.product-gallery-card[_ngcontent-%COMP%]   .gallery-image-box[_ngcontent-%COMP%] {\n  position: relative;\n  width: 100%;\n  max-width: 240px;\n  aspect-ratio: 1/1;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.product-gallery-card[_ngcontent-%COMP%]   .gallery-image-box[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  max-width: 100%;\n  max-height: 100%;\n  object-fit: contain;\n  filter: drop-shadow(0 4px 12px rgba(0, 0, 0, 0.08));\n}\n.product-gallery-card[_ngcontent-%COMP%]   .gallery-image-box[_ngcontent-%COMP%]   .discount-badge-ribbon[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  background: #ef4444;\n  color: #ffffff;\n  font-size: 11px;\n  font-weight: 850;\n  padding: 3px 8px;\n  border-radius: 8px;\n  box-shadow: 0 2px 6px rgba(239, 68, 68, 0.35);\n}\n.product-gallery-card[_ngcontent-%COMP%]   .gallery-image-box[_ngcontent-%COMP%]   .rx-pill-badge[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 0;\n  right: 0;\n  background: #fef2f2;\n  border: 1px solid #fecaca;\n  color: #dc2626;\n  font-size: 10.5px;\n  font-weight: 800;\n  padding: 2px 8px;\n  border-radius: 99px;\n}\n.product-header-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 18px;\n  border: 1px solid #e2e8f0;\n  padding: 16px;\n  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.03);\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n.product-header-card[_ngcontent-%COMP%]   .product-brand[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  font-weight: 800;\n  color: #059669;\n  text-transform: uppercase;\n  letter-spacing: 0.5px;\n}\n.product-header-card[_ngcontent-%COMP%]   .product-title[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 19px;\n  font-weight: 850;\n  color: #0f172a;\n  line-height: 1.25;\n}\n.product-header-card[_ngcontent-%COMP%]   .product-specs-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  flex-wrap: wrap;\n  margin-top: 2px;\n}\n.product-header-card[_ngcontent-%COMP%]   .product-specs-row[_ngcontent-%COMP%]   .spec-pill[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  font-weight: 650;\n  color: #475569;\n  background: #f1f5f9;\n  padding: 3px 10px;\n  border-radius: 99px;\n}\n.product-header-card[_ngcontent-%COMP%]   .product-specs-row[_ngcontent-%COMP%]   .spec-pill.in-stock[_ngcontent-%COMP%] {\n  background: #ecfdf5;\n  color: #059669;\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  font-weight: 750;\n}\n.product-header-card[_ngcontent-%COMP%]   .product-specs-row[_ngcontent-%COMP%]   .spec-pill.in-stock[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 13px;\n}\n.product-header-card[_ngcontent-%COMP%]   .composition-info-row[_ngcontent-%COMP%], \n.product-header-card[_ngcontent-%COMP%]   .manufacturer-info-row[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 6px;\n  font-size: 11.5px;\n  line-height: 1.4;\n  padding-top: 4px;\n  border-top: 1px dashed #f1f5f9;\n}\n.product-header-card[_ngcontent-%COMP%]   .composition-info-row[_ngcontent-%COMP%]   .comp-label[_ngcontent-%COMP%], \n.product-header-card[_ngcontent-%COMP%]   .composition-info-row[_ngcontent-%COMP%]   .mfg-label[_ngcontent-%COMP%], \n.product-header-card[_ngcontent-%COMP%]   .manufacturer-info-row[_ngcontent-%COMP%]   .comp-label[_ngcontent-%COMP%], \n.product-header-card[_ngcontent-%COMP%]   .manufacturer-info-row[_ngcontent-%COMP%]   .mfg-label[_ngcontent-%COMP%] {\n  color: #64748b;\n  font-weight: 700;\n  flex-shrink: 0;\n}\n.product-header-card[_ngcontent-%COMP%]   .composition-info-row[_ngcontent-%COMP%]   .comp-val[_ngcontent-%COMP%], \n.product-header-card[_ngcontent-%COMP%]   .composition-info-row[_ngcontent-%COMP%]   .mfg-val[_ngcontent-%COMP%], \n.product-header-card[_ngcontent-%COMP%]   .manufacturer-info-row[_ngcontent-%COMP%]   .comp-val[_ngcontent-%COMP%], \n.product-header-card[_ngcontent-%COMP%]   .manufacturer-info-row[_ngcontent-%COMP%]   .mfg-val[_ngcontent-%COMP%] {\n  color: #1e293b;\n  font-weight: 600;\n}\n.product-pricing-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 18px;\n  border: 1px solid #e2e8f0;\n  padding: 16px;\n  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.03);\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n}\n.product-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 12px;\n}\n.product-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%]   .price-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n}\n.product-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%]   .price-col[_ngcontent-%COMP%]   .price-line[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: baseline;\n  gap: 8px;\n  flex-wrap: wrap;\n}\n.product-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%]   .price-col[_ngcontent-%COMP%]   .price-line[_ngcontent-%COMP%]   .selling-price[_ngcontent-%COMP%] {\n  font-size: 22px;\n  font-weight: 900;\n  color: #0f172a;\n  letter-spacing: -0.5px;\n}\n.product-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%]   .price-col[_ngcontent-%COMP%]   .price-line[_ngcontent-%COMP%]   .mrp-strike[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  color: #94a3b8;\n  text-decoration: line-through;\n  font-weight: 600;\n}\n.product-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%]   .price-col[_ngcontent-%COMP%]   .price-line[_ngcontent-%COMP%]   .savings-tag[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 800;\n  background: #ecfdf5;\n  color: #059669;\n  padding: 2px 7px;\n  border-radius: 6px;\n}\n.product-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%]   .price-col[_ngcontent-%COMP%]   .tax-footnote[_ngcontent-%COMP%] {\n  font-size: 10.5px;\n  color: #64748b;\n  font-weight: 500;\n}\n.product-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%]   .cta-col[_ngcontent-%COMP%] {\n  flex-shrink: 0;\n}\n.product-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%]   .cta-col[_ngcontent-%COMP%]   .btn-primary-add[_ngcontent-%COMP%] {\n  background: #059669;\n  color: #ffffff;\n  border: none;\n  border-radius: 12px;\n  padding: 10px 18px;\n  font-size: 12.5px;\n  font-weight: 850;\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  cursor: pointer;\n  box-shadow: 0 3px 10px rgba(5, 150, 105, 0.3);\n  transition: all 0.15s ease;\n}\n.product-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%]   .cta-col[_ngcontent-%COMP%]   .btn-primary-add[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 16px;\n}\n.product-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%]   .cta-col[_ngcontent-%COMP%]   .btn-primary-add[_ngcontent-%COMP%]:active {\n  transform: scale(0.96);\n}\n.product-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%]   .cta-col[_ngcontent-%COMP%]   .qty-stepper[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  background: #ecfdf5;\n  border: 1.5px solid #059669;\n  border-radius: 12px;\n  overflow: hidden;\n}\n.product-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%]   .cta-col[_ngcontent-%COMP%]   .qty-stepper[_ngcontent-%COMP%]   .btn-stepper[_ngcontent-%COMP%] {\n  width: 34px;\n  height: 34px;\n  background: transparent;\n  border: none;\n  color: #059669;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 16px;\n  cursor: pointer;\n  transition: background 0.1s ease;\n}\n.product-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%]   .cta-col[_ngcontent-%COMP%]   .qty-stepper[_ngcontent-%COMP%]   .btn-stepper[_ngcontent-%COMP%]:active {\n  background: #d1fae5;\n}\n.product-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%]   .cta-col[_ngcontent-%COMP%]   .qty-stepper[_ngcontent-%COMP%]   .qty-number[_ngcontent-%COMP%] {\n  min-width: 28px;\n  text-align: center;\n  font-size: 14px;\n  font-weight: 850;\n  color: #065f46;\n}\n.product-pricing-card[_ngcontent-%COMP%]   .fast-delivery-strip[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  background: #f0fdf4;\n  border: 1px solid #bbf7d0;\n  border-radius: 12px;\n  padding: 9px 12px;\n}\n.product-pricing-card[_ngcontent-%COMP%]   .fast-delivery-strip[_ngcontent-%COMP%]   .delivery-icon-box[_ngcontent-%COMP%] {\n  width: 28px;\n  height: 28px;\n  border-radius: 8px;\n  background: #22c55e;\n  color: #ffffff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 16px;\n  flex-shrink: 0;\n}\n.product-pricing-card[_ngcontent-%COMP%]   .fast-delivery-strip[_ngcontent-%COMP%]   .delivery-text-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n.product-pricing-card[_ngcontent-%COMP%]   .fast-delivery-strip[_ngcontent-%COMP%]   .delivery-text-col[_ngcontent-%COMP%]   .delivery-title[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 800;\n  color: #14532d;\n}\n.product-pricing-card[_ngcontent-%COMP%]   .fast-delivery-strip[_ngcontent-%COMP%]   .delivery-text-col[_ngcontent-%COMP%]   .delivery-sub[_ngcontent-%COMP%] {\n  font-size: 10.5px;\n  color: #15803d;\n  font-weight: 500;\n}\n.info-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 18px;\n  border: 1px solid #e2e8f0;\n  padding: 16px;\n  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.03);\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n.info-card[_ngcontent-%COMP%]   .card-section-title[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 14px;\n  font-weight: 800;\n  color: #0f172a;\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.info-card[_ngcontent-%COMP%]   .card-section-title[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n  color: #059669;\n}\n.info-card[_ngcontent-%COMP%]   .section-para[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 12.5px;\n  color: #475569;\n  line-height: 1.5;\n}\n.info-card[_ngcontent-%COMP%]   .uses-chips-wrap[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 6px;\n  margin-top: 4px;\n}\n.info-card[_ngcontent-%COMP%]   .uses-chips-wrap[_ngcontent-%COMP%]   .use-chip[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  font-weight: 650;\n  color: #065f46;\n  background: #ecfdf5;\n  border: 1px solid #d1fae5;\n  padding: 3px 10px;\n  border-radius: 99px;\n}\n.safety-advice-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: 1fr;\n  gap: 10px;\n  margin-top: 4px;\n}\n.safety-advice-grid[_ngcontent-%COMP%]   .safety-item[_ngcontent-%COMP%] {\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n  border-radius: 12px;\n  padding: 10px 12px;\n  display: flex;\n  flex-direction: column;\n  gap: 3px;\n}\n.safety-advice-grid[_ngcontent-%COMP%]   .safety-item[_ngcontent-%COMP%]   .safety-topic[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 800;\n  color: #0f172a;\n}\n.safety-advice-grid[_ngcontent-%COMP%]   .safety-item[_ngcontent-%COMP%]   .safety-detail[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #64748b;\n  line-height: 1.4;\n}\n.trust-guarantee-card[_ngcontent-%COMP%] {\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n  border-radius: 16px;\n  padding: 14px;\n  display: flex;\n  align-items: center;\n  gap: 12px;\n}\n.trust-guarantee-card[_ngcontent-%COMP%]   .shield-circle[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 38px;\n  border-radius: 50%;\n  background: #ecfdf5;\n  color: #059669;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 20px;\n  flex-shrink: 0;\n}\n.trust-guarantee-card[_ngcontent-%COMP%]   .trust-text-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n}\n.trust-guarantee-card[_ngcontent-%COMP%]   .trust-text-col[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 12.5px;\n  font-weight: 800;\n  color: #0f172a;\n}\n.trust-guarantee-card[_ngcontent-%COMP%]   .trust-text-col[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 11px;\n  color: #64748b;\n  line-height: 1.35;\n}\n.bottom-nav-spacer[_ngcontent-%COMP%] {\n  height: 24px;\n  width: 100%;\n  transition: height 0.2s ease;\n}\n.bottom-nav-spacer.has-cart[_ngcontent-%COMP%] {\n  height: 110px;\n}\n.docked-cart-banner[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  width: 100%;\n  padding: 8px 14px calc(env(safe-area-inset-bottom, 0px) + 14px);\n  background:\n    linear-gradient(\n      to top,\n      rgb(248, 250, 252) 75%,\n      rgba(248, 250, 252, 0.9) 50%,\n      rgba(248, 250, 252, 0) 100%);\n  z-index: 99;\n  pointer-events: auto;\n  box-sizing: border-box;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #064e3b 0%,\n      #022c22 100%);\n  border: 1px solid rgba(52, 211, 153, 0.35);\n  border-radius: 16px;\n  padding: 10px 14px;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 10px;\n  box-shadow: 0 6px 20px rgba(6, 78, 59, 0.35);\n  cursor: pointer;\n  transition: transform 0.15s ease, box-shadow 0.15s ease;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]:active {\n  transform: scale(0.985);\n  box-shadow: 0 3px 12px rgba(6, 78, 59, 0.25);\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  min-width: 0;\n  flex: 1;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-icon-circle[_ngcontent-%COMP%] {\n  width: 34px;\n  height: 34px;\n  border-radius: 10px;\n  background: rgba(255, 255, 255, 0.15);\n  color: #ffffff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 18px;\n  flex-shrink: 0;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-text-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  min-width: 0;\n  gap: 2px;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-text-col[_ngcontent-%COMP%]   .cart-badge-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-text-col[_ngcontent-%COMP%]   .cart-badge-row[_ngcontent-%COMP%]   .badge-text[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  font-weight: 850;\n  color: #34d399;\n  letter-spacing: 0.5px;\n  text-transform: uppercase;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-text-col[_ngcontent-%COMP%]   .cart-badge-row[_ngcontent-%COMP%]   .item-count-chip[_ngcontent-%COMP%] {\n  font-size: 9px;\n  font-weight: 800;\n  background: rgba(255, 255, 255, 0.18);\n  color: #ffffff;\n  padding: 1px 5px;\n  border-radius: 4px;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-text-col[_ngcontent-%COMP%]   .cart-price-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: baseline;\n  gap: 6px;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-text-col[_ngcontent-%COMP%]   .cart-price-row[_ngcontent-%COMP%]   .cart-grand-total[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 900;\n  color: #ffffff;\n  letter-spacing: -0.2px;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-text-col[_ngcontent-%COMP%]   .cart-price-row[_ngcontent-%COMP%]   .cart-savings-chip[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  font-weight: 800;\n  background: rgba(16, 185, 129, 0.25);\n  color: #a7f3d0;\n  padding: 1px 5px;\n  border-radius: 4px;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-actions-right[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  flex-shrink: 0;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-actions-right[_ngcontent-%COMP%]   .btn-view-cart[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #10b981 0%,\n      #059669 100%);\n  color: #ffffff;\n  border: none;\n  border-radius: 99px;\n  padding: 8px 16px;\n  font-size: 12.5px;\n  font-weight: 850;\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  box-shadow: 0 3px 12px rgba(16, 185, 129, 0.4);\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-actions-right[_ngcontent-%COMP%]   .btn-view-cart[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n}\n.docked-cart-banner[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-actions-right[_ngcontent-%COMP%]   .btn-view-cart[_ngcontent-%COMP%]:active {\n  transform: scale(0.95);\n}\n/*# sourceMappingURL=medicine-details.page.css.map */"] });
var MedicineDetailsPage = _MedicineDetailsPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(MedicineDetailsPage, { className: "MedicineDetailsPage", filePath: "src/app/pages/medicine-details/medicine-details.page.ts", lineNumber: 50 });
})();
export {
  MedicineDetailsPage
};
//# sourceMappingURL=medicine-details.page-YLQBHVFR.js.map
