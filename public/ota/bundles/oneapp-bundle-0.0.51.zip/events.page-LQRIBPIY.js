import {
  EventsService
} from "./chunk-GKNTDGNO.js";
import {
  FooterComponent
} from "./chunk-BAXPXNKU.js";
import {
  addIcons,
  arrowBack,
  arrowBackOutline,
  calendarOutline,
  chevronBack,
  heart,
  heartOutline,
  helpCircleOutline,
  locationOutline,
  searchOutline,
  ticketOutline
} from "./chunk-V2INQVNG.js";
import {
  AuthService
} from "./chunk-EB6T6TPT.js";
import {
  ModalController,
  PopoverController
} from "./chunk-OE5MTPUR.js";
import "./chunk-YJYUHAOC.js";
import "./chunk-XR3JUECC.js";
import {
  IonButton,
  IonButtons,
  IonContent,
  IonFab,
  IonFabButton,
  IonHeader,
  IonIcon,
  IonModal,
  IonRefresher,
  IonRefresherContent,
  IonSearchbar,
  IonSkeletonText,
  IonTitle,
  IonToolbar
} from "./chunk-CJE2NDTY.js";
import {
  CommonModule,
  CurrencyPipe,
  DatePipe,
  FormsModule,
  NavController,
  NavParams,
  NgForOf,
  NgIf,
  TitleCasePipe,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵloadQuery,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind1,
  ɵɵpipeBind2,
  ɵɵpipeBind4,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵqueryRefresh,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIdentity,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵviewQuery
} from "./chunk-Z7XNNJSA.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async,
  __spreadProps,
  __spreadValues
} from "./chunk-6B6DTIB5.js";

// src/app/components/event-dialog/event-dialog.component.ts
function EventDialogComponent_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "img", 6);
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275property("src", ctx_r0.eventDetails.imageUrl, \u0275\u0275sanitizeUrl);
  }
}
function EventDialogComponent_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "img", 7);
  }
}
function EventDialogComponent_div_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 24);
    \u0275\u0275text(1, "Free");
    \u0275\u0275elementEnd();
  }
}
function EventDialogComponent_Conditional_43_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 21);
    \u0275\u0275text(1);
    \u0275\u0275pipe(2, "currency");
    \u0275\u0275elementStart(3, "span", 25);
    \u0275\u0275text(4, "/person");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", \u0275\u0275pipeBind4(2, 1, ctx_r0.eventDetails.ticketPrice, "INR", "symbol", "1.0-0"), " ");
  }
}
function EventDialogComponent_Conditional_44_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 22);
    \u0275\u0275text(1, "Free Entry");
    \u0275\u0275elementEnd();
  }
}
var _EventDialogComponent = class _EventDialogComponent {
  constructor(navCtrl, navParams, modalCtrl, popoverController) {
    this.navCtrl = navCtrl;
    this.navParams = navParams;
    this.modalCtrl = modalCtrl;
    this.popoverController = popoverController;
    this.eventDetails = this.navParams.get("item");
    console.log("Item from navParams:", this.eventDetails);
  }
  ngOnInit() {
    console.log(this.eventDetails);
  }
  bookNow(item) {
    return __async(this, null, function* () {
      yield this.modalCtrl.dismiss();
      this.navCtrl.navigateForward("/layout/order-details", {
        state: { eventId: item.id }
      });
    });
  }
};
_EventDialogComponent.\u0275fac = function EventDialogComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _EventDialogComponent)(\u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(NavParams), \u0275\u0275directiveInject(ModalController), \u0275\u0275directiveInject(PopoverController));
};
_EventDialogComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _EventDialogComponent, selectors: [["app-event-dialog"]], decls: 47, vars: 23, consts: [[1, "event-details-container", "animate__animated", "animate__fadeIn"], [1, "info-pill", "my-2"], [1, "event-name", "mb-0"], [1, "split-header"], [1, "image-column"], [1, "image-wrapper"], [1, "main-event-image", 3, "src"], ["src", "https://dummyimage.com/1080x1410/e0e0e0/c2c2c2.png&text=Coming Soon"], ["class", "image-overlay-tag", 4, "ngIf"], [1, "details-column"], [1, "info-pill"], [1, "bi", "bi-calendar-event", "text-warning"], [1, "bi", "bi-hourglass-split", "text-success"], [1, "bi", "bi-geo-alt", "text-primary"], [1, "bi", "bi-telephone", "text-success"], [1, "description-card"], [1, "section-label"], [1, "description-text"], [1, "organizer-tag"], [1, "action-footer"], [1, "price-section"], [1, "price-amount"], [1, "free-text"], [1, "book-btn", "w-100", 3, "click"], [1, "image-overlay-tag"], [1, "price-unit"]], template: function EventDialogComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 0)(1, "div", 1)(2, "h3", 2);
    \u0275\u0275text(3);
    \u0275\u0275pipe(4, "titlecase");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "div", 3)(6, "div", 4)(7, "div", 5);
    \u0275\u0275template(8, EventDialogComponent_Conditional_8_Template, 1, 1, "img", 6)(9, EventDialogComponent_Conditional_9_Template, 1, 0, "img", 7)(10, EventDialogComponent_div_10_Template, 2, 0, "div", 8);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(11, "div", 9)(12, "div", 10);
    \u0275\u0275element(13, "i", 11);
    \u0275\u0275elementStart(14, "span");
    \u0275\u0275text(15);
    \u0275\u0275pipe(16, "date");
    \u0275\u0275pipe(17, "date");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(18, "div", 10);
    \u0275\u0275element(19, "i", 12);
    \u0275\u0275elementStart(20, "span");
    \u0275\u0275text(21);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(22, "div", 10);
    \u0275\u0275element(23, "i", 13);
    \u0275\u0275elementStart(24, "span");
    \u0275\u0275text(25);
    \u0275\u0275pipe(26, "titlecase");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(27, "div", 10);
    \u0275\u0275element(28, "i", 14);
    \u0275\u0275elementStart(29, "span");
    \u0275\u0275text(30);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(31, "div", 15)(32, "h4", 16);
    \u0275\u0275text(33, "About Event");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(34, "p", 17);
    \u0275\u0275text(35);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(36, "div", 18);
    \u0275\u0275text(37, " Organized by ");
    \u0275\u0275elementStart(38, "span");
    \u0275\u0275text(39);
    \u0275\u0275pipe(40, "titlecase");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(41, "div", 19)(42, "div", 20);
    \u0275\u0275template(43, EventDialogComponent_Conditional_43_Template, 5, 6, "span", 21)(44, EventDialogComponent_Conditional_44_Template, 2, 0, "span", 22);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(45, "ion-button", 23);
    \u0275\u0275listener("click", function EventDialogComponent_Template_ion_button_click_45_listener() {
      return ctx.bookNow(ctx.eventDetails);
    });
    \u0275\u0275text(46, " Book Now ");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(4, 11, ctx.eventDetails.name || ctx.eventDetails.title));
    \u0275\u0275advance(5);
    \u0275\u0275conditional(ctx.eventDetails.imageUrl ? 8 : 9);
    \u0275\u0275advance(2);
    \u0275\u0275property("ngIf", ctx.eventDetails.isFree);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate2("", \u0275\u0275pipeBind2(16, 13, ctx.eventDetails.date, "dd MMM"), " \u2022 ", \u0275\u0275pipeBind2(17, 16, ctx.eventDetails.date, "hh:mm a"), "");
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(ctx.eventDetails.duration);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(26, 19, ctx.eventDetails.location.location));
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx.eventDetails.contact);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx.eventDetails.description);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(40, 21, ctx.eventDetails.organizer));
    \u0275\u0275advance(4);
    \u0275\u0275conditional(!ctx.eventDetails.isFree ? 43 : 44);
  }
}, dependencies: [CommonModule, NgIf, TitleCasePipe, CurrencyPipe, DatePipe, FormsModule, IonButton], styles: ["\n\n.event-details-container[_ngcontent-%COMP%] {\n  padding: 16px;\n  background: #ffffff;\n}\n.event-details-container[_ngcontent-%COMP%]   .split-header[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 12px;\n  align-items: stretch;\n  margin-bottom: 16px;\n}\n.event-details-container[_ngcontent-%COMP%]   .image-column[_ngcontent-%COMP%] {\n  flex: 1;\n  display: flex;\n}\n.event-details-container[_ngcontent-%COMP%]   .details-column[_ngcontent-%COMP%] {\n  flex: 1.2;\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n.event-details-container[_ngcontent-%COMP%]   .image-wrapper[_ngcontent-%COMP%] {\n  position: relative;\n  width: 100%;\n  border-radius: 18px;\n  overflow: hidden;\n  background: #f8fafc;\n  border: 1px solid #f1f5f9;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.event-details-container[_ngcontent-%COMP%]   .image-wrapper[_ngcontent-%COMP%]   .main-event-image[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: contain;\n  display: block;\n}\n.event-details-container[_ngcontent-%COMP%]   .image-wrapper[_ngcontent-%COMP%]   .image-overlay-tag[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 8px;\n  left: 8px;\n  background: rgba(45, 211, 111, 0.9);\n  color: white;\n  padding: 2px 8px;\n  border-radius: 6px;\n  font-weight: 700;\n  font-size: 10px;\n  -webkit-backdrop-filter: blur(4px);\n  backdrop-filter: blur(4px);\n}\n.event-details-container[_ngcontent-%COMP%]   .info-pill[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  padding: 10px 12px;\n  background: #f8fafc;\n  border: 1px solid #f1f5f9;\n  border-radius: 14px;\n  color: #334155;\n}\n.event-details-container[_ngcontent-%COMP%]   .info-pill[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  font-size: 14px;\n  margin-right: 8px;\n  min-width: 18px;\n}\n.event-details-container[_ngcontent-%COMP%]   .info-pill[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 600;\n  color: #334155;\n  line-height: 1.2;\n}\n.event-details-container[_ngcontent-%COMP%]   .description-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border: 1px solid #e2e8f0;\n  border-radius: 18px;\n  padding: 16px;\n  margin-top: 8px;\n}\n.event-details-container[_ngcontent-%COMP%]   .description-card[_ngcontent-%COMP%]   .section-label[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-weight: 800;\n  text-transform: uppercase;\n  letter-spacing: 0.5px;\n  margin: 0 0 6px 0;\n  color: #94a3b8;\n}\n.event-details-container[_ngcontent-%COMP%]   .description-card[_ngcontent-%COMP%]   .description-text[_ngcontent-%COMP%] {\n  font-size: 14px;\n  line-height: 1.5;\n  color: #475569;\n  margin-bottom: 8px;\n}\n.event-details-container[_ngcontent-%COMP%]   .description-card[_ngcontent-%COMP%]   .organizer-tag[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: #64748b;\n}\n.event-details-container[_ngcontent-%COMP%]   .description-card[_ngcontent-%COMP%]   .organizer-tag[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: #10b981;\n  font-weight: 700;\n}\n.event-details-container[_ngcontent-%COMP%]   .action-footer[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  width: 100%;\n  gap: 16px;\n  padding: 12px 0;\n  border-top: 1px solid #f1f5f9;\n}\n.event-details-container[_ngcontent-%COMP%]   .action-footer[_ngcontent-%COMP%]   .price-section[_ngcontent-%COMP%] {\n  flex-shrink: 0;\n  display: flex;\n  flex-direction: column;\n  white-space: nowrap;\n}\n.event-details-container[_ngcontent-%COMP%]   .action-footer[_ngcontent-%COMP%]   .price-section[_ngcontent-%COMP%]   .price-amount[_ngcontent-%COMP%] {\n  font-size: 22px;\n  font-weight: 800;\n  color: #000;\n  display: flex;\n  align-items: baseline;\n  gap: 2px;\n}\n.event-details-container[_ngcontent-%COMP%]   .action-footer[_ngcontent-%COMP%]   .price-section[_ngcontent-%COMP%]   .price-unit[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #94a3b8;\n  font-weight: 600;\n}\n.event-details-container[_ngcontent-%COMP%]   .action-footer[_ngcontent-%COMP%]   .price-section[_ngcontent-%COMP%]   .free-text[_ngcontent-%COMP%] {\n  font-size: 20px;\n  font-weight: 800;\n  color: #10b981;\n}\n.event-details-container[_ngcontent-%COMP%]   .action-footer[_ngcontent-%COMP%]   .book-btn[_ngcontent-%COMP%] {\n  flex: 1;\n  height: 54px;\n  margin: 0;\n  --border-radius: 16px;\n  font-weight: 700;\n  font-size: 16px;\n  --box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);\n}\n/*# sourceMappingURL=event-dialog.component.css.map */"] });
var EventDialogComponent = _EventDialogComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(EventDialogComponent, { className: "EventDialogComponent", filePath: "src/app/components/event-dialog/event-dialog.component.ts", lineNumber: 14 });
})();

// src/app/pages/events/events.page.ts
var _c0 = () => [1, 2, 3, 4];
function EventsPage_Conditional_13_ion_skeleton_text_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-skeleton-text", 18);
  }
}
function EventsPage_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 9)(1, "div", 11);
    \u0275\u0275element(2, "ion-skeleton-text", 12)(3, "ion-skeleton-text", 13);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "div", 14);
    \u0275\u0275element(5, "ion-skeleton-text", 15)(6, "ion-skeleton-text", 15)(7, "ion-skeleton-text", 15);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "div", 16);
    \u0275\u0275template(9, EventsPage_Conditional_13_ion_skeleton_text_9_Template, 1, 0, "ion-skeleton-text", 17);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(9);
    \u0275\u0275property("ngForOf", \u0275\u0275pureFunction0(1, _c0));
  }
}
function EventsPage_Conditional_14_For_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 23);
    \u0275\u0275listener("click", function EventsPage_Conditional_14_For_9_Template_div_click_0_listener() {
      const item_r4 = \u0275\u0275restoreView(_r3).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.applyFilter(item_r4));
    });
    \u0275\u0275text(1);
    \u0275\u0275pipe(2, "titlecase");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const item_r4 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275classProp("active", ctx_r1.currentFilter === item_r4);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", \u0275\u0275pipeBind1(2, 3, item_r4), " ");
  }
}
function EventsPage_Conditional_14_Conditional_11_For_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 39);
    \u0275\u0275listener("click", function EventsPage_Conditional_14_Conditional_11_For_6_Template_div_click_0_listener() {
      const feat_r6 = \u0275\u0275restoreView(_r5).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.openItemModal(feat_r6));
    });
    \u0275\u0275element(1, "img", 40);
    \u0275\u0275elementStart(2, "div", 41)(3, "span", 42);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "h3");
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "p");
    \u0275\u0275element(8, "ion-icon", 43);
    \u0275\u0275text(9);
    \u0275\u0275pipe(10, "date");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const feat_r6 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275property("src", feat_r6.imageUrl || "https://dummyimage.com/600x800/eee/aaa?text=Event", \u0275\u0275sanitizeUrl);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(feat_r6.category);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(feat_r6.title);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" ", \u0275\u0275pipeBind2(10, 4, feat_r6.date, "EEE, d MMM"), "");
  }
}
function EventsPage_Conditional_14_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 26)(1, "div", 35)(2, "h2", 36);
    \u0275\u0275text(3, "Featured");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(4, "div", 37);
    \u0275\u0275repeaterCreate(5, EventsPage_Conditional_14_Conditional_11_For_6_Template, 11, 7, "div", 38, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(5);
    \u0275\u0275repeater(ctx_r1.featuredEvents);
  }
}
function EventsPage_Conditional_14_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 29);
    \u0275\u0275element(1, "ion-icon", 44);
    \u0275\u0275elementStart(2, "p");
    \u0275\u0275text(3, "No events found");
    \u0275\u0275elementEnd()();
  }
}
function EventsPage_Conditional_14_For_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 45);
    \u0275\u0275listener("click", function EventsPage_Conditional_14_For_19_Template_div_click_0_listener() {
      const card_r8 = \u0275\u0275restoreView(_r7).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.openItemModal(card_r8));
    });
    \u0275\u0275elementStart(1, "div", 46);
    \u0275\u0275element(2, "img", 47);
    \u0275\u0275elementStart(3, "div", 48);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "button", 49);
    \u0275\u0275listener("click", function EventsPage_Conditional_14_For_19_Template_button_click_5_listener($event) {
      const card_r8 = \u0275\u0275restoreView(_r7).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.toggleFavorite(card_r8, $event));
    });
    \u0275\u0275element(6, "ion-icon", 50);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "div", 51)(8, "div", 52)(9, "span", 53);
    \u0275\u0275text(10);
    \u0275\u0275pipe(11, "date");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "span", 54);
    \u0275\u0275text(13);
    \u0275\u0275pipe(14, "date");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "div", 55)(16, "h3", 56);
    \u0275\u0275text(17);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "p", 57);
    \u0275\u0275element(19, "ion-icon", 58);
    \u0275\u0275text(20);
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const card_r8 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275property("src", card_r8.imageUrl || "https://dummyimage.com/600x800/eee/aaa?text=Event", \u0275\u0275sanitizeUrl);
    \u0275\u0275advance();
    \u0275\u0275classProp("free", card_r8.isFree);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", card_r8.isFree ? "FREE" : "\u20B9" + card_r8.ticketPrice, " ");
    \u0275\u0275advance(2);
    \u0275\u0275property("name", card_r8.isFavorite ? "heart" : "heart-outline")("color", card_r8.isFavorite ? "danger" : "medium");
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(11, 10, card_r8.date, "MMM"));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(14, 13, card_r8.date, "dd"));
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(card_r8.title);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" ", card_r8.location.location || "Bangalore", " ");
  }
}
function EventsPage_Conditional_14_Conditional_22_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 34);
    \u0275\u0275text(1, "My Bookings");
    \u0275\u0275elementEnd();
  }
}
function EventsPage_Conditional_14_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 34);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("Upcoming (", ctx_r1.upcomingBookings.length, ")");
  }
}
function EventsPage_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 19)(1, "div", 20)(2, "ion-searchbar", 21);
    \u0275\u0275listener("ionInput", function EventsPage_Conditional_14_Template_ion_searchbar_ionInput_2_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.handleSearch($event));
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(3, "div", 22)(4, "div", 23);
    \u0275\u0275listener("click", function EventsPage_Conditional_14_Template_div_click_4_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.applyFilter("All"));
    });
    \u0275\u0275text(5, "All");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "div", 23);
    \u0275\u0275listener("click", function EventsPage_Conditional_14_Template_div_click_6_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.applyFilter("Upcoming"));
    });
    \u0275\u0275text(7, "Upcoming");
    \u0275\u0275elementEnd();
    \u0275\u0275repeaterCreate(8, EventsPage_Conditional_14_For_9_Template, 3, 5, "div", 24, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(10, "div", 25);
    \u0275\u0275template(11, EventsPage_Conditional_14_Conditional_11_Template, 7, 0, "div", 26);
    \u0275\u0275elementStart(12, "div", 27)(13, "h2", 28);
    \u0275\u0275text(14);
    \u0275\u0275pipe(15, "titlecase");
    \u0275\u0275elementEnd();
    \u0275\u0275template(16, EventsPage_Conditional_14_Conditional_16_Template, 4, 0, "div", 29);
    \u0275\u0275elementStart(17, "div", 30);
    \u0275\u0275repeaterCreate(18, EventsPage_Conditional_14_For_19_Template, 21, 16, "div", 31, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(20, "ion-fab", 32)(21, "ion-fab-button", 33);
    \u0275\u0275listener("click", function EventsPage_Conditional_14_Template_ion_fab_button_click_21_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.openBookings());
    });
    \u0275\u0275template(22, EventsPage_Conditional_14_Conditional_22_Template, 2, 0, "span", 34)(23, EventsPage_Conditional_14_Conditional_23_Template, 2, 1, "span", 34);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275classProp("active", ctx_r1.currentFilter === "All");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("active", ctx_r1.currentFilter === "Upcoming");
    \u0275\u0275advance(2);
    \u0275\u0275repeater(ctx_r1.categories);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx_r1.currentFilter === "All" && !ctx_r1.searchTerm ? 11 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" ", ctx_r1.searchTerm ? "Search Results" : ctx_r1.currentFilter === "All" ? "Popular Events" : \u0275\u0275pipeBind1(15, 8, ctx_r1.currentFilter) + " Events", " ");
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.filteredEvents.length === 0 ? 16 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275repeater(ctx_r1.filteredEvents);
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx_r1.upcomingBookings.length == 0 ? 22 : 23);
  }
}
var _EventsPage = class _EventsPage {
  constructor(navCtrl, eventsService, authService, modalCtrl) {
    this.navCtrl = navCtrl;
    this.eventsService = eventsService;
    this.authService = authService;
    this.modalCtrl = modalCtrl;
    this.events = [];
    this.filteredEvents = [];
    this.featuredEvents = [];
    this.upcomingBookings = [];
    this.categories = [];
    this.isLoading = true;
    this.currentFilter = "All";
    this.searchTerm = "";
    addIcons({ arrowBack, arrowBackOutline, calendarOutline, searchOutline, locationOutline, ticketOutline, chevronBack, helpCircleOutline, heart, heartOutline });
  }
  ngOnInit() {
    return __async(this, null, function* () {
      yield this.getToken();
      this.getEvents();
    });
  }
  getToken() {
    return __async(this, null, function* () {
      this.token = yield this.authService.getToken();
    });
  }
  getEvents() {
    this.isLoading = true;
    this.eventsService.getEvents(this.token).subscribe((res) => {
      setTimeout(() => {
        this.events = res.data.map((e) => __spreadProps(__spreadValues({}, e), { isFavorite: false }));
        this.categories = this.getUniqueCategories(this.events);
        this.featuredEvents = this.events.slice(0, 5);
        this.upcomingBookings = res.bookedEvents;
        this.applyFilter("All");
        this.isLoading = false;
      }, 800);
    }, (error) => {
      this.isLoading = false;
    });
  }
  handleRefresh(event) {
    return __async(this, null, function* () {
      yield this.getEvents();
      event.target.complete();
    });
  }
  getUniqueCategories(events) {
    return [...new Set(events.map((event) => event.category))].filter(Boolean).sort();
  }
  applyFilter(filterType) {
    this.currentFilter = filterType;
    this.filterList();
  }
  handleSearch(event) {
    this.searchTerm = event.target.value.toLowerCase();
    this.filterList();
  }
  filterList() {
    let temp = this.events;
    if (this.currentFilter === "Upcoming") {
      const today = /* @__PURE__ */ new Date();
      const tenDaysFromNow = /* @__PURE__ */ new Date();
      tenDaysFromNow.setDate(today.getDate() + 10);
      temp = temp.filter((e) => {
        const d = new Date(e.date);
        return d >= today && d <= tenDaysFromNow;
      });
    } else if (this.currentFilter !== "All") {
      temp = temp.filter((e) => e.category === this.currentFilter);
    }
    if (this.searchTerm) {
      temp = temp.filter((e) => e.title.toLowerCase().includes(this.searchTerm) || e.location.location && e.location.location.toLowerCase().includes(this.searchTerm));
    }
    this.filteredEvents = temp;
  }
  toggleFavorite(event, e) {
    e.stopPropagation();
    event.isFavorite = !event.isFavorite;
  }
  openItemModal(item) {
    return __async(this, null, function* () {
      document.body.classList.add("modal-open");
      const modal = yield this.modalCtrl.create({
        component: EventDialogComponent,
        componentProps: { item },
        cssClass: "bottom-sheet-modal",
        initialBreakpoint: 1,
        breakpoints: [0, 1],
        handle: true
      });
      yield modal.present();
      yield modal.onDidDismiss();
      document.body.classList.remove("modal-open");
    });
  }
  openBookings() {
    this.navCtrl.navigateForward("/layout/history");
  }
  openHelp() {
    this.navCtrl.navigateForward("/layout/support");
  }
  back() {
    this.navCtrl.navigateRoot("/layout/home");
  }
  goBack() {
    this.navCtrl.navigateRoot("/layout/home");
  }
};
_EventsPage.\u0275fac = function EventsPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _EventsPage)(\u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(EventsService), \u0275\u0275directiveInject(AuthService), \u0275\u0275directiveInject(ModalController));
};
_EventsPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _EventsPage, selectors: [["app-events"]], viewQuery: function EventsPage_Query(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275viewQuery(IonModal, 5);
  }
  if (rf & 2) {
    let _t;
    \u0275\u0275queryRefresh(_t = \u0275\u0275loadQuery()) && (ctx.modal = _t.first);
  }
}, decls: 17, vars: 2, consts: [[1, "ion-no-border", "bg-white", "pt-2"], ["slot", "start"], [3, "click"], ["name", "arrow-back-outline", "color", "dark"], [1, "fw-bold", "text-dark"], ["slot", "end"], ["name", "help-circle-outline", "slot", "icon-only", "color", "medium"], [1, "bg-gray-50", 3, "fullscreen"], ["slot", "fixed", 3, "ionRefresh"], [1, "p-2", "pt-4"], [1, "mt-3"], [1, "flex", "gap-4", "overflow-hidden", "mb-6"], ["animated", "", 2, "width", "85%", "height", "200px", "border-radius", "20px", "flex-shrink", "0"], ["animated", "", 2, "width", "15%", "height", "200px", "border-radius", "20px 0 0 20px", "flex-shrink", "0"], [1, "flex", "gap-3", "mb-6"], ["animated", "", 2, "width", "80px", "height", "36px", "border-radius", "18px"], [1, "grid", "grid-cols-2", "gap-4"], ["animated", "", "style", "height: 220px; border-radius: 16px;", 4, "ngFor", "ngForOf"], ["animated", "", 2, "height", "220px", "border-radius", "16px"], [1, "sticky-header-section"], [1, "px-4", "mb-2"], ["mode", "ios", "placeholder", "Search concerts, workshops...", 1, "custom-search", 3, "ionInput"], [1, "horizontal-scroll-container", "px-4", "pb-4"], [1, "category-pill", 3, "click"], [1, "category-pill", 3, "active"], [1, "content-container", "pb-24"], [1, "mb-6"], [1, "px-4"], [1, "text-lg", "font-bold", "text-gray-800", "mb-3"], [1, "text-center", "py-10", "text-gray-400"], [1, "event-masonry-grid"], [1, "modern-event-card", "animate__animated", "animate__fadeIn"], ["vertical", "bottom", "horizontal", "center", "slot", "fixed", 1, "mb-4"], ["color", "dark", 1, "extended-fab", 3, "click"], [1, "font-bold"], [1, "flex", "items-end", "justify-between", "px-4", "mb-3"], [1, "text-lg", "font-bold", "text-gray-800", "m-0"], [1, "featured-scroll", "px-4"], [1, "featured-card"], [1, "featured-card", 3, "click"], ["alt", "Event", "loading", "lazy", 3, "src"], [1, "overlay"], [1, "feat-badge"], ["name", "calendar-outline"], ["name", "search-outline", 1, "text-4xl", "mb-2"], [1, "modern-event-card", "animate__animated", "animate__fadeIn", 3, "click"], [1, "card-image-box"], ["loading", "lazy", 3, "src"], [1, "price-tag"], [1, "fav-btn", 3, "click"], [3, "name", "color"], [1, "card-info"], [1, "date-badge"], [1, "month"], [1, "day"], [1, "details"], [1, "card-name", "text-truncate-2", "text-wrap"], [1, "location", "text-truncate", "text-wrap"], ["name", "location-outline"]], template: function EventsPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar")(2, "ion-buttons", 1)(3, "ion-button", 2);
    \u0275\u0275listener("click", function EventsPage_Template_ion_button_click_3_listener() {
      return ctx.goBack();
    });
    \u0275\u0275element(4, "ion-icon", 3);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "ion-title", 4);
    \u0275\u0275text(6, "Local Events");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "ion-buttons", 5)(8, "ion-button", 2);
    \u0275\u0275listener("click", function EventsPage_Template_ion_button_click_8_listener() {
      return ctx.openHelp();
    });
    \u0275\u0275element(9, "ion-icon", 6);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(10, "ion-content", 7)(11, "ion-refresher", 8);
    \u0275\u0275listener("ionRefresh", function EventsPage_Template_ion_refresher_ionRefresh_11_listener($event) {
      return ctx.handleRefresh($event);
    });
    \u0275\u0275element(12, "ion-refresher-content");
    \u0275\u0275elementEnd();
    \u0275\u0275template(13, EventsPage_Conditional_13_Template, 10, 2, "div", 9)(14, EventsPage_Conditional_14_Template, 24, 10);
    \u0275\u0275elementStart(15, "div", 10);
    \u0275\u0275element(16, "app-footer");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(10);
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx.isLoading ? 13 : 14);
  }
}, dependencies: [
  IonRefresherContent,
  IonRefresher,
  CommonModule,
  NgForOf,
  TitleCasePipe,
  DatePipe,
  FormsModule,
  FooterComponent,
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  IonButtons,
  IonButton,
  IonIcon,
  IonSearchbar,
  IonSkeletonText,
  IonFab,
  IonFabButton
], styles: ["\n\n[_nghost-%COMP%] {\n  --primary: #6366f1;\n  --bg-color: #f8fafc;\n  --text-dark: #1e293b;\n  --text-light: #64748b;\n  --card-radius: 16px;\n}\n.flex[_ngcontent-%COMP%] {\n  display: flex;\n}\n.justify-between[_ngcontent-%COMP%] {\n  justify-content: space-between;\n}\n.items-center[_ngcontent-%COMP%] {\n  align-items: center;\n}\n.gap-2[_ngcontent-%COMP%] {\n  gap: 8px;\n}\n.gap-3[_ngcontent-%COMP%] {\n  gap: 12px;\n}\n.gap-4[_ngcontent-%COMP%] {\n  gap: 16px;\n}\n.px-4[_ngcontent-%COMP%] {\n  padding-left: 16px;\n  padding-right: 16px;\n}\n.pt-12[_ngcontent-%COMP%] {\n  padding-top: 48px;\n}\n.mb-6[_ngcontent-%COMP%] {\n  margin-bottom: 24px;\n}\n.font-black[_ngcontent-%COMP%] {\n  font-weight: 900;\n}\n.text-2xl[_ngcontent-%COMP%] {\n  font-size: 1.5rem;\n}\n.bg-white\\/80[_ngcontent-%COMP%] {\n  background-color: rgba(255, 255, 255, 0.85);\n}\n.backdrop-blur-md[_ngcontent-%COMP%] {\n  backdrop-filter: blur(12px);\n  -webkit-backdrop-filter: blur(12px);\n}\nion-content[_ngcontent-%COMP%] {\n  --background: var(--bg-color);\n}\n.sticky-header-section[_ngcontent-%COMP%] {\n  position: sticky;\n  top: 0px;\n  z-index: 40;\n  background: #f8fafc;\n  padding-bottom: 10px;\n}\n.custom-search[_ngcontent-%COMP%] {\n  --background: #fff;\n  --box-shadow: 0 4px 15px rgba(0,0,0,0.03);\n  --border-radius: 12px;\n  --placeholder-color: #94a3b8;\n  padding: 0;\n  margin-bottom: 15px;\n}\n.horizontal-scroll-container[_ngcontent-%COMP%] {\n  display: flex;\n  overflow-x: auto;\n  gap: 10px;\n  scrollbar-width: none;\n}\n.horizontal-scroll-container[_ngcontent-%COMP%]::-webkit-scrollbar {\n  display: none;\n}\n.horizontal-scroll-container[_ngcontent-%COMP%]   .category-pill[_ngcontent-%COMP%] {\n  white-space: nowrap;\n  padding: 8px 20px;\n  background: #fff;\n  border-radius: 20px;\n  font-size: 13px;\n  font-weight: 600;\n  color: var(--text-light);\n  border: 1px solid #e2e8f0;\n  transition: all 0.2s;\n  cursor: pointer;\n}\n.horizontal-scroll-container[_ngcontent-%COMP%]   .category-pill.active[_ngcontent-%COMP%] {\n  background: #111;\n  color: #fff;\n  border-color: #111;\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);\n}\n.featured-scroll[_ngcontent-%COMP%] {\n  display: flex;\n  overflow-x: auto;\n  gap: 16px;\n  padding-bottom: 10px;\n  scroll-snap-type: x mandatory;\n  scrollbar-width: none;\n}\n.featured-scroll[_ngcontent-%COMP%]::-webkit-scrollbar {\n  display: none;\n}\n.featured-scroll[_ngcontent-%COMP%]   .featured-card[_ngcontent-%COMP%] {\n  flex: 0 0 85%;\n  height: 200px;\n  border-radius: 24px;\n  position: relative;\n  overflow: hidden;\n  scroll-snap-align: center;\n  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);\n}\n.featured-scroll[_ngcontent-%COMP%]   .featured-card[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n.featured-scroll[_ngcontent-%COMP%]   .featured-card[_ngcontent-%COMP%]   .overlay[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  background:\n    linear-gradient(\n      to top,\n      rgba(0, 0, 0, 0.8),\n      transparent);\n  padding: 20px;\n  color: white;\n}\n.featured-scroll[_ngcontent-%COMP%]   .featured-card[_ngcontent-%COMP%]   .overlay[_ngcontent-%COMP%]   .feat-badge[_ngcontent-%COMP%] {\n  background: var(--primary);\n  font-size: 10px;\n  padding: 4px 8px;\n  border-radius: 6px;\n  text-transform: uppercase;\n  font-weight: 700;\n}\n.featured-scroll[_ngcontent-%COMP%]   .featured-card[_ngcontent-%COMP%]   .overlay[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin: 8px 0 4px;\n  font-size: 18px;\n  font-weight: 700;\n}\n.featured-scroll[_ngcontent-%COMP%]   .featured-card[_ngcontent-%COMP%]   .overlay[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 12px;\n  display: flex;\n  align-items: center;\n  gap: 4px;\n  opacity: 0.9;\n}\n.event-masonry-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: 1fr 1fr;\n  gap: 16px;\n}\n.modern-event-card[_ngcontent-%COMP%] {\n  background: white;\n  border-radius: var(--card-radius);\n  overflow: hidden;\n  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);\n  display: flex;\n  flex-direction: column;\n}\n.modern-event-card[_ngcontent-%COMP%]   .card-image-box[_ngcontent-%COMP%] {\n  position: relative;\n  height: 140px;\n}\n.modern-event-card[_ngcontent-%COMP%]   .card-image-box[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n.modern-event-card[_ngcontent-%COMP%]   .card-image-box[_ngcontent-%COMP%]   .price-tag[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 8px;\n  left: 8px;\n  background: rgba(255, 255, 255, 0.95);\n  -webkit-backdrop-filter: blur(4px);\n  backdrop-filter: blur(4px);\n  padding: 4px 8px;\n  border-radius: 6px;\n  font-size: 11px;\n  font-weight: 800;\n  color: var(--text-dark);\n}\n.modern-event-card[_ngcontent-%COMP%]   .card-image-box[_ngcontent-%COMP%]   .price-tag.free[_ngcontent-%COMP%] {\n  color: #10b981;\n}\n.modern-event-card[_ngcontent-%COMP%]   .card-image-box[_ngcontent-%COMP%]   .fav-btn[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 8px;\n  right: 8px;\n  background: rgba(255, 255, 255, 0.8);\n  border-radius: 50%;\n  width: 28px;\n  height: 28px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  -webkit-backdrop-filter: blur(4px);\n  backdrop-filter: blur(4px);\n  border: none;\n}\n.modern-event-card[_ngcontent-%COMP%]   .card-info[_ngcontent-%COMP%] {\n  padding: 12px;\n  display: flex;\n  gap: 10px;\n}\n.modern-event-card[_ngcontent-%COMP%]   .card-info[_ngcontent-%COMP%]   .date-badge[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  background: #f1f5f9;\n  border-radius: 10px;\n  padding: 6px 8px;\n  height: fit-content;\n  min-width: 45px;\n}\n.modern-event-card[_ngcontent-%COMP%]   .card-info[_ngcontent-%COMP%]   .date-badge[_ngcontent-%COMP%]   .month[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 700;\n  color: #ef4444;\n  text-transform: uppercase;\n}\n.modern-event-card[_ngcontent-%COMP%]   .card-info[_ngcontent-%COMP%]   .date-badge[_ngcontent-%COMP%]   .day[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 800;\n  color: var(--text-dark);\n  line-height: 1;\n}\n.modern-event-card[_ngcontent-%COMP%]   .card-info[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%] {\n  flex: 1;\n}\n.modern-event-card[_ngcontent-%COMP%]   .card-info[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .card-name[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 700;\n  color: var(--text-dark);\n  margin: 0 0 4px;\n  line-height: 1.25;\n}\n.modern-event-card[_ngcontent-%COMP%]   .card-info[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .location[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: var(--text-light);\n  margin: 0;\n  display: flex;\n  align-items: center;\n  gap: 3px;\n}\n.text-truncate-2[_ngcontent-%COMP%] {\n  display: -webkit-box;\n  -webkit-line-clamp: 2;\n  -webkit-box-orient: vertical;\n  overflow: hidden;\n}\n.extended-fab[_ngcontent-%COMP%] {\n  --border-radius: 50px;\n  width: auto;\n  min-width: 140px;\n  height: 48px;\n  text-transform: capitalize;\n  letter-spacing: 0.5px;\n  font-size: 14px;\n}\n/*# sourceMappingURL=events.page.css.map */"] });
var EventsPage = _EventsPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(EventsPage, { className: "EventsPage", filePath: "src/app/pages/events/events.page.ts", lineNumber: 24 });
})();
export {
  EventsPage
};
//# sourceMappingURL=events.page-LQRIBPIY.js.map
