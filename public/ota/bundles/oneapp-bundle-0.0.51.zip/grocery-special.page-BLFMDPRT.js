import {
  ErrorComponent
} from "./chunk-WSTY3NBK.js";
import {
  ProductCardComponent
} from "./chunk-PCADZWYU.js";
import {
  GroceryService
} from "./chunk-UOJDERHI.js";
import {
  addIcons,
  arrowBack,
  arrowBackOutline,
  caretForwardOutline,
  filterOutline,
  searchOutline
} from "./chunk-V2INQVNG.js";
import {
  AuthService
} from "./chunk-EB6T6TPT.js";
import "./chunk-OE5MTPUR.js";
import "./chunk-YJYUHAOC.js";
import "./chunk-XR3JUECC.js";
import {
  IonButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonIcon,
  IonSkeletonText,
  IonTitle,
  IonToolbar
} from "./chunk-CJE2NDTY.js";
import {
  ChangeDetectorRef,
  CommonModule,
  FormsModule,
  NavController,
  NgForOf,
  Router,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵstyleProp,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate
} from "./chunk-Z7XNNJSA.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/pages/grocery-special/grocery-special.page.ts
var _c0 = () => [1, 2, 3, 4];
var _c1 = () => [1, 2, 3, 4, 5, 6];
function GrocerySpecialPage_Conditional_11_ion_skeleton_text_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-skeleton-text", 16);
  }
}
function GrocerySpecialPage_Conditional_11_div_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 17);
    \u0275\u0275element(1, "ion-skeleton-text", 18)(2, "ion-skeleton-text", 19)(3, "ion-skeleton-text", 20);
    \u0275\u0275elementStart(4, "div", 21);
    \u0275\u0275element(5, "ion-skeleton-text", 22)(6, "ion-skeleton-text", 23);
    \u0275\u0275elementEnd()();
  }
}
function GrocerySpecialPage_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div")(1, "div", 10);
    \u0275\u0275element(2, "ion-skeleton-text", 11);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 12);
    \u0275\u0275template(4, GrocerySpecialPage_Conditional_11_ion_skeleton_text_4_Template, 1, 0, "ion-skeleton-text", 13);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 14);
    \u0275\u0275template(6, GrocerySpecialPage_Conditional_11_div_6_Template, 7, 0, "div", 15);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(4);
    \u0275\u0275property("ngForOf", \u0275\u0275pureFunction0(2, _c0));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngForOf", \u0275\u0275pureFunction0(3, _c1));
  }
}
function GrocerySpecialPage_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "app-error", 24);
    \u0275\u0275listener("retry", function GrocerySpecialPage_Conditional_12_Template_app_error_retry_0_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.getProductsByTerm());
    });
    \u0275\u0275elementEnd();
  }
}
function GrocerySpecialPage_Conditional_13_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 25);
    \u0275\u0275element(1, "img", 29);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275property("src", ctx_r1.banner, \u0275\u0275sanitizeUrl);
  }
}
function GrocerySpecialPage_Conditional_13_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 30)(1, "div", 31)(2, "h5");
    \u0275\u0275text(3, "Fresh Picks");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "h2");
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span", 32);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "div", 33);
    \u0275\u0275element(9, "img", 34);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275styleProp("background", ctx_r1.categoryInfo.color);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r1.categoryInfo.name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.categoryInfo.offerText);
    \u0275\u0275advance(2);
    \u0275\u0275property("src", ctx_r1.categoryInfo.bannerImg, \u0275\u0275sanitizeUrl);
  }
}
function GrocerySpecialPage_Conditional_13_app_product_card_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "app-product-card", 35);
    \u0275\u0275listener("increase", function GrocerySpecialPage_Conditional_13_app_product_card_4_Template_app_product_card_increase_0_listener($event) {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.increase($event));
    })("decrease", function GrocerySpecialPage_Conditional_13_app_product_card_4_Template_app_product_card_decrease_0_listener($event) {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.decrease($event));
    })("itemClicked", function GrocerySpecialPage_Conditional_13_app_product_card_4_Template_app_product_card_itemClicked_0_listener($event) {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.goToDetails($event));
    });
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const p_r4 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275property("product", p_r4)("qty", ctx_r1.getQty(p_r4.id));
  }
}
function GrocerySpecialPage_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div");
    \u0275\u0275template(1, GrocerySpecialPage_Conditional_13_Conditional_1_Template, 2, 1, "div", 25)(2, GrocerySpecialPage_Conditional_13_Conditional_2_Template, 10, 5, "div", 26);
    \u0275\u0275elementStart(3, "div", 14);
    \u0275\u0275template(4, GrocerySpecialPage_Conditional_13_app_product_card_4_Template, 1, 2, "app-product-card", 27);
    \u0275\u0275elementEnd();
    \u0275\u0275element(5, "div", 28);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.banner ? 1 : 2);
    \u0275\u0275advance(3);
    \u0275\u0275property("ngForOf", ctx_r1.products);
  }
}
var _GrocerySpecialPage = class _GrocerySpecialPage {
  // [
  //   { id: 1, name: 'Fresh Tomato', weight: '500g', price: 24, oldPrice: 30, discount: 20, img: 'https://cdn-icons-png.flaticon.com/512/1202/1202125.png', qty: 0 },
  //   { id: 2, name: 'Red Onion', weight: '1kg', price: 45, oldPrice: 60, discount: 25, img: 'https://cdn-icons-png.flaticon.com/512/765/765580.png', qty: 2 },
  //   { id: 3, name: 'Potato', weight: '1kg', price: 35, oldPrice: 40, discount: 0, img: 'https://cdn-icons-png.flaticon.com/512/765/765544.png', qty: 0 },
  //   { id: 4, name: 'Broccoli', weight: '1 pc', price: 60, oldPrice: 80, discount: 15, img: 'https://cdn-icons-png.flaticon.com/512/2329/2329905.png', qty: 0 },
  //   { id: 5, name: 'Carrot', weight: '500g', price: 30, oldPrice: 40, discount: 10, img: 'https://cdn-icons-png.flaticon.com/512/2329/2329954.png', qty: 0 },
  //   { id: 6, name: 'Spinach', weight: '1 bunch', price: 15, oldPrice: 20, discount: 0, img: 'https://cdn-icons-png.flaticon.com/512/2329/2329937.png', qty: 1 },
  //   { id: 7, name: 'Capsicum', weight: '500g', price: 40, oldPrice: 50, discount: 0, img: 'https://cdn-icons-png.flaticon.com/512/2329/2329932.png', qty: 0 },
  //   { id: 8, name: 'Cucumber', weight: '500g', price: 18, oldPrice: 25, discount: 5, img: 'https://cdn-icons-png.flaticon.com/512/2329/2329921.png', qty: 0 },
  // ];
  constructor(router, groceryService, authService, cdr, navCtrl) {
    this.router = router;
    this.groceryService = groceryService;
    this.authService = authService;
    this.cdr = cdr;
    this.navCtrl = navCtrl;
    this.categoryInfo = {
      name: "Farm Fresh Veggies",
      color: "#e8f5e9",
      // Light Green Theme
      bannerImg: "https://cdn-icons-png.flaticon.com/512/2909/2909808.png",
      offerText: "Up to 40% OFF"
    };
    this.filters = ["All", "Leafy", "Root", "Organic", "Exotic", "Cut & Peeled"];
    this.selectedFilter = "All";
    this.term = "";
    this.cartItems = [];
    this.title = "";
    this.isLoading = false;
    this.isError = false;
    this.banner = "";
    this.products = [];
    addIcons({ searchOutline, filterOutline, caretForwardOutline, arrowBack, arrowBackOutline });
  }
  ngOnInit() {
    return __async(this, null, function* () {
      var _a, _b;
      const navigation = this.router.getCurrentNavigation();
      if ((_b = (_a = navigation == null ? void 0 : navigation.extras) == null ? void 0 : _a.state) == null ? void 0 : _b["term"]) {
        this.term = navigation.extras.state["term"];
        console.log("term:", this.term);
      }
      this.token = yield this.authService.getToken();
      this.groceryService.cart$.subscribe((items) => {
        console.log("\u{1F6D2} UI Cart Updated:", items);
        this.cartItems = items;
        this.cdr.detectChanges();
      });
      this.getProductsByTerm();
    });
  }
  increase(productId) {
    this.groceryService.increaseQty(productId, this.token).subscribe({
      next: () => console.log("Increase Success"),
      error: (err) => console.error("API Failed", err)
    });
  }
  decrease(productId) {
    var _a;
    (_a = this.groceryService.decreaseQty(productId, this.token)) == null ? void 0 : _a.subscribe({
      next: () => console.log("Decrease Success"),
      error: (err) => console.error("API Failed", err)
    });
  }
  // --- HELPERS ---
  getQty(productId) {
    if (!this.cartItems || this.cartItems.length === 0)
      return 0;
    const item = this.cartItems.find((i) => String(i.productId) === String(productId));
    return item ? item.quantity : 0;
  }
  // Filter Logic
  setFilter(f) {
    this.selectedFilter = f;
  }
  getProductsByTerm() {
    this.isLoading = true;
    this.isError = false;
    this.groceryService.getProductsByTerm(this.term).subscribe({
      next: (response) => {
        console.log("Products by term:", response);
        this.products = response.data.products;
        this.title = response.data.title;
        this.banner = response.data.banner;
        this.cdr.detectChanges();
        this.isLoading = false;
      },
      error: (error) => {
        console.error("Error fetching products by term:", error);
        this.isLoading = false;
        this.isError = true;
      }
    });
  }
  goToDetails(product) {
    this.router.navigate([`/layout/grocery-layout/grocery-item-details/${product == null ? void 0 : product.id}`], {
      state: { productId: product == null ? void 0 : product.id }
    });
  }
  gotoSearch() {
    this.router.navigate(["/layout/grocery-layout/grocery-search"]);
  }
  back() {
    this.navCtrl.back();
  }
};
_GrocerySpecialPage.\u0275fac = function GrocerySpecialPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _GrocerySpecialPage)(\u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(GroceryService), \u0275\u0275directiveInject(AuthService), \u0275\u0275directiveInject(ChangeDetectorRef), \u0275\u0275directiveInject(NavController));
};
_GrocerySpecialPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _GrocerySpecialPage, selectors: [["app-grocery-special"]], decls: 14, vars: 3, consts: [[1, "ion-no-border", "bg-white", "pt-2"], ["slot", "start"], [3, "click"], ["name", "arrow-back-outline", "color", "dark"], [1, "fw-bold", "text-dark"], ["slot", "end"], ["color", "dark", 3, "click"], ["name", "search-outline"], [1, "bg-light", 3, "fullscreen"], ["title", "Failed to Load Products", "subtitle", "Please check your internet connection and try again.", "buttonText", "Retry"], [2, "margin", "16px", "height", "180px", "border-radius", "20px", "overflow", "hidden"], ["animated", "", 2, "width", "100%", "height", "100%", "margin", "0"], [2, "display", "flex", "gap", "10px", "padding", "0 16px", "margin-bottom", "20px", "overflow", "hidden"], ["animated", "", "style", "width: 80px; height: 32px; border-radius: 20px; flex-shrink: 0;", 4, "ngFor", "ngForOf"], [1, "product-grid", "px-3"], ["style", "margin-bottom: 16px;", 4, "ngFor", "ngForOf"], ["animated", "", 2, "width", "80px", "height", "32px", "border-radius", "20px", "flex-shrink", "0"], [2, "margin-bottom", "16px"], ["animated", "", 2, "width", "100%", "height", "150px", "border-radius", "12px"], ["animated", "", 2, "width", "80%", "height", "14px", "margin-top", "10px", "border-radius", "4px"], ["animated", "", 2, "width", "40%", "height", "14px", "margin-top", "5px", "border-radius", "4px"], [2, "display", "flex", "justify-content", "space-between", "align-items", "center", "margin-top", "10px"], ["animated", "", 2, "width", "50px", "height", "20px", "border-radius", "4px"], ["animated", "", 2, "width", "70px", "height", "30px", "border-radius", "6px"], ["title", "Failed to Load Products", "subtitle", "Please check your internet connection and try again.", "buttonText", "Retry", 3, "retry"], [1, "d-flex", "w-100", "justify-content-center", "p-2"], [1, "hero-banner", 3, "background"], [3, "product", "qty", "increase", "decrease", "itemClicked", 4, "ngFor", "ngForOf"], [2, "height", "200px"], ["alt", "", 1, "w-100", "mx-2", 2, "border-radius", "10px", 3, "src"], [1, "hero-banner"], [1, "text-content"], [1, "offer-badge"], [1, "img-content"], [3, "src"], [3, "increase", "decrease", "itemClicked", "product", "qty"]], template: function GrocerySpecialPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar")(2, "ion-buttons", 1)(3, "ion-button", 2);
    \u0275\u0275listener("click", function GrocerySpecialPage_Template_ion_button_click_3_listener() {
      return ctx.back();
    });
    \u0275\u0275element(4, "ion-icon", 3);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "ion-title", 4);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "ion-buttons", 5)(8, "ion-button", 6);
    \u0275\u0275listener("click", function GrocerySpecialPage_Template_ion_button_click_8_listener() {
      return ctx.gotoSearch();
    });
    \u0275\u0275element(9, "ion-icon", 7);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(10, "ion-content", 8);
    \u0275\u0275template(11, GrocerySpecialPage_Conditional_11_Template, 7, 4, "div")(12, GrocerySpecialPage_Conditional_12_Template, 1, 0, "app-error", 9)(13, GrocerySpecialPage_Conditional_13_Template, 6, 2, "div");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(ctx.title);
    \u0275\u0275advance(4);
    \u0275\u0275property("fullscreen", true);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.isLoading ? 11 : ctx.isError ? 12 : 13);
  }
}, dependencies: [IonSkeletonText, IonButton, IonIcon, IonButtons, IonContent, IonHeader, IonTitle, IonToolbar, CommonModule, NgForOf, FormsModule, ProductCardComponent, ErrorComponent], styles: ["\n\n[_nghost-%COMP%] {\n  display: block;\n  width: 100%;\n  height: 100%;\n}\nion-toolbar[_ngcontent-%COMP%] {\n  --background: #fff;\n}\nion-content[_ngcontent-%COMP%] {\n  --background: #f5f7fd;\n}\n.hero-banner[_ngcontent-%COMP%] {\n  margin: 10px 15px;\n  border-radius: 16px;\n  height: 140px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 20px;\n  position: relative;\n  overflow: hidden;\n}\n.hero-banner[_ngcontent-%COMP%]   .text-content[_ngcontent-%COMP%] {\n  z-index: 1;\n}\n.hero-banner[_ngcontent-%COMP%]   .text-content[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 600;\n  text-transform: uppercase;\n  color: #555;\n  margin: 0;\n  opacity: 0.7;\n}\n.hero-banner[_ngcontent-%COMP%]   .text-content[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  font-size: 22px;\n  font-weight: 800;\n  color: #222;\n  margin: 5px 0 10px;\n  line-height: 1.1;\n}\n.hero-banner[_ngcontent-%COMP%]   .text-content[_ngcontent-%COMP%]   .offer-badge[_ngcontent-%COMP%] {\n  background: #3d0374;\n  color: white;\n  padding: 4px 10px;\n  border-radius: 20px;\n  font-size: 11px;\n  font-weight: 700;\n}\n.hero-banner[_ngcontent-%COMP%]   .img-content[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  height: 110px;\n  width: auto;\n  filter: drop-shadow(0 5px 10px rgba(0, 0, 0, 0.1));\n  transform: rotate(10deg);\n}\n.filter-scroll[_ngcontent-%COMP%] {\n  display: flex;\n  overflow-x: auto;\n  padding: 0 15px 15px;\n  gap: 10px;\n}\n.filter-scroll[_ngcontent-%COMP%]::-webkit-scrollbar {\n  display: none;\n}\n.filter-scroll[_ngcontent-%COMP%]   .chip[_ngcontent-%COMP%] {\n  background: #fff;\n  padding: 8px 16px;\n  border-radius: 20px;\n  border: 1px solid #e0e0e0;\n  font-size: 13px;\n  font-weight: 600;\n  color: #555;\n  white-space: nowrap;\n}\n.filter-scroll[_ngcontent-%COMP%]   .chip.active[_ngcontent-%COMP%] {\n  background: #3d0374;\n  background: #222;\n  color: white;\n  border-color: #222;\n}\n.product-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(2, minmax(0, 1fr));\n  gap: 12px;\n  padding-bottom: 20px;\n}\n@media (min-width: 768px) {\n  .product-grid[_ngcontent-%COMP%] {\n    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));\n  }\n}\n.product-grid[_ngcontent-%COMP%]   .product-card[_ngcontent-%COMP%] {\n  background: #fff;\n  border-radius: 16px;\n  padding: 10px;\n  border: 1px solid #f0f0f0;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.02);\n  display: flex;\n  flex-direction: column;\n}\n.product-grid[_ngcontent-%COMP%]   .product-card[_ngcontent-%COMP%]   .img-box[_ngcontent-%COMP%] {\n  height: 100px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  position: relative;\n  margin-bottom: 8px;\n}\n.product-grid[_ngcontent-%COMP%]   .product-card[_ngcontent-%COMP%]   .img-box[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  max-height: 90px;\n  object-fit: contain;\n}\n.product-grid[_ngcontent-%COMP%]   .product-card[_ngcontent-%COMP%]   .img-box[_ngcontent-%COMP%]   .discount-tag[_ngcontent-%COMP%] {\n  position: absolute;\n  top: -5px;\n  left: -5px;\n  background: #5c6bc0;\n  color: white;\n  font-size: 9px;\n  padding: 3px 6px;\n  border-radius: 4px;\n  font-weight: 700;\n}\n.product-grid[_ngcontent-%COMP%]   .product-card[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .time-row[_ngcontent-%COMP%] {\n  background: #f5f5f5;\n  width: fit-content;\n  font-size: 9px;\n  padding: 2px 6px;\n  border-radius: 4px;\n  font-weight: 700;\n  color: #555;\n  margin-bottom: 6px;\n}\n.product-grid[_ngcontent-%COMP%]   .product-card[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .name[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-weight: 600;\n  color: #222;\n  margin-bottom: 2px;\n  line-height: 1.3;\n}\n.product-grid[_ngcontent-%COMP%]   .product-card[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .weight[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #888;\n  font-weight: 500;\n  margin-bottom: 10px;\n}\n.product-grid[_ngcontent-%COMP%]   .product-card[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .price-action[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n.product-grid[_ngcontent-%COMP%]   .product-card[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .price-action[_ngcontent-%COMP%]   .prices[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n.product-grid[_ngcontent-%COMP%]   .product-card[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .price-action[_ngcontent-%COMP%]   .prices[_ngcontent-%COMP%]   .curr[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 700;\n  color: #222;\n}\n.product-grid[_ngcontent-%COMP%]   .product-card[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .price-action[_ngcontent-%COMP%]   .prices[_ngcontent-%COMP%]   .old[_ngcontent-%COMP%] {\n  font-size: 10px;\n  text-decoration: line-through;\n  color: #999;\n}\n.product-grid[_ngcontent-%COMP%]   .product-card[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .price-action[_ngcontent-%COMP%]   .action-btn[_ngcontent-%COMP%]   .add-btn[_ngcontent-%COMP%] {\n  background: #fff;\n  border: 1px solid #a000e2;\n  color: #a000e2;\n  font-size: 12px;\n  font-weight: 800;\n  padding: 5px 15px;\n  border-radius: 6px;\n  text-transform: uppercase;\n  box-shadow: 0 2px 4px rgba(255, 50, 105, 0.1);\n}\n.product-grid[_ngcontent-%COMP%]   .product-card[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .price-action[_ngcontent-%COMP%]   .action-btn[_ngcontent-%COMP%]   .counter[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  background: #a000e2;\n  border-radius: 6px;\n  height: 28px;\n  min-width: 65px;\n  justify-content: space-between;\n  padding: 0 5px;\n  color: white;\n  font-weight: bold;\n  font-size: 16px;\n  box-shadow: 0 2px 4px rgba(255, 50, 105, 0.3);\n}\n.product-grid[_ngcontent-%COMP%]   .product-card[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   .price-action[_ngcontent-%COMP%]   .action-btn[_ngcontent-%COMP%]   .counter[_ngcontent-%COMP%]   .count[_ngcontent-%COMP%] {\n  font-size: 12px;\n}\n.cart-footer[_ngcontent-%COMP%] {\n  padding: 10px 15px 20px;\n  background: transparent;\n  position: absolute;\n  bottom: 0;\n  width: 100%;\n  pointer-events: none;\n}\n.cart-footer[_ngcontent-%COMP%]   .cart-bar[_ngcontent-%COMP%] {\n  pointer-events: auto;\n  background: #3d0374;\n  border-radius: 12px;\n  padding: 12px 16px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  color: white;\n  box-shadow: 0 10px 20px rgba(61, 3, 116, 0.3);\n}\n.cart-footer[_ngcontent-%COMP%]   .cart-bar[_ngcontent-%COMP%]   .cart-info[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  line-height: 1.2;\n}\n.cart-footer[_ngcontent-%COMP%]   .cart-bar[_ngcontent-%COMP%]   .cart-info[_ngcontent-%COMP%]   small[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 700;\n  opacity: 0.8;\n  letter-spacing: 0.5px;\n}\n.cart-footer[_ngcontent-%COMP%]   .cart-bar[_ngcontent-%COMP%]   .cart-info[_ngcontent-%COMP%]   h6[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 16px;\n  font-weight: 700;\n}\n.cart-footer[_ngcontent-%COMP%]   .cart-bar[_ngcontent-%COMP%]   .cart-info[_ngcontent-%COMP%]   .tax[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: 400;\n  opacity: 0.7;\n}\n.cart-footer[_ngcontent-%COMP%]   .cart-bar[_ngcontent-%COMP%]   .view-cart-btn[_ngcontent-%COMP%] {\n  font-weight: 700;\n  font-size: 14px;\n  display: flex;\n  align-items: center;\n  gap: 5px;\n}\n.qty-counter[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  background: #a000e2;\n  border-radius: 6px;\n  height: 28px;\n  box-shadow: 0 2px 5px rgba(255, 50, 105, 0.3);\n}\n.qty-counter[_ngcontent-%COMP%]   .minus[_ngcontent-%COMP%], \n.qty-counter[_ngcontent-%COMP%]   .plus[_ngcontent-%COMP%] {\n  width: 25px;\n  height: 100%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  color: white;\n  font-weight: bold;\n  font-size: 16px;\n}\n.qty-counter[_ngcontent-%COMP%]   .count[_ngcontent-%COMP%] {\n  color: white;\n  font-weight: 700;\n  font-size: 12px;\n  min-width: 15px;\n  text-align: center;\n}\n/*# sourceMappingURL=grocery-special.page.css.map */"] });
var GrocerySpecialPage = _GrocerySpecialPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(GrocerySpecialPage, { className: "GrocerySpecialPage", filePath: "src/app/pages/grocery-special/grocery-special.page.ts", lineNumber: 21 });
})();
export {
  GrocerySpecialPage
};
//# sourceMappingURL=grocery-special.page-BLFMDPRT.js.map
