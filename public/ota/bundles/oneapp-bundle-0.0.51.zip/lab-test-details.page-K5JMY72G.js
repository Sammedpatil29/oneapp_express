import {
  DUMMY_LAB_TESTS
} from "./chunk-GFPPLSVS.js";
import {
  PharmacyCartService
} from "./chunk-SFLHCKYK.js";
import {
  add,
  addIcons,
  arrowBack,
  arrowForward,
  checkmarkCircle,
  chevronForward,
  documentTextOutline,
  flaskOutline,
  homeOutline,
  medkitOutline,
  receiptOutline,
  remove,
  shareSocialOutline,
  shieldCheckmarkOutline,
  sparklesOutline,
  timeOutline,
  waterOutline
} from "./chunk-V2INQVNG.js";
import {
  IonContent,
  IonHeader,
  IonIcon,
  IonToolbar,
  ToastController
} from "./chunk-CJE2NDTY.js";
import {
  ActivatedRoute,
  CommonModule,
  FormsModule,
  NavController,
  Router,
  inject,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIdentity,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2
} from "./chunk-Z7XNNJSA.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async
} from "./chunk-6B6DTIB5.js";

// src/app/pages/lab-test-details/lab-test-details.page.ts
function LabTestDetailsPage_Conditional_12_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 15);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("", ctx_r1.testPackage.discountPercent, "% OFF");
  }
}
function LabTestDetailsPage_Conditional_12_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 18)(1, "span", 64);
    \u0275\u0275text(2, "Recommended for:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 65);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r1.testPackage.recommendedFor);
  }
}
function LabTestDetailsPage_Conditional_12_For_15_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 20);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const tag_r3 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("\u2022 ", tag_r3, "");
  }
}
function LabTestDetailsPage_Conditional_12_Conditional_55_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 66);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "span", 67);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("\u20B9", ctx_r1.testPackage.mrp, "");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("Save \u20B9", ctx_r1.testPackage.mrp - ctx_r1.testPackage.price, "");
  }
}
function LabTestDetailsPage_Conditional_12_Conditional_59_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 68);
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2, "ADDED TO CART");
    \u0275\u0275elementEnd();
  }
}
function LabTestDetailsPage_Conditional_12_Conditional_60_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 69);
    \u0275\u0275elementStart(1, "span");
    \u0275\u0275text(2, "BOOK PACKAGE");
    \u0275\u0275elementEnd();
  }
}
function LabTestDetailsPage_Conditional_12_For_79_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 53)(1, "span", 70);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 71);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const param_r4 = ctx.$implicit;
    const \u0275$index_186_r5 = ctx.$index;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("", \u0275$index_186_r5 + 1, ".");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(param_r4);
  }
}
function LabTestDetailsPage_Conditional_12_Conditional_119_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 81);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("Saved \u20B9", ctx_r1.labSummary.savings, "");
  }
}
function LabTestDetailsPage_Conditional_12_Conditional_119_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "aside", 63)(1, "div", 72);
    \u0275\u0275listener("click", function LabTestDetailsPage_Conditional_12_Conditional_119_Template_div_click_1_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.goToCart());
    });
    \u0275\u0275elementStart(2, "div", 73)(3, "div", 74);
    \u0275\u0275element(4, "ion-icon", 24);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 75)(6, "div", 76)(7, "span", 77);
    \u0275\u0275text(8, "LAB TESTS CART");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "span", 78);
    \u0275\u0275text(10);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(11, "div", 79)(12, "span", 80);
    \u0275\u0275text(13);
    \u0275\u0275elementEnd();
    \u0275\u0275template(14, LabTestDetailsPage_Conditional_12_Conditional_119_Conditional_14_Template, 2, 1, "span", 81);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(15, "div", 82)(16, "button", 83);
    \u0275\u0275listener("click", function LabTestDetailsPage_Conditional_12_Conditional_119_Template_button_click_16_listener($event) {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext(2);
      ctx_r1.goToCart();
      return \u0275\u0275resetView($event.stopPropagation());
    });
    \u0275\u0275elementStart(17, "span");
    \u0275\u0275text(18, "View Cart");
    \u0275\u0275elementEnd();
    \u0275\u0275element(19, "ion-icon", 84);
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(10);
    \u0275\u0275textInterpolate2("", ctx_r1.labSummary.itemCount, " ", ctx_r1.labSummary.itemCount === 1 ? "PACKAGE" : "PACKAGES", "");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r1.labSummary.grandTotal, "");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.labSummary.savings > 0 ? 14 : -1);
  }
}
function LabTestDetailsPage_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "main", 10)(1, "section", 11)(2, "div", 12)(3, "div", 13);
    \u0275\u0275element(4, "ion-icon", 14);
    \u0275\u0275elementStart(5, "span");
    \u0275\u0275text(6, "NABL & ICMR ACCREDITED LAB");
    \u0275\u0275elementEnd()();
    \u0275\u0275template(7, LabTestDetailsPage_Conditional_12_Conditional_7_Template, 2, 1, "span", 15);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "h2", 16);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "p", 17);
    \u0275\u0275text(11);
    \u0275\u0275elementEnd();
    \u0275\u0275template(12, LabTestDetailsPage_Conditional_12_Conditional_12_Template, 5, 1, "div", 18);
    \u0275\u0275elementStart(13, "div", 19);
    \u0275\u0275repeaterCreate(14, LabTestDetailsPage_Conditional_12_For_15_Template, 2, 1, "span", 20, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(16, "section", 21)(17, "div", 22)(18, "div", 23);
    \u0275\u0275element(19, "ion-icon", 24);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "div", 25)(21, "span", 26);
    \u0275\u0275text(22);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(23, "span", 27);
    \u0275\u0275text(24, "Included in Package");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(25, "div", 22)(26, "div", 28);
    \u0275\u0275element(27, "ion-icon", 29);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(28, "div", 25)(29, "span", 26);
    \u0275\u0275text(30);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(31, "span", 27);
    \u0275\u0275text(32, "Preparation");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(33, "div", 22)(34, "div", 30);
    \u0275\u0275element(35, "ion-icon", 31);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(36, "div", 25)(37, "span", 26);
    \u0275\u0275text(38);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(39, "span", 27);
    \u0275\u0275text(40, "Sample Type");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(41, "div", 22)(42, "div", 32);
    \u0275\u0275element(43, "ion-icon", 33);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(44, "div", 25)(45, "span", 26);
    \u0275\u0275text(46);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(47, "span", 27);
    \u0275\u0275text(48, "Report Turnaround");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(49, "section", 34)(50, "div", 35)(51, "div", 36)(52, "div", 37)(53, "span", 38);
    \u0275\u0275text(54);
    \u0275\u0275elementEnd();
    \u0275\u0275template(55, LabTestDetailsPage_Conditional_12_Conditional_55_Template, 4, 2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(56, "span", 39);
    \u0275\u0275text(57, "Free home sample collection on orders > \u20B9499");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(58, "button", 40);
    \u0275\u0275listener("click", function LabTestDetailsPage_Conditional_12_Template_button_click_58_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.toggleBooking());
    });
    \u0275\u0275template(59, LabTestDetailsPage_Conditional_12_Conditional_59_Template, 3, 0)(60, LabTestDetailsPage_Conditional_12_Conditional_60_Template, 3, 0);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(61, "div", 41)(62, "div", 42);
    \u0275\u0275element(63, "ion-icon", 43);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(64, "div", 44)(65, "span", 45);
    \u0275\u0275text(66, "\u{1F3E1} Doorstep Home Sample Pickup");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(67, "span", 46);
    \u0275\u0275text(68, "Strictly hygienic single-use vacutainers & cold-chain preservation");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(69, "section", 47)(70, "div", 48)(71, "h4", 49);
    \u0275\u0275element(72, "ion-icon", 50);
    \u0275\u0275elementStart(73, "span");
    \u0275\u0275text(74);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(75, "p", 51);
    \u0275\u0275text(76, "This diagnostic package examines key biomarkers to evaluate your overall systemic health.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(77, "div", 52);
    \u0275\u0275repeaterCreate(78, LabTestDetailsPage_Conditional_12_For_79_Template, 5, 2, "div", 53, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(80, "section", 47)(81, "h4", 49);
    \u0275\u0275element(82, "ion-icon", 54);
    \u0275\u0275elementStart(83, "span");
    \u0275\u0275text(84, "Preparation & Instructions");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(85, "div", 55)(86, "div", 56)(87, "div", 57);
    \u0275\u0275text(88, "1");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(89, "div", 58)(90, "strong");
    \u0275\u0275text(91, "Fasting Guidelines");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(92, "p");
    \u0275\u0275text(93);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(94, "div", 56)(95, "div", 57);
    \u0275\u0275text(96, "2");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(97, "div", 58)(98, "strong");
    \u0275\u0275text(99, "Certified Phlebotomist Visit");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(100, "p");
    \u0275\u0275text(101, "A trained, vaccinated health specialist visits your home at your selected date and 30-minute time slot.");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(102, "div", 56)(103, "div", 57);
    \u0275\u0275text(104, "3");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(105, "div", 58)(106, "strong");
    \u0275\u0275text(107, "Smart Digital Report Delivery");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(108, "p");
    \u0275\u0275text(109);
    \u0275\u0275elementEnd()()()()();
    \u0275\u0275elementStart(110, "section", 59)(111, "div", 60);
    \u0275\u0275element(112, "ion-icon", 14);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(113, "div", 61)(114, "h5");
    \u0275\u0275text(115, "Certified & Calibrated Equipment");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(116, "p");
    \u0275\u0275text(117, "All blood, serum, and urine samples are tested in NABL, CAP, and ICMR accredited laboratory facilities using automated analyzers with two-tier doctor sign-off.");
    \u0275\u0275elementEnd()()();
    \u0275\u0275element(118, "div", 62);
    \u0275\u0275elementEnd();
    \u0275\u0275template(119, LabTestDetailsPage_Conditional_12_Conditional_119_Template, 20, 4, "aside", 63);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(7);
    \u0275\u0275conditional(ctx_r1.testPackage.discountPercent > 0 ? 7 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.testPackage.name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.testPackage.description);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.testPackage.recommendedFor ? 12 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275repeater(ctx_r1.testPackage.tags);
    \u0275\u0275advance(8);
    \u0275\u0275textInterpolate1("", ctx_r1.testPackage.testCount, " Tests");
    \u0275\u0275advance(8);
    \u0275\u0275textInterpolate(ctx_r1.testPackage.fastingRequirement);
    \u0275\u0275advance(8);
    \u0275\u0275textInterpolate(ctx_r1.testPackage.sampleType);
    \u0275\u0275advance(8);
    \u0275\u0275textInterpolate1("", ctx_r1.testPackage.reportTimeHours, " Hours");
    \u0275\u0275advance(8);
    \u0275\u0275textInterpolate1("\u20B9", ctx_r1.testPackage.price, "");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.testPackage.mrp > ctx_r1.testPackage.price ? 55 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275classProp("booked", ctx_r1.isBooked);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.isBooked ? 59 : 60);
    \u0275\u0275advance(15);
    \u0275\u0275textInterpolate1("Included Tests & Parameters (", ctx_r1.testPackage.parameters.length, ")");
    \u0275\u0275advance(4);
    \u0275\u0275repeater(ctx_r1.testPackage.parameters);
    \u0275\u0275advance(15);
    \u0275\u0275textInterpolate1("", ctx_r1.testPackage.fastingRequirement, ". Plain water is allowed and recommended to keep veins hydrated.");
    \u0275\u0275advance(16);
    \u0275\u0275textInterpolate1("Verified digital reports will be available on the app and WhatsApp within ", ctx_r1.testPackage.reportTimeHours, " hours, reviewed by MD Pathologists.");
    \u0275\u0275advance(9);
    \u0275\u0275classProp("has-cart", ctx_r1.labSummary.itemCount > 0);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.labSummary.itemCount > 0 ? 119 : -1);
  }
}
var _LabTestDetailsPage = class _LabTestDetailsPage {
  constructor() {
    this.route = inject(ActivatedRoute);
    this.router = inject(Router);
    this.navCtrl = inject(NavController);
    this.toastCtrl = inject(ToastController);
    this.cartService = inject(PharmacyCartService);
    this.testPackage = null;
    this.isBooked = false;
    this.labSummary = {
      subtotal: 0,
      totalMrp: 0,
      savings: 0,
      fee: 0,
      grandTotal: 0,
      itemCount: 0
    };
    addIcons({
      arrowBack,
      shareSocialOutline,
      flaskOutline,
      timeOutline,
      receiptOutline,
      waterOutline,
      checkmarkCircle,
      shieldCheckmarkOutline,
      add,
      remove,
      chevronForward,
      arrowForward,
      homeOutline,
      sparklesOutline,
      documentTextOutline,
      medkitOutline
    });
  }
  ngOnInit() {
    const id = this.route.snapshot.paramMap.get("id");
    if (id) {
      this.testPackage = DUMMY_LAB_TESTS.find((t) => t.id === id) || null;
    }
    if (!this.testPackage) {
      this.testPackage = DUMMY_LAB_TESTS[0];
    }
    this.cartSub = this.cartService.labCart$.subscribe(() => {
      if (this.testPackage) {
        this.isBooked = this.cartService.isLabTestInCart(this.testPackage.id);
      }
    });
    this.summarySub = this.cartService.labSummary$.subscribe((summary) => {
      this.labSummary = summary;
    });
  }
  ngOnDestroy() {
    var _a, _b;
    (_a = this.cartSub) == null ? void 0 : _a.unsubscribe();
    (_b = this.summarySub) == null ? void 0 : _b.unsubscribe();
  }
  goBack() {
    this.navCtrl.navigateBack("/layout/pharmacy");
  }
  goToCart() {
    this.router.navigate(["/layout/pharmacy/cart"], {
      queryParams: { type: "lab" }
    });
  }
  toggleBooking() {
    if (!this.testPackage)
      return;
    this.cartService.toggleLabTest(this.testPackage);
  }
  sharePackage() {
    return __async(this, null, function* () {
      if (!this.testPackage)
        return;
      if (navigator.share) {
        try {
          yield navigator.share({
            title: this.testPackage.name,
            text: `Book ${this.testPackage.name} (${this.testPackage.testCount} tests) on Pintu at just \u20B9${this.testPackage.price}! Free home sample pickup.`,
            url: window.location.href
          });
        } catch (e) {
        }
      } else {
        const toast = yield this.toastCtrl.create({
          message: "Link copied to clipboard!",
          duration: 1800,
          position: "bottom",
          color: "dark"
        });
        yield toast.present();
      }
    });
  }
};
_LabTestDetailsPage.\u0275fac = function LabTestDetailsPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _LabTestDetailsPage)();
};
_LabTestDetailsPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _LabTestDetailsPage, selectors: [["app-lab-test-details"]], decls: 13, vars: 1, consts: [[1, "lab-details-header", "ion-no-border"], [1, "lab-details-toolbar"], [1, "header-top-row"], ["type", "button", "aria-label", "Go Back", 1, "btn-nav-back", 3, "click"], ["name", "arrow-back"], [1, "header-center-title"], [1, "header-actions-right"], ["type", "button", "aria-label", "Share", 1, "btn-share-nav", 3, "click"], ["name", "share-social-outline"], [1, "lab-details-content"], [1, "lab-details-container"], [1, "package-hero-card"], [1, "hero-top-badges"], [1, "accreditation-chip"], ["name", "shield-checkmark-outline"], [1, "discount-pill"], [1, "package-name"], [1, "package-description"], [1, "recommended-row"], [1, "tags-pills-row"], [1, "tag-chip"], [1, "highlights-matrix-card"], [1, "highlight-tile"], [1, "tile-icon-box", "blue"], ["name", "flask-outline"], [1, "tile-text"], [1, "tile-val"], [1, "tile-lbl"], [1, "tile-icon-box", "orange"], ["name", "time-outline"], [1, "tile-icon-box", "purple"], ["name", "water-outline"], [1, "tile-icon-box", "green"], ["name", "receipt-outline"], [1, "package-pricing-card"], [1, "pricing-main-row"], [1, "price-col"], [1, "price-line"], [1, "selling-price"], [1, "tax-footnote"], ["type", "button", 1, "btn-book-action", 3, "click"], [1, "pickup-guarantee-strip"], [1, "pickup-icon-box"], ["name", "home-outline"], [1, "pickup-text-col"], [1, "pickup-title"], [1, "pickup-sub"], [1, "info-card"], [1, "section-title-row"], [1, "card-section-title"], ["name", "document-text-outline", 1, "title-icon", "blue"], [1, "section-para"], [1, "parameters-list"], [1, "parameter-item"], ["name", "medkit-outline", 1, "title-icon", "green"], [1, "instructions-steps"], [1, "instruction-step"], [1, "step-num"], [1, "step-content"], [1, "trust-guarantee-card"], [1, "shield-circle"], [1, "trust-text-col"], [1, "bottom-nav-spacer"], ["slot", "fixed", 1, "docked-cart-banner", "lab", "animate__animated", "animate__fadeInUp"], [1, "rec-label"], [1, "rec-val"], [1, "mrp-strike"], [1, "savings-tag"], ["name", "checkmark-circle"], ["name", "add"], [1, "param-number"], [1, "param-title"], ["role", "button", "tabindex", "0", 1, "cart-banner-card", 3, "click"], [1, "banner-left"], [1, "cart-icon-circle", "lab"], [1, "cart-text-col"], [1, "cart-badge-row"], [1, "badge-text", "lab"], [1, "item-count-chip", "lab"], [1, "cart-price-row"], [1, "cart-grand-total"], [1, "cart-savings-chip", "lab"], [1, "banner-actions-right"], ["type", "button", "aria-label", "View Lab Cart", 1, "btn-view-cart", "lab", 3, "click"], ["name", "arrow-forward"]], template: function LabTestDetailsPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar", 1)(2, "div", 2)(3, "button", 3);
    \u0275\u0275listener("click", function LabTestDetailsPage_Template_button_click_3_listener() {
      return ctx.goBack();
    });
    \u0275\u0275element(4, "ion-icon", 4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 5)(6, "h4");
    \u0275\u0275text(7, "Package Details");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "div", 6)(9, "button", 7);
    \u0275\u0275listener("click", function LabTestDetailsPage_Template_button_click_9_listener() {
      return ctx.sharePackage();
    });
    \u0275\u0275element(10, "ion-icon", 8);
    \u0275\u0275elementEnd()()()()();
    \u0275\u0275elementStart(11, "ion-content", 9);
    \u0275\u0275template(12, LabTestDetailsPage_Conditional_12_Template, 120, 19);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance(12);
    \u0275\u0275conditional(ctx.testPackage ? 12 : -1);
  }
}, dependencies: [
  CommonModule,
  FormsModule,
  IonHeader,
  IonToolbar,
  IonContent,
  IonIcon
], styles: ["\n\n[_nghost-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  width: 100%;\n  height: 100%;\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  overflow: hidden;\n}\n.lab-details-header[_ngcontent-%COMP%] {\n  --background: #ffffff;\n  background: #ffffff;\n  border-bottom: 1px solid #f1f5f9;\n  box-shadow: 0 1px 4px rgba(15, 23, 42, 0.04);\n  z-index: 100;\n  padding: 0 !important;\n  margin: 0 !important;\n  --ion-safe-area-top: 0px;\n  flex-shrink: 0;\n}\n.lab-details-header[_ngcontent-%COMP%]   .lab-details-toolbar[_ngcontent-%COMP%] {\n  --background: #ffffff;\n  background: #ffffff;\n  --padding-start: 12px;\n  --padding-end: 12px;\n  --padding-top: env(safe-area-inset-top, 0px);\n  --padding-bottom: 8px;\n  --min-height: 48px;\n  --border-width: 0;\n}\n.lab-details-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  width: 100%;\n}\n.lab-details-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .btn-nav-back[_ngcontent-%COMP%], \n.lab-details-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .btn-share-nav[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 38px;\n  border-radius: 50%;\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n  color: #0f172a;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 20px;\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n.lab-details-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .btn-nav-back[_ngcontent-%COMP%]:active, \n.lab-details-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .btn-share-nav[_ngcontent-%COMP%]:active {\n  background: #e2e8f0;\n  transform: scale(0.95);\n}\n.lab-details-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .header-center-title[_ngcontent-%COMP%] {\n  flex: 1;\n  text-align: center;\n}\n.lab-details-header[_ngcontent-%COMP%]   .header-top-row[_ngcontent-%COMP%]   .header-center-title[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 15px;\n  font-weight: 800;\n  color: #0f172a;\n  letter-spacing: -0.2px;\n}\n.lab-details-content[_ngcontent-%COMP%] {\n  --background: #f8fafc;\n  flex: 1;\n  width: 100%;\n  height: 100%;\n  position: relative;\n}\n.lab-details-container[_ngcontent-%COMP%] {\n  padding: 14px 14px 20px;\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n}\n.package-hero-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 20px;\n  border: 1px solid #e2e8f0;\n  padding: 18px 16px;\n  box-shadow: 0 2px 10px rgba(15, 23, 42, 0.04);\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n}\n.package-hero-card[_ngcontent-%COMP%]   .hero-top-badges[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 8px;\n  flex-wrap: wrap;\n}\n.package-hero-card[_ngcontent-%COMP%]   .hero-top-badges[_ngcontent-%COMP%]   .accreditation-chip[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  background: #f0fdf4;\n  border: 1px solid #bbf7d0;\n  color: #166534;\n  font-size: 10.5px;\n  font-weight: 800;\n  padding: 3px 9px;\n  border-radius: 99px;\n  letter-spacing: 0.3px;\n}\n.package-hero-card[_ngcontent-%COMP%]   .hero-top-badges[_ngcontent-%COMP%]   .accreditation-chip[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 13px;\n  color: #16a34a;\n}\n.package-hero-card[_ngcontent-%COMP%]   .hero-top-badges[_ngcontent-%COMP%]   .discount-pill[_ngcontent-%COMP%] {\n  background: #ef4444;\n  color: #ffffff;\n  font-size: 11px;\n  font-weight: 850;\n  padding: 3px 8px;\n  border-radius: 8px;\n  box-shadow: 0 2px 6px rgba(239, 68, 68, 0.3);\n}\n.package-hero-card[_ngcontent-%COMP%]   .package-name[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 19px;\n  font-weight: 850;\n  color: #0f172a;\n  line-height: 1.25;\n}\n.package-hero-card[_ngcontent-%COMP%]   .package-description[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 12.5px;\n  color: #475569;\n  line-height: 1.5;\n}\n.package-hero-card[_ngcontent-%COMP%]   .recommended-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: baseline;\n  gap: 6px;\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n  border-radius: 10px;\n  padding: 7px 10px;\n  font-size: 11.5px;\n}\n.package-hero-card[_ngcontent-%COMP%]   .recommended-row[_ngcontent-%COMP%]   .rec-label[_ngcontent-%COMP%] {\n  color: #64748b;\n  font-weight: 700;\n  flex-shrink: 0;\n}\n.package-hero-card[_ngcontent-%COMP%]   .recommended-row[_ngcontent-%COMP%]   .rec-val[_ngcontent-%COMP%] {\n  color: #0f172a;\n  font-weight: 650;\n}\n.package-hero-card[_ngcontent-%COMP%]   .tags-pills-row[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 6px;\n}\n.package-hero-card[_ngcontent-%COMP%]   .tags-pills-row[_ngcontent-%COMP%]   .tag-chip[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 700;\n  color: #0284c7;\n  background: #f0f9ff;\n  border: 1px solid #bae6fd;\n  padding: 2.5px 8px;\n  border-radius: 99px;\n}\n.highlights-matrix-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 18px;\n  border: 1px solid #e2e8f0;\n  padding: 14px;\n  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.03);\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 10px;\n}\n.highlights-matrix-card[_ngcontent-%COMP%]   .highlight-tile[_ngcontent-%COMP%] {\n  background: #f8fafc;\n  border: 1px solid #f1f5f9;\n  border-radius: 14px;\n  padding: 10px;\n  display: flex;\n  align-items: center;\n  gap: 10px;\n}\n.highlights-matrix-card[_ngcontent-%COMP%]   .highlight-tile[_ngcontent-%COMP%]   .tile-icon-box[_ngcontent-%COMP%] {\n  width: 36px;\n  height: 36px;\n  border-radius: 10px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 18px;\n  flex-shrink: 0;\n}\n.highlights-matrix-card[_ngcontent-%COMP%]   .highlight-tile[_ngcontent-%COMP%]   .tile-icon-box.blue[_ngcontent-%COMP%] {\n  background: #e0f2fe;\n  color: #0284c7;\n}\n.highlights-matrix-card[_ngcontent-%COMP%]   .highlight-tile[_ngcontent-%COMP%]   .tile-icon-box.orange[_ngcontent-%COMP%] {\n  background: #fef3c7;\n  color: #d97706;\n}\n.highlights-matrix-card[_ngcontent-%COMP%]   .highlight-tile[_ngcontent-%COMP%]   .tile-icon-box.purple[_ngcontent-%COMP%] {\n  background: #f3e8ff;\n  color: #7c3aed;\n}\n.highlights-matrix-card[_ngcontent-%COMP%]   .highlight-tile[_ngcontent-%COMP%]   .tile-icon-box.green[_ngcontent-%COMP%] {\n  background: #dcfce7;\n  color: #16a34a;\n}\n.highlights-matrix-card[_ngcontent-%COMP%]   .highlight-tile[_ngcontent-%COMP%]   .tile-text[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  min-width: 0;\n}\n.highlights-matrix-card[_ngcontent-%COMP%]   .highlight-tile[_ngcontent-%COMP%]   .tile-text[_ngcontent-%COMP%]   .tile-val[_ngcontent-%COMP%] {\n  font-size: 12.5px;\n  font-weight: 800;\n  color: #0f172a;\n  line-height: 1.25;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.highlights-matrix-card[_ngcontent-%COMP%]   .highlight-tile[_ngcontent-%COMP%]   .tile-text[_ngcontent-%COMP%]   .tile-lbl[_ngcontent-%COMP%] {\n  font-size: 10.5px;\n  color: #64748b;\n  font-weight: 600;\n}\n.package-pricing-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 18px;\n  border: 1px solid #e2e8f0;\n  padding: 16px;\n  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.03);\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n}\n.package-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 12px;\n}\n.package-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%]   .price-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n}\n.package-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%]   .price-col[_ngcontent-%COMP%]   .price-line[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: baseline;\n  gap: 8px;\n  flex-wrap: wrap;\n}\n.package-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%]   .price-col[_ngcontent-%COMP%]   .price-line[_ngcontent-%COMP%]   .selling-price[_ngcontent-%COMP%] {\n  font-size: 22px;\n  font-weight: 900;\n  color: #0f172a;\n  letter-spacing: -0.5px;\n}\n.package-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%]   .price-col[_ngcontent-%COMP%]   .price-line[_ngcontent-%COMP%]   .mrp-strike[_ngcontent-%COMP%] {\n  font-size: 13.5px;\n  color: #94a3b8;\n  text-decoration: line-through;\n  font-weight: 600;\n}\n.package-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%]   .price-col[_ngcontent-%COMP%]   .price-line[_ngcontent-%COMP%]   .savings-tag[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 800;\n  background: #f0fdf4;\n  color: #16a34a;\n  padding: 2px 7px;\n  border-radius: 6px;\n}\n.package-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%]   .price-col[_ngcontent-%COMP%]   .tax-footnote[_ngcontent-%COMP%] {\n  font-size: 10.5px;\n  color: #64748b;\n  font-weight: 500;\n}\n.package-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%]   .btn-book-action[_ngcontent-%COMP%] {\n  background: #0284c7;\n  color: #ffffff;\n  border: none;\n  border-radius: 12px;\n  padding: 11px 18px;\n  font-size: 12.5px;\n  font-weight: 850;\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  cursor: pointer;\n  box-shadow: 0 3px 10px rgba(2, 132, 199, 0.3);\n  transition: all 0.15s ease;\n  flex-shrink: 0;\n}\n.package-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%]   .btn-book-action[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 16px;\n}\n.package-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%]   .btn-book-action.booked[_ngcontent-%COMP%] {\n  background: #059669;\n  box-shadow: 0 3px 10px rgba(5, 150, 105, 0.3);\n}\n.package-pricing-card[_ngcontent-%COMP%]   .pricing-main-row[_ngcontent-%COMP%]   .btn-book-action[_ngcontent-%COMP%]:active {\n  transform: scale(0.96);\n}\n.package-pricing-card[_ngcontent-%COMP%]   .pickup-guarantee-strip[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  background: #f0f9ff;\n  border: 1px solid #bae6fd;\n  border-radius: 12px;\n  padding: 9px 12px;\n}\n.package-pricing-card[_ngcontent-%COMP%]   .pickup-guarantee-strip[_ngcontent-%COMP%]   .pickup-icon-box[_ngcontent-%COMP%] {\n  width: 28px;\n  height: 28px;\n  border-radius: 8px;\n  background: #0284c7;\n  color: #ffffff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 16px;\n  flex-shrink: 0;\n}\n.package-pricing-card[_ngcontent-%COMP%]   .pickup-guarantee-strip[_ngcontent-%COMP%]   .pickup-text-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n.package-pricing-card[_ngcontent-%COMP%]   .pickup-guarantee-strip[_ngcontent-%COMP%]   .pickup-text-col[_ngcontent-%COMP%]   .pickup-title[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 800;\n  color: #0369a1;\n}\n.package-pricing-card[_ngcontent-%COMP%]   .pickup-guarantee-strip[_ngcontent-%COMP%]   .pickup-text-col[_ngcontent-%COMP%]   .pickup-sub[_ngcontent-%COMP%] {\n  font-size: 10.5px;\n  color: #0284c7;\n  font-weight: 500;\n}\n.info-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border-radius: 18px;\n  border: 1px solid #e2e8f0;\n  padding: 16px;\n  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.03);\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n}\n.info-card[_ngcontent-%COMP%]   .card-section-title[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 14px;\n  font-weight: 800;\n  color: #0f172a;\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.info-card[_ngcontent-%COMP%]   .card-section-title[_ngcontent-%COMP%]   .title-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n}\n.info-card[_ngcontent-%COMP%]   .card-section-title[_ngcontent-%COMP%]   .title-icon.blue[_ngcontent-%COMP%] {\n  color: #0284c7;\n}\n.info-card[_ngcontent-%COMP%]   .card-section-title[_ngcontent-%COMP%]   .title-icon.green[_ngcontent-%COMP%] {\n  color: #059669;\n}\n.info-card[_ngcontent-%COMP%]   .section-para[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 12px;\n  color: #64748b;\n  line-height: 1.45;\n}\n.info-card[_ngcontent-%COMP%]   .parameters-list[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n  margin-top: 4px;\n}\n.info-card[_ngcontent-%COMP%]   .parameters-list[_ngcontent-%COMP%]   .parameter-item[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-start;\n  gap: 8px;\n  background: #f8fafc;\n  border: 1px solid #f1f5f9;\n  border-radius: 10px;\n  padding: 9px 12px;\n}\n.info-card[_ngcontent-%COMP%]   .parameters-list[_ngcontent-%COMP%]   .parameter-item[_ngcontent-%COMP%]   .param-number[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  font-weight: 800;\n  color: #0284c7;\n  flex-shrink: 0;\n}\n.info-card[_ngcontent-%COMP%]   .parameters-list[_ngcontent-%COMP%]   .parameter-item[_ngcontent-%COMP%]   .param-title[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 650;\n  color: #1e293b;\n  line-height: 1.35;\n}\n.info-card[_ngcontent-%COMP%]   .instructions-steps[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n}\n.info-card[_ngcontent-%COMP%]   .instructions-steps[_ngcontent-%COMP%]   .instruction-step[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-start;\n  gap: 10px;\n}\n.info-card[_ngcontent-%COMP%]   .instructions-steps[_ngcontent-%COMP%]   .instruction-step[_ngcontent-%COMP%]   .step-num[_ngcontent-%COMP%] {\n  width: 24px;\n  height: 24px;\n  border-radius: 50%;\n  background: #ecfdf5;\n  border: 1px solid #a7f3d0;\n  color: #059669;\n  font-size: 11.5px;\n  font-weight: 850;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  flex-shrink: 0;\n  margin-top: 1px;\n}\n.info-card[_ngcontent-%COMP%]   .instructions-steps[_ngcontent-%COMP%]   .instruction-step[_ngcontent-%COMP%]   .step-content[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n}\n.info-card[_ngcontent-%COMP%]   .instructions-steps[_ngcontent-%COMP%]   .instruction-step[_ngcontent-%COMP%]   .step-content[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 800;\n  color: #0f172a;\n}\n.info-card[_ngcontent-%COMP%]   .instructions-steps[_ngcontent-%COMP%]   .instruction-step[_ngcontent-%COMP%]   .step-content[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 11.5px;\n  color: #64748b;\n  line-height: 1.4;\n}\n.trust-guarantee-card[_ngcontent-%COMP%] {\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n  border-radius: 16px;\n  padding: 14px;\n  display: flex;\n  align-items: center;\n  gap: 12px;\n}\n.trust-guarantee-card[_ngcontent-%COMP%]   .shield-circle[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 38px;\n  border-radius: 50%;\n  background: #e0f2fe;\n  color: #0284c7;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 20px;\n  flex-shrink: 0;\n}\n.trust-guarantee-card[_ngcontent-%COMP%]   .trust-text-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n}\n.trust-guarantee-card[_ngcontent-%COMP%]   .trust-text-col[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 12.5px;\n  font-weight: 800;\n  color: #0f172a;\n}\n.trust-guarantee-card[_ngcontent-%COMP%]   .trust-text-col[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 11px;\n  color: #64748b;\n  line-height: 1.35;\n}\n.bottom-nav-spacer[_ngcontent-%COMP%] {\n  height: 24px;\n  width: 100%;\n  transition: height 0.2s ease;\n}\n.bottom-nav-spacer.has-cart[_ngcontent-%COMP%] {\n  height: 110px;\n}\n.docked-cart-banner.lab[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  width: 100%;\n  padding: 8px 14px calc(env(safe-area-inset-bottom, 0px) + 14px);\n  background:\n    linear-gradient(\n      to top,\n      rgb(248, 250, 252) 75%,\n      rgba(248, 250, 252, 0.9) 50%,\n      rgba(248, 250, 252, 0) 100%);\n  z-index: 99;\n  pointer-events: auto;\n  box-sizing: border-box;\n}\n.docked-cart-banner.lab[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #0c4a6e 0%,\n      #082f49 100%);\n  border: 1px solid rgba(56, 189, 248, 0.35);\n  border-radius: 16px;\n  padding: 10px 14px;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 10px;\n  box-shadow: 0 6px 20px rgba(12, 74, 110, 0.35);\n  cursor: pointer;\n  transition: transform 0.15s ease, box-shadow 0.15s ease;\n}\n.docked-cart-banner.lab[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]:active {\n  transform: scale(0.985);\n  box-shadow: 0 3px 12px rgba(12, 74, 110, 0.25);\n}\n.docked-cart-banner.lab[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  min-width: 0;\n  flex: 1;\n}\n.docked-cart-banner.lab[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-icon-circle.lab[_ngcontent-%COMP%] {\n  width: 34px;\n  height: 34px;\n  border-radius: 10px;\n  background: rgba(255, 255, 255, 0.18);\n  color: #ffffff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 18px;\n  flex-shrink: 0;\n}\n.docked-cart-banner.lab[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-text-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  min-width: 0;\n  gap: 2px;\n}\n.docked-cart-banner.lab[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-text-col[_ngcontent-%COMP%]   .cart-badge-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n}\n.docked-cart-banner.lab[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-text-col[_ngcontent-%COMP%]   .cart-badge-row[_ngcontent-%COMP%]   .badge-text.lab[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  font-weight: 850;\n  color: #38bdf8;\n  letter-spacing: 0.5px;\n  text-transform: uppercase;\n}\n.docked-cart-banner.lab[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-text-col[_ngcontent-%COMP%]   .cart-badge-row[_ngcontent-%COMP%]   .item-count-chip.lab[_ngcontent-%COMP%] {\n  font-size: 9px;\n  font-weight: 800;\n  background: rgba(255, 255, 255, 0.2);\n  color: #ffffff;\n  padding: 1px 5px;\n  border-radius: 4px;\n}\n.docked-cart-banner.lab[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-text-col[_ngcontent-%COMP%]   .cart-price-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: baseline;\n  gap: 6px;\n}\n.docked-cart-banner.lab[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-text-col[_ngcontent-%COMP%]   .cart-price-row[_ngcontent-%COMP%]   .cart-grand-total[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 900;\n  color: #ffffff;\n  letter-spacing: -0.2px;\n}\n.docked-cart-banner.lab[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-left[_ngcontent-%COMP%]   .cart-text-col[_ngcontent-%COMP%]   .cart-price-row[_ngcontent-%COMP%]   .cart-savings-chip.lab[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  font-weight: 800;\n  background: rgba(56, 189, 248, 0.25);\n  color: #bae6fd;\n  padding: 1px 5px;\n  border-radius: 4px;\n}\n.docked-cart-banner.lab[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-actions-right[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  flex-shrink: 0;\n}\n.docked-cart-banner.lab[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-actions-right[_ngcontent-%COMP%]   .btn-view-cart.lab[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #0284c7 0%,\n      #0369a1 100%);\n  color: #ffffff;\n  border: none;\n  border-radius: 99px;\n  padding: 8px 16px;\n  font-size: 12.5px;\n  font-weight: 850;\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  box-shadow: 0 3px 12px rgba(2, 132, 199, 0.4);\n  cursor: pointer;\n  transition: all 0.15s ease;\n}\n.docked-cart-banner.lab[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-actions-right[_ngcontent-%COMP%]   .btn-view-cart.lab[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 14px;\n}\n.docked-cart-banner.lab[_ngcontent-%COMP%]   .cart-banner-card[_ngcontent-%COMP%]   .banner-actions-right[_ngcontent-%COMP%]   .btn-view-cart.lab[_ngcontent-%COMP%]:active {\n  transform: scale(0.95);\n}\n/*# sourceMappingURL=lab-test-details.page.css.map */"] });
var LabTestDetailsPage = _LabTestDetailsPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(LabTestDetailsPage, { className: "LabTestDetailsPage", filePath: "src/app/pages/lab-test-details/lab-test-details.page.ts", lineNumber: 50 });
})();
export {
  LabTestDetailsPage
};
//# sourceMappingURL=lab-test-details.page-K5JMY72G.js.map
