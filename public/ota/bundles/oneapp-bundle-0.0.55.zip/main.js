import {
  AdmobService
} from "./chunk-RNU3LUBM.js";
import "./chunk-3YO22OKP.js";
import {
  PlayStoreUpdateService
} from "./chunk-7T6YL63B.js";
import {
  CommonService
} from "./chunk-74TU2SUK.js";
import {
  OtaKit,
  OtaService
} from "./chunk-MSFQCQDI.js";
import {
  AppDialogService
} from "./chunk-W37RSO62.js";
import {
  AuthService
} from "./chunk-EB6T6TPT.js";
import {
  environment
} from "./chunk-YJYUHAOC.js";
import {
  Network
} from "./chunk-TKIKIY3A.js";
import {
  App
} from "./chunk-EBMCUG2R.js";
import "./chunk-OE5MTPUR.js";
import {
  IonApp,
  IonContent,
  IonRouterOutlet,
  provideIonicAngular
} from "./chunk-CJE2NDTY.js";
import {
  CommonModule,
  EventEmitter,
  IonicRouteStrategy,
  Location,
  NavController,
  Platform,
  PreloadAllModules,
  RouteReuseStrategy,
  Router,
  bootstrapApplication,
  inject,
  provideHttpClient,
  provideRouter,
  withPreloading,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵloadQuery,
  ɵɵnamespaceHTML,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵqueryRefresh,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵstyleProp,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵviewQuery
} from "./chunk-Z7XNNJSA.js";
import "./chunk-XR3JUECC.js";
import {
  Capacitor,
  registerPlugin
} from "./chunk-FH4NU4VH.js";
import "./chunk-W5WUSSJZ.js";
import "./chunk-GTFNXAFE.js";
import "./chunk-HHPBBMWP.js";
import "./chunk-JTY7BC2Y.js";
import "./chunk-6NM256MY.js";
import "./chunk-7UGXZ5VH.js";
import "./chunk-KQEJHESJ.js";
import "./chunk-7BX7IMG4.js";
import "./chunk-BKPN4S4N.js";
import "./chunk-PAF2VYD4.js";
import "./chunk-FTXXDWTZ.js";
import "./chunk-52T2EOVQ.js";
import "./chunk-X6PYF5VD.js";
import "./chunk-2HS7YJ5A.js";
import "./chunk-F4BDZKIT.js";
import "./chunk-IB5345WT.js";
import "./chunk-JYOJD2RE.js";
import "./chunk-4IE5DNQS.js";
import "./chunk-L4P3BNFI.js";
import "./chunk-3IXIHDM2.js";
import "./chunk-LWQSMKKU.js";
import "./chunk-ETTZUOMA.js";
import "./chunk-OQQEQ4WG.js";
import "./chunk-DVIDKGFB.js";
import "./chunk-5HAZIVKH.js";
import "./chunk-46OOKGK2.js";
import "./chunk-LHYYZWFK.js";
import "./chunk-4WT7J3YM.js";
import "./chunk-6FFMTLXI.js";
import "./chunk-XIXT7DF6.js";
import "./chunk-CC56LK7W.js";
import "./chunk-K3HSXS64.js";
import {
  __async,
  __spreadProps,
  __spreadValues
} from "./chunk-6B6DTIB5.js";

// src/app/guards/auth.guard.ts
var authGuard = (route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);
  if (authService.hasToken()) {
    return true;
  }
  router.navigate(["/login"], { queryParams: { returnUrl: state.url } });
  return false;
};
var noAuthGuard = (route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);
  if (authService.hasToken()) {
    router.navigate(["/layout/home"]);
    return false;
  }
  return true;
};

// src/app/guards/leave-dedicated-layout.guard.ts
var DEDICATED_LAYOUTS = [
  {
    name: "Pharmacy & Lab Tests",
    urlPrefixes: [
      "/layout/pharmacy",
      "/layout/medicine-details",
      "/layout/lab-test-details",
      "/layout/pharmacy-search",
      "/layout/pharmacy-cart"
    ],
    landingPaths: ["/layout/pharmacy"]
  },
  {
    name: "Properties",
    urlPrefixes: ["/layout/property", "/layout/property-layout"],
    landingPaths: ["/layout/property"]
  },
  {
    name: "Dineout",
    urlPrefixes: ["/layout/dineout", "/layout/dineout-layout"],
    landingPaths: ["/layout/dineout-layout/dineout", "/layout/dineout-layout"]
  },
  {
    name: "Local Events",
    urlPrefixes: ["/layout/events"],
    landingPaths: ["/layout/events"]
  },
  {
    name: "Book a Ride",
    urlPrefixes: ["/layout/rides", "/layout/ride", "/layout/ride-selection-page", "/layout/track-order"],
    landingPaths: ["/layout/rides", "/layout/rides/search"]
  }
];
var isConfirmingExit = false;
var leaveDedicatedLayoutGuard = (component, currentRoute, currentState, nextState) => __async(void 0, null, function* () {
  const dialogService = inject(AppDialogService);
  if (!nextState || !nextState.url) {
    return true;
  }
  const currentUrl = currentState.url;
  const nextUrl = nextState.url;
  const layout = DEDICATED_LAYOUTS.find((l) => l.urlPrefixes.some((prefix) => currentUrl.startsWith(prefix)));
  if (!layout) {
    return true;
  }
  const isStaying = layout.urlPrefixes.some((prefix) => nextUrl.startsWith(prefix));
  if (isStaying) {
    return true;
  }
  const isOnLandingPage = layout.landingPaths.some((lp) => {
    const cleanUrl = currentUrl.split("?")[0].replace(/\/$/, "");
    const cleanLp = lp.replace(/\/$/, "");
    return cleanUrl === cleanLp;
  });
  if (!isOnLandingPage) {
    return true;
  }
  if (isConfirmingExit || dialogService.isAlertOpen) {
    return false;
  }
  isConfirmingExit = true;
  try {
    const confirmed = yield dialogService.showConfirm({
      title: `Leave ${layout.name}?`,
      message: `Are you sure you want to leave ${layout.name} and return to Home?`,
      confirmText: "Leave",
      cancelText: "Stay"
    });
    return confirmed;
  } catch {
    return false;
  } finally {
    isConfirmingExit = false;
  }
});

// src/app/app.routes.ts
var routes = [
  // 1. Authentication
  {
    path: "login",
    loadComponent: () => import("./login.page-NT5PJWVT.js").then((m) => m.LoginPage),
    canActivate: [noAuthGuard]
  },
  {
    path: "offline",
    loadComponent: () => import("./offline.page-74MBVKQB.js").then((m) => m.OfflinePage)
  },
  // 2. Master Layout Container (Protected by AuthGuard)
  {
    path: "layout",
    loadComponent: () => import("./layout.page-GSJGWUJS.js").then((m) => m.LayoutPage),
    canActivate: [authGuard],
    children: [
      {
        path: "",
        redirectTo: "home",
        pathMatch: "full"
      },
      // Primary Tabs
      {
        path: "home",
        loadComponent: () => import("./home.page-XIIAU3X5.js").then((m) => m.HomePage)
      },
      {
        path: "history",
        loadComponent: () => import("./history.page-6YR7PJCL.js").then((m) => m.HistoryPage)
      },
      {
        path: "support",
        loadComponent: () => import("./support.page-7J2DUDWM.js").then((m) => m.SupportPage)
      },
      {
        path: "profile",
        loadComponent: () => import("./profile.page-35RY7ZQD.js").then((m) => m.ProfilePage)
      },
      // Single Location Capture Window for all services
      {
        path: "map",
        loadComponent: () => import("./map.page-WTMF7RYQ.js").then((m) => m.MapPage)
      },
      // Profile Container Sub-routes
      {
        path: "profile-details",
        loadComponent: () => import("./profile-details.page-SHXWJVNP.js").then((m) => m.ProfileDetailsPage)
      },
      {
        path: "address-list",
        loadComponent: () => import("./address-list.page-PYFN25MD.js").then((m) => m.AddressListPage)
      },
      {
        path: "about",
        loadComponent: () => import("./about.page-RNE2TZTJ.js").then((m) => m.AboutPage)
      },
      {
        path: "referral",
        loadComponent: () => import("./referral.page-A2NZ4KHU.js").then((m) => m.ReferralPage)
      },
      {
        path: "pintu-pocket",
        loadComponent: () => import("./pintu-pocket.page-SJISVMLD.js").then((m) => m.PintuPocketPage)
      },
      {
        path: "wallet",
        redirectTo: "pintu-pocket",
        pathMatch: "full"
      },
      // Rides Service Container
      {
        path: "rides",
        canDeactivate: [leaveDedicatedLayoutGuard],
        children: [
          {
            path: "",
            redirectTo: "search",
            pathMatch: "full"
          },
          {
            path: "search",
            loadComponent: () => import("./ride.page-2RN3MFMY.js").then((m) => m.RidePage)
          },
          {
            path: "select",
            loadComponent: () => import("./ride-selection-page.page-XWE5A2CZ.js").then((m) => m.RideSelectionPagePage)
          },
          {
            path: "tracking",
            loadComponent: () => import("./track-order.page-BFRLXZNH.js").then((m) => m.TrackOrderPage)
          }
        ]
      },
      // Grocery Service Container
      {
        path: "grocery",
        loadComponent: () => import("./grocery-layout.page-DJYQ4I63.js").then((m) => m.GroceryLayoutPage),
        children: [
          {
            path: "",
            loadComponent: () => import("./grocery.page-XFA7P4JY.js").then((m) => m.GroceryPage)
          },
          {
            path: "search",
            loadComponent: () => import("./grocery-search.page-4HQKEO3P.js").then((m) => m.GrocerySearchPage)
          },
          {
            path: "categories",
            loadComponent: () => import("./grocery-by-category.page-3RYNE5LZ.js").then((m) => m.GroceryByCategoryPage)
          },
          {
            path: "cart",
            loadComponent: () => import("./cart.page-EPRED7FF.js").then((m) => m.CartPage)
          },
          {
            path: "payment",
            loadComponent: () => import("./payment.page-35DM5C3A.js").then((m) => m.PaymentPage)
          },
          {
            path: "tracking/:id",
            loadComponent: () => import("./grocery-order-details.page-EEI2DYXB.js").then((m) => m.GroceryOrderDetailsPage)
          },
          {
            path: "item/:id",
            loadComponent: () => import("./grocery-item-details.page-XSOYCWUJ.js").then((m) => m.GroceryItemDetailsPage)
          },
          {
            path: "special",
            loadComponent: () => import("./grocery-special.page-PEHJHFH6.js").then((m) => m.GrocerySpecialPage)
          }
        ]
      },
      // Legacy Dineout & Property modules
      {
        path: "dineout-layout",
        loadComponent: () => import("./dineout-layout.page-PEBWXGQC.js").then((m) => m.DineoutLayoutPage),
        canDeactivate: [leaveDedicatedLayoutGuard],
        children: [
          {
            path: "dineout",
            loadComponent: () => import("./dineout.page-LCRZ4S4V.js").then((m) => m.DineoutPage)
          },
          {
            path: "dineout-hotel-details/:id",
            loadComponent: () => import("./dineout-hotel-details.page-N5H6CZF4.js").then((m) => m.DineoutHotelDetailsPage)
          },
          {
            path: "dineout-select-time/:id",
            loadComponent: () => import("./dineout-select-time.page-YN2IVZVJ.js").then((m) => m.DineoutSelectTimePage)
          },
          {
            path: "dineout-track/:id",
            loadComponent: () => import("./dineout-track.page-6WCEHK5Q.js").then((m) => m.DineoutTrackPage)
          },
          {
            path: "dineout-paybill",
            loadComponent: () => import("./dineout-paybill.page-633XC3JB.js").then((m) => m.dineoutPaybillPage)
          },
          {
            path: "",
            redirectTo: "dineout",
            pathMatch: "full"
          }
        ]
      },
      {
        path: "property",
        loadComponent: () => import("./property-layout.page-2KCUAV2M.js").then((m) => m.PropertyLayoutPage),
        canDeactivate: [leaveDedicatedLayoutGuard],
        children: [
          {
            path: "",
            loadComponent: () => import("./property.page-2NMLK6CS.js").then((m) => m.PropertyPage)
          },
          {
            path: "details/:id",
            loadComponent: () => import("./property-details.page-GHN3UH7O.js").then((m) => m.PropertyDetailsPage)
          },
          {
            path: "register",
            loadComponent: () => import("./property-register.page-RWLEHS4J.js").then((m) => m.PropertyRegisterPage)
          }
        ]
      },
      {
        path: "events",
        loadComponent: () => import("./events.page-RGPZPBIZ.js").then((m) => m.EventsPage),
        canDeactivate: [leaveDedicatedLayoutGuard]
      },
      {
        path: "order-details",
        loadComponent: () => import("./order-details.page-AD3PO7FP.js").then((m) => m.OrderDetailsPage)
      },
      // Pharmacy Details Views (Directly in main Layout outlet)
      {
        path: "pharmacy/medicine/:id",
        loadComponent: () => import("./medicine-details.page-D6WU33RU.js").then((m) => m.MedicineDetailsPage)
      },
      {
        path: "pharmacy/test/:id",
        loadComponent: () => import("./lab-test-details.page-FDH7TXSE.js").then((m) => m.LabTestDetailsPage)
      },
      {
        path: "medicine-details/:id",
        loadComponent: () => import("./medicine-details.page-D6WU33RU.js").then((m) => m.MedicineDetailsPage)
      },
      {
        path: "lab-test-details/:id",
        loadComponent: () => import("./lab-test-details.page-FDH7TXSE.js").then((m) => m.LabTestDetailsPage)
      },
      // Pharmacy & Lab Tests Service Container
      {
        path: "pharmacy",
        loadComponent: () => import("./pharmacy-layout.page-EDSYBSRF.js").then((m) => m.PharmacyLayoutPage),
        canDeactivate: [leaveDedicatedLayoutGuard],
        children: [
          {
            path: "",
            loadComponent: () => import("./pharmacy.page-QMI3SPAP.js").then((m) => m.PharmacyPage)
          },
          {
            path: "search",
            loadComponent: () => import("./pharmacy-search.page-MHTEQUTM.js").then((m) => m.PharmacySearchPage)
          },
          {
            path: "cart",
            loadComponent: () => import("./pharmacy-cart.page-6KINNI6Q.js").then((m) => m.PharmacyCartPage)
          },
          {
            path: "medicine/:id",
            loadComponent: () => import("./medicine-details.page-D6WU33RU.js").then((m) => m.MedicineDetailsPage)
          },
          {
            path: "test/:id",
            loadComponent: () => import("./lab-test-details.page-FDH7TXSE.js").then((m) => m.LabTestDetailsPage)
          }
        ]
      },
      // Backward Compatibility Redirect Aliases
      { path: "pharmacy-search", redirectTo: "pharmacy/search", pathMatch: "full" },
      { path: "pharmacy-cart", redirectTo: "pharmacy/cart", pathMatch: "full" },
      { path: "example/home", redirectTo: "home", pathMatch: "full" },
      { path: "example/history", redirectTo: "history", pathMatch: "full" },
      { path: "example/support", redirectTo: "support", pathMatch: "full" },
      { path: "example/profile", redirectTo: "profile", pathMatch: "full" },
      { path: "ride", redirectTo: "rides/search", pathMatch: "full" },
      { path: "ride-selection-page", redirectTo: "rides/select", pathMatch: "full" },
      { path: "track-order", redirectTo: "rides/tracking", pathMatch: "full" },
      { path: "grocery-layout", redirectTo: "grocery", pathMatch: "prefix" },
      { path: "grocery-layout/cart", redirectTo: "grocery/cart", pathMatch: "full" },
      { path: "grocery-layout/grocery-search", redirectTo: "grocery/search", pathMatch: "full" },
      { path: "grocery-layout/grocery-by-category", redirectTo: "grocery/categories", pathMatch: "full" },
      { path: "grocery-layout/grocery-order-details/:id", redirectTo: "grocery/tracking/:id", pathMatch: "full" },
      { path: "grocery-layout/grocery-item-details/:id", redirectTo: "grocery/item/:id", pathMatch: "full" },
      { path: "payment", redirectTo: "grocery/payment", pathMatch: "full" },
      { path: "cart", redirectTo: "grocery/cart", pathMatch: "full" },
      { path: "property-layout", redirectTo: "property", pathMatch: "prefix" }
    ]
  },
  // Default Route
  {
    path: "",
    pathMatch: "full",
    redirectTo: () => {
      const auth = inject(AuthService);
      return auth.hasToken() ? "layout/home" : "login";
    }
  },
  {
    path: "**",
    redirectTo: () => {
      const auth = inject(AuthService);
      return auth.hasToken() ? "layout/home" : "login";
    }
  }
];

// node_modules/@capacitor/screen-orientation/dist/esm/index.js
var ScreenOrientation = registerPlugin("ScreenOrientation", {
  web: () => import("./web-JYHTEAYX.js").then((m) => new m.ScreenOrientationWeb())
});

// node_modules/@capacitor/local-notifications/dist/esm/definitions.js
var Weekday;
(function(Weekday2) {
  Weekday2[Weekday2["Sunday"] = 1] = "Sunday";
  Weekday2[Weekday2["Monday"] = 2] = "Monday";
  Weekday2[Weekday2["Tuesday"] = 3] = "Tuesday";
  Weekday2[Weekday2["Wednesday"] = 4] = "Wednesday";
  Weekday2[Weekday2["Thursday"] = 5] = "Thursday";
  Weekday2[Weekday2["Friday"] = 6] = "Friday";
  Weekday2[Weekday2["Saturday"] = 7] = "Saturday";
})(Weekday || (Weekday = {}));

// node_modules/@capacitor/local-notifications/dist/esm/index.js
var LocalNotifications = registerPlugin("LocalNotifications", {
  web: () => import("./web-WCYHL2TZ.js").then((m) => new m.LocalNotificationsWeb())
});

// node_modules/@capacitor/splash-screen/dist/esm/index.js
var SplashScreen = registerPlugin("SplashScreen", {
  web: () => import("./web-R2JB5DOO.js").then((m) => new m.SplashScreenWeb())
});

// src/app/pages/custom-splash/custom-splash.component.ts
var _forTrack0 = ($index, $item) => $item.title;
function CustomSplashComponent_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "img", 31);
    \u0275\u0275listener("load", function CustomSplashComponent_Conditional_16_Template_img_load_0_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.onImageLoaded());
    })("error", function CustomSplashComponent_Conditional_16_Template_img_error_0_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.onImageError());
    });
    \u0275\u0275elementEnd();
    \u0275\u0275element(1, "div", 32);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275classProp("loaded", ctx_r1.isImageLoaded);
    \u0275\u0275property("src", ctx_r1.activeBanner.imageUrl, \u0275\u0275sanitizeUrl);
  }
}
function CustomSplashComponent_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 13);
    \u0275\u0275element(1, "div", 33)(2, "div", 34)(3, "div", 35)(4, "div", 36);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275attribute("data-theme", ctx_r1.activeBanner.gradientTheme || "violet");
  }
}
function CustomSplashComponent_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 19)(1, "span", 37);
    \u0275\u0275text(2, "\u2728");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r1.activeBanner.discountBadge);
  }
}
function CustomSplashComponent_Conditional_29_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 38)(1, "span", 39);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 40)(4, "span", 41);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span", 42);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const perk_r3 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(perk_r3.icon);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(perk_r3.title);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(perk_r3.subtitle);
  }
}
function CustomSplashComponent_Conditional_29_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 22);
    \u0275\u0275repeaterCreate(1, CustomSplashComponent_Conditional_29_For_2_Template, 8, 3, "div", 38, _forTrack0);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r1.activeBanner.highlights);
  }
}
function CustomSplashComponent_Conditional_30_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 49);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.activeBanner.promoTerms);
  }
}
function CustomSplashComponent_Conditional_30_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 23)(1, "div", 43)(2, "span", 44);
    \u0275\u0275text(3, "COUPON CODE");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "span", 45);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd()();
    \u0275\u0275element(6, "div", 46);
    \u0275\u0275elementStart(7, "div", 47)(8, "span", 48);
    \u0275\u0275text(9, "1-TAP AUTO APPLY");
    \u0275\u0275elementEnd();
    \u0275\u0275template(10, CustomSplashComponent_Conditional_30_Conditional_10_Template, 2, 1, "span", 49);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r1.activeBanner.promoCode);
    \u0275\u0275advance(5);
    \u0275\u0275conditional(ctx_r1.activeBanner.promoTerms ? 10 : -1);
  }
}
var _CustomSplashComponent = class _CustomSplashComponent {
  constructor() {
    this.dismiss = new EventEmitter();
    this.commonService = inject(CommonService);
    this.promotionalCampaigns = [
      {
        id: 1,
        tag: "\u26A1 MEGA SAVINGS FEST",
        headline: "Flat 50% OFF + Instant Delivery",
        subheadline: "Groceries, Fresh Food, Medicines & Daily Rides",
        discountBadge: "UP TO 50% OFF",
        promoCode: "PINTU50",
        promoTerms: "Auto-applied on first 3 orders \u2022 Min order \u20B9149",
        gradientTheme: "violet",
        highlights: [
          { icon: "\u26A1", title: "10-Min Delivery", subtitle: "Doorstep Service" },
          { icon: "\u{1F45B}", title: "\u20B950 Bonus", subtitle: "In Pintu Pocket" },
          { icon: "\u{1F6E1}\uFE0F", title: "100% Genuine", subtitle: "Verified Quality" }
        ]
      },
      {
        id: 2,
        tag: "\u{1F381} WELCOME REWARDS",
        headline: "Get \u20B950 Free In Pintu Pocket",
        subheadline: "Use instantly across Rides, Groceries & Pharmacy",
        discountBadge: "FREE \u20B950 REWARD",
        promoCode: "WELCOME50",
        promoTerms: "Instant wallet cashback \u2022 100% usable on orders",
        gradientTheme: "emerald",
        highlights: [
          { icon: "\u{1F6F5}", title: "Instant Rides", subtitle: "Lowest Auto & Cab" },
          { icon: "\u{1F48A}", title: "Medicines", subtitle: "Flat 15% OFF + Rx" },
          { icon: "\u{1F6D2}", title: "Supermarket", subtitle: "Fresh Produce" }
        ]
      },
      {
        id: 3,
        tag: "\u{1F525} SUPER VALUE DEALS",
        headline: "Free Delivery On All Essentials",
        subheadline: "Exclusive discounts on top restaurants and daily groceries",
        discountBadge: "FREE DELIVERY",
        promoCode: "FREESHIP",
        promoTerms: "Zero delivery fee on all orders today",
        gradientTheme: "amber",
        highlights: [
          { icon: "\u{1F354}", title: "Dineout", subtitle: "Table Booking Deals" },
          { icon: "\u{1F3E0}", title: "Properties", subtitle: "Verified Local Rentals" },
          { icon: "\u{1F39F}\uFE0F", title: "Local Events", subtitle: "Shows & Tickets" }
        ]
      }
    ];
    this.activeBanner = this.promotionalCampaigns[0];
    this.isImageLoaded = false;
    this.hasImageError = false;
    this.loadingProgress = 20;
    this.loadingMessages = [
      "Loading today's best offers...",
      "Checking exclusive discounts...",
      "Preparing your super-app...",
      "Almost ready..."
    ];
    this.currentMessageIndex = 0;
  }
  ngOnInit() {
    this.initCachedBanner();
    this.fetchRemoteSplashBanners();
    this.startLoaderAnimation();
  }
  ngOnDestroy() {
    this.clearTimers();
  }
  clearTimers() {
    if (this.progressInterval)
      clearInterval(this.progressInterval);
    if (this.messageInterval)
      clearInterval(this.messageInterval);
  }
  /**
   * Load cached banner from localStorage if available for immediate zero-latency rendering.
   */
  initCachedBanner() {
    try {
      const cached = localStorage.getItem("pintu_cached_splash_banner");
      if (cached) {
        const parsed = JSON.parse(cached);
        if (parsed && (parsed.imageUrl || parsed.headline)) {
          this.activeBanner = __spreadValues(__spreadValues({}, this.activeBanner), parsed);
          return;
        }
      }
    } catch {
    }
    const dayIndex = (/* @__PURE__ */ new Date()).getDay() % this.promotionalCampaigns.length;
    this.activeBanner = this.promotionalCampaigns[dayIndex];
  }
  /**
   * Fetch active splash promotional banners from the backend API.
   * If a banner with placement 'splash' exists, it takes precedence.
   */
  fetchRemoteSplashBanners() {
    this.commonService.getActiveBanners("splash").subscribe({
      next: (res) => {
        const items = Array.isArray(res) ? res : res == null ? void 0 : res.data;
        if (Array.isArray(items) && items.length > 0) {
          this.applyBackendBanner(items[0]);
        } else {
          this.fetchHometopFallback();
        }
      },
      error: () => {
        this.fetchHometopFallback();
      }
    });
  }
  fetchHometopFallback() {
    this.commonService.getActiveBanners("hometop").subscribe({
      next: (res) => {
        const items = Array.isArray(res) ? res : res == null ? void 0 : res.data;
        if (Array.isArray(items) && items.length > 0) {
          const itemWithImage = items.find((b) => b.img && String(b.img).trim());
          if (itemWithImage) {
            this.applyBackendBanner(itemWithImage);
          }
        }
      },
      error: () => {
      }
    });
  }
  applyBackendBanner(item) {
    if (!item)
      return;
    const img = item.img ? String(item.img).trim() : "";
    const updated = __spreadProps(__spreadValues({}, this.activeBanner), {
      id: item.id || this.activeBanner.id,
      headline: item.title && item.title.trim() ? item.title : this.activeBanner.headline,
      imageUrl: img || this.activeBanner.imageUrl,
      route: item.route || this.activeBanner.route
    });
    this.activeBanner = updated;
    this.hasImageError = false;
    try {
      localStorage.setItem("pintu_cached_splash_banner", JSON.stringify(updated));
    } catch {
    }
  }
  startLoaderAnimation() {
    this.progressInterval = setInterval(() => {
      if (this.loadingProgress < 95) {
        this.loadingProgress += Math.floor(Math.random() * 8) + 4;
        if (this.loadingProgress > 95)
          this.loadingProgress = 95;
      }
    }, 110);
    this.messageInterval = setInterval(() => {
      this.currentMessageIndex = (this.currentMessageIndex + 1) % this.loadingMessages.length;
    }, 650);
  }
  onImageLoaded() {
    this.isImageLoaded = true;
  }
  onImageError() {
    this.hasImageError = true;
  }
  onSkipClick(event) {
    if (event)
      event.stopPropagation();
    this.dismiss.emit();
  }
};
_CustomSplashComponent.\u0275fac = function CustomSplashComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _CustomSplashComponent)();
};
_CustomSplashComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _CustomSplashComponent, selectors: [["app-custom-splash"]], outputs: { dismiss: "dismiss" }, decls: 43, vars: 12, consts: [[1, "splash-screen", 3, "click"], [1, "top-progress-track"], [1, "top-progress-bar"], [1, "top-loader-pill", 3, "click"], [1, "spinner-ring"], [1, "ring-pulse"], [1, "ring-core"], [1, "loader-text-group"], [1, "loader-primary-msg"], ["type", "button", "aria-label", "Skip splash", 1, "skip-btn", 3, "click"], ["width", "12", "height", "12", "viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2.5", "stroke-linecap", "round", "stroke-linejoin", "round"], ["points", "9 18 15 12 9 6"], [1, "banner-media-container"], [1, "banner-artwork-canvas"], [1, "splash-content-container"], [1, "offer-hero-wrapper"], [1, "offer-tag-pill"], [1, "live-pulse-dot"], [1, "tag-text"], [1, "discount-super-badge"], [1, "offer-headline"], [1, "offer-subheadline"], [1, "offer-perks-row"], [1, "promo-voucher-box"], [1, "splash-footer-wrap"], [1, "brand-pill"], [1, "brand-bolt"], [1, "brand-title"], [1, "brand-sep"], [1, "brand-desc"], [1, "tap-hint"], ["alt", "Promotional Offer Banner", 1, "banner-bg-img", 3, "load", "error", "src"], [1, "banner-gradient-overlay"], [1, "ambient-orb", "orb-1"], [1, "ambient-orb", "orb-2"], [1, "ambient-orb", "orb-3"], [1, "ambient-grid-pattern"], [1, "sparkle-icon"], [1, "perk-chip"], [1, "perk-icon"], [1, "perk-text-wrap"], [1, "perk-title"], [1, "perk-subtitle"], [1, "voucher-ticket-left"], [1, "voucher-label"], [1, "voucher-code"], [1, "voucher-divider"], [1, "voucher-ticket-right"], [1, "voucher-badge"], [1, "voucher-terms"]], template: function CustomSplashComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 0);
    \u0275\u0275listener("click", function CustomSplashComponent_Template_div_click_0_listener($event) {
      return ctx.onSkipClick($event);
    });
    \u0275\u0275elementStart(1, "div", 1);
    \u0275\u0275element(2, "div", 2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 3);
    \u0275\u0275listener("click", function CustomSplashComponent_Template_div_click_3_listener($event) {
      return ctx.onSkipClick($event);
    });
    \u0275\u0275elementStart(4, "div", 4);
    \u0275\u0275element(5, "div", 5)(6, "div", 6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "div", 7)(8, "span", 8);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(10, "button", 9);
    \u0275\u0275listener("click", function CustomSplashComponent_Template_button_click_10_listener($event) {
      return ctx.onSkipClick($event);
    });
    \u0275\u0275elementStart(11, "span");
    \u0275\u0275text(12, "Skip");
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(13, "svg", 10);
    \u0275\u0275element(14, "polyline", 11);
    \u0275\u0275elementEnd()()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(15, "div", 12);
    \u0275\u0275template(16, CustomSplashComponent_Conditional_16_Template, 2, 3)(17, CustomSplashComponent_Conditional_17_Template, 5, 1, "div", 13);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "div", 14)(19, "div", 15)(20, "div", 16);
    \u0275\u0275element(21, "span", 17);
    \u0275\u0275elementStart(22, "span", 18);
    \u0275\u0275text(23);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(24, CustomSplashComponent_Conditional_24_Template, 5, 1, "div", 19);
    \u0275\u0275elementStart(25, "h1", 20);
    \u0275\u0275text(26);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(27, "p", 21);
    \u0275\u0275text(28);
    \u0275\u0275elementEnd();
    \u0275\u0275template(29, CustomSplashComponent_Conditional_29_Template, 3, 0, "div", 22)(30, CustomSplashComponent_Conditional_30_Template, 11, 2, "div", 23);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(31, "div", 24)(32, "div", 25)(33, "span", 26);
    \u0275\u0275text(34, "\u26A1");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(35, "span", 27);
    \u0275\u0275text(36, "Pintu");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(37, "span", 28);
    \u0275\u0275text(38, "\u2022");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(39, "span", 29);
    \u0275\u0275text(40, "Fast \u2022 Fresh \u2022 Super-App");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(41, "p", 30);
    \u0275\u0275text(42, "Tap anywhere to proceed");
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("width", ctx.loadingProgress, "%");
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate(ctx.loadingMessages[ctx.currentMessageIndex]);
    \u0275\u0275advance(6);
    \u0275\u0275classProp("has-image", ctx.activeBanner.imageUrl && !ctx.hasImageError);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.activeBanner.imageUrl && !ctx.hasImageError ? 16 : 17);
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate(ctx.activeBanner.tag);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.activeBanner.discountBadge ? 24 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx.activeBanner.headline);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx.activeBanner.subheadline);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.activeBanner.highlights && ctx.activeBanner.highlights.length > 0 ? 29 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.activeBanner.promoCode ? 30 : -1);
  }
}, dependencies: [CommonModule], styles: ['\n\n[_nghost-%COMP%] {\n  display: block;\n  position: fixed;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  z-index: 99999;\n}\n.splash-screen[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  z-index: 99999;\n  display: flex;\n  flex-direction: column;\n  overflow: hidden;\n  background: #0d0620;\n  -webkit-user-select: none;\n  user-select: none;\n  font-family:\n    -apple-system,\n    BlinkMacSystemFont,\n    "Segoe UI",\n    Roboto,\n    "Helvetica Neue",\n    sans-serif;\n  cursor: pointer;\n  -webkit-tap-highlight-color: transparent;\n}\n.top-progress-track[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  height: 3.5px;\n  z-index: 100002;\n  background: rgba(255, 255, 255, 0.08);\n}\n.top-progress-bar[_ngcontent-%COMP%] {\n  height: 100%;\n  background:\n    linear-gradient(\n      90deg,\n      #a000e2 0%,\n      #f43f5e 50%,\n      #fbbf24 100%);\n  box-shadow: 0 0 12px rgba(244, 63, 94, 0.75);\n  transition: width 0.12s cubic-bezier(0.4, 0, 0.2, 1);\n}\n.top-loader-pill[_ngcontent-%COMP%] {\n  position: absolute;\n  top: max(16px, env(safe-area-inset-top) + 12px);\n  left: 50%;\n  transform: translateX(-50%);\n  z-index: 100002;\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  padding: 6px 12px 6px 8px;\n  background: rgba(15, 23, 42, 0.78);\n  backdrop-filter: blur(18px);\n  -webkit-backdrop-filter: blur(18px);\n  border: 1px solid rgba(255, 255, 255, 0.18);\n  border-radius: 999px;\n  box-shadow: 0 12px 30px -4px rgba(0, 0, 0, 0.55), 0 0 16px rgba(160, 0, 226, 0.25);\n  animation: _ngcontent-%COMP%_pillFadeIn 0.4s ease-out;\n  max-width: calc(100vw - 32px);\n}\n.spinner-ring[_ngcontent-%COMP%] {\n  position: relative;\n  width: 22px;\n  height: 22px;\n  flex-shrink: 0;\n}\n.spinner-ring[_ngcontent-%COMP%]   .ring-pulse[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  border-radius: 50%;\n  border: 2px solid rgba(160, 0, 226, 0.3);\n  animation: _ngcontent-%COMP%_ringPulse 1.6s ease-out infinite;\n}\n.spinner-ring[_ngcontent-%COMP%]   .ring-core[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  border-radius: 50%;\n  border: 2.2px solid transparent;\n  border-top-color: #ec4899;\n  border-right-color: #a000e2;\n  animation: _ngcontent-%COMP%_spinCore 0.75s linear infinite;\n}\n.loader-text-group[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  min-width: 0;\n}\n.loader-primary-msg[_ngcontent-%COMP%] {\n  font-size: 12px;\n  font-weight: 600;\n  color: #f8fafc;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  max-width: 180px;\n  letter-spacing: 0.15px;\n}\n.skip-btn[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 3px;\n  padding: 3px 9px;\n  background: rgba(255, 255, 255, 0.14);\n  border: 1px solid rgba(255, 255, 255, 0.25);\n  border-radius: 999px;\n  color: #ffffff;\n  font-size: 11px;\n  font-weight: 700;\n  cursor: pointer;\n  outline: none;\n  transition: all 0.2s ease;\n  flex-shrink: 0;\n}\n.skip-btn[_ngcontent-%COMP%]:active {\n  transform: scale(0.92);\n  background: rgba(255, 255, 255, 0.28);\n}\n.banner-media-container[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  z-index: 1;\n  overflow: hidden;\n  background: #0a0418;\n}\n.banner-bg-img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n  object-position: center top;\n  opacity: 0;\n  transform: scale(1.05);\n  transition: opacity 0.5s ease-out, transform 8s cubic-bezier(0.2, 1, 0.3, 1);\n}\n.banner-bg-img.loaded[_ngcontent-%COMP%] {\n  opacity: 1;\n  transform: scale(1);\n}\n.banner-gradient-overlay[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  background:\n    linear-gradient(\n      to bottom,\n      rgba(10, 4, 24, 0.75) 0%,\n      rgba(10, 4, 24, 0.25) 25%,\n      rgba(10, 4, 24, 0.65) 55%,\n      rgba(10, 4, 24, 0.94) 80%,\n      rgb(10, 4, 24) 100%);\n}\n.banner-artwork-canvas[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  background:\n    radial-gradient(\n      circle at 50% 15%,\n      #2a084e 0%,\n      #130426 55%,\n      #080212 100%);\n  overflow: hidden;\n}\n.banner-artwork-canvas[data-theme=emerald][_ngcontent-%COMP%] {\n  background:\n    radial-gradient(\n      circle at 50% 15%,\n      #064e3b 0%,\n      #06261c 55%,\n      #02120e 100%);\n}\n.banner-artwork-canvas[data-theme=emerald][_ngcontent-%COMP%]   .orb-1[_ngcontent-%COMP%] {\n  background:\n    radial-gradient(\n      circle,\n      rgba(16, 185, 129, 0.45) 0%,\n      transparent 70%);\n}\n.banner-artwork-canvas[data-theme=emerald][_ngcontent-%COMP%]   .orb-2[_ngcontent-%COMP%] {\n  background:\n    radial-gradient(\n      circle,\n      rgba(5, 150, 105, 0.35) 0%,\n      transparent 70%);\n}\n.banner-artwork-canvas[data-theme=amber][_ngcontent-%COMP%] {\n  background:\n    radial-gradient(\n      circle at 50% 15%,\n      #78350f 0%,\n      #301305 55%,\n      #150601 100%);\n}\n.banner-artwork-canvas[data-theme=amber][_ngcontent-%COMP%]   .orb-1[_ngcontent-%COMP%] {\n  background:\n    radial-gradient(\n      circle,\n      rgba(245, 158, 11, 0.45) 0%,\n      transparent 70%);\n}\n.banner-artwork-canvas[data-theme=amber][_ngcontent-%COMP%]   .orb-2[_ngcontent-%COMP%] {\n  background:\n    radial-gradient(\n      circle,\n      rgba(217, 119, 6, 0.35) 0%,\n      transparent 70%);\n}\n.ambient-orb[_ngcontent-%COMP%] {\n  position: absolute;\n  border-radius: 50%;\n  filter: blur(55px);\n  pointer-events: none;\n  opacity: 0.85;\n}\n.ambient-orb.orb-1[_ngcontent-%COMP%] {\n  width: 260px;\n  height: 260px;\n  top: 10%;\n  left: -15%;\n  background:\n    radial-gradient(\n      circle,\n      rgba(160, 0, 226, 0.55) 0%,\n      transparent 70%);\n  animation: _ngcontent-%COMP%_floatOrb 10s ease-in-out infinite alternate;\n}\n.ambient-orb.orb-2[_ngcontent-%COMP%] {\n  width: 320px;\n  height: 320px;\n  bottom: 25%;\n  right: -20%;\n  background:\n    radial-gradient(\n      circle,\n      rgba(236, 72, 153, 0.45) 0%,\n      transparent 70%);\n  animation: _ngcontent-%COMP%_floatOrb 12s ease-in-out infinite alternate-reverse;\n}\n.ambient-orb.orb-3[_ngcontent-%COMP%] {\n  width: 200px;\n  height: 200px;\n  top: 45%;\n  left: 20%;\n  background:\n    radial-gradient(\n      circle,\n      rgba(99, 102, 241, 0.35) 0%,\n      transparent 70%);\n  animation: _ngcontent-%COMP%_floatOrb 8s ease-in-out infinite alternate;\n}\n.ambient-grid-pattern[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  background-image: radial-gradient(rgba(255, 255, 255, 0.07) 1px, transparent 1px);\n  background-size: 24px 24px;\n  opacity: 0.45;\n}\n.splash-content-container[_ngcontent-%COMP%] {\n  position: relative;\n  z-index: 10;\n  display: flex;\n  flex-direction: column;\n  justify-content: flex-end;\n  height: 100%;\n  padding: calc(env(safe-area-inset-top) + 70px) 20px max(20px, env(safe-area-inset-bottom)) 20px;\n  box-sizing: border-box;\n}\n.offer-hero-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  text-align: center;\n  gap: 12px;\n  animation: _ngcontent-%COMP%_slideUpFade 0.6s cubic-bezier(0.16, 1, 0.3, 1);\n}\n.offer-tag-pill[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n  padding: 5px 13px;\n  background: rgba(255, 255, 255, 0.12);\n  border: 1px solid rgba(255, 255, 255, 0.22);\n  border-radius: 999px;\n  backdrop-filter: blur(10px);\n  -webkit-backdrop-filter: blur(10px);\n}\n.offer-tag-pill[_ngcontent-%COMP%]   .live-pulse-dot[_ngcontent-%COMP%] {\n  width: 7px;\n  height: 7px;\n  border-radius: 50%;\n  background: #10b981;\n  box-shadow: 0 0 8px #10b981;\n  animation: _ngcontent-%COMP%_pulseDot 1.4s infinite;\n}\n.offer-tag-pill[_ngcontent-%COMP%]   .tag-text[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: 800;\n  letter-spacing: 0.7px;\n  color: #ffffff;\n  text-transform: uppercase;\n}\n.discount-super-badge[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n  padding: 4px 14px;\n  background:\n    linear-gradient(\n      135deg,\n      #f59e0b 0%,\n      #ec4899 100%);\n  border-radius: 8px;\n  color: #ffffff;\n  font-size: 12px;\n  font-weight: 900;\n  letter-spacing: 0.5px;\n  box-shadow: 0 4px 14px rgba(236, 72, 153, 0.45);\n  text-transform: uppercase;\n}\n.discount-super-badge[_ngcontent-%COMP%]   .sparkle-icon[_ngcontent-%COMP%] {\n  font-size: 13px;\n}\n.offer-headline[_ngcontent-%COMP%] {\n  margin: 2px 0 0;\n  font-size: 26px;\n  line-height: 1.22;\n  font-weight: 900;\n  color: #ffffff;\n  letter-spacing: -0.5px;\n  text-shadow: 0 2px 12px rgba(0, 0, 0, 0.6);\n}\n.offer-subheadline[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 13.5px;\n  line-height: 1.4;\n  color: #cbd5e1;\n  font-weight: 500;\n  max-width: 320px;\n}\n.offer-perks-row[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  gap: 8px;\n  width: 100%;\n  margin-top: 4px;\n}\n.perk-chip[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  padding: 10px 6px;\n  background: rgba(255, 255, 255, 0.08);\n  backdrop-filter: blur(12px);\n  -webkit-backdrop-filter: blur(12px);\n  border: 1px solid rgba(255, 255, 255, 0.12);\n  border-radius: 14px;\n  text-align: center;\n  gap: 3px;\n}\n.perk-chip[_ngcontent-%COMP%]   .perk-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n}\n.perk-chip[_ngcontent-%COMP%]   .perk-text-wrap[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n}\n.perk-chip[_ngcontent-%COMP%]   .perk-title[_ngcontent-%COMP%] {\n  font-size: 11.5px;\n  font-weight: 700;\n  color: #ffffff;\n  line-height: 1.2;\n  white-space: nowrap;\n}\n.perk-chip[_ngcontent-%COMP%]   .perk-subtitle[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  color: #94a3b8;\n  font-weight: 500;\n  line-height: 1.15;\n  white-space: nowrap;\n}\n.promo-voucher-box[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  width: 100%;\n  padding: 10px 14px;\n  background: rgba(255, 255, 255, 0.09);\n  backdrop-filter: blur(16px);\n  -webkit-backdrop-filter: blur(16px);\n  border: 1.5px dashed rgba(255, 255, 255, 0.28);\n  border-radius: 14px;\n  box-sizing: border-box;\n  margin-top: 2px;\n}\n.voucher-ticket-left[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  text-align: left;\n  flex-shrink: 0;\n}\n.voucher-ticket-left[_ngcontent-%COMP%]   .voucher-label[_ngcontent-%COMP%] {\n  font-size: 9px;\n  font-weight: 800;\n  color: #fbbf24;\n  letter-spacing: 0.6px;\n  text-transform: uppercase;\n}\n.voucher-ticket-left[_ngcontent-%COMP%]   .voucher-code[_ngcontent-%COMP%] {\n  font-size: 15px;\n  font-weight: 900;\n  letter-spacing: 1px;\n  color: #ffffff;\n}\n.voucher-divider[_ngcontent-%COMP%] {\n  width: 1px;\n  height: 32px;\n  background: rgba(255, 255, 255, 0.2);\n  margin: 0 12px;\n  flex-shrink: 0;\n}\n.voucher-ticket-right[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  text-align: left;\n  min-width: 0;\n}\n.voucher-ticket-right[_ngcontent-%COMP%]   .voucher-badge[_ngcontent-%COMP%] {\n  font-size: 9.5px;\n  font-weight: 800;\n  color: #34d399;\n  letter-spacing: 0.4px;\n}\n.voucher-ticket-right[_ngcontent-%COMP%]   .voucher-terms[_ngcontent-%COMP%] {\n  font-size: 10px;\n  color: #cbd5e1;\n  line-height: 1.25;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  max-width: 190px;\n}\n.splash-footer-wrap[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  margin-top: 14px;\n  gap: 5px;\n}\n.brand-pill[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 5px;\n  padding: 4px 12px;\n  background: rgba(255, 255, 255, 0.07);\n  border-radius: 999px;\n  color: #e2e8f0;\n  font-size: 11.5px;\n  font-weight: 600;\n}\n.brand-pill[_ngcontent-%COMP%]   .brand-bolt[_ngcontent-%COMP%] {\n  color: #fbbf24;\n}\n.brand-pill[_ngcontent-%COMP%]   .brand-title[_ngcontent-%COMP%] {\n  font-weight: 800;\n  color: #ffffff;\n}\n.brand-pill[_ngcontent-%COMP%]   .brand-sep[_ngcontent-%COMP%] {\n  color: rgba(255, 255, 255, 0.35);\n}\n.brand-pill[_ngcontent-%COMP%]   .brand-desc[_ngcontent-%COMP%] {\n  color: #94a3b8;\n  font-size: 11px;\n}\n.tap-hint[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 10px;\n  color: rgba(255, 255, 255, 0.45);\n  letter-spacing: 0.2px;\n}\n@keyframes _ngcontent-%COMP%_spinCore {\n  0% {\n    transform: rotate(0deg);\n  }\n  100% {\n    transform: rotate(360deg);\n  }\n}\n@keyframes _ngcontent-%COMP%_ringPulse {\n  0% {\n    transform: scale(0.9);\n    opacity: 0.8;\n  }\n  50% {\n    transform: scale(1.15);\n    opacity: 0.2;\n  }\n  100% {\n    transform: scale(0.9);\n    opacity: 0.8;\n  }\n}\n@keyframes _ngcontent-%COMP%_pillFadeIn {\n  from {\n    opacity: 0;\n    transform: translate(-50%, -10px);\n  }\n  to {\n    opacity: 1;\n    transform: translate(-50%, 0);\n  }\n}\n@keyframes _ngcontent-%COMP%_slideUpFade {\n  from {\n    opacity: 0;\n    transform: translateY(22px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n@keyframes _ngcontent-%COMP%_pulseDot {\n  0%, 100% {\n    opacity: 1;\n    transform: scale(1);\n  }\n  50% {\n    opacity: 0.4;\n    transform: scale(0.75);\n  }\n}\n@keyframes _ngcontent-%COMP%_floatOrb {\n  0% {\n    transform: translate(0, 0) scale(1);\n  }\n  100% {\n    transform: translate(25px, -20px) scale(1.1);\n  }\n}\n/*# sourceMappingURL=custom-splash.component.css.map */'] });
var CustomSplashComponent = _CustomSplashComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(CustomSplashComponent, { className: "CustomSplashComponent", filePath: "src/app/pages/custom-splash/custom-splash.component.ts", lineNumber: 32 });
})();

// src/app/app.component.ts
function AppComponent_Conditional_1_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "app-custom-splash", 1);
    \u0275\u0275listener("dismiss", function AppComponent_Conditional_1_Conditional_1_Template_app_custom_splash_dismiss_0_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.onSplashDismiss());
    });
    \u0275\u0275elementEnd();
  }
}
function AppComponent_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-router-outlet");
    \u0275\u0275template(1, AppComponent_Conditional_1_Conditional_1_Template, 1, 0, "app-custom-splash");
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.showSplash ? 1 : -1);
  }
}
function AppComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-content")(1, "div", 2);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(2, "svg", 3);
    \u0275\u0275element(3, "rect", 4)(4, "rect", 5)(5, "rect", 6)(6, "rect", 7)(7, "rect", 8)(8, "circle", 9)(9, "line", 10);
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(10, "h4");
    \u0275\u0275text(11, "No Internet Connection");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "p", 11)(13, "strong");
    \u0275\u0275text(14, "\u0CB8\u0CCD\u0CB5\u0CB2\u0CCD\u0CAA \u0CA8\u0CC6\u0C9F\u0CCD\u0CB5\u0CB0\u0CCD\u0C95\u0CCD \u0C9A\u0CC6\u0C95\u0CCD \u0CAE\u0CBE\u0CA1\u0CCD\u0C95\u0CCB\u0CB0\u0CBF \u0CAC\u0CB0\u0CCD\u0CA4\u0CA4\u0CBF!");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "button", 12);
    \u0275\u0275listener("click", function AppComponent_Conditional_2_Template_button_click_15_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.onRefreshClick());
    });
    \u0275\u0275text(16, "Refresh");
    \u0275\u0275elementEnd()()();
  }
}
function AppComponent_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 0);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.environment.watermark);
  }
}
var _AppComponent = class _AppComponent {
  constructor(platform, navCtrl, location, router, otaService, authService, dialogService, playStoreUpdateService, admobService) {
    this.platform = platform;
    this.navCtrl = navCtrl;
    this.location = location;
    this.router = router;
    this.otaService = otaService;
    this.authService = authService;
    this.dialogService = dialogService;
    this.playStoreUpdateService = playStoreUpdateService;
    this.admobService = admobService;
    this.environment = environment;
    this.isOnline = true;
    this.showSplash = true;
    this.remoteUrl = "https://pintu-teal.vercel.app/";
    this.SERVICE_PAGES = [
      {
        landing: "/layout/pharmacy",
        subPagePrefixes: [
          "/layout/pharmacy/cart",
          "/layout/pharmacy/search",
          "/layout/pharmacy/medicine/",
          "/layout/pharmacy/test/",
          "/layout/medicine-details/",
          "/layout/lab-test-details/",
          "/layout/pharmacy-cart",
          "/layout/pharmacy-search"
        ]
      },
      {
        landing: "/layout/property",
        subPagePrefixes: [
          "/layout/property/details/",
          "/layout/property/register"
        ]
      },
      {
        landing: "/layout/dineout-layout/dineout",
        subPagePrefixes: [
          "/layout/dineout-layout/dineout-hotel-details/",
          "/layout/dineout-layout/dineout-select-time/",
          "/layout/dineout-layout/dineout-track/",
          "/layout/dineout-layout/dineout-paybill"
        ]
      },
      {
        landing: "/layout/rides/search",
        subPagePrefixes: [
          "/layout/rides/select",
          "/layout/rides/tracking"
        ]
      }
    ];
    const startTime = Date.now();
    this.routeBasedOnAuth(startTime);
    setTimeout(() => {
      if (this.showSplash) {
        this.showSplash = false;
      }
    }, 3500);
  }
  onSplashDismiss() {
    this.showSplash = false;
  }
  dismissSplash(startTime) {
    const elapsed = Date.now() - startTime;
    const minDisplay = 2e3;
    const delay = Math.max(0, minDisplay - elapsed);
    setTimeout(() => {
      this.showSplash = false;
    }, delay);
  }
  routeBasedOnAuth(startTime) {
    const targetUrl = this.authService.hasToken() ? "/layout/home" : "/login";
    this.router.navigateByUrl(targetUrl).then(() => {
      this.dismissSplash(startTime);
    }).catch(() => {
      this.dismissSplash(startTime);
    });
  }
  ngOnInit() {
    this.lockOrientation();
    this.listenToNotificationClicks();
    this.initializeBackButtonCustomHandler();
    this.initializeApp();
  }
  initializeApp() {
    return __async(this, null, function* () {
      yield this.platform.ready();
      yield SplashScreen.hide();
      try {
        yield SplashScreen.hide();
      } catch (e) {
      }
      this.otaService.initialize();
      this.playStoreUpdateService.initialize();
      yield this.checkNetworkStatus();
      this.listenToNetwork();
    });
  }
  checkNetworkStatus() {
    return __async(this, null, function* () {
      const status = yield Network.getStatus();
      this.isOnline = status.connected;
      try {
        const status2 = yield Network.getStatus();
        this.isOnline = status2.connected;
        if (!this.isOnline) {
          console.log("\u{1F4F4} Offline on launch \u2192 navigating to offline page");
          this.navCtrl.navigateRoot("/offline");
        }
      } catch (e) {
        console.warn("Network status check error:", e);
      }
    });
  }
  listenToNetwork() {
    Network.addListener("networkStatusChange", (status) => {
      this.isOnline = status.connected;
    });
    try {
      Network.addListener("networkStatusChange", (status) => {
        this.isOnline = status.connected;
        if (!status.connected) {
          console.log("\u{1F4F4} Disconnected from network \u2192 navigating to offline page");
          this.navCtrl.navigateRoot("/offline");
        }
      });
    } catch (e) {
      console.warn("Network listener error:", e);
    }
  }
  onRefreshClick() {
    return __async(this, null, function* () {
      yield this.checkNetworkStatus();
    });
  }
  lockOrientation() {
    return __async(this, null, function* () {
      yield ScreenOrientation.lock({ orientation: "portrait-primary" });
    });
  }
  requestPermission() {
    return __async(this, null, function* () {
      const permission = yield LocalNotifications.requestPermissions();
      if (permission.display !== "granted") {
        console.log("Notification permission not granted");
      }
    });
  }
  listenToNotificationClicks() {
    LocalNotifications.addListener("localNotificationActionPerformed", (notification) => {
      var _a;
      const orderId = (_a = notification.notification.extra) == null ? void 0 : _a.orderId;
      if (orderId) {
        this.navCtrl.navigateRoot("/layout/track-order", {
          state: {
            fromNotification: true,
            orderId
          }
        });
      }
    });
  }
  initializeBackButtonCustomHandler() {
    this.platform.backButton.subscribeWithPriority(10, (processNextHandler) => __async(this, null, function* () {
      const currentUrl = this.router.url;
      console.log("\u{1F4CD} Back Pressed. Current URL:", currentUrl);
      if (this.dialogService.isAlertOpen) {
        this.dialogService.handleCancel();
        return;
      }
      if (currentUrl.includes("/home")) {
        const confirmed = yield this.dialogService.showConfirm({
          title: "Exit Pintu?",
          message: "Are you sure you want to exit the app?",
          confirmText: "Exit App",
          cancelText: "Stay"
        });
        if (confirmed) {
          App.exitApp();
        }
        return;
      }
      const isDirectExitPage = currentUrl.includes("/login") || currentUrl.includes("/offline");
      if (isDirectExitPage) {
        App.exitApp();
        return;
      }
      if (this.isServiceSubPage(currentUrl)) {
        const landingUrl = this.getServiceLandingUrl(currentUrl);
        this.navCtrl.navigateBack(landingUrl);
        return;
      }
      if (this.isServicePage(currentUrl)) {
        this.navCtrl.navigateRoot("/layout/home");
        return;
      }
      if (currentUrl.includes("/layout/history") || currentUrl.includes("/layout/support") || currentUrl.includes("/layout/profile") || currentUrl.includes("/layout/refer")) {
        this.navCtrl.navigateRoot("/layout/home");
        return;
      }
      if (this.routerOutlet && this.routerOutlet.canGoBack()) {
        this.navCtrl.back({ animated: false });
      } else {
        processNextHandler();
      }
    }));
  }
  /** Check if user is on a sub-page within a dedicated service (not the landing page) */
  isServiceSubPage(url) {
    return this.SERVICE_PAGES.some((s) => s.subPagePrefixes.some((prefix) => url.includes(prefix)));
  }
  /** Get the landing page URL for the service the user is currently in */
  getServiceLandingUrl(url) {
    const service = this.SERVICE_PAGES.find((s) => s.subPagePrefixes.some((prefix) => url.includes(prefix)));
    return service ? service.landing : "/layout/home";
  }
  /** Check if user is on any dedicated service page (landing or sub-page) */
  isServicePage(url) {
    return url.includes("/layout/pharmacy") || url.includes("/layout/property") || url.includes("/layout/dineout") || url.includes("/layout/events") || url.includes("/layout/ride");
  }
};
_AppComponent.\u0275fac = function AppComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _AppComponent)(\u0275\u0275directiveInject(Platform), \u0275\u0275directiveInject(NavController), \u0275\u0275directiveInject(Location), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(OtaService), \u0275\u0275directiveInject(AuthService), \u0275\u0275directiveInject(AppDialogService), \u0275\u0275directiveInject(PlayStoreUpdateService), \u0275\u0275directiveInject(AdmobService));
};
_AppComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _AppComponent, selectors: [["app-root"]], viewQuery: function AppComponent_Query(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275viewQuery(IonRouterOutlet, 7);
  }
  if (rf & 2) {
    let _t;
    \u0275\u0275queryRefresh(_t = \u0275\u0275loadQuery()) && (ctx.routerOutlet = _t.first);
  }
}, decls: 4, vars: 2, consts: [[1, "position-fixed", "p-1", 2, "top", "30px", "left", "10px", "border-radius", "10px", "background-color", "rgba(0, 128, 0, 0.342)"], [3, "dismiss"], [1, "no-internet", "h-100", "d-flex", "flex-column", "justify-content-center", "align-items-center"], ["width", "180", "height", "180", "viewBox", "0 0 256 256", "xmlns", "http://www.w3.org/2000/svg"], ["width", "256", "height", "256", "fill", "white"], ["x", "40", "y", "140", "width", "30", "height", "60", "rx", "15", "fill", "#cfd8dc"], ["x", "80", "y", "110", "width", "30", "height", "90", "rx", "15", "fill", "#b0bec5"], ["x", "120", "y", "80", "width", "30", "height", "120", "rx", "15", "fill", "#90a4ae"], ["x", "160", "y", "50", "width", "30", "height", "150", "rx", "15", "fill", "#78909c"], ["cx", "140", "cy", "140", "r", "45", "fill", "none", "stroke", "#e53935", "stroke-width", "14"], ["x1", "110", "y1", "170", "x2", "170", "y2", "110", "stroke", "#e53935", "stroke-width", "14", "stroke-linecap", "round"], [1, "p-0"], [1, "btn", "btn-dark", "btn-sm", 3, "click"]], template: function AppComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-app");
    \u0275\u0275template(1, AppComponent_Conditional_1_Template, 2, 1)(2, AppComponent_Conditional_2_Template, 17, 0, "ion-content")(3, AppComponent_Conditional_3_Template, 2, 1, "div", 0);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.isOnline ? 1 : 2);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(!ctx.environment.production ? 3 : -1);
  }
}, dependencies: [IonApp, IonRouterOutlet, IonContent, CustomSplashComponent], encapsulation: 2 });
var AppComponent = _AppComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(AppComponent, { className: "AppComponent", filePath: "src/app/app.component.ts", lineNumber: 27 });
})();

// src/main.ts
if (Capacitor.isNativePlatform()) {
  OtaKit.notifyAppReady().then(() => {
    console.log("\u2705 [OtaKit] Immediate notifyAppReady confirmed in main.ts");
  }).catch((err) => {
    console.warn("[OtaKit] Early notifyAppReady warning:", err);
  });
}
bootstrapApplication(AppComponent, {
  providers: [
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
    provideIonicAngular(),
    provideHttpClient(),
    provideRouter(routes, withPreloading(PreloadAllModules))
  ]
});
//# sourceMappingURL=main.js.map
